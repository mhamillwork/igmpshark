#!/usr/bin/env perl
# Harness entry. The releasable script is tools/reset_pg.pl.
use FindBin qw($Bin);
exec $^X, "$Bin/../../../tools/reset_pg.pl", @ARGV;
die "reset_pg: exec tools/reset_pg.pl failed: $!\n";
