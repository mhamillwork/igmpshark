#!/usr/bin/env bash
# Added for this catalog: start postgres, reset to the empty snapshot, run
# the stayed-up / exited matrix, reset again. Exit 0 if the catalog ran.
#
# BREAK_PG_MODE selects where postgres comes from:
#   docker   (default when docker is on PATH) postgres:18.6 container
#            `dbshark-break-pg` on 127.0.0.1:55432
#   local    (default otherwise) a cluster owned by pg_local.sh in
#            tests/dbshark/break/.work/pg (needs postgresql-server binaries;
#            this is what the RHEL test image uses)
#   external an already running server described by PG* / DATABASE_URL;
#            the two crash-postgres cases are recorded as harness_error
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/../../.." && pwd)
BREAK=$ROOT/tests/dbshark/break
WS=${WS:-$HOME/wireshark-4.2.6}
export WS_LIB=${WS_LIB:-$WS/build/run}
export DBSHARK=${DBSHARK:-$ROOT/build/run/dbshark}
export BREAK_PG_CONTAINER=${BREAK_PG_CONTAINER:-dbshark-break-pg}
export BREAK_PG_IMAGE=${BREAK_PG_IMAGE:-postgres:18.6}
export PGHOST=${PGHOST:-127.0.0.1}
export PGPORT=${PGPORT:-55432}
export PGUSER=${PGUSER:-postgres}
export PGPASSWORD=${PGPASSWORD:-postgres}
export PGDATABASE=${PGDATABASE:-logshark_break}

if [ -z "${BREAK_PG_MODE:-}" ]; then
    if command -v docker >/dev/null 2>&1; then
        BREAK_PG_MODE=docker
    else
        BREAK_PG_MODE=local
    fi
fi
export BREAK_PG_MODE

if [ ! -x "$DBSHARK" ]; then
    echo "error: $DBSHARK is not executable. Build it with ./tests/dbshark/build/build.sh" >&2
    exit 2
fi
if [ ! -e "$WS_LIB/libwireshark.so" ] && ! ls "$WS_LIB"/libwireshark.so.* >/dev/null 2>&1; then
    echo "error: Wireshark libs not found in $WS_LIB (set WS= or WS_LIB=)" >&2
    exit 2
fi
if ! command -v perl >/dev/null; then
    echo "error: perl is required for reset_pg.pl" >&2
    exit 2
fi
case "$BREAK_PG_MODE" in
    docker)
        if ! command -v docker >/dev/null; then
            echo "error: BREAK_PG_MODE=docker but docker is not on PATH" >&2
            exit 2
        fi
        ;;
    local)
        if ! command -v psql >/dev/null; then
            echo "error: BREAK_PG_MODE=local needs psql and postgresql-server (pg_ctl, initdb)" >&2
            exit 2
        fi
        ;;
    external)
        if ! command -v psql >/dev/null; then
            echo "error: BREAK_PG_MODE=external needs psql on PATH" >&2
            exit 2
        fi
        ;;
    *)
        echo "error: BREAK_PG_MODE must be docker, local or external" >&2
        exit 2
        ;;
esac

export LD_LIBRARY_PATH=$WS_LIB${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}

start_break_pg() {
    docker rm -f "$BREAK_PG_CONTAINER" >/dev/null 2>&1 || true
    docker run -d \
        --name "$BREAK_PG_CONTAINER" \
        -e POSTGRES_USER="$PGUSER" \
        -e POSTGRES_PASSWORD="$PGPASSWORD" \
        -e POSTGRES_DB="$PGDATABASE" \
        -p "$PGPORT:5432" \
        "$BREAK_PG_IMAGE" \
        postgres -c max_locks_per_transaction=64
    for _ in $(seq 1 80); do
        if docker exec "$BREAK_PG_CONTAINER" pg_isready -U "$PGUSER" -d "$PGDATABASE" >/dev/null 2>&1 \
            && docker exec -e PGPASSWORD="$PGPASSWORD" "$BREAK_PG_CONTAINER" \
                psql -U "$PGUSER" -d postgres -tAc 'SELECT 1' 2>/dev/null | grep -q 1; then
            return 0
        fi
        sleep 0.5
    done
    docker logs "$BREAK_PG_CONTAINER" >&2 || true
    echo "error: catalog postgres did not accept connections" >&2
    return 1
}

pg_up() {
    case "$BREAK_PG_MODE" in
        docker)
            if ! docker inspect -f '{{.State.Running}}' "$BREAK_PG_CONTAINER" 2>/dev/null | grep -q true; then
                start_break_pg
            fi
            ;;
        local)
            "$BREAK/pg_local.sh" start
            ;;
        external)
            for _ in $(seq 1 40); do
                if psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d postgres -tAc 'SELECT 1' 2>/dev/null | grep -q 1; then
                    return 0
                fi
                sleep 0.5
            done
            echo "error: external postgres $PGHOST:$PGPORT not reachable" >&2
            return 1
            ;;
    esac
}

echo "catalog postgres: mode=$BREAK_PG_MODE host=$PGHOST port=$PGPORT db=$PGDATABASE"
pg_up
perl "$BREAK/reset_pg.pl" --reset || { pg_up && perl "$BREAK/reset_pg.pl" --reset; }

# RHEL 8's python3 is 3.6; pick the newest interpreter that is >= 3.9.
if [ -z "${PYTHON:-}" ]; then
    PYTHON=python3
    for p in python3.13 python3.12 python3.11 python3.10 python3.9 python3; do
        if command -v "$p" >/dev/null 2>&1 \
            && "$p" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
            PYTHON=$p
            break
        fi
    done
fi
if ! "$PYTHON" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
    echo "error: catalog needs Python >= 3.9 ($PYTHON is $("$PYTHON" --version 2>&1)); set PYTHON=" >&2
    exit 2
fi

set +e
"$PYTHON" "$BREAK/catalog.py"
rc=$?
set -e

pg_up >/dev/null 2>&1 || true
perl "$BREAK/reset_pg.pl" --reset || true

if [ "${BREAK_KEEP_PG:-}" != "1" ]; then
    case "$BREAK_PG_MODE" in
        docker) docker rm -f "$BREAK_PG_CONTAINER" >/dev/null 2>&1 || true ;;
        local) "$BREAK/pg_local.sh" stop >/dev/null 2>&1 || true ;;
    esac
fi

REPORT=${BREAK_REPORT:-$BREAK/report.json}
if [ "$rc" -eq 0 ]; then
    echo "catalog finished; matrix in $REPORT"
    exit 0
fi
echo "catalog harness failed rc=$rc" >&2
exit "$rc"
