# Dbshark durability catalog

This is a **gap list**, not a green-CI suite. The later goal is that dbshark
never exits. These cases plant production mishaps against **today's**
`src/dbshark.c` (do not change dbshark here) and record whether the process
stayed up or died.

The two-node race gate stays in [`tests/dbshark/compose/`](../compose/).
This tree covers messy mixed-protocol bursts, first-message COPY
savepoints, and **up to three** concurrent nodes.

## Run

From the repo root, with `build/run/dbshark` built:

```bash
./tests/dbshark/break/run.sh
```

`run.sh` starts `postgres:18.6` as `dbshark-break-pg` on `127.0.0.1:55432`
(when docker is on PATH), calls [`reset_pg.pl`](reset_pg.pl) to the
empty-catalog snapshot, runs every case, resets again, and removes the
container. Without docker, or with `BREAK_PG_MODE=local`, it runs its own
cluster from the local `postgresql-server` binaries via
[`pg_local.sh`](pg_local.sh) in `.work/pg` (port 55432); the crash cases
SIGKILL that postmaster. `BREAK_PG_MODE=external` uses the server in
`PG*`/`DATABASE_URL` and records the two crash cases as `harness_error`.
This is how the catalog runs inside the RHEL images
(`tests/dbshark/run-rhel.sh`). The harness exits **0
if it ran**. Case exits are findings.

Optional:

```bash
BREAK_FILTER='first_' ./tests/dbshark/break/run.sh
BREAK_FAMILY=nodes,firstmsg ./tests/dbshark/break/run.sh
SKIP_LIVE=1 ./tests/dbshark/break/run.sh
BREAK_KEEP_PG=1 ./tests/dbshark/break/run.sh   # leave postgres up
BREAK_PG_MODE=local ./tests/dbshark/break/run.sh   # no docker: pg_ctl cluster in .work/pg
BREAK_REPORT=/tmp/matrix.json ./tests/dbshark/break/run.sh
```

Live cases need `cap_net_raw` on `build/run/dbshark` (`getcap`), or a
root process that already holds it (the container run). Without it they
are recorded as `harness_error` / skipped.

## How to read the matrix

[`report.json`](report.json) after a pass:

| outcome | meaning |
|---|---|
| `stayed_up` | reached a normal end or SIGTERM drain; no fatal ingest ERROR |
| `exited` | dbshark chose to stop. **This is a finding**, even if the exit looks correct today |
| `crashed` | signal, abort, timeout with no summary |
| `harness_error` | we failed to set the trap (or skipped live) |

`stop_site` names the path in `dbshark.c` the case aimed at.
`error_needles` are log fragments (`postgres copy savepoint`,
`unsupported jsonb version`, `dropping uncommitted rows`, …).
`findings` are row-level gaps the process can survive: an unlogged
ingest that committed nothing, unlogged rows that survived a Postgres
`SIGKILL`, logged rows that did not, a three-node count that does
not match one node times three, `--unlogged` that did not double an
existing logged heap, a later default node that wrote into an
unlogged heap, or a process that stayed up and dropped the batch
after a Postgres error (`dropping rows`). `persistence` is `p`
(logged) or `u` (unlogged) heap counts. `rows_after_crash` is the
count after an unclean Postgres restart. `log_tail` is kept when a
case has needles, findings, or zero rows. Concurrent `--unlogged` /
default / `--packet-local` is order-dependent;
`nodes_unlogged_heap_then_others` and `life_logged_then_unlogged`
pin the two orders.

## Stable Postgres

[`tools/reset_pg.pl`](../../../tools/reset_pg.pl) empties the database you
name. The harness calls it through [`reset_pg.pl`](reset_pg.pl).

```bash
export PGHOST=127.0.0.1 PGPORT=5432
export PGUSER=... PGPASSWORD=... PGDATABASE=...
# or DATABASE_URL=postgresql://user:pass@host:5432/dbname

perl tools/reset_pg.pl --check
perl tools/reset_pg.pl --reset
```

`--reset` replaces that database when it can, and otherwise drops the
objects inside it. `--check` asserts UTF-8, empty `public`, default
`search_path`, and `statement_timeout` / `lock_timeout` /
`idle_in_transaction_session_timeout` at 0.

## Traffic

Default pcaps are **messy**: DIS (full corpus), DNS, NTP, syslog, CoAP,
garbage UDP, TCP SYN, truncations, VLAN, IPv6, shuffled. Cases pass
`-p dis -p dns -p ntp -p syslog -p coap` unless they are about a missing
`-p`. Production NICs do not deliver one protocol in order.
