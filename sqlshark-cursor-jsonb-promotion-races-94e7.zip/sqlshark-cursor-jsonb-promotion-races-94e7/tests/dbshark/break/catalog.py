#!/usr/bin/env python3
"""Added for this catalog: run every mishap, score stayed_up vs exited.

This is not a pass/fail suite. dbshark exiting (even "correctly") is a
durability finding. The harness exits 0 when it managed to run cases.
Non-zero only if Docker / the binary never started.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import traceback
from dataclasses import dataclass
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from cases import CASES, ProcResult  # noqa: E402
import cases.firstmsg  # noqa: E402,F401
import cases.lifecycle  # noqa: E402,F401
import cases.live  # noqa: E402,F401
import cases.nodes  # noqa: E402,F401
import cases.packets  # noqa: E402,F401
import cases.pg  # noqa: E402,F401

MIXED_P = ["-p", "dis", "-p", "dns", "-p", "ntp", "-p", "syslog", "-p", "coap"]

# Added for this catalog: strings that mean ingest_ok hit 0 or connect died.
ERROR_NEEDLES = (
    "postgres copy savepoint",
    "postgres ddl savepoint",
    "unsupported jsonb version",
    "invalid packet lengths",
    "SAVEPOINT can only be used",
    "current transaction is aborted",
    "is not a permanent logged table",
    "unknown protocol filter",
    "too many -p PROTO",
    "postgres copy start",
    "postgres copy (",
    "postgres ddl:",
    "postgres:",
    "connect:",
    "rolling back current transaction",
    "create table",
    "select target schema",
    "wtap_open_offline",
    "wtap_read",
    "incompatible column",
    # A seal gave up. The process stays up and the rows are gone.
    "dropping uncommitted rows",
    "dropping row on",
    "dropping rows on",
    # Rows that are on disk instead of in the database (exit status 3).
    "spilled ",
    "quarantined",
    "they are lost",
)

REPORT_PATH = Path(os.environ.get("BREAK_REPORT", str(HERE / "report.json")))
PG_LOCAL = HERE / "pg_local.sh"


@dataclass
class Harness:
    """Added for this catalog: one Postgres, isolated DBs, classify outcomes."""

    work: Path
    dbshark: Path
    ws_lib: Path
    pghost: str
    pgport: str
    pguser: str
    pgpassword: str
    container: str
    # docker: postgres is the container `container` (docker exec/kill/start).
    # local: pg_local.sh owns a cluster in BREAK_PG_DATA (no docker needed).
    # external: an already-running server; crash cases become harness_error.
    pg_mode: str = "docker"
    current_db: str = "logshark_break"
    skip_live: bool = False
    has_cap: bool = False

    def conninfo(self, db: str | None = None) -> str:
        db = db or self.current_db
        return (
            f"host={self.pghost} port={self.pgport} user={self.pguser} "
            f"password={self.pgpassword} dbname={db}"
        )

    def env(self, extra: dict | None = None) -> dict:
        e = os.environ.copy()
        e["PGHOST"] = self.pghost
        e["PGPORT"] = self.pgport
        e["PGUSER"] = self.pguser
        e["PGPASSWORD"] = self.pgpassword
        e["PGDATABASE"] = self.current_db
        e["LD_LIBRARY_PATH"] = str(self.ws_lib) + (
            os.pathsep + e["LD_LIBRARY_PATH"] if e.get("LD_LIBRARY_PATH") else ""
        )
        cfg = HERE.parents[2] / "ws-config"
        if cfg.is_dir():
            e["WIRESHARK_CONFIG_DIR"] = str(cfg)
        # Spill files are per node and per database; keep the catalog's
        # out of /var/tmp so a run leaves nothing behind on the host.
        e.setdefault("DBSHARK_SPILL_DIR", str(self.work / "spill"))
        if extra:
            e.update(extra)
        return e

    def _container_running(self) -> bool:
        if self.pg_mode != "docker" or not shutil.which("docker"):
            return False
        running = subprocess.run(
            ["docker", "inspect", "-f", "{{.State.Running}}", self.container],
            capture_output=True,
            text=True,
        )
        return running.returncode == 0 and running.stdout.strip() == "true"

    def pg_start(self) -> None:
        """Bring postgres back after a crash (or make sure it is up)."""
        if self.pg_mode == "docker":
            subprocess.run(["docker", "start", self.container], capture_output=True)
        elif self.pg_mode == "local":
            subprocess.run(
                [str(PG_LOCAL), "start"], env=self.env(), capture_output=True, text=True
            )
        # external: nothing we can do; ensure_pg waits.

    def pg_crash(self) -> None:
        """Unclean postgres stop: SIGKILL, no checkpoint, no shutdown record."""
        if self.pg_mode == "docker":
            subprocess.run(
                ["docker", "kill", "--signal", "KILL", self.container], capture_output=True
            )
        elif self.pg_mode == "local":
            r = subprocess.run(
                [str(PG_LOCAL), "crash"], env=self.env(), capture_output=True, text=True
            )
            if r.returncode != 0:
                raise RuntimeError(f"pg_local.sh crash failed: {(r.stderr or r.stdout).strip()}")
        else:
            raise RuntimeError("BREAK_PG_MODE=external: cannot crash a server we do not own")

    def _psql_argv(self, db: str) -> list[str]:
        # Added for this catalog: talk to the catalog container's psql.
        # Host psql without -h hits /var/run/postgresql and a different cluster.
        if self._container_running():
            return [
                "docker",
                "exec",
                "-e",
                f"PGPASSWORD={self.pgpassword}",
                # Database defaults (statement_timeout=1ms) must not cancel
                # the harness's own counts. dbshark's session is unchanged.
                "-e",
                "PGOPTIONS=-c statement_timeout=0",
                self.container,
                "psql",
                "-U",
                self.pguser,
                "-d",
                db,
                "-X",
                "-A",
                "-t",
                "-v",
                "ON_ERROR_STOP=1",
            ]
        if shutil.which("psql"):
            return [
                "psql",
                "-h",
                self.pghost,
                "-p",
                self.pgport,
                "-U",
                self.pguser,
                "-d",
                db,
                "-X",
                "-A",
                "-t",
                "-v",
                "ON_ERROR_STOP=1",
            ]
        raise RuntimeError("no docker catalog postgres and no host psql")

    def psql(self, sql: str, db: str | None = None) -> str:
        db = db or self.current_db
        r = subprocess.run(
            self._psql_argv(db) + ["-c", sql],
            env=self.env({"PGOPTIONS": "-c statement_timeout=0"}),
            capture_output=True,
            text=True,
        )
        if r.returncode != 0:
            return f"__PSQL_ERR__ {(r.stderr or r.stdout).strip()}"
        return (r.stdout or "").strip()

    def dbname_for(self, case_id: str) -> str:
        slug = re.sub(r"[^a-z0-9_]", "_", case_id.lower())
        name = f"break_{slug}"
        return name[:63]

    def ensure_pg(self) -> None:
        """Added for this catalog: kill-pg cases leave recovery; wait or start."""
        for _ in range(160):
            ping = self.psql("SELECT 1;", db="postgres")
            if ping == "1":
                return
            if self.pg_mode == "docker":
                if not self._container_running():
                    self.pg_start()
            elif self.pg_mode == "local":
                self.pg_start()
            time.sleep(0.5)
        raise RuntimeError("postgres did not come back")

    def reset_case_db(self, case_id: str) -> str:
        self.ensure_pg()
        name = self.dbname_for(case_id)
        # Drop leftover from a previous crashed case, then create empty.
        self.psql(
            f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            f"WHERE datname = '{name}' AND pid <> pg_backend_pid();",
            db="postgres",
        )
        self.psql(f"DROP DATABASE IF EXISTS {name};", db="postgres")
        created = self.psql(f"CREATE DATABASE {name};", db="postgres")
        if created.startswith("__PSQL_ERR__"):
            self.ensure_pg()
            created = self.psql(f"CREATE DATABASE {name};", db="postgres")
        if created.startswith("__PSQL_ERR__"):
            raise RuntimeError(f"CREATE DATABASE {name}: {created}")
        self.current_db = name
        # Spill files are keyed <spill-dir>/<node-id>/<database>. A file a
        # previous run of this case left behind would be replayed into the
        # fresh database (rows counted twice) or counted as a leftover
        # (exit 3), so the case starts with no spill history either.
        spill_root = Path(self.env()["DBSHARK_SPILL_DIR"])
        if spill_root.is_dir():
            for node_dir in spill_root.iterdir():
                case_dir = node_dir / name
                if case_dir.is_dir():
                    shutil.rmtree(case_dir, ignore_errors=True)
        return name

    def count_rows(self) -> int:
        names = self.psql(
            "SELECT tablename FROM pg_tables WHERE schemaname = current_schema() "
            "ORDER BY 1;"
        )
        if names.startswith("__PSQL_ERR__") or not names:
            return 0
        total = 0
        for raw in names.splitlines():
            t = raw.strip()
            if not t:
                continue
            n = self.psql(f'SELECT count(*) FROM "{t}";')
            if n.startswith("__PSQL_ERR__"):
                continue
            try:
                total += int(n)
            except ValueError:
                pass
        return total

    def persistence(self) -> str:
        """Added for this catalog: 'p' is logged, 'u' is unlogged. Empty if no heap."""
        raw = self.psql(
            "SELECT coalesce(string_agg(pers || '=' || n::text, ',' ORDER BY 1), '') "
            "FROM (SELECT c.relpersistence::text AS pers, count(*)::bigint AS n "
            "FROM pg_class c "
            "JOIN pg_namespace ns ON ns.oid = c.relnamespace "
            "WHERE ns.nspname = current_schema() AND c.relkind = 'r' "
            "GROUP BY 1) s;"
        )
        return raw

    def public_tables(self) -> list[str]:
        names = self.psql(
            "SELECT tablename FROM pg_tables WHERE schemaname = current_schema() "
            "ORDER BY 1;"
        )
        if names.startswith("__PSQL_ERR__") or not names:
            return []
        return [x.strip() for x in names.splitlines() if x.strip()]

    def dbshark_cmd(self, extra: list[str], conn: str | None = None) -> list[str]:
        cmd = [str(self.dbshark)]
        if conn is not None:
            cmd += ["-o", conn]
        elif "-o" not in extra and "DATABASE_URL" not in (os.environ):
            cmd += ["-o", self.conninfo()]
        cmd += extra
        return cmd

    def run_one(
        self,
        extra: list[str],
        timeout: float,
        conn: str | None = None,
        env: dict | None = None,
        kill_after: float | None = None,
        kill_sig: int = signal.SIGTERM,
        stdin: bool = False,
    ) -> ProcResult:
        argv = self.dbshark_cmd(extra, conn=conn)
        logf = self.work / f"run_{int(time.time() * 1000)}_{os.getpid()}.log"
        e = self.env(env)
        proc = subprocess.Popen(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=e,
            text=True,
        )
        killed = False
        timed_out = False
        try:
            if kill_after is not None:
                t0 = time.monotonic()
                while proc.poll() is None and (time.monotonic() - t0) < kill_after:
                    time.sleep(0.05)
                if proc.poll() is None:
                    proc.send_signal(kill_sig)
                    killed = True
                    try:
                        out, _ = proc.communicate(timeout=max(5.0, timeout))
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        out, _ = proc.communicate()
                        timed_out = True
                else:
                    out, _ = proc.communicate()
            else:
                try:
                    out, _ = proc.communicate(timeout=timeout)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    out, _ = proc.communicate()
                    timed_out = True
                    killed = True
        except Exception:
            proc.kill()
            out = traceback.format_exc()
            timed_out = True
        text = out or ""
        try:
            logf.write_text(text)
        except OSError:
            pass
        return ProcResult(
            rc=proc.returncode,
            log=text,
            timed_out=timed_out,
            killed=killed,
            argv=argv,
        )

    def ingest(
        self,
        pcap: Path | None,
        *,
        nodes: int = 1,
        args: list[str] | None = None,
        node_args: list[list[str]] | None = None,
        timeout: float = 90.0,
        conn: str | None = None,
        env: dict | None = None,
        stagger_ms: list[int] | None = None,
        kill_after: float | None = None,
        kill_sig: int = signal.SIGTERM,
        proto_args: list[str] | None = None,
    ) -> dict:
        proto_args = proto_args if proto_args is not None else list(MIXED_P)
        base = list(args or [])
        if pcap is not None and "-r" not in base and "-i" not in base:
            base = ["-r", str(pcap)] + base
        results: list[ProcResult] = []
        if nodes <= 1:
            extra = proto_args + base
            if node_args and node_args[0]:
                extra = proto_args + node_args[0] + base
            results.append(
                self.run_one(
                    extra,
                    timeout,
                    conn=conn,
                    env=env,
                    kill_after=kill_after,
                    kill_sig=kill_sig,
                )
            )
        else:
            results = self._run_nodes(
                nodes,
                proto_args,
                base,
                node_args,
                timeout,
                conn,
                env,
                stagger_ms,
            )
        return self.pack(results)

    def _run_nodes(
        self,
        n: int,
        proto_args: list[str],
        base: list[str],
        node_args: list[list[str]] | None,
        timeout: float,
        conn: str | None,
        env: dict | None,
        stagger_ms: list[int] | None,
    ) -> list[ProcResult]:
        # Added for this catalog: start N offline ingest processes against one DB.
        stagger_ms = stagger_ms or [0] * n
        procs: list[tuple[subprocess.Popen, list[str], float]] = []
        e = self.env(env)
        t_start = time.monotonic()
        for i in range(n):
            extra = list(proto_args) + list(base)
            if node_args and i < len(node_args) and node_args[i]:
                extra = list(proto_args) + list(node_args[i]) + list(base)
            if i < len(stagger_ms) and stagger_ms[i]:
                time.sleep(stagger_ms[i] / 1000.0)
            argv = self.dbshark_cmd(extra, conn=conn)
            p = subprocess.Popen(
                argv,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=e,
                text=True,
            )
            procs.append((p, argv, time.monotonic()))
        out: list[ProcResult] = []
        for i, (p, argv, _) in enumerate(procs):
            timed_out = False
            try:
                remain = max(1.0, timeout - (time.monotonic() - t_start))
                text, _ = p.communicate(timeout=remain)
            except subprocess.TimeoutExpired:
                p.kill()
                text, _ = p.communicate()
                timed_out = True
            text = text or ""
            # Multi-node output used to live only in the packed report and
            # was dropped. Keep the same files run_one writes.
            logf = self.work / f"run_{int(time.time() * 1000)}_{os.getpid()}_{i}.log"
            try:
                logf.write_text(text)
            except OSError:
                pass
            out.append(
                ProcResult(
                    rc=p.returncode,
                    log=text,
                    timed_out=timed_out,
                    killed=timed_out,
                    argv=argv,
                )
            )
        return out

    def classify(self, pr: ProcResult) -> str:
        log = pr.log or ""
        if pr.timed_out and pr.rc not in (0, 143, 128 + 15):
            return "crashed"
        if pr.rc is None:
            return "crashed"
        # SIGKILL / other signals: crashed unless we sent SIGTERM.
        if pr.rc < 0:
            return "crashed" if pr.rc != -signal.SIGTERM else "stayed_up"
        # rc 0 means ingest_ok stayed set — INFO "postgres ddl:" races are
        # not exits. Needles still go in the report for later fixes.
        if pr.rc == 0:
            return "stayed_up"
        if pr.killed and pr.rc in (128 + 15, 143):
            return "stayed_up"
        if pr.rc in (1, 2):
            return "exited"
        # 3: the capture finished, but rows the database refused (or that
        # it never acknowledged) were written to the spill directory.
        # The process did not fall over; the report keeps rc and needles.
        if pr.rc == 3:
            return "stayed_up"
        return "crashed"

    def needles_in(self, text: str) -> list[str]:
        hit = []
        low = text.lower()
        for n in ERROR_NEEDLES:
            if n.lower() in low:
                hit.append(n)
        return hit

    def pack(self, results: list[ProcResult]) -> dict:
        outcomes = [self.classify(r) for r in results]
        rank = {"harness_error": 3, "crashed": 2, "exited": 1, "stayed_up": 0}
        worst = max(outcomes, key=lambda o: rank.get(o, 0)) if outcomes else "harness_error"
        logs = "\n---\n".join(r.log for r in results)
        return {
            "rc": [r.rc for r in results],
            "outcome": worst,
            "node_outcomes": outcomes,
            "error_needles": self.needles_in(logs),
            "rows": self.count_rows(),
            "tables": self.public_tables(),
            "spilled": any(r.rc == 3 for r in results),
            "killed": [r.killed for r in results],
            "timed_out": [r.timed_out for r in results],
            "logs": logs[-8000:],
        }


def live_caps_ok(dbshark: Path) -> bool:
    # Root inside a container (or on a host) already holds CAP_NET_RAW in its
    # effective set; the binary needs no file capability then.
    if os.geteuid() == 0:
        try:
            for line in Path("/proc/self/status").read_text().splitlines():
                if line.startswith("CapEff:"):
                    cap_net_raw = 13
                    return bool(int(line.split()[1], 16) >> cap_net_raw & 1)
        except (OSError, ValueError, IndexError):
            return True
    getcap = shutil.which("getcap")
    if not getcap:
        return False
    r = subprocess.run([getcap, str(dbshark)], capture_output=True, text=True)
    return "cap_net_raw" in (r.stdout or "")


def load_filter(cases):
    filt = os.environ.get("BREAK_FILTER", "").strip()
    fam = os.environ.get("BREAK_FAMILY", "").strip()
    out = cases
    if fam:
        want = {x.strip() for x in fam.split(",") if x.strip()}
        out = [c for c in out if c.family in want]
    if filt:
        rx = re.compile(filt)
        out = [c for c in out if rx.search(c.id)]
    return out


def main() -> int:
    root = HERE.parents[2]
    dbshark = Path(os.environ.get("DBSHARK", root / "build/run/dbshark"))
    if not dbshark.is_file() or not os.access(dbshark, os.X_OK):
        print(f"error: dbshark not executable: {dbshark}", file=sys.stderr)
        return 2
    ws_lib = Path(os.environ.get("WS_LIB", os.path.expanduser("~/wireshark-4.2.6/build/run")))
    work = Path(os.environ.get("BREAK_WORK", str(HERE / ".work")))
    work.mkdir(parents=True, exist_ok=True)

    h = Harness(
        work=work,
        dbshark=dbshark,
        ws_lib=ws_lib,
        pghost=os.environ.get("PGHOST", "127.0.0.1"),
        pgport=os.environ.get("PGPORT", "55432"),
        pguser=os.environ.get("PGUSER", "postgres"),
        pgpassword=os.environ.get("PGPASSWORD", "postgres"),
        container=os.environ.get("BREAK_PG_CONTAINER", "dbshark-break-pg"),
        pg_mode=os.environ.get("BREAK_PG_MODE", "docker"),
        skip_live=os.environ.get("SKIP_LIVE", "") not in ("", "0"),
        has_cap=live_caps_ok(dbshark),
    )
    if h.pg_mode not in ("docker", "local", "external"):
        print(f"error: BREAK_PG_MODE must be docker, local or external (got {h.pg_mode})", file=sys.stderr)
        return 2
    if h.pg_mode == "local":
        h.pg_start()
    ping = ""
    for _ in range(40):
        ping = h.psql("SELECT 1;", db="postgres")
        if ping == "1":
            break
        time.sleep(0.25)
    else:
        print(f"error: postgres not reachable: {ping}", file=sys.stderr)
        return 2

    selected = load_filter(CASES)
    report = {
        "generated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "dbshark": str(dbshark),
        "cases": [],
    }
    print(f"catalog: {len(selected)} cases (of {len(CASES)} registered)", flush=True)
    for case in selected:
        row = {
            "id": case.id,
            "family": case.family,
            "stop_site": case.stop_site,
            "notes": case.notes,
            "rc": None,
            "outcome": "harness_error",
            "error_needles": [],
            "rows": 0,
        }
        print(f"  [{case.family}] {case.id} ...", flush=True)
        try:
            if case.live and (h.skip_live or not h.has_cap):
                row["outcome"] = "harness_error"
                row["notes"] = (
                    case.notes
                    + " skipped: live family needs CAP_NET_RAW "
                    + ("(SKIP_LIVE=1)" if h.skip_live else "(getcap missing cap_net_raw)")
                )
            else:
                h.reset_case_db(case.id)
                extra = case.run(h) or {}
                row.update(extra)
                if "persistence" not in row:
                    row["persistence"] = h.persistence()
                logs = str(row.get("logs") or "")
                findings = list(row.get("findings") or [])
                # Permission and timeout failures used to stay up with
                # rows=0 and only a needle. That is a dropped batch.
                if (
                    row.get("outcome") == "stayed_up"
                    and (row.get("rows") or 0) == 0
                    and "dropping rows" in logs
                    and not any("drop" in f for f in findings)
                ):
                    findings.append(
                        "process stayed up and dropped the batch after a Postgres error"
                    )
                if findings:
                    row["findings"] = findings
                if row.get("logs") and (
                    row.get("error_needles") or row.get("findings") or row.get("rows") == 0
                ):
                    row["log_tail"] = str(row.get("logs"))[-1200:]
                if "outcome" not in extra:
                    row["outcome"] = "harness_error"
                    row["notes"] = case.notes + " case returned no outcome"
        except Exception as exc:
            row["outcome"] = "harness_error"
            row["notes"] = case.notes + f" harness exception: {exc}"
            row["logs"] = traceback.format_exc()[-4000:]
        report["cases"].append(
            {
                k: row[k]
                for k in (
                    "id",
                    "family",
                    "stop_site",
                    "rc",
                    "outcome",
                    "error_needles",
                    "rows",
                    "notes",
                )
                if k in row
            }
            | {
                k: row[k]
                for k in row
                if k in (
                    "node_outcomes",
                    "tables",
                    "persistence",
                    "findings",
                    "rows_after_crash",
                    "log_tail",
                )
            }
        )
        extra_note = ""
        if row.get("findings"):
            extra_note = " findings=" + "; ".join(row["findings"])
        print(
            f"    -> {row.get('outcome')} rc={row.get('rc')} rows={row.get('rows')}"
            f"{extra_note}",
            flush=True,
        )

    REPORT_PATH.write_text(json.dumps(report, indent=2) + "\n")
    stayed = sum(1 for c in report["cases"] if c.get("outcome") == "stayed_up")
    exited = sum(1 for c in report["cases"] if c.get("outcome") == "exited")
    crashed = sum(1 for c in report["cases"] if c.get("outcome") == "crashed")
    herr = sum(1 for c in report["cases"] if c.get("outcome") == "harness_error")
    nfind = sum(1 for c in report["cases"] if c.get("findings"))
    print(
        f"catalog matrix: stayed_up={stayed} exited={exited} "
        f"crashed={crashed} harness_error={herr} findings={nfind} -> {REPORT_PATH}",
        flush=True,
    )
    # Added for this catalog: exits are findings, not a failed harness.
    return 0


if __name__ == "__main__":
    sys.exit(main())
