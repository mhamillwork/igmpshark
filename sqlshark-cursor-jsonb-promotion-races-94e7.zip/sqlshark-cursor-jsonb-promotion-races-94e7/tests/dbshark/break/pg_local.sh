#!/usr/bin/env bash
# Local Postgres cluster for the durability catalog (BREAK_PG_MODE=local).
#
# Replaces the docker-run postgres when docker is not available, e.g. inside
# the RHEL test image or on a bare RHEL host with postgresql-server installed.
#
#   pg_local.sh start    initdb (first time) + pg_ctl start, create PGDATABASE
#   pg_local.sh crash    SIGKILL the postmaster and every child (unclean stop)
#   pg_local.sh stop     pg_ctl stop -m fast
#   pg_local.sh status   exit 0 if the cluster accepts connections
#   pg_local.sh destroy  stop and remove the data directory
#
# Env: BREAK_PG_DATA (default <break>/.work/pg), PGPORT, PGUSER, PGPASSWORD,
#      PGDATABASE, PG_MAX_LOCKS (default 64), PGBIN (dir with pg_ctl/initdb).
#
# Postgres refuses to run as root; when invoked as root the cluster is owned
# by and run as $BREAK_PG_OSUSER (default: postgres).
set -euo pipefail

HERE=$(cd "$(dirname "$0")" && pwd)
CMD=${1:-status}
DATA=${BREAK_PG_DATA:-$HERE/.work/pg}
PGPORT=${PGPORT:-55432}
PGUSER=${PGUSER:-postgres}
PGPASSWORD=${PGPASSWORD:-postgres}
PGDATABASE=${PGDATABASE:-logshark_break}
PG_MAX_LOCKS=${PG_MAX_LOCKS:-64}
OSUSER=${BREAK_PG_OSUSER:-postgres}
LOG=$DATA.log

find_pgbin() {
    if [ -n "${PGBIN:-}" ] && [ -x "$PGBIN/pg_ctl" ]; then
        echo "$PGBIN"
        return 0
    fi
    if command -v pg_ctl >/dev/null 2>&1; then
        dirname "$(command -v pg_ctl)"
        return 0
    fi
    if command -v pg_config >/dev/null 2>&1 && [ -x "$(pg_config --bindir)/pg_ctl" ]; then
        pg_config --bindir
        return 0
    fi
    # Debian/Ubuntu and PGDG layouts.
    for d in /usr/lib/postgresql/*/bin /usr/pgsql-*/bin; do
        if [ -x "$d/pg_ctl" ]; then
            echo "$d"
            return 0
        fi
    done
    return 1
}

PGBIN=$(find_pgbin) || {
    echo "pg_local: pg_ctl not found (install postgresql-server, or set PGBIN=)" >&2
    exit 2
}

# Run a command as the cluster owner when we are root.
as_owner() {
    if [ "$(id -u)" = 0 ]; then
        if ! id "$OSUSER" >/dev/null 2>&1; then
            useradd -r -s /bin/sh -d "$DATA" "$OSUSER" 2>/dev/null || adduser --system --home "$DATA" --shell /bin/sh "$OSUSER"
        fi
        if command -v runuser >/dev/null 2>&1; then
            runuser -u "$OSUSER" -- "$@"
        else
            su -s /bin/sh "$OSUSER" -c "$(printf '%q ' "$@")"
        fi
    else
        "$@"
    fi
}

psql_ok() {
    PGPASSWORD=$PGPASSWORD "$PGBIN/psql" -h 127.0.0.1 -p "$PGPORT" -U "$PGUSER" -d postgres \
        -X -A -t -c 'SELECT 1' 2>/dev/null | grep -qx 1
}

postmaster_pid() {
    if [ -f "$DATA/postmaster.pid" ]; then
        head -n 1 "$DATA/postmaster.pid"
    fi
}

running() {
    local pid
    pid=$(postmaster_pid) || true
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}

init_cluster() {
    mkdir -p "$(dirname "$DATA")"
    if [ "$(id -u)" = 0 ]; then
        mkdir -p "$DATA"
        chown "$OSUSER" "$DATA" "$(dirname "$DATA")" 2>/dev/null || true
        chmod 700 "$DATA"
        : >"$LOG" && chown "$OSUSER" "$LOG"
    fi
    pwfile=$(mktemp)
    printf '%s\n' "$PGPASSWORD" >"$pwfile"
    chmod 644 "$pwfile"
    as_owner "$PGBIN/initdb" -D "$DATA" -U "$PGUSER" --pwfile="$pwfile" \
        --auth-host=scram-sha-256 --auth-local=trust -E UTF8 --locale=C >/dev/null
    rm -f "$pwfile"
    cat >>"$DATA/postgresql.conf" <<EOF
# tests/dbshark/break/pg_local.sh
listen_addresses = '127.0.0.1'
port = $PGPORT
unix_socket_directories = '$DATA'
max_locks_per_transaction = $PG_MAX_LOCKS
log_min_messages = warning
EOF
    if [ "$(id -u)" = 0 ]; then
        chown "$OSUSER" "$DATA/postgresql.conf"
    fi
}

start_cluster() {
    if [ ! -f "$DATA/PG_VERSION" ]; then
        init_cluster
    fi
    if running && psql_ok; then
        return 0
    fi
    if running; then
        # postmaster alive but not accepting (still in recovery) - wait below.
        :
    else
        rm -f "$DATA/postmaster.pid"
        as_owner "$PGBIN/pg_ctl" -D "$DATA" -l "$LOG" -w -t 120 start >/dev/null
    fi
    for _ in $(seq 1 240); do
        if psql_ok; then
            break
        fi
        sleep 0.5
    done
    if ! psql_ok; then
        echo "pg_local: cluster did not accept connections; tail of $LOG:" >&2
        tail -n 40 "$LOG" >&2 || true
        return 1
    fi
    if ! PGPASSWORD=$PGPASSWORD "$PGBIN/psql" -h 127.0.0.1 -p "$PGPORT" -U "$PGUSER" -d postgres -X -A -t \
        -c "SELECT 1 FROM pg_database WHERE datname = '$PGDATABASE'" 2>/dev/null | grep -qx 1; then
        PGPASSWORD=$PGPASSWORD "$PGBIN/psql" -h 127.0.0.1 -p "$PGPORT" -U "$PGUSER" -d postgres -X -q \
            -c "CREATE DATABASE $PGDATABASE" >/dev/null
    fi
}

crash_cluster() {
    local pid
    pid=$(postmaster_pid) || true
    if [ -z "$pid" ] || ! kill -0 "$pid" 2>/dev/null; then
        echo "pg_local: no running postmaster to crash" >&2
        return 1
    fi
    # pg_ctl starts the postmaster with setsid, so its process group is
    # the whole cluster. SIGKILL everything at once: no checkpoint, no
    # shutdown record. Unlogged heaps must be empty after recovery.
    kill -KILL -- "-$pid" 2>/dev/null || kill -KILL "$pid" 2>/dev/null || true
    for _ in $(seq 1 100); do
        if ! kill -0 "$pid" 2>/dev/null; then
            break
        fi
        sleep 0.05
    done
    rm -f "$DATA/postmaster.pid"
}

case "$CMD" in
    start)
        start_cluster
        ;;
    crash)
        crash_cluster
        ;;
    stop)
        if running; then
            as_owner "$PGBIN/pg_ctl" -D "$DATA" -m fast -w stop >/dev/null || true
        fi
        ;;
    status)
        running && psql_ok
        ;;
    destroy)
        if running; then
            as_owner "$PGBIN/pg_ctl" -D "$DATA" -m immediate -w stop >/dev/null || true
        fi
        rm -rf "$DATA" "$LOG"
        ;;
    *)
        echo "usage: $0 start|crash|stop|status|destroy" >&2
        exit 2
        ;;
esac
