#!/usr/bin/env python3
"""Added for this catalog: production capture is not a tidy DIS pcap.
Build Ethernet/IPv4/IPv6/VLAN/fragment frames for several protocols,
then shuffle them with garbage. dbshark is asked to ingest the mess
with several -p PROTO arguments at once.
"""
from __future__ import annotations

import importlib.util
import random
import socket
import struct
from pathlib import Path

DIS_PDUS = Path(__file__).resolve().parent.parent / "compose" / "dis_pdus.py"


def _load_dis():
    spec = importlib.util.spec_from_file_location("dis_pdus_break", DIS_PDUS)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


_dis = None


def dis_mod():
    global _dis
    if _dis is None:
        _dis = _load_dis()
    return _dis


# Default protocol set for mixed bursts. These are Wireshark filter names
# dbshark accepts with -p.
MIXED_PROTOS = ("dis", "dns", "ntp", "syslog", "coap")

PCAP_MAGIC = 0xA1B2C3D4
PCAP_MAGIC_NSEC = 0xA1B23C4D
DLT_EN10MB = 1
DLT_LINUX_SLL = 113
# Added for this catalog: epoch used by one-frame and first-message pcaps.
T0_US = 1_700_000_000_000_000


def ipv4_checksum(hdr: bytes) -> int:
    if len(hdr) % 2:
        hdr += b"\x00"
    s = 0
    for i in range(0, len(hdr), 2):
        s += (hdr[i] << 8) | hdr[i + 1]
    s = (s >> 16) + (s & 0xFFFF)
    s += s >> 16
    return (~s) & 0xFFFF


def eth(payload: bytes, ethertype: int = 0x0800, vlan: int | None = None) -> bytes:
    dst = b"\x00\x00\x00\x00\x00\x02"
    src = b"\x00\x00\x00\x00\x00\x01"
    if vlan is None:
        return dst + src + struct.pack("!H", ethertype) + payload
    # 802.1Q: TPID 0x8100, TCI, then real ethertype
    return dst + src + struct.pack("!HHH", 0x8100, vlan & 0x0FFF, ethertype) + payload


def ipv4(payload: bytes, proto: int, src="10.0.0.1", dst="10.0.0.2",
         ident=0x1111, frag_off=0, flags=0, ttl=64) -> bytes:
    ihl = 5
    total = 20 + len(payload)
    src_b = socket.inet_aton(src)
    dst_b = socket.inet_aton(dst)
    flags_frag = (flags << 13) | (frag_off & 0x1FFF)
    hdr = struct.pack(
        "!BBHHHBBH4s4s",
        (4 << 4) | ihl,
        0,
        total,
        ident,
        flags_frag,
        ttl,
        proto,
        0,
        src_b,
        dst_b,
    )
    csum = ipv4_checksum(hdr)
    hdr = hdr[:10] + struct.pack("!H", csum) + hdr[12:]
    return hdr + payload


def ipv6(payload: bytes, nxt: int, src="2001:db8::1", dst="2001:db8::2") -> bytes:
    src_b = socket.inet_pton(socket.AF_INET6, src)
    dst_b = socket.inet_pton(socket.AF_INET6, dst)
    plen = len(payload)
    hdr = struct.pack("!IHBB", (6 << 28), plen, nxt, 64) + src_b + dst_b
    return hdr + payload


def udp(payload: bytes, sport=12345, dport=3000) -> bytes:
    length = 8 + len(payload)
    return struct.pack("!HHHH", sport, dport, length, 0) + payload


def tcp_syn(sport=12345, dport=80) -> bytes:
    # 20-byte header, SYN set. Not a full handshake — just noise on the wire.
    seq = 1
    off = 5 << 12
    flags = 0x02
    return struct.pack("!HHIIHHHH", sport, dport, seq, 0, off | flags, 8192, 0, 0)


def frame_udp(payload: bytes, dport: int, sport: int = 12345, **ipkw) -> bytes:
    return eth(ipv4(udp(payload, sport=sport, dport=dport), proto=17, **ipkw))


def frame_udp6(payload: bytes, dport: int, sport: int = 12345) -> bytes:
    return eth(ipv6(udp(payload, sport=sport, dport=dport), nxt=17), ethertype=0x86DD)


def dns_query(name: str = "example.test") -> bytes:
    # Standard query, RD set, one question A IN.
    txid = 0x4242
    flags = 0x0100
    q = b""
    for lab in name.split("."):
        q += bytes([len(lab)]) + lab.encode("ascii")
    q += b"\x00" + struct.pack("!HH", 1, 1)
    return struct.pack("!HHHHHH", txid, flags, 1, 0, 0, 0) + q


def ntp_client() -> bytes:
    # LI=0 VN=3 Mode=3 (client), rest zero — valid enough for packet-ntp.
    return bytes([0x1B]) + b"\x00" * 47


def syslog_line(msg: str = "break catalog mixed burst") -> bytes:
    return f"<13>Oct  5 12:00:00 testhost app[1]: {msg}\n".encode()


def coap_get(path: str = ".well-known/core") -> bytes:
    # Ver=1 Type=0 (CON) TKL=0 Code=GET (1) MID=1, Uri-Path options.
    hdr = struct.pack("!BBH", 0x40, 1, 1)
    opts = b""
    prev = 0
    for seg in path.strip("/").split("/"):
        delta = 11 - prev  # Uri-Path is option 11
        prev = 11
        b = seg.encode()
        opts += bytes([(delta << 4) | (len(b) & 0x0F)]) + b
    return hdr + opts


def dis_pdu(name: str = "entity_state") -> bytes:
    m = dis_mod()
    for n, builder in m.CORPUS:
        if n == name:
            return builder()
    raise KeyError(name)


def all_dis_pdus() -> list[bytes]:
    m = dis_mod()
    return [builder() for _, builder in m.CORPUS]


def legal_mix_payloads(rng: random.Random) -> list[tuple[bytes, int]]:
    """(udp_payload, dest_port) for several protocols, no order promised."""
    out: list[tuple[bytes, int]] = []
    for pdu in all_dis_pdus():
        out.append((pdu, 3000))
    out.append((dns_query("alpha.example"), 53))
    out.append((dns_query("beta.example"), 53))
    out.append((ntp_client(), 123))
    out.append((syslog_line("first"), 514))
    out.append((syslog_line("second with spaces and 123"), 514))
    out.append((coap_get(), 5683))
    out.append((coap_get("sensors/temp"), 5683))
    rng.shuffle(out)
    return out


def garbage(n: int, rng: random.Random) -> bytes:
    return bytes(rng.getrandbits(8) for _ in range(n))


def messy_burst(
    n: int = 300,
    rng: random.Random | None = None,
    include_garbage: bool = True,
    include_trunc: bool = True,
    include_vlan: bool = True,
    include_v6: bool = True,
) -> list[tuple[int, bytes, int]]:
    """Added for this catalog: a production-like pile of frames.

    Returns list of (ts_us, frame, orig_len). orig_len may exceed the
    captured bytes (snaplen / truncation). Order is shuffled. Protocols
    are interleaved — we never emit a clean DIS-only run here.
    """
    rng = rng or random.Random(0xD15B)
    mix = legal_mix_payloads(rng)
    frames: list[tuple[int, bytes, int]] = []
    t0 = 1_700_000_000_000_000
    for i in range(n):
        kind = rng.randrange(10)
        ts = t0 + i * 1000 + rng.randrange(0, 500)
        if include_garbage and kind == 0:
            payload = garbage(rng.randrange(8, 200), rng)
            dport = rng.choice([7, 9, 53, 123, 514, 3000, 5683, 9999])
            fr = frame_udp(payload, dport=dport, sport=rng.randrange(1024, 65000))
            frames.append((ts, fr, len(fr)))
        elif include_trunc and kind == 1:
            payload, dport = mix[i % len(mix)]
            fr = frame_udp(payload, dport=dport)
            cut = max(14 + 20 + 8, len(fr) // 2)
            frames.append((ts, fr[:cut], len(fr)))
        elif include_v6 and kind == 2:
            payload, dport = mix[i % len(mix)]
            fr = frame_udp6(payload, dport=dport)
            frames.append((ts, fr, len(fr)))
        elif include_vlan and kind == 3:
            payload, dport = mix[i % len(mix)]
            body = ipv4(udp(payload, dport=dport), proto=17)
            fr = eth(body, vlan=42)
            frames.append((ts, fr, len(fr)))
        elif kind == 4:
            # TCP SYN noise — not a selected proto, still hits the NIC.
            fr = eth(ipv4(tcp_syn(dport=rng.choice([80, 443, 22])), proto=6))
            frames.append((ts, fr, len(fr)))
        else:
            payload, dport = mix[i % len(mix)]
            fr = frame_udp(
                payload,
                dport=dport,
                sport=rng.randrange(1024, 65000),
                src=f"10.{rng.randrange(0, 5)}.{rng.randrange(0, 255)}.{rng.randrange(1, 254)}",
            )
            frames.append((ts, fr, len(fr)))
    rng.shuffle(frames)
    return frames


def ip_fragments(payload: bytes, dport: int = 3000, ident: int = 0xABCD) -> list[bytes]:
    """Two IPv4 fragments of one UDP datagram. First has MF, second is the rest."""
    udp_p = udp(payload, dport=dport)
    # 8-byte UDP hdr + payload; split after 8+8 bytes of UDP datagram.
    split = 8  # bytes of UDP datagram in first fragment (must be multiple of 8)
    first = udp_p[:split]
    second = udp_p[split:]
    f1 = eth(ipv4(first, proto=17, ident=ident, flags=1, frag_off=0))
    f2 = eth(ipv4(second, proto=17, ident=ident, flags=0, frag_off=split // 8))
    return [f1, f2]


def caplen_gt_len_frame() -> tuple[bytes, int, int]:
    """Captured length claims to be longer than on-wire — process_packet stops."""
    fr = frame_udp(b"short", dport=3000)
    return fr, len(fr) + 40, len(fr)


def frames_caplen_gt_len(ts: int = T0_US) -> list[tuple[int, bytes, int]]:
    """Added for this catalog: write_pcap triple with incl_len > orig_len."""
    fr, caplen, orig = caplen_gt_len_frame()
    padded = fr + b"\x00" * max(0, caplen - len(fr))
    return [(ts, padded, orig)]


def dns_response_many_a(name: str = "multi.example", n: int = 6) -> bytes:
    """Added for this catalog: one DNS reply with many A records (n_hit > HIT_INLINE)."""

    def qname(host: str) -> bytes:
        out = b""
        for lab in host.split("."):
            out += bytes([len(lab)]) + lab.encode("ascii")
        return out + b"\x00"

    q = qname(name)
    # Name compression pointer back to offset 12 (start of QNAME).
    ptr = struct.pack("!H", 0xC00C)
    answers = b""
    for i in range(n):
        answers += ptr + struct.pack("!HHIH", 1, 1, 60, 4)
        answers += socket.inet_aton(f"10.0.0.{i + 1}")
    hdr = struct.pack("!HHHHHH", 0x4243, 0x8180, 1, n, 0, 0)
    return hdr + q + struct.pack("!HH", 1, 1) + answers


def huge_signal(nbytes: int = 8000) -> bytes:
    """Added for this catalog: DIS Signal PDU with a large data blob."""
    m = dis_mod()
    data = bytes(i & 0xFF for i in range(nbytes))
    payload = (
        m.entity_id()
        + m._u16(1)
        + m._u16(0)
        + m._u16(0)
        + m._u32(8000)
        + m._u16(min(nbytes * 8, 0xFFFF))
        + m._u16(1)
        + data
    )
    return m.wrap_header(m.PDU_SIGNAL, m.FAM_RADIO, payload)


def one_dis_frame(name: str = "entity_state", ts: int = T0_US) -> list[tuple[int, bytes, int]]:
    fr = frame_udp(dis_pdu(name), dport=3000)
    return [(ts, fr, len(fr))]


def one_dns_frame(ts: int = T0_US, many: bool = False) -> list[tuple[int, bytes, int]]:
    payload = dns_response_many_a() if many else dns_query()
    fr = frame_udp(payload, dport=53)
    return [(ts, fr, len(fr))]


def one_each_proto_frames(ts: int = T0_US) -> list[tuple[int, bytes, int]]:
    """Added for this catalog: one legal frame per mixed protocol, still shuffled."""
    items = [
        (dis_pdu("entity_state"), 3000),
        (dns_query(), 53),
        (ntp_client(), 123),
        (syslog_line("one"), 514),
        (coap_get(), 5683),
    ]
    rng = random.Random(7)
    rng.shuffle(items)
    out = []
    for i, (payload, dport) in enumerate(items):
        fr = frame_udp(payload, dport=dport)
        out.append((ts + i * 1000, fr, len(fr)))
    return out


def fire_then_es_frames() -> list[tuple[int, bytes, int]]:
    """Added for this catalog: list-valued Fire then single-valued Entity State."""
    fire = frame_udp(dis_pdu("fire"), dport=3000)
    es = frame_udp(dis_pdu("entity_state"), dport=3000)
    return [(T0_US, fire, len(fire)), (T0_US + 2000, es, len(es))]


def legal_after_garbage_frames() -> list[tuple[int, bytes, int]]:
    """Added for this catalog: junk, then a bad caplen, then a legal DIS (dies today)."""
    junk = frame_udp(garbage(40, random.Random(1)), dport=9)
    bad = frames_caplen_gt_len(T0_US + 1000)[0]
    good = frame_udp(dis_pdu("entity_state"), dport=3000)
    return [
        (T0_US, junk, len(junk)),
        bad,
        (T0_US + 2000, good, len(good)),
    ]


def fragment_frames(missing_second: bool = False) -> list[tuple[int, bytes, int]]:
    frs = ip_fragments(dis_pdu("entity_state"), dport=3000)
    if missing_second:
        frs = frs[:1]
    return [(T0_US + i * 100, fr, len(fr)) for i, fr in enumerate(frs)]


def stamp(frames: list[tuple[int, bytes, int]], mode: str) -> list[tuple[int, bytes, int]]:
    """Added for this catalog: burst / trickle / duplicate / backward / clock-jump."""
    if mode == "burst":
        return [(T0_US + i * 200, fr, orig) for i, (_, fr, orig) in enumerate(frames)]
    if mode == "trickle":
        return [(T0_US + i * 2_000_000, fr, orig) for i, (_, fr, orig) in enumerate(frames)]
    if mode == "backward":
        n = len(frames)
        return [(T0_US + (n - i) * 1000, fr, orig) for i, (_, fr, orig) in enumerate(frames)]
    if mode == "clock_jump":
        out = []
        for i, (_, fr, orig) in enumerate(frames):
            ts = T0_US + i * 1000
            if i == len(frames) // 2:
                ts += 3_600_000_000  # +1 hour
            out.append((ts, fr, orig))
        return out
    if mode == "dup":
        out = []
        for i, (_, fr, orig) in enumerate(frames):
            out.append((T0_US + i * 1000, fr, orig))
            out.append((T0_US + i * 1000 + 10, fr, orig))
        return out
    return frames


def empty_pcap_bytes() -> bytes:
    return struct.pack("<IHHIIII", PCAP_MAGIC, 2, 4, 0, 0, 65535, DLT_EN10MB)


def write_empty_pcap(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(empty_pcap_bytes())


def frame_qinq(payload: bytes, dport: int = 3000) -> bytes:
    """Added for this catalog: 802.1ad + 802.1Q (QinQ) around IPv4/UDP."""
    body = ipv4(udp(payload, dport=dport), proto=17)
    dst = b"\x00\x00\x00\x00\x00\x02"
    src = b"\x00\x00\x00\x00\x00\x01"
    return dst + src + struct.pack("!HHHH", 0x88A8, 100, 0x8100, 200) + body


def frame_gre_udp(payload: bytes, dport: int = 3000) -> bytes:
    """Added for this catalog: Ethernet/IPv4/GRE/IPv4/UDP — DIS one tunnel in."""
    inner = ipv4(udp(payload, dport=dport), proto=17, src="10.1.0.1", dst="10.1.0.2")
    gre = struct.pack("!HH", 0, 0x0800) + inner
    return eth(ipv4(gre, proto=47, src="172.16.0.1", dst="172.16.0.2"))


def frame_sll_udp(payload: bytes, dport: int) -> bytes:
    """Linux cooked capture (SLL) — common tcpdump -i any."""
    sll = struct.pack("!HHH8sH", 0, 1, 6, b"\x00" * 8, 0x0800)
    return sll + ipv4(udp(payload, dport=dport), proto=17)


def frame_tiny_eth() -> bytes:
    return b"\x00\x01\x02\x03\x04\x05\x06\x07"


def dis_nan_inf() -> bytes:
    """Entity State with NaN / Inf / -Inf ECEF — binary COPY of DOUBLE."""
    import math

    m = dis_mod()
    loc = struct.pack("!ddd", math.nan, math.inf, -math.inf)
    payload = (
        m.entity_id()
        + m._u8(1)
        + m._u8(0)
        + m.entity_type()
        + m.entity_type()
        + m.vec3f(1.0, 0.0, 0.0)
        + loc
        + m.vec3f(0.1, 0.0, 0.0)
        + m._u32(0)
        + m._u8(2)
        + (b"\x00" * 15)
        + m.vec3f()
        + m.vec3f()
        + m.marking("NANINF")
        + m._u32(0)
    )
    return m.wrap_header(m.PDU_ENTITY_STATE, m.FAM_ENTITY, payload)


def syslog_hostile() -> bytes:
    """NUL, invalid UTF-8, and a very long line — TEXT COPY / binary bytes."""
    return (
        b"<13>Oct  5 12:00:00 host app[1]: "
        + b"ok\x00embedded-nul "
        + bytes([0xFF, 0xFE, 0x80])
        + b" "
        + (b"X" * 4000)
        + b"\n"
    )


def dns_compression_loop() -> bytes:
    """Pointer to itself — a dissector that follows names can spin."""
    hdr = struct.pack("!HHHHHH", 0x1111, 0x0100, 1, 0, 0, 0)
    # QNAME is a pointer to offset 12 (itself).
    return hdr + struct.pack("!HHH", 0xC00C, 1, 1)


def write_pcap_ns(path: Path, frames: list[tuple[int, bytes, int]]) -> None:
    """Added for this catalog: nanosecond pcap magic (tcpdump -j nano)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        f.write(struct.pack("<IHHIIII", PCAP_MAGIC_NSEC, 2, 4, 0, 0, 65535, DLT_EN10MB))
        for ts_us, data, orig in frames:
            ns = ts_us * 1000
            f.write(
                struct.pack(
                    "<IIII",
                    ns // 1_000_000_000,
                    ns % 1_000_000_000,
                    len(data),
                    orig or len(data),
                )
            )
            f.write(data)


def write_pcap_dlt(path: Path, dlt: int, frames: list[tuple[int, bytes, int]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        f.write(struct.pack("<IHHIIII", PCAP_MAGIC, 2, 4, 0, 0, 65535, dlt))
        for ts_us, data, orig in frames:
            f.write(
                struct.pack(
                    "<IIII",
                    ts_us // 1_000_000,
                    ts_us % 1_000_000,
                    len(data),
                    orig or len(data),
                )
            )
            f.write(data)


def write_truncated_pcap(path: Path) -> None:
    """Added for this catalog: global header plus a cut-off packet header (wtap)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(empty_pcap_bytes() + b"\x00\x01\x02\x03\x04")


def write_pcap(
    path: Path,
    frames: list[tuple[int, bytes, int]],
    snaplen: int = 65535,
) -> None:
    """frames: (ts_us, captured_bytes, orig_len)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        f.write(struct.pack("<IHHIIII", PCAP_MAGIC, 2, 4, 0, 0, snaplen, DLT_EN10MB))
        for ts_us, data, orig in frames:
            cap = data[:snaplen]
            orig_len = orig if orig else len(data)
            f.write(struct.pack("<IIII", ts_us // 1_000_000, ts_us % 1_000_000, len(cap), orig_len))
            f.write(cap)


def write_pcapng(path: Path, frames: list[tuple[int, bytes, int]]) -> None:
    """Minimal pcapng: SHB + IDB (Ethernet) + EPBs. wtap should open this."""
    path.parent.mkdir(parents=True, exist_ok=True)

    def blk(typ: int, body: bytes) -> bytes:
        total = 12 + len(body)
        pad = (4 - (len(body) % 4)) % 4
        total += pad
        return struct.pack("<II", typ, total) + body + (b"\x00" * pad) + struct.pack("<I", total)

    # Added for this catalog: SHB section length is int64 -1 (unknown).
    # EPB is if_id, ts_high, ts_low, caplen, origlen, bytes.
    shb_body = struct.pack("<IHHq", 0x1A2B3C4D, 1, 0, -1)
    idb_body = struct.pack("<HHI", DLT_EN10MB, 0, 65535)
    with path.open("wb") as f:
        f.write(blk(0x0A0D0D0A, shb_body))
        f.write(blk(1, idb_body))
        for ts_us, data, orig in frames:
            cap = data
            orig_len = orig if orig else len(data)
            ts_high = (ts_us >> 32) & 0xFFFFFFFF
            ts_low = ts_us & 0xFFFFFFFF
            body = struct.pack("<IIIII", 0, ts_high, ts_low, len(cap), orig_len) + cap
            f.write(blk(6, body))
