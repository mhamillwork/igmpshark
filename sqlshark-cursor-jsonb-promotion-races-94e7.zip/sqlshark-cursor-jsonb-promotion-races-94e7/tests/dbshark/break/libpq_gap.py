#!/usr/bin/env python3
"""Added for this catalog: libpq frontend proxy to force SAVEPOINT copy errors.

dbshark first packet:
  startup BEGIN → SAVEPOINT ddl / CREATE → commit_schema COMMIT + BEGIN
  → encode row on the client (server idle) → PQexec("SAVEPOINT copy")

Two ways that PQexec fails with PGRES_FATAL_ERROR (the prod log line
`postgres copy savepoint`):

1. idle_in_transaction_session_timeout fires in the encode gap
   → FATAL terminating connection due to idle-in-transaction timeout
2. The BEGIN after COMMIT never reaches the server (pooler / missed begin)
   → ERROR SAVEPOINT can only be used in transaction blocks
"""
from __future__ import annotations

import struct
import socket
import threading
import time


def _fake_begin_idle() -> bytes:
    """CommandComplete BEGIN + ReadyForQuery Idle — client thinks BEGIN worked."""
    tag = b"BEGIN\x00"
    complete = b"C" + struct.pack(">I", 4 + len(tag)) + tag
    ready = b"Z" + struct.pack(">I", 5) + b"I"
    return complete + ready


def _pipe_c2s(
    src: socket.socket,
    dst: socket.socket,
    hold: bytes | None,
    delay_s: float,
    drop_nth_begin: int,
    begin_seen: list,
) -> None:
    try:
        while True:
            data = src.recv(65536)
            if not data:
                break
            # Simple-query 'Q' payloads are small; dbshark sends whole queries.
            if drop_nth_begin and b"BEGIN" in data and data[:1] == b"Q":
                begin_seen[0] += 1
                if begin_seen[0] == drop_nth_begin:
                    src.sendall(_fake_begin_idle())
                    continue
            if hold and hold in data:
                time.sleep(delay_s)
            dst.sendall(data)
    except OSError:
        pass
    try:
        dst.shutdown(socket.SHUT_WR)
    except OSError:
        pass


def _pipe_s2c(src: socket.socket, dst: socket.socket) -> None:
    try:
        while True:
            data = src.recv(65536)
            if not data:
                break
            dst.sendall(data)
    except OSError:
        pass
    try:
        dst.shutdown(socket.SHUT_WR)
    except OSError:
        pass


def serve(
    listen: socket.socket,
    pghost: str,
    pgport: int,
    hold: bytes | None,
    delay_s: float,
    drop_nth_begin: int,
) -> None:
    while True:
        try:
            client, _ = listen.accept()
        except OSError:
            return
        backend = socket.create_connection((pghost, int(pgport)))
        begin_seen = [0]
        threading.Thread(
            target=_pipe_c2s,
            args=(client, backend, hold, delay_s, drop_nth_begin, begin_seen),
            daemon=True,
        ).start()
        threading.Thread(target=_pipe_s2c, args=(backend, client), daemon=True).start()


def start(
    pghost: str,
    pgport: str | int,
    hold: str | None = "SAVEPOINT copy",
    delay_s: float = 0.08,
    drop_nth_begin: int = 0,
):
    """Listen on 127.0.0.1:0. drop_nth_begin=2 eats commit_schema's BEGIN."""
    ls = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    ls.bind(("127.0.0.1", 0))
    ls.listen(8)
    port = ls.getsockname()[1]
    t = threading.Thread(
        target=serve,
        args=(
            ls,
            pghost,
            int(pgport),
            hold.encode() if hold else None,
            delay_s,
            drop_nth_begin,
        ),
        daemon=True,
    )
    t.start()

    def stop() -> None:
        try:
            ls.close()
        except OSError:
            pass

    return port, stop
