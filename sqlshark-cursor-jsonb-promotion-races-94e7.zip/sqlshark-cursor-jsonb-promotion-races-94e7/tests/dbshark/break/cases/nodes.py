"""Added for this catalog: 1 / 2 / 3 concurrent dbshark nodes, same mixed pcap."""
from __future__ import annotations

import pcapgen
from cases import ProcResult, register


def _mixed(h, n=80):
    p = h.work / f"nodes_{n}.pcap"
    pcapgen.write_pcap(p, pcapgen.messy_burst(n, include_trunc=False))
    return p


@register(
    id="nodes_1_mixed",
    family="nodes",
    stop_site="copy_flush_table",
    notes="added for this catalog: one process mixed burst (control)",
)
def case_one(h):
    return h.ingest(_mixed(h, 60), nodes=1, timeout=90)


@register(
    id="nodes_2_mixed",
    family="nodes",
    stop_site="pg_exec_ddl",
    notes="added for this catalog: two processes, same mixed pcap, same DB, start together",
)
def case_two(h):
    return h.ingest(_mixed(h, 60), nodes=2, timeout=120)


@register(
    id="nodes_3_mixed",
    family="nodes",
    stop_site="pg_exec_ddl",
    notes="added for this catalog: three processes start together (CREATE/ALTER/COPY)",
)
def case_three(h):
    return h.ingest(_mixed(h, 60), nodes=3, timeout=180)


@register(
    id="nodes_3_stagger",
    family="nodes",
    stop_site="pg_exec_ddl",
    notes="added for this catalog: three processes stagger 0/50/200 ms",
)
def case_stagger(h):
    return h.ingest(_mixed(h, 60), nodes=3, stagger_ms=[0, 50, 200], timeout=180)


@register(
    id="nodes_3_mismatched_flags",
    family="nodes",
    stop_site="ensure_table_exists",
    notes="added for this catalog: --unlogged vs --packet-local vs default on one DB",
)
def case_flags(h):
    got = h.ingest(
        _mixed(h, 40),
        nodes=3,
        proto_args=["-p", "dis", "-p", "dns"],
        node_args=[["--unlogged"], ["--packet-local"], []],
        timeout=180,
    )
    persistence = h.persistence()
    logs = str(got.get("logs") or "")
    findings = []
    if "not a permanent logged table" in logs:
        fate = "quarantined those rows" if "quarantined" in logs else "dropped those rows"
        findings.append(f"logged node refused an unlogged heap and {fate}")
    if "u=" in str(persistence) and "p=" in str(persistence):
        findings.append(f"mixed logged and unlogged heaps ({persistence})")
    got = dict(got)
    got["persistence"] = persistence
    got["findings"] = findings
    got["notes"] = (
        "added for this catalog: --unlogged vs --packet-local vs default; "
        f"rows={got.get('rows')} persistence={persistence}. "
        "Whoever creates the heap decides the count: an unlogged creator makes "
        "the other nodes quarantine their rows for those tables (exit 3); "
        "a logged creator lets --unlogged write in."
    )
    return got


@register(
    id="nodes_unlogged_heap_then_others",
    family="nodes",
    stop_site="ensure_table_exists",
    notes="added for this catalog: unlogged heap first, then default and --packet-local add nothing",
)
def case_unlogged_heap_then_others(h):
    """Concurrent mismatched flags swing (71 vs 213 on the same pcap) because
    CREATE is a race. Start --unlogged to completion, then the other two modes."""
    p = _mixed(h, 20)
    first = h.ingest(p, args=["--unlogged"], timeout=90)
    rows_u = first.get("rows", 0)
    persistence = h.persistence()
    others = h.ingest(
        p,
        nodes=2,
        node_args=[["--packet-local"], []],
        timeout=180,
    )
    after = others.get("rows", 0)
    logs = str(others.get("logs") or "")
    findings = []
    if rows_u <= 0:
        findings.append("unlogged leader committed no rows")
    if not str(persistence).startswith("u=") or "p=" in str(persistence):
        findings.append(f"leader did not leave only unlogged heaps ({persistence})")
    if "not a permanent logged table" not in logs:
        findings.append("later nodes did not refuse the unlogged heap")
    if after != rows_u:
        findings.append(f"later nodes changed the row count ({rows_u} -> {after})")
    needles = list(
        dict.fromkeys(first.get("error_needles", []) + others.get("error_needles", []))
    )
    return {
        "rc": [first.get("rc"), others.get("rc")],
        "outcome": _worst(
            [
                first.get("outcome") or "harness_error",
                others.get("outcome") or "harness_error",
            ]
        ),
        "error_needles": needles,
        "rows": after,
        "persistence": persistence,
        "findings": findings,
        "logs": "\n---\n".join(
            str(part.get("logs") or "") for part in (first, others)
        )[-8000:],
        "notes": (
            "added for this catalog: unlogged heap, then --packet-local and default; "
            f"unlogged_rows={rows_u} after_others={after} persistence={persistence}"
        ),
    }


@register(
    id="nodes_3_mismatched_p",
    family="nodes",
    stop_site="build_tables_for_proto",
    notes="added for this catalog: dis-only vs dns+ntp vs full mix, same DB",
)
def case_psubset(h):
    p = _mixed(h, 50)
    # ingest() applies the same proto_args to every node. Run three
    # processes ourselves so -p subsets differ.
    import time
    import subprocess

    cmds = [
        ["-r", str(p), "-p", "dis"],
        ["-r", str(p), "-p", "dns", "-p", "ntp"],
        ["-r", str(p), "-p", "dis", "-p", "dns", "-p", "ntp", "-p", "syslog", "-p", "coap"],
    ]
    e = h.env()
    procs = []
    t0 = time.monotonic()
    for extra in cmds:
        argv = h.dbshark_cmd(extra)
        procs.append(
            subprocess.Popen(
                argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=e, text=True
            )
        )
    results = []
    for pproc, extra in zip(procs, cmds):
        try:
            remain = max(1.0, 180.0 - (time.monotonic() - t0))
            text, _ = pproc.communicate(timeout=remain)
            timed = False
        except subprocess.TimeoutExpired:
            pproc.kill()
            text, _ = pproc.communicate()
            timed = True
        results.append(
            ProcResult(
                rc=pproc.returncode,
                log=text or "",
                timed_out=timed,
                killed=timed,
                argv=extra,
            )
        )
    return h.pack(results)


def _worst(outcomes: list[str]) -> str:
    rank = {"harness_error": 3, "crashed": 2, "exited": 1, "stayed_up": 0}
    return max(outcomes, key=lambda o: rank.get(o, 0)) if outcomes else "harness_error"


@register(
    id="nodes_count_parity",
    family="nodes",
    stop_site="seal_batch",
    notes="added for this catalog: one node, three at once, and three staggered must commit the same rows per node",
)
def case_parity(h):
    """The mixed run used to stay up and still drop two rows the stagger kept."""
    p = h.work / "parity20.pcap"
    pcapgen.write_pcap(p, pcapgen.messy_burst(20, include_trunc=False))
    one = h.ingest(p, timeout=90)
    rows_one = one.get("rows", 0)
    h.reset_case_db("nodes_count_parity")
    mixed = h.ingest(p, nodes=3, timeout=180)
    rows_mixed = mixed.get("rows", 0)
    h.reset_case_db("nodes_count_parity")
    stagger = h.ingest(p, nodes=3, stagger_ms=[0, 50, 200], timeout=180)
    rows_stagger = stagger.get("rows", 0)
    findings = []
    if rows_one <= 0:
        findings.append("single node committed no rows")
    if rows_mixed != rows_one * 3:
        findings.append(f"mixed {rows_mixed} != 3 x single {rows_one}")
    if rows_stagger != rows_mixed:
        findings.append(f"stagger {rows_stagger} != mixed {rows_mixed}")
    needles = list(
        dict.fromkeys(
            one.get("error_needles", [])
            + mixed.get("error_needles", [])
            + stagger.get("error_needles", [])
        )
    )
    return {
        "rc": [one.get("rc"), mixed.get("rc"), stagger.get("rc")],
        "outcome": _worst(
            [
                one.get("outcome") or "harness_error",
                mixed.get("outcome") or "harness_error",
                stagger.get("outcome") or "harness_error",
            ]
        ),
        "node_outcomes": [
            one.get("outcome"),
            mixed.get("outcome"),
            stagger.get("outcome"),
        ],
        "error_needles": needles,
        "rows": rows_stagger,
        "findings": findings,
        "logs": "\n---\n".join(
            str(part.get("logs") or "") for part in (one, mixed, stagger)
        )[-8000:],
        "notes": f"single={rows_one} mixed={rows_mixed} stagger={rows_stagger}"
        + (
            "; jsonb version 0 was retried and the row count still matched"
            if any("unsupported jsonb version" in n for n in needles) and not findings
            else ""
        ),
    }
