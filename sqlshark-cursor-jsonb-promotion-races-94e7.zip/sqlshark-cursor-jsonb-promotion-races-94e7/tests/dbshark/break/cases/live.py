"""Added for this catalog: live capture family. Skipped without CAP_NET_RAW."""
from __future__ import annotations

import socket
import subprocess
import time

import pcapgen
from cases import ProcResult, register


def _send_udp(payload: bytes, dport: int, host: str = "127.0.0.1") -> None:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.sendto(payload, (host, dport))
    finally:
        s.close()


def _run_live(h, bpf: str, send_fn, wait_before: float, extra: list[str] | None = None, hold: float = 1.0):
    args = ["-i", "lo", "-f", bpf, "-p", "dis", "-p", "dns"]
    if extra:
        args += extra
    argv = h.dbshark_cmd(args)
    proc = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=h.env(),
        text=True,
    )
    time.sleep(max(0.3, wait_before))
    try:
        send_fn()
    except OSError as exc:
        proc.send_signal(15)
        text, _ = proc.communicate(timeout=10)
        return h.pack(
            [
                ProcResult(
                    rc=proc.returncode,
                    log=(text or "") + f"\nsend failed: {exc}",
                    timed_out=False,
                    killed=True,
                    argv=argv,
                )
            ]
        )
    time.sleep(hold)
    if proc.poll() is None:
        proc.send_signal(15)
    try:
        text, _ = proc.communicate(timeout=20)
        timed = False
    except subprocess.TimeoutExpired:
        proc.kill()
        text, _ = proc.communicate()
        timed = True
    return h.pack(
        [
            ProcResult(
                rc=proc.returncode,
                log=text or "",
                timed_out=timed,
                killed=True,
                argv=argv,
            )
        ]
    )


@register(
    id="live_idle_then_first",
    family="live",
    stop_site="copy_flush_table",
    notes="added for this catalog: prod hint — idle_in_transaction kills startup BEGIN, then first packet",
    live=True,
)
def case_idle_first(h):
    h.psql(f"ALTER DATABASE {h.current_db} SET idle_in_transaction_session_timeout = '2s';")

    def send():
        _send_udp(pcapgen.dis_pdu("entity_state"), 39991)

    return _run_live(h, "udp port 39991", send, wait_before=3.2, hold=1.0)


@register(
    id="live_flood_small_buf",
    family="live",
    stop_site="on_pkt",
    notes="added for this catalog: flood vs --capture-buffer-mib 1",
    live=True,
)
def case_flood(h):
    pdu = pcapgen.dis_pdu("entity_state")

    def send():
        for _ in range(4000):
            _send_udp(pdu, 39992)

    return _run_live(
        h,
        "udp port 39992",
        send,
        wait_before=0.4,
        extra=["--capture-buffer-mib", "1"],
        hold=1.5,
    )


@register(
    id="live_trickle",
    family="live",
    stop_site="maybe_flush",
    notes="added for this catalog: a few packets with gaps (not a full 60s flush wait)",
    live=True,
)
def case_trickle(h):
    pdu = pcapgen.dis_pdu("entity_state")

    def send():
        for _ in range(3):
            _send_udp(pdu, 39993)
            time.sleep(0.4)

    return _run_live(h, "udp port 39993", send, wait_before=0.4, hold=1.0)


@register(
    id="live_nic_flap",
    family="live",
    stop_site="pcap_dispatch",
    notes="added for this catalog: iface down/up if we can (often needs root)",
    live=True,
)
def case_flap(h):
    args = ["-i", "lo", "-f", "udp port 39994", "-p", "dis"]
    argv = h.dbshark_cmd(args)
    proc = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=h.env(),
        text=True,
    )
    time.sleep(0.4)
    _send_udp(pcapgen.dis_pdu("entity_state"), 39994)
    down = subprocess.run(["ip", "link", "set", "lo", "down"], capture_output=True, text=True)
    time.sleep(0.2)
    subprocess.run(["ip", "link", "set", "lo", "up"], capture_output=True)
    time.sleep(0.2)
    try:
        _send_udp(pcapgen.dis_pdu("entity_state"), 39994)
    except OSError:
        pass
    if proc.poll() is None:
        proc.send_signal(15)
    try:
        text, _ = proc.communicate(timeout=15)
        timed = False
    except subprocess.TimeoutExpired:
        proc.kill()
        text, _ = proc.communicate()
        timed = True
    note = ""
    if down.returncode != 0:
        note = f" ip link down failed ({(down.stderr or '').strip()}); recorded anyway"
    pr = ProcResult(
        rc=proc.returncode,
        log=(text or "") + note,
        timed_out=timed,
        killed=True,
        argv=argv,
    )
    packed = h.pack([pr])
    packed["notes"] = "added for this catalog: lo down/up" + note
    return packed
