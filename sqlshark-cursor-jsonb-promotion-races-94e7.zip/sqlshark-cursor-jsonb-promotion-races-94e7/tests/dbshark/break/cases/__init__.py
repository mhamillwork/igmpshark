"""Added for this catalog: case registry. Each module calls register()."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


@dataclass
class ProcResult:
    """Added for this catalog: one dbshark process outcome (lives here so cases do not re-import catalog)."""

    rc: int | None
    log: str
    timed_out: bool
    killed: bool
    argv: list[str]


@dataclass
class Case:
    id: str
    family: str
    stop_site: str
    notes: str
    live: bool
    run: Callable


CASES: list[Case] = []


def register(id: str, family: str, stop_site: str, notes: str = "", live: bool = False):
    """Added for this catalog: decorator. id is the report key and the DB suffix."""

    def deco(fn: Callable) -> Callable:
        CASES.append(
            Case(
                id=id,
                family=family,
                stop_site=stop_site,
                notes=notes,
                live=live,
                run=fn,
            )
        )
        return fn

    return deco
