"""Added for this catalog: production Postgres mishaps (GUCs, DBA, kill, privileges)."""
from __future__ import annotations

import subprocess
import time

import pcapgen
from cases import ProcResult, register


def _mix(h, n=40):
    p = h.work / f"pg_{n}.pcap"
    pcapgen.write_pcap(p, pcapgen.messy_burst(n, include_trunc=False, include_garbage=False))
    return p


@register(
    id="pg_lock_timeout",
    family="pg",
    stop_site="pg_exec_ddl",
    notes="added for this catalog: lock_timeout=1ms during first ALTER",
)
def case_lock_timeout(h):
    h.psql(f"ALTER DATABASE {h.current_db} SET lock_timeout = '1ms';")
    return h.ingest(_mix(h, 20), proto_args=["-p", "dis", "-p", "dns"])


@register(
    id="pg_idle_in_txn_timeout_offline",
    family="pg",
    stop_site="pg_exec",
    notes="added for this catalog: idle_in_transaction_session_timeout=1s; -r is too fast to trip",
)
def case_idle_offline(h):
    h.psql(f"ALTER DATABASE {h.current_db} SET idle_in_transaction_session_timeout = '1s';")
    return h.ingest(_mix(h, 15))


@register(
    id="pg_max_locks",
    family="pg",
    stop_site="pg_exec_ddl",
    notes="added for this catalog: ALTER DATABASE cannot set max_locks; use many columns via mix",
)
def case_max_locks(h):
    # Cluster GUC needs restart. We still run a wide mixed ingest so lock
    # use is high; reset_pg.pl puts max_locks_per_transaction back to 64.
    return h.ingest(_mix(h, 80), proto_args=["-p", "dis", "-p", "dns", "-p", "ntp"])


@register(
    id="pg_datconnlimit",
    family="pg",
    stop_site="main connect",
    notes="added for this catalog: CONNECTION LIMIT 0 — connect refuse on first message",
)
def case_connlimit(h):
    # Superuser bypasses CONNECTION LIMIT. Use a login role like prod apps.
    h.psql("DROP ROLE IF EXISTS break_conn;")
    h.psql("CREATE ROLE break_conn LOGIN PASSWORD 'conn';")
    h.psql(f"GRANT CONNECT ON DATABASE {h.current_db} TO break_conn;")
    h.psql("GRANT ALL ON SCHEMA public TO break_conn;")
    h.psql(f"ALTER DATABASE {h.current_db} CONNECTION LIMIT 0;")
    conn = (
        f"host={h.pghost} port={h.pgport} user=break_conn "
        f"password=conn dbname={h.current_db}"
    )
    return h.ingest(_mix(h, 5), proto_args=["-p", "dis"], conn=conn)


@register(
    id="pg_terminate_backend",
    family="pg",
    stop_site="pg_ok",
    notes="added for this catalog: drop the TCP session mid -r",
)
def case_terminate(h):
    p = _mix(h, 80)
    argv = h.dbshark_cmd(["-r", str(p), "-p", "dis", "-p", "dns"])
    proc = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=h.env(),
        text=True,
    )
    time.sleep(1.2)
    h.psql(
        "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
        f"WHERE datname = '{h.current_db}' AND pid <> pg_backend_pid();",
        db="postgres",
    )
    try:
        text, _ = proc.communicate(timeout=30)
        timed = False
    except subprocess.TimeoutExpired:
        proc.kill()
        text, _ = proc.communicate()
        timed = True
    from cases import ProcResult

    return h.pack(
        [
            ProcResult(
                rc=proc.returncode,
                log=text or "",
                timed_out=timed,
                killed=timed,
                argv=argv,
            )
        ]
    )


@register(
    id="pg_kill_postgres",
    family="pg",
    stop_site="pg_ok",
    notes="added for this catalog: SIGKILL the catalog postgres mid-ingest, then restart",
)
def case_kill_pg(h):
    p = _mix(h, 80)
    argv = h.dbshark_cmd(["-r", str(p), "-p", "dis"])
    proc = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=h.env(),
        text=True,
    )
    time.sleep(0.8)
    try:
        h.pg_crash()
    except RuntimeError:
        proc.kill()
        proc.communicate()
        raise
    try:
        text, _ = proc.communicate(timeout=20)
        timed = False
    except subprocess.TimeoutExpired:
        proc.kill()
        text, _ = proc.communicate()
        timed = True
    h.pg_start()
    try:
        h.ensure_pg()
    except RuntimeError:
        pass
    from cases import ProcResult

    return h.pack(
        [
            ProcResult(
                rc=proc.returncode,
                log=text or "",
                timed_out=timed,
                killed=timed,
                argv=argv,
            )
        ]
    )


@register(
    id="pg_wrong_ts_us_type",
    family="pg",
    stop_site="ensure_fixed_columns",
    notes="added for this catalog: pre-create dis.ts_us as TEXT",
)
def case_ts_text(h):
    h.psql(
        "CREATE TABLE dis (ts_us TEXT, src_ip TEXT, dst_ip TEXT, "
        "src_port INTEGER, dst_port INTEGER, frame_len INTEGER);"
    )
    p = h.work / "ts_text.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pg_json_not_jsonb",
    family="pg",
    stop_site="mark_existing_json_cols",
    notes="added for this catalog: json (not jsonb) column already on disk",
)
def case_json(h):
    h.psql(
        "CREATE TABLE dis (ts_us BIGINT, src_ip TEXT, dst_ip TEXT, "
        "src_port INTEGER, dst_port INTEGER, frame_len INTEGER, "
        "entity_id_site json);"
    )
    p = h.work / "json_not.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pg_extra_columns",
    family="pg",
    stop_site="refresh_from_disk",
    notes="added for this catalog: leftover DBA columns on the table",
)
def case_extra(h):
    h.psql(
        "CREATE TABLE dis (ts_us BIGINT, src_ip TEXT, dst_ip TEXT, "
        "src_port INTEGER, dst_port INTEGER, frame_len INTEGER, "
        "dba_note TEXT DEFAULT 'x');"
    )
    p = h.work / "extra_col.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pg_empty_search_path",
    family="pg",
    stop_site="main connect",
    notes="added for this catalog: search_path emptied (current_schema is NULL)",
)
def case_search_path(h):
    h.psql(f"ALTER DATABASE {h.current_db} SET search_path = '';")
    return h.ingest(_mix(h, 5), proto_args=["-p", "dis"])


@register(
    id="pg_no_create_schema",
    family="pg",
    stop_site="ensure_table_exists",
    notes="added for this catalog: login role can CONNECT but not CREATE",
)
def case_no_create(h):
    h.psql("DROP ROLE IF EXISTS break_limited;")
    h.psql("CREATE ROLE break_limited LOGIN PASSWORD 'limited';")
    h.psql(f"GRANT CONNECT ON DATABASE {h.current_db} TO break_limited;")
    h.psql("REVOKE ALL ON SCHEMA public FROM PUBLIC;")
    h.psql("REVOKE CREATE ON SCHEMA public FROM break_limited;")
    h.psql("GRANT USAGE ON SCHEMA public TO break_limited;")
    conn = (
        f"host={h.pghost} port={h.pgport} user=break_limited "
        f"password=limited dbname={h.current_db}"
    )
    return h.ingest(_mix(h, 8), proto_args=["-p", "dis"], conn=conn)


@register(
    id="pg_select_no_copy",
    family="pg",
    stop_site="copy_flush_table",
    notes="added for this catalog: SELECT granted, COPY/INSERT not",
)
def case_select_only(h):
    h.psql(
        "CREATE TABLE dis (ts_us BIGINT, src_ip TEXT, dst_ip TEXT, "
        "src_port INTEGER, dst_port INTEGER, frame_len INTEGER);"
    )
    h.psql("DROP ROLE IF EXISTS break_sel;")
    h.psql("CREATE ROLE break_sel LOGIN PASSWORD 'sel';")
    h.psql(f"GRANT CONNECT ON DATABASE {h.current_db} TO break_sel;")
    h.psql("GRANT USAGE ON SCHEMA public TO break_sel;")
    h.psql("GRANT SELECT ON ALL TABLES IN SCHEMA public TO break_sel;")
    conn = (
        f"host={h.pghost} port={h.pgport} user=break_sel "
        f"password=sel dbname={h.current_db}"
    )
    p = h.work / "sel.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"], conn=conn)


@register(
    id="pg_dba_alter_mid",
    family="pg",
    stop_site="copy_flush_table",
    notes="added for this catalog: DBA ALTER COLUMN type while ingest is running",
)
def case_dba_alter(h):
    p = _mix(h, 80)
    argv = h.dbshark_cmd(["-r", str(p), "-p", "dis", "-p", "dns"])
    proc = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=h.env(),
        text=True,
    )
    time.sleep(1.0)
    tables = h.public_tables()
    if tables:
        h.psql(f'ALTER TABLE "{tables[0]}" ALTER COLUMN ts_us TYPE TEXT;')
    try:
        text, _ = proc.communicate(timeout=40)
        timed = False
    except subprocess.TimeoutExpired:
        proc.kill()
        text, _ = proc.communicate()
        timed = True
    from cases import ProcResult

    return h.pack(
        [
            ProcResult(
                rc=proc.returncode,
                log=text or "",
                timed_out=timed,
                killed=timed,
                argv=argv,
            )
        ]
    )


@register(
    id="pg_temp_file_limit",
    family="pg",
    stop_site="copy_flush_table",
    notes="added for this catalog: temp_file_limit=64kB",
)
def case_temp_limit(h):
    h.psql(f"ALTER DATABASE {h.current_db} SET temp_file_limit = '64kB';")
    return h.ingest(_mix(h, 30))


@register(
    id="pg_not_null_extra",
    family="pg",
    stop_site="copy_flush_table",
    notes="added for this catalog: DBA extra NOT NULL column with no default — COPY omits it",
)
def case_not_null(h):
    h.psql(
        "CREATE TABLE dis (ts_us BIGINT, src_ip TEXT, dst_ip TEXT, "
        "src_port INTEGER, dst_port INTEGER, frame_len INTEGER, "
        "dba_required TEXT NOT NULL);"
    )
    p = h.work / "nn.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pg_unlogged_precreate",
    family="pg",
    stop_site="ensure_table_exists",
    notes="added for this catalog: DBA left UNLOGGED dis; default dbshark rejects",
)
def case_unlogged_pre(h):
    h.psql(
        "CREATE UNLOGGED TABLE dis (ts_us BIGINT, src_ip TEXT, dst_ip TEXT, "
        "src_port INTEGER, dst_port INTEGER, frame_len INTEGER);"
    )
    p = h.work / "ulog.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    got = h.ingest(p, proto_args=["-p", "dis"])
    dis_n = h.psql("SELECT count(*) FROM dis;")
    dis_pers = h.psql(
        "SELECT relpersistence::text FROM pg_class WHERE relname = 'dis';"
    )
    findings = []
    if dis_pers.strip() != "u":
        findings.append(f"precreated dis is no longer unlogged ({dis_pers.strip()})")
    if dis_n.strip() not in ("0", ""):
        findings.append(f"default dbshark wrote {dis_n.strip()} rows into unlogged dis")
    if "not a permanent logged table" not in str(got.get("logs") or ""):
        findings.append("default dbshark did not log the unlogged-heap refusal")
    got = dict(got)
    got["persistence"] = h.persistence()
    got["findings"] = findings
    got["notes"] = (
        "added for this catalog: precreated UNLOGGED dis is refused; "
        f"dis_rows={dis_n.strip()} sibling heaps may still be logged"
    )
    return got


@register(
    id="pg_table_is_view",
    family="pg",
    stop_site="copy_flush_table",
    notes="added for this catalog: name dis is a VIEW, not a base table",
)
def case_view(h):
    h.psql(
        "CREATE TABLE dis_heap (ts_us BIGINT, src_ip TEXT, dst_ip TEXT, "
        "src_port INTEGER, dst_port INTEGER, frame_len INTEGER);"
    )
    h.psql("CREATE VIEW dis AS SELECT * FROM dis_heap;")
    p = h.work / "view.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pg_rls_no_policy",
    family="pg",
    stop_site="copy_flush_table",
    notes="added for this catalog: RLS on, no policy, non-owner COPY",
)
def case_rls(h):
    h.psql(
        "CREATE TABLE dis (ts_us BIGINT, src_ip TEXT, dst_ip TEXT, "
        "src_port INTEGER, dst_port INTEGER, frame_len INTEGER);"
    )
    h.psql("ALTER TABLE dis ENABLE ROW LEVEL SECURITY;")
    h.psql("ALTER TABLE dis FORCE ROW LEVEL SECURITY;")
    h.psql("DROP ROLE IF EXISTS break_rls;")
    h.psql("CREATE ROLE break_rls LOGIN PASSWORD 'rls';")
    h.psql(f"GRANT CONNECT ON DATABASE {h.current_db} TO break_rls;")
    h.psql("GRANT USAGE ON SCHEMA public TO break_rls;")
    h.psql("GRANT INSERT, SELECT ON dis TO break_rls;")
    conn = (
        f"host={h.pghost} port={h.pgport} user=break_rls "
        f"password=rls dbname={h.current_db}"
    )
    p = h.work / "rls.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"], conn=conn)


@register(
    id="pg_drop_column_mid",
    family="pg",
    stop_site="copy_flush_table",
    notes="added for this catalog: DBA DROP COLUMN while COPY is listing it",
)
def case_drop_col(h):
    p = _mix(h, 60)
    argv = h.dbshark_cmd(["-r", str(p), "-p", "dis"])
    proc = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=h.env(),
        text=True,
    )
    time.sleep(1.0)
    tables = h.public_tables()
    if tables:
        cols = h.psql(
            f"SELECT column_name FROM information_schema.columns "
            f"WHERE table_name='{tables[0]}' AND column_name NOT IN "
            f"('ts_us','src_ip','dst_ip','src_port','dst_port','frame_len') LIMIT 1;"
        )
        if cols and not cols.startswith("__PSQL_ERR__"):
            h.psql(f'ALTER TABLE "{tables[0]}" DROP COLUMN "{cols.strip()}";')
    try:
        text, _ = proc.communicate(timeout=40)
        timed = False
    except subprocess.TimeoutExpired:
        proc.kill()
        text, _ = proc.communicate()
        timed = True
    return h.pack(
        [
            ProcResult(
                rc=proc.returncode,
                log=text or "",
                timed_out=timed,
                killed=timed,
                argv=argv,
            )
        ]
    )


@register(
    id="pg_lc_messages",
    family="pg",
    stop_site="copy_flush_table",
    notes="added for this catalog: non-C lc_messages — strstr jsonb version is English-only",
)
def case_lc(h):
    # Container may lack de_DE; C.UTF-8 still documents the GUC. Try German.
    h.psql(f"ALTER DATABASE {h.current_db} SET lc_messages = 'C';")
    loc = h.psql("SELECT EXISTS (SELECT 1 FROM pg_collation WHERE collname LIKE 'de_DE%');")
    if loc.strip() == "t":
        h.psql(f"ALTER DATABASE {h.current_db} SET lc_messages = 'de_DE.UTF-8';")
    p = h.work / "fire_es_lc.pcap"
    pcapgen.write_pcap(p, pcapgen.fire_then_es_frames())
    return h.ingest(p, proto_args=["-p", "dis"], nodes=2, timeout=90)


@register(
    id="pg_serializable_3node",
    family="pg",
    stop_site="pg_exec_ddl",
    notes="added for this catalog: serializable isolation + 3 nodes (40001 / 40P01)",
)
def case_serializable(h):
    # A snapshot that cannot see the other node's CREATE returns zero
    # rows from pg_class. ensure_table_exists treats that like an unlogged heap.
    # The overlap is a race, so try a few times and keep the hit.
    got = None
    hit_on = 0
    attempts = 4
    for attempt in range(1, attempts + 1):
        h.reset_case_db("pg_serializable_3node")
        h.psql(
            f"ALTER DATABASE {h.current_db} "
            f"SET default_transaction_isolation = 'serializable';"
        )
        got = h.ingest(
            _mix(h, 40), nodes=3, proto_args=["-p", "dis", "-p", "dns"], timeout=180
        )
        if "not a permanent logged table" in str(got.get("logs") or ""):
            hit_on = attempt
            break
    assert got is not None
    findings = []
    if hit_on:
        findings.append(
            "serializable snapshot hid a new table and dbshark treated it as unlogged"
        )
    got = dict(got)
    got["findings"] = findings
    got["notes"] = (
        "added for this catalog: serializable isolation + 3 nodes; "
        f"rows={got.get('rows')} attempts={hit_on or attempts} "
        f"reproduced={bool(hit_on)}"
    )
    return got
