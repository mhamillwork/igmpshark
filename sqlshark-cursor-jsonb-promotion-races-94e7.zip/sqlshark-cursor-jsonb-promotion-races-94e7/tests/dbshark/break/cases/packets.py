"""Added for this catalog: messy mixed-protocol pcaps aimed at process_packet / wtap."""
from __future__ import annotations

from pathlib import Path

import pcapgen
from cases import register


def _pcap(h, name: str) -> Path:
    p = h.work / f"{name}.pcap"
    return p


@register(
    id="pkt_mixed_burst",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: shuffled DIS+DNS+NTP+syslog+CoAP+garbage burst",
)
def case_mixed_burst(h):
    p = _pcap(h, "mixed_burst")
    pcapgen.write_pcap(p, pcapgen.messy_burst(120))
    return h.ingest(p)


@register(
    id="pkt_mixed_trickle",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: same mix, 2s gaps (production trickle)",
)
def case_mixed_trickle(h):
    p = _pcap(h, "mixed_trickle")
    frames = pcapgen.messy_burst(20, include_garbage=True)
    pcapgen.write_pcap(p, pcapgen.stamp(frames, "trickle"))
    return h.ingest(p, timeout=60)


@register(
    id="pkt_mixed_dup",
    family="packets",
    stop_site="copy_flush_table",
    notes="added for this catalog: every frame sent twice (replay / NIC dup)",
)
def case_mixed_dup(h):
    p = _pcap(h, "mixed_dup")
    frames = pcapgen.messy_burst(30, include_garbage=False, include_trunc=False)
    pcapgen.write_pcap(p, pcapgen.stamp(frames, "dup"))
    return h.ingest(p)


@register(
    id="pkt_mixed_backward_ts",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: timestamps go backwards (unsorted capture)",
)
def case_mixed_backward(h):
    p = _pcap(h, "mixed_back")
    frames = pcapgen.messy_burst(40, include_garbage=False)
    pcapgen.write_pcap(p, pcapgen.stamp(frames, "backward"))
    return h.ingest(p)


@register(
    id="pkt_clock_jump",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: mid-file clock jump of one hour",
)
def case_clock_jump(h):
    p = _pcap(h, "clock_jump")
    frames = pcapgen.messy_burst(24, include_garbage=False)
    pcapgen.write_pcap(p, pcapgen.stamp(frames, "clock_jump"))
    return h.ingest(p)


@register(
    id="pkt_truncated_bodies",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: snaplen cut through IP/UDP/body",
)
def case_trunc_bodies(h):
    p = _pcap(h, "trunc_bodies")
    pcapgen.write_pcap(
        p,
        pcapgen.messy_burst(40, include_trunc=True, include_garbage=False, include_v6=False),
    )
    return h.ingest(p)


@register(
    id="pkt_caplen_gt_len",
    family="packets",
    stop_site="process_packet caplen",
    notes="added for this catalog: caplen>len stops the whole run today",
)
def case_caplen(h):
    p = _pcap(h, "caplen_gt_len")
    pcapgen.write_pcap(p, pcapgen.frames_caplen_gt_len())
    return h.ingest(p)


@register(
    id="pkt_legal_after_garbage",
    family="packets",
    stop_site="process_packet caplen",
    notes="added for this catalog: junk then bad caplen then legal DIS; legal never lands",
)
def case_legal_after(h):
    p = _pcap(h, "legal_after")
    pcapgen.write_pcap(p, pcapgen.legal_after_garbage_frames())
    return h.ingest(p)


@register(
    id="pkt_empty_udp",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: zero-payload UDP on DIS/DNS ports",
)
def case_empty_udp(h):
    p = _pcap(h, "empty_udp")
    frames = []
    for i, dport in enumerate((3000, 53, 123, 514, 5683)):
        fr = pcapgen.frame_udp(b"", dport=dport)
        frames.append((pcapgen.T0_US + i * 1000, fr, len(fr)))
    pcapgen.write_pcap(p, frames)
    return h.ingest(p)


@register(
    id="pkt_ip_fragments",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: two IPv4 fragments of one DIS UDP",
)
def case_frags(h):
    p = _pcap(h, "frags")
    pcapgen.write_pcap(p, pcapgen.fragment_frames(missing_second=False))
    return h.ingest(p)


@register(
    id="pkt_ip_fragments_missing",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: first fragment only (second never arrives)",
)
def case_frags_miss(h):
    p = _pcap(h, "frags_miss")
    pcapgen.write_pcap(p, pcapgen.fragment_frames(missing_second=True))
    return h.ingest(p)


@register(
    id="pkt_ipv6",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: IPv6 UDP mix",
)
def case_v6(h):
    p = _pcap(h, "v6")
    pcapgen.write_pcap(
        p,
        pcapgen.messy_burst(30, include_v6=True, include_garbage=False, include_vlan=False),
    )
    return h.ingest(p)


@register(
    id="pkt_vlan",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: 802.1Q tagged frames",
)
def case_vlan(h):
    p = _pcap(h, "vlan")
    pcapgen.write_pcap(
        p,
        pcapgen.messy_burst(30, include_vlan=True, include_garbage=False, include_v6=False),
    )
    return h.ingest(p)


@register(
    id="pkt_empty_file",
    family="packets",
    stop_site="wtap_open_offline",
    notes="added for this catalog: pcap global header only",
)
def case_empty_file(h):
    p = _pcap(h, "empty")
    pcapgen.write_empty_pcap(p)
    return h.ingest(p)


@register(
    id="pkt_truncated_file",
    family="packets",
    stop_site="wtap_read",
    notes="added for this catalog: cut-off pcap (incomplete record is an error)",
)
def case_trunc_file(h):
    p = _pcap(h, "trunc_file")
    pcapgen.write_truncated_pcap(p)
    return h.ingest(p)


@register(
    id="pkt_pcapng",
    family="packets",
    stop_site="process_file",
    notes="added for this catalog: same mix in pcapng (SHB+IDB+EPB)",
)
def case_pcapng(h):
    p = h.work / "mixed.pcapng"
    pcapgen.write_pcapng(p, pcapgen.messy_burst(40, include_garbage=False))
    return h.ingest(p)


@register(
    id="pkt_huge_signal",
    family="packets",
    stop_site="copy_flush_table",
    notes="added for this catalog: large DIS Signal variable data",
)
def case_huge(h):
    p = _pcap(h, "huge_sig")
    fr = pcapgen.frame_udp(pcapgen.huge_signal(4000), dport=3000)
    pcapgen.write_pcap(p, [(pcapgen.T0_US, fr, len(fr))])
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pkt_fire_then_es",
    family="packets",
    stop_site="promote_col_to_json",
    notes="added for this catalog: Fire (lists) then Entity State (singles) in one file",
)
def case_fire_es(h):
    p = _pcap(h, "fire_es")
    pcapgen.write_pcap(p, pcapgen.fire_then_es_frames())
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pkt_dns_many_answers",
    family="packets",
    stop_site="maybe_promote_bucket",
    notes="added for this catalog: n_hit > HIT_INLINE (4) on one DNS column",
)
def case_dns_many(h):
    p = _pcap(h, "dns_many")
    pcapgen.write_pcap(p, pcapgen.one_dns_frame(many=True))
    return h.ingest(p, proto_args=["-p", "dns"])


@register(
    id="pkt_qinq",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: QinQ (802.1ad+802.1Q) around DIS — two tags, not one VLAN",
)
def case_qinq(h):
    p = _pcap(h, "qinq")
    fr = pcapgen.frame_qinq(pcapgen.dis_pdu("entity_state"), dport=3000)
    pcapgen.write_pcap(p, [(pcapgen.T0_US, fr, len(fr))])
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pkt_gre_tunnel",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: GRE-encapsulated DIS; hidden tree may not reach inner proto",
)
def case_gre(h):
    p = _pcap(h, "gre")
    fr = pcapgen.frame_gre_udp(pcapgen.dis_pdu("entity_state"), dport=3000)
    pcapgen.write_pcap(p, [(pcapgen.T0_US, fr, len(fr))])
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pkt_linux_sll",
    family="packets",
    stop_site="wtap_open_offline",
    notes="added for this catalog: DLT_LINUX_SLL (tcpdump -i any) offline",
)
def case_sll(h):
    p = _pcap(h, "sll")
    fr = pcapgen.frame_sll_udp(pcapgen.dis_pdu("entity_state"), 3000)
    pcapgen.write_pcap_dlt(p, pcapgen.DLT_LINUX_SLL, [(pcapgen.T0_US, fr, len(fr))])
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pkt_nsec_pcap",
    family="packets",
    stop_site="process_file",
    notes="added for this catalog: nanosecond pcap magic — ts_us must not be 1000x wrong",
)
def case_nsec(h):
    p = _pcap(h, "nsec")
    pcapgen.write_pcap_ns(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pkt_tiny_eth",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: 8-byte runt, shorter than an Ethernet header",
)
def case_tiny(h):
    p = _pcap(h, "tiny")
    fr = pcapgen.frame_tiny_eth()
    pcapgen.write_pcap(p, [(pcapgen.T0_US, fr, len(fr))])
    return h.ingest(p)


@register(
    id="pkt_snaplen_zero",
    family="packets",
    stop_site="wtap_open_offline",
    notes="added for this catalog: pcap snaplen=0 (every packet captured as empty)",
)
def case_snap0(h):
    p = _pcap(h, "snap0")
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"), snaplen=0)
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pkt_ts_epoch_and_far_future",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: ts=0 and year-2106 in one file",
)
def case_ts_edge(h):
    p = _pcap(h, "ts_edge")
    a = pcapgen.frame_udp(pcapgen.dis_pdu("entity_state"), dport=3000)
    b = pcapgen.frame_udp(pcapgen.dis_pdu("fire"), dport=3000)
    # 2106-02-07 is near uint32 epoch overflow.
    pcapgen.write_pcap(p, [(0, a, len(a)), (4_102_444_800_000_000, b, len(b))])
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pkt_nan_inf_double",
    family="packets",
    stop_site="copy_flush_table",
    notes="added for this catalog: DIS ECEF NaN/Inf — binary COPY of DOUBLE PRECISION",
)
def case_nan(h):
    p = _pcap(h, "nan")
    fr = pcapgen.frame_udp(pcapgen.dis_nan_inf(), dport=3000)
    pcapgen.write_pcap(p, [(pcapgen.T0_US, fr, len(fr))])
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="pkt_syslog_nul_utf8",
    family="packets",
    stop_site="copy_flush_table",
    notes="added for this catalog: syslog with embedded NUL, invalid UTF-8, 4k line",
)
def case_syslog_ugly(h):
    p = _pcap(h, "syslog_ugly")
    fr = pcapgen.frame_udp(pcapgen.syslog_hostile(), dport=514)
    pcapgen.write_pcap(p, [(pcapgen.T0_US, fr, len(fr))])
    return h.ingest(p, proto_args=["-p", "syslog"])


@register(
    id="pkt_dns_compression_loop",
    family="packets",
    stop_site="epan_dissect_run",
    notes="added for this catalog: DNS QNAME pointer to itself (name-loop)",
)
def case_dns_loop(h):
    p = _pcap(h, "dns_loop")
    fr = pcapgen.frame_udp(pcapgen.dns_compression_loop(), dport=53)
    pcapgen.write_pcap(p, [(pcapgen.T0_US, fr, len(fr))])
    return h.ingest(p, proto_args=["-p", "dns"], timeout=20)


@register(
    id="pkt_dns_64_answers",
    family="packets",
    stop_site="bucket_fi",
    notes="added for this catalog: 64 RR on one column — extra[] growth past HIT_INLINE",
)
def case_dns_64(h):
    p = _pcap(h, "dns64")
    fr = pcapgen.frame_udp(pcapgen.dns_response_many_a(n=64), dport=53)
    pcapgen.write_pcap(p, [(pcapgen.T0_US, fr, len(fr))])
    return h.ingest(p, proto_args=["-p", "dns"])


@register(
    id="pkt_packet_local_frags",
    family="packets",
    stop_site="process_packet",
    notes="added for this catalog: --packet-local disables reassembly; fragments stay broken",
)
def case_pl_frags(h):
    p = _pcap(h, "pl_frags")
    pcapgen.write_pcap(p, pcapgen.fragment_frames(missing_second=False))
    return h.ingest(p, proto_args=["-p", "dis"], args=["--packet-local"])


@register(
    id="pkt_select_eth",
    family="packets",
    stop_site="build_tables_for_proto",
    notes="added for this catalog: -p eth (thousands of fields / column pressure)",
)
def case_eth(h):
    p = _pcap(h, "eth")
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "eth"], timeout=90)
