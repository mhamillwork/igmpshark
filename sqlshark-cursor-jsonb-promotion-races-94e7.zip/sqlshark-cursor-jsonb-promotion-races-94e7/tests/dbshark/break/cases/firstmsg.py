"""Added for this catalog: first-message COPY savepoint path (production hint).

Startup BEGIN → schema_dirty=1 → SAVEPOINT ddl → commit_schema
COMMIT+BEGIN → SAVEPOINT copy + binary COPY of that one row.
"""
from __future__ import annotations

import libpq_gap
import pcapgen
from cases import register


@register(
    id="first_cold_one_frame",
    family="firstmsg",
    stop_site="copy_flush_table",
    notes="added for this catalog: empty DB, one DIS Entity State (exact first-message path)",
)
def case_cold(h):
    p = h.work / "first_cold.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="first_cold_mixed_one_each",
    family="firstmsg",
    stop_site="copy_flush_table",
    notes="added for this catalog: one frame per mixed proto so several COPY savepoints",
)
def case_one_each(h):
    p = h.work / "first_each.pcap"
    pcapgen.write_pcap(p, pcapgen.one_each_proto_frames())
    return h.ingest(p)


@register(
    id="first_repeated_field",
    family="firstmsg",
    stop_site="copy_flush_table",
    notes="added for this catalog: first ADD COLUMN is JSONB (n_hit>1) then first COPY is jsonb",
)
def case_repeated(h):
    p = h.work / "first_rep.pcap"
    # Articulated ES repeats VP fields; DNS many-A is the explicit n_hit>1.
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state_articulated"))
    return h.ingest(p, proto_args=["-p", "dis"])


@register(
    id="first_warm_jsonb_then_es",
    family="firstmsg",
    stop_site="copy_flush_table",
    notes="added for this catalog: prod restart — Fire warms JSONB, new process one ES",
)
def case_warm_jsonb(h):
    warm = h.work / "warm_fire.pcap"
    pcapgen.write_pcap(warm, pcapgen.one_dis_frame("fire"))
    first = h.ingest(warm, proto_args=["-p", "dis"])
    cold = h.work / "warm_es.pcap"
    pcapgen.write_pcap(cold, pcapgen.one_dis_frame("entity_state"))
    # New process, same DB (do not reset). This is the jsonb version 0 path
    # if is_json is stale; savepoint retries or exits.
    second = h.ingest(cold, proto_args=["-p", "dis"])
    needles = list(dict.fromkeys(first.get("error_needles", []) + second.get("error_needles", [])))
    return {
        "rc": [first.get("rc"), second.get("rc")],
        "outcome": second.get("outcome") or first.get("outcome"),
        "error_needles": needles,
        "rows": second.get("rows", 0),
        "tables": second.get("tables", []),
        "notes": "added for this catalog: warm Fire then new-process ES",
    }


@register(
    id="first_one_pdu_multi_table",
    family="firstmsg",
    stop_site="commit_schema",
    notes="added for this catalog: one DIS PDU, split-depth 2, several subtables / COPY savepoints",
)
def case_multi_table(h):
    p = h.work / "first_multi.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"], args=["--split-depth", "2"])


@register(
    id="first_statement_timeout",
    family="firstmsg",
    stop_site="copy_flush_table",
    notes="added for this catalog: statement_timeout=1ms on the first SAVEPOINT copy / COPY",
)
def case_stmt_timeout(h):
    h.psql(f"ALTER DATABASE {h.current_db} SET statement_timeout = '1ms';")
    p = h.work / "first_stmt.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    got = h.ingest(p, proto_args=["-p", "dis"])
    logs = str(got.get("logs") or "")
    findings = []
    if got.get("rows", 0) <= 0 and "dropping rows" in logs:
        findings.append(
            "statement_timeout cancelled DDL and the open batch was dropped"
        )
    got = dict(got)
    got["findings"] = findings
    return got


@register(
    id="first_read_only",
    family="firstmsg",
    stop_site="pg_exec_ddl",
    notes="added for this catalog: default_transaction_read_only on first CREATE/COPY",
)
def case_ro(h):
    h.psql(f"ALTER DATABASE {h.current_db} SET default_transaction_read_only = on;")
    p = h.work / "first_ro.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"])


def _through_proxy(h, **proxy_kw):
    port, stop = libpq_gap.start(h.pghost, h.pgport, **proxy_kw)
    try:
        p = h.work / "first_gap.pcap"
        pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
        conn = (
            f"host=127.0.0.1 port={port} user={h.pguser} "
            f"password={h.pgpassword} dbname={h.current_db}"
        )
        return h.ingest(p, proto_args=["-p", "dis"], conn=conn, timeout=30)
    finally:
        stop()


@register(
    id="first_copy_savepoint_idle_gap",
    family="firstmsg",
    stop_site="copy_flush_table",
    notes="added for this catalog: replicate postgres copy savepoint — idle after commit_schema BEGIN, then SAVEPOINT copy",
)
def case_copy_sp_idle(h):
    h.psql(
        f"ALTER DATABASE {h.current_db} "
        f"SET idle_in_transaction_session_timeout = '20ms';"
    )
    return _through_proxy(h, hold="SAVEPOINT copy", delay_s=0.08)


@register(
    id="first_copy_savepoint_no_txn",
    family="firstmsg",
    stop_site="copy_flush_table",
    notes="added for this catalog: commit_schema COMMIT, swallow the following BEGIN, SAVEPOINT copy runs outside a txn",
)
def case_copy_sp_no_txn(h):
    # First BEGIN (process_file) is forwarded. Second BEGIN (commit_schema)
    # is ACKed to the client as Idle so the server has already committed.
    return _through_proxy(h, hold=None, delay_s=0.0, drop_nth_begin=2)
