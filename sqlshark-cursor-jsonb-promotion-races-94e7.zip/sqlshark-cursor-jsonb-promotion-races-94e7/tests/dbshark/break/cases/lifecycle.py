"""Added for this catalog: kill/rerun, unlogged second start, bad argv."""
from __future__ import annotations

import signal
import subprocess

import pcapgen
from cases import ProcResult, register


def _mix(h, n=50):
    p = h.work / f"life_{n}.pcap"
    pcapgen.write_pcap(p, pcapgen.messy_burst(n, include_trunc=False))
    return p


@register(
    id="life_sigterm_mid",
    family="lifecycle",
    stop_site="finish_txn",
    notes="added for this catalog: SIGTERM mid-file then start again on the same DB",
)
def case_sigterm(h):
    p = _mix(h, 80)
    first = h.ingest(p, proto_args=["-p", "dis", "-p", "dns"], kill_after=0.8, timeout=40)
    second = h.ingest(p, proto_args=["-p", "dis", "-p", "dns"], timeout=60)
    needles = list(dict.fromkeys(first.get("error_needles", []) + second.get("error_needles", [])))
    return {
        "rc": [first.get("rc"), second.get("rc")],
        "outcome": second.get("outcome"),
        "error_needles": needles,
        "rows": second.get("rows", 0),
        "notes": "added for this catalog: SIGTERM then rerun",
    }


@register(
    id="life_sigkill_mid",
    family="lifecycle",
    stop_site="finish_txn",
    notes="added for this catalog: SIGKILL mid-file (no drain) then rerun",
)
def case_sigkill(h):
    p = _mix(h, 80)
    first = h.ingest(
        p,
        proto_args=["-p", "dis"],
        kill_after=0.6,
        kill_sig=signal.SIGKILL,
        timeout=40,
    )
    second = h.ingest(p, proto_args=["-p", "dis"], timeout=60)
    return {
        "rc": [first.get("rc"), second.get("rc")],
        "outcome": second.get("outcome"),
        "error_needles": second.get("error_needles", []),
        "rows": second.get("rows", 0),
        "notes": "added for this catalog: SIGKILL then rerun",
    }


@register(
    id="life_unlogged_then_logged",
    family="lifecycle",
    stop_site="ensure_table_exists",
    notes="added for this catalog: --unlogged first, second start default rejects today",
)
def case_unlogged(h):
    p = h.work / "unlog.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    first = h.ingest(p, proto_args=["-p", "dis"], args=["--unlogged"])
    persistence = h.persistence()
    second = h.ingest(p, proto_args=["-p", "dis"])
    findings = []
    if first.get("rows", 0) <= 0:
        findings.append("--unlogged first process committed no rows")
    if not str(persistence).startswith("u="):
        findings.append(f"--unlogged did not leave an unlogged heap ({persistence})")
    if "not a permanent logged table" not in str(second.get("logs") or ""):
        findings.append("logged process did not refuse the unlogged heap")
    if second.get("rows", 0) != first.get("rows", 0):
        findings.append(
            f"logged process changed the row count ({first.get('rows')} -> {second.get('rows')})"
        )
    needles = list(
        dict.fromkeys(first.get("error_needles", []) + second.get("error_needles", []))
    )
    return {
        "rc": [first.get("rc"), second.get("rc")],
        "outcome": second.get("outcome"),
        "error_needles": needles,
        "rows": second.get("rows", 0),
        "persistence": persistence,
        "findings": findings,
        "logs": "\n---\n".join(
            str(part.get("logs") or "") for part in (first, second)
        )[-8000:],
        "notes": (
            "added for this catalog: --unlogged commits, then a default process refuses "
            f"first_rows={first.get('rows')} persistence={persistence}"
        ),
    }


@register(
    id="life_logged_then_unlogged",
    family="lifecycle",
    stop_site="ensure_table_exists",
    notes="added for this catalog: a logged heap already exists; --unlogged writes into it",
)
def case_logged_then_unlogged(h):
    """The reverse of life_unlogged_then_logged. CREATE IF NOT EXISTS does not
    convert a permanent table, and the unlogged flag skips the relpersistence check."""
    p = h.work / "logged_then_unlogged.pcap"
    pcapgen.write_pcap(p, pcapgen.messy_burst(20, include_trunc=False))
    first = h.ingest(p)
    rows_p = first.get("rows", 0)
    pers1 = h.persistence()
    second = h.ingest(p, args=["--unlogged"])
    rows2 = second.get("rows", 0)
    pers2 = h.persistence()
    logs = str(second.get("logs") or "")
    findings = []
    if rows_p <= 0:
        findings.append("logged first process committed no rows")
    if "u=" in str(pers1):
        findings.append(f"default ingest left an unlogged heap ({pers1})")
    if "not a permanent logged table" in logs:
        findings.append("--unlogged refused an existing logged heap")
    if rows2 != rows_p * 2:
        findings.append(
            f"--unlogged did not double the logged rows ({rows_p} -> {rows2})"
        )
    if "u=" in str(pers2):
        findings.append(f"--unlogged left an unlogged heap on a logged database ({pers2})")
    needles = list(
        dict.fromkeys(first.get("error_needles", []) + second.get("error_needles", []))
    )
    return {
        "rc": [first.get("rc"), second.get("rc")],
        "outcome": second.get("outcome") or first.get("outcome"),
        "error_needles": needles,
        "rows": rows2,
        "persistence": pers2,
        "findings": findings,
        "logs": "\n---\n".join(
            str(part.get("logs") or "") for part in (first, second)
        )[-8000:],
        "notes": (
            "added for this catalog: logged heap first, then --unlogged writes into it "
            f"logged_rows={rows_p} after_unlogged={rows2} persistence={pers1}->{pers2}"
        ),
    }


@register(
    id="life_bad_password",
    family="lifecycle",
    stop_site="main connect",
    notes="added for this catalog: wrong password — exits today (durability hole)",
)
def case_bad_pw(h):
    conn = (
        f"host={h.pghost} port={h.pgport} user={h.pguser} "
        f"password=wrong-password dbname={h.current_db}"
    )
    p = h.work / "badpw.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"], conn=conn)


@register(
    id="life_unknown_p",
    family="lifecycle",
    stop_site="main connect",
    notes="added for this catalog: -p notaprotocol",
)
def case_unknown_p(h):
    p = h.work / "unkp.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "notaprotocol"])


@register(
    id="life_too_many_p",
    family="lifecycle",
    stop_site="main",
    notes="added for this catalog: more than 32 -p arguments",
)
def case_too_many(h):
    p = h.work / "manyp.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    protos = []
    # 33 names — even if unknown, the max check fires first for the 33rd.
    names = [f"proto{i}" for i in range(33)]
    for n in names:
        protos += ["-p", n]
    return h.ingest(p, proto_args=protos)


@register(
    id="life_split_depth_1",
    family="lifecycle",
    stop_site="build_tables_for_proto",
    notes="added for this catalog: --split-depth 1 (wide tables)",
)
def case_split1(h):
    p = h.work / "sd1.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"], args=["--split-depth", "1"])


@register(
    id="life_split_depth_8",
    family="lifecycle",
    stop_site="build_tables_for_proto",
    notes="added for this catalog: --split-depth 8 (many tables)",
)
def case_split8(h):
    p = h.work / "sd8.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis"], args=["--split-depth", "8"])


@register(
    id="life_database_url",
    family="lifecycle",
    stop_site="main connect",
    notes="added for this catalog: DATABASE_URL, no -o",
)
def case_url(h):
    p = h.work / "url.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    url = (
        f"postgresql://{h.pguser}:{h.pgpassword}@"
        f"{h.pghost}:{h.pgport}/{h.current_db}"
    )
    # Force no -o: pass conn="" and put DATABASE_URL in env. dbshark_cmd
    # adds -o unless we pass extra that already has -r only.
    import subprocess
    import time as _t
    argv = [str(h.dbshark), "-r", str(p), "-p", "dis"]
    e = h.env({"DATABASE_URL": url})
    proc = subprocess.Popen(
        argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=e, text=True
    )
    try:
        text, _ = proc.communicate(timeout=60)
        timed = False
    except subprocess.TimeoutExpired:
        proc.kill()
        text, _ = proc.communicate()
        timed = True
    return h.pack(
        [
            ProcResult(
                rc=proc.returncode,
                log=text or "",
                timed_out=timed,
                killed=timed,
                argv=argv,
            )
        ]
    )


@register(
    id="life_usage_no_p",
    family="lifecycle",
    stop_site="main",
    notes="added for this catalog: missing -p (usage, rc=2)",
)
def case_no_p(h):
    p = h.work / "nop.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=[])


@register(
    id="life_r_missing",
    family="lifecycle",
    stop_site="wtap_open_offline",
    notes="added for this catalog: -r path does not exist",
)
def case_missing(h):
    return h.ingest(h.work / "no_such_file.pcap", proto_args=["-p", "dis"])


@register(
    id="life_r_is_directory",
    family="lifecycle",
    stop_site="wtap_open_offline",
    notes="added for this catalog: -r points at a directory",
)
def case_dir(h):
    return h.ingest(h.work, proto_args=["-p", "dis"])


@register(
    id="life_p_frame",
    family="lifecycle",
    stop_site="build_tables_for_proto",
    notes="added for this catalog: -p frame (meta proto, huge registrar)",
)
def case_p_frame(h):
    p = h.work / "frame.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "frame"], timeout=90)


@register(
    id="life_dup_p",
    family="lifecycle",
    stop_site="main",
    notes="added for this catalog: duplicate -p dis (warn today, still runs)",
)
def case_dup_p(h):
    p = h.work / "dupp.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    return h.ingest(p, proto_args=["-p", "dis", "-p", "dis"])


@register(
    id="life_conn_options_readonly",
    family="lifecycle",
    stop_site="pg_exec_ddl",
    notes="added for this catalog: libpq options=-c default_transaction_read_only=on",
)
def case_uri_ro(h):
    p = h.work / "uriro.pcap"
    pcapgen.write_pcap(p, pcapgen.one_dis_frame("entity_state"))
    conn = (
        f"host={h.pghost} port={h.pgport} user={h.pguser} "
        f"password={h.pgpassword} dbname={h.current_db} "
        f"options='-c default_transaction_read_only=on'"
    )
    return h.ingest(p, proto_args=["-p", "dis"], conn=conn)


def _crash_restart(h):
    """Added for this catalog: unclean Postgres stop. Unlogged heaps truncate on recovery."""
    h.pg_crash()
    h.pg_start()
    try:
        h.ensure_pg()
    except RuntimeError:
        pass


@register(
    id="life_unlogged_rows",
    family="lifecycle",
    stop_site="ensure_table_exists",
    notes="added for this catalog: --unlogged must commit rows into relpersistence=u",
)
def case_unlogged_rows(h):
    p = h.work / "unlog_rows.pcap"
    pcapgen.write_pcap(p, pcapgen.messy_burst(20, include_trunc=False))
    got = h.ingest(p, args=["--unlogged"])
    persistence = h.persistence()
    findings = []
    if got.get("rows", 0) <= 0:
        findings.append("unlogged ingest committed no rows")
    if not str(persistence).startswith("u=") or "p=" in str(persistence):
        findings.append(f"expected an unlogged heap, persistence={persistence}")
    got = dict(got)
    got["persistence"] = persistence
    got["findings"] = findings
    got["notes"] = (
        "added for this catalog: --unlogged commits into UNLOGGED tables "
        f"rows={got.get('rows')} persistence={persistence}"
    )
    return got


@register(
    id="life_unlogged_crash_wipe",
    family="lifecycle",
    stop_site="ensure_table_exists",
    notes="added for this catalog: committed --unlogged rows are empty after SIGKILL recovery",
)
def case_unlogged_crash(h):
    p = h.work / "unlog_crash.pcap"
    pcapgen.write_pcap(p, pcapgen.messy_burst(20, include_trunc=False))
    got = h.ingest(p, args=["--unlogged"])
    before = got.get("rows", 0)
    persistence = h.persistence()
    _crash_restart(h)
    after = h.count_rows()
    findings = []
    if before <= 0:
        findings.append("unlogged ingest committed no rows before the crash")
    if "u=" not in str(persistence):
        findings.append(f"expected unlogged heap before crash, persistence={persistence}")
    if after != 0:
        findings.append(f"unlogged rows survived SIGKILL (before={before} after={after})")
    return {
        "rc": got.get("rc"),
        "outcome": got.get("outcome"),
        "error_needles": got.get("error_needles", []),
        "rows": before,
        "rows_after_crash": after,
        "persistence": persistence,
        "tables": got.get("tables", []),
        "findings": findings,
        "logs": got.get("logs", ""),
        "notes": f"unlogged before={before} after_sigkill={after} persistence={persistence}",
    }


@register(
    id="life_logged_crash_keeps",
    family="lifecycle",
    stop_site="finish_txn",
    notes="added for this catalog: committed logged rows are still there after SIGKILL recovery",
)
def case_logged_crash(h):
    p = h.work / "log_crash.pcap"
    pcapgen.write_pcap(p, pcapgen.messy_burst(20, include_trunc=False))
    got = h.ingest(p)
    before = got.get("rows", 0)
    persistence = h.persistence()
    _crash_restart(h)
    after = h.count_rows()
    findings = []
    if before <= 0:
        findings.append("logged ingest committed no rows before the crash")
    if "u=" in str(persistence):
        findings.append(f"default ingest created an unlogged heap ({persistence})")
    if after != before:
        findings.append(f"logged rows changed across SIGKILL (before={before} after={after})")
    return {
        "rc": got.get("rc"),
        "outcome": got.get("outcome"),
        "error_needles": got.get("error_needles", []),
        "rows": before,
        "rows_after_crash": after,
        "persistence": persistence,
        "tables": got.get("tables", []),
        "findings": findings,
        "logs": got.get("logs", ""),
        "notes": f"logged before={before} after_sigkill={after} persistence={persistence}",
    }
