# dbshark test suite

| Path | What | Needs |
|---|---|---|
| [`test_reassembly_rotate.py`](test_reassembly_rotate.py) | `-M` session rotation vs no-reset baseline: split TCP, long-lived, out-of-order, incomplete, idle expiry, retransmission, IP fragments, hold cap, volume. Fails on any row difference or duplicate. | `build/run/dbshark`, Postgres reachable as the current user (`PG*` env), database `dbshark_reassembly` |
| [`test_pg_recovery.py`](test_pg_recovery.py) | Multi-process Postgres recovery: a node's scalar-encoded batch submitted after another process promoted the column to JSONB, two nodes promoting the same column, a forced 40P01 deadlock inside a multi-table batch, connection lost before COMMIT, COMMIT reply lost, retry exhaustion into a spill file + `--replay-spill`, value types. Barriers are trigger + advisory lock (no sleeps). Per-record integrity (src port + node id, payload compared). With `DBSHARK_BEFORE=<pre-fix binary>` the concurrency cases are also run on the old build and reported as `XFAIL(before)`. | `build/run/dbshark`, Postgres as the current user, database `dbshark_recovery` (created if absent) |
| [`break/`](break/README.md) | Durability catalog: 93 production mishaps (messy traffic, first-message COPY, lifecycle signals, Postgres faults, up to three nodes). Records stayed_up / exited / crashed per case. Exits are findings. | dbshark, Postgres: docker (`postgres:18.6`), `BREAK_PG_MODE=local` (postgresql-server binaries) or `external` |
| [`compose/`](compose/README.md) | Three live-capture nodes (separate containers) + DIS driver + UDP stubs + Postgres + judge. Scenarios `promote-race`, `deadlock`, `lock-exhaust-spill`, `conn-loss`, `contention`, `cold-burst`, `stagger`, `unlogged`, `unlogged-kill-pg`, `locks`; strict per-node per-record judge. | docker compose |
| [`run-rhel.sh`](run-rhel.sh) | All of the above inside isolated RHEL 8 and RHEL 9 containers | docker (or podman) |
| [`build/`](build/README.md) | `build.sh`, `build-wireshark-4.2.6.sh`, `CMakeLists.txt`, `deps-*.sh`, `Dockerfile.rhel` | |
| [`reports/`](reports/) | `DBSHARK_DESIGN.rst`, `PERFORMANCE.rst`, `CURRENT_BUGS.rst` | |

## Host run (Debian/Ubuntu or RHEL with the deps installed)

```bash
./tests/dbshark/build/build.sh
createdb dbshark_reassembly && python3 tests/dbshark/test_reassembly_rotate.py
python3 tests/dbshark/test_pg_recovery.py            # DBSHARK_BEFORE=/path/to/old/dbshark for the regression column
./tests/dbshark/break/run.sh
SCENARIO=promote-race ./tests/dbshark/compose/run.sh  # see compose/README.md for the others
```

## Isolated RHEL 8 / RHEL 9 run

```bash
./tests/dbshark/run-rhel.sh            # both versions, suites unit,recovery,break,compose
./tests/dbshark/run-rhel.sh 9          # one version
SUITES=unit,recovery,break ./tests/dbshark/run-rhel.sh 8
SCENARIOS=cold-burst,stagger,unlogged,unlogged-kill-pg,locks ./tests/dbshark/run-rhel.sh
BEFORE_IMAGE=dbshark-test:rhel9-before ./tests/dbshark/run-rhel.sh 9   # also run every compose scenario on a pre-fix image
```

`run-rhel.sh` builds `dbshark-test:rhel<N>` from
[`build/Dockerfile.rhel`](build/Dockerfile.rhel): unchanged Wireshark 4.2.6
libs and dbshark compiled **on that OS** (gcc 8.5 on RHEL 8, gcc 11 on
RHEL 9), plus PostgreSQL 16 from the distro module, python3, perl and the
tests. The unit test, the recovery suite and the catalog run inside the
container against a local cluster (`break/pg_local.sh`, which SIGKILLs the
postmaster for the crash cases). The compose scenarios then start the
three capture nodes from that image (`compose/compose.image.yaml`) instead
of bind-mounting a host build. The default scenario list is
`cold-burst,promote-race,deadlock,lock-exhaust-spill,conn-loss,contention`.

Results: `tests/dbshark/.rhel-results/rhel<N>/` (`suite-summary.txt`,
`unit.log`, `recovery.log`, `recovery/recovery_report.json`, `break.log`,
`break-report.json`, `compose-<scenario>/`).

The base image defaults to AlmaLinux, a 1:1 RHEL rebuild with public
repos. Red Hat's UBI repos do not carry flex or c-ares (both required by
Wireshark); on an entitled RHEL host, `podman` forwards the subscription and
`BASE_IMAGE=registry.access.redhat.com/ubi9/ubi ./tests/dbshark/run-rhel.sh 9`
builds on the official base.
