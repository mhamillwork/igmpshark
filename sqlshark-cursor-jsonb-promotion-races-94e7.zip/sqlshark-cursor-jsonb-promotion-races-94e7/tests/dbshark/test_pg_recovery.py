#!/usr/bin/env python3
"""Deterministic multi-node recovery tests for dbshark.

Every scenario reproduces a concrete concurrency or failure defect with a
controlled lock or an injected fault — no sleeps-as-synchronisation, no
random stress — and then proves that every record that entered dbshark is
present in Postgres exactly once with its complete payload.

Record identity is the pcap source UDP port (unique per datagram) plus the
node id; the expected payload for each record is captured in a manifest so
the judge checks values, not just row counts.

The headline scenario (``stale_promote``) is run against the *built* binary
and, when ``DBSHARK_BEFORE`` points at a pre-fix build, against that one too,
so the report shows the regression failing on the old binary and passing on
the new one.

Env:
  DBSHARK         path to the dbshark under test (default build/run/dbshark)
  DBSHARK_BEFORE  optional path to a pre-fix binary for the regression column
  DBSHARK_TEST_DB database to use (default dbshark_recovery; created if absent)
  WS_LIB          Wireshark 4.2.6 run dir (default ~/wireshark-4.2.6/build/run)
  DBSHARK_ARTIFACTS  where to write logs + report (default /opt/cursor/artifacts/recovery)
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tests" / "dbshark" / "break"))
import pcapgen  # noqa: E402

dis_pdus = pcapgen.dis_mod()

DBSHARK = Path(os.environ.get("DBSHARK", str(ROOT / "build" / "run" / "dbshark")))
_before_default = "/tmp/dbshark-before"
DBSHARK_BEFORE = os.environ.get("DBSHARK_BEFORE",
                                _before_default if Path(_before_default).exists() else "")
DB = os.environ.get("DBSHARK_TEST_DB", "dbshark_recovery")
WS_LIB = os.environ.get("WS_LIB", os.path.expanduser("~/wireshark-4.2.6/build/run"))
ART = Path(os.environ.get("DBSHARK_ARTIFACTS", "/opt/cursor/artifacts/recovery"))
SPILL_ROOT = Path(os.environ.get("DBSHARK_SPILL_ROOT", "/tmp/dbshark-recovery-spill"))

ART.mkdir(parents=True, exist_ok=True)
SPILL_ROOT.mkdir(parents=True, exist_ok=True)

ADVISORY_KEY = 424242


def env_for(extra=None):
    e = dict(os.environ)
    e["LD_LIBRARY_PATH"] = WS_LIB + (os.pathsep + e["LD_LIBRARY_PATH"] if e.get("LD_LIBRARY_PATH") else "")
    if extra:
        e.update(extra)
    return e


def psql(sql, db=DB, check=True, field=False):
    args = ["psql", "-v", "ON_ERROR_STOP=1", "-d", db, "-c", sql]
    if field:
        args[1:1] = ["-tA"]
    r = subprocess.run(args, capture_output=True, text=True, env=env_for())
    if check and r.returncode != 0:
        raise RuntimeError(f"psql failed: {sql}\n{r.stderr}")
    return r.stdout.strip()


def ensure_db():
    out = subprocess.run(["psql", "-tA", "-d", "postgres", "-c",
                          f"SELECT 1 FROM pg_database WHERE datname='{DB}'"],
                         capture_output=True, text=True, env=env_for())
    if out.stdout.strip() != "1":
        subprocess.run(["createdb", DB], check=True, env=env_for())


class Psql:
    """A persistent psql session, e.g. to hold a session-level advisory lock."""

    def __init__(self, db=DB):
        self.p = subprocess.Popen(
            ["psql", "-q", "-X", "-v", "ON_ERROR_STOP=0", "-d", db],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, env=env_for(),
        )

    def send(self, sql):
        self.p.stdin.write(sql + "\n")
        self.p.stdin.flush()

    def close(self):
        try:
            self.p.stdin.write("\\q\n")
            self.p.stdin.flush()
            self.p.wait(timeout=10)
        except Exception:
            self.p.kill()


def reset_schema(schema):
    psql(f'DROP SCHEMA IF EXISTS "{schema}" CASCADE; CREATE SCHEMA "{schema}";')


def conninfo(schema, gucs=None):
    opts = [f"-csearch_path={schema}"]
    for k, v in (gucs or {}).items():
        opts.append(f"-c{k}={v}")
    return f"dbname={DB} options='{' '.join(opts)}'"


def supports_new_flags(binary):
    return str(binary) != DBSHARK_BEFORE


def run_dbshark(binary, pcap, schema, node, args, logname, fault=None,
                background=False, spill_dir=None, gucs=None):
    spill = Path(spill_dir) if spill_dir else SPILL_ROOT / logname
    env = env_for({"DBSHARK_SPILL_DIR": str(spill)})
    node_args = []
    if supports_new_flags(binary):
        node_args = ["--node-id", node, "--node-column", "node", "--spill-dir", str(spill)]
        if fault:
            env["DBSHARK_FAULT"] = fault
    else:
        # The pre-fix binary has no node id / spill / replay flags; drop any
        # that it would reject so the regression column still runs.
        args = [a for a in args if not a.startswith("--")
                or a in ("--unlogged", "--async-commit", "--packet-local")]
    # --replay-spill is a stand-alone mode: no capture source is allowed.
    source = [] if "--replay-spill" in args else ["-r", str(pcap)]
    cmd = [str(binary), *source, "-o", conninfo(schema, gucs),
           "-p", "dis", *node_args, *args]
    logf = open(ART / (logname + ".log"), "w")
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=logf, env=env)
    if background:
        p._logf = logf  # type: ignore
        return p
    p.wait()
    logf.close()
    return p.returncode


def wait_waiting(locktype=None, mode=None, relation=None, timeout=30):
    """Block until a backend is waiting (granted=false) for the given lock."""
    cond = ["NOT l.granted"]
    if locktype:
        cond.append(f"l.locktype = '{locktype}'")
    if mode:
        cond.append(f"l.mode = '{mode}'")
    if relation:
        cond.append(f"l.relation = '{relation}'::regclass")
    where = " AND ".join(cond)
    sql = f"SELECT count(*) FROM pg_locks l WHERE {where}"
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            if int(psql(sql, field=True) or "0") > 0:
                return True
        except RuntimeError:
            pass
        time.sleep(0.05)
    return False


# ---- pcap + manifest ----------------------------------------------------

def want_entity_state(entity, marking):
    """Expected (marking, entity_id_site, entity_id_entity, pdu_type) as
    psql -tA prints them, for a scalar *or* a JSONB-promoted column."""
    return (marking, str(dis_pdus.SITE), str(entity), str(dis_pdus.PDU_ENTITY_STATE))


# A fire PDU carries three entity ids: dissection sees entity_id_site three
# times, which is what forces the column to JSONB. These are the values
# pdu_fire() encodes; marking is absent (SQL NULL -> empty text).
WANT_FIRE = ("", "[1, 2, 3]",
             f"[{dis_pdus.FIRE_ENT}, {dis_pdus.TGT_ENT}, {dis_pdus.MUN_ENT}]",
             str(dis_pdus.PDU_FIRE))


def make_dis_pcap(path, n, base_port, marking_prefix, entity_base=0,
                  fire_every=0, fire_from=0):
    """n frames, each with a unique src port so the record identity is
    checkable. entity_state frames carry a unique marking; when fire_every
    is set every k-th frame from index fire_from on is a fire PDU
    (repeated entity ids -> JSONB). Returns the manifest: src_port ->
    expected payload."""
    frames = []
    manifest = []
    ts = pcapgen.T0_US
    for i in range(n):
        sport = base_port + i
        if fire_every and i >= fire_from and i % fire_every == fire_every - 1:
            pdu = dis_pdus.pdu_fire()
            want = WANT_FIRE
        else:
            entity = (entity_base + i) % 65535 or 1
            marking = f"{marking_prefix}{i:05d}"[:11]
            pdu = dis_pdus.pdu_entity_state(entity=entity, marking_text=marking)
            want = want_entity_state(entity, marking)
        fr = pcapgen.frame_udp(pdu, dport=3000, sport=sport)
        frames.append((ts + i, fr, len(fr)))
        manifest.append({"src_port": sport, "want": want})
    pcapgen.write_pcap(Path(path), frames)
    return manifest


# ---- integrity check ----------------------------------------------------

def site_scalar(val):
    """dis.site may be BIGINT (e.g. '1') or JSONB ('1'). Normalise to int."""
    if val is None:
        return None
    v = val.strip()
    return int(v)


def check_integrity(schema, manifest, result, node=None, key="integrity"):
    """Every manifest record present once, payload intact, no extras, no dup.
    Keyed on src_port (unique per datagram) so it works for the pre-fix
    binary too, which has no node column; with node= the rows are also
    required to carry that node id. The manifest's ports occupy a
    contiguous range disjoint from any pre-existing row."""
    ports = {m["src_port"] for m in manifest}
    lo, hi = min(ports), max(ports)
    where = f"src_port BETWEEN {lo} AND {hi}"
    if node:
        where += f" AND node = '{node}'"
    # ::text reads the same whether a column is still BIGINT or was
    # promoted to JSONB, so the value check is type-agnostic.
    rows = psql(
        f'SELECT src_port, entity_marking, entity_id_site::text, entity_id_entity::text, '
        f'pdu_type::text FROM "{schema}".dis WHERE {where} ORDER BY src_port', field=True)
    seen = {}
    dup = 0
    for line in [r for r in rows.splitlines() if r]:
        sp, mark, site, ent, pdu = (line.split("|") + [""] * 5)[:5]
        sp = int(sp)
        if sp in seen:
            dup += 1
        seen[sp] = (mark, site, ent, pdu)
    missing = []
    wrong = []
    for rec in manifest:
        sp = rec["src_port"]
        want = tuple(rec["want"])
        if sp not in seen:
            missing.append(sp)
        elif seen[sp] != want:
            wrong.append((sp, want, seen[sp]))
    extras = [sp for sp in seen if sp not in ports]
    stats = {
        "expected": len(manifest),
        "present": len(seen),
        "missing": len(missing),
        "duplicates": dup,
        "payload_mismatch": len(wrong),
        "unexpected": len(extras),
    }
    ok = not missing and not dup and not wrong and not extras
    stats["integrity_ok"] = ok
    if missing[:5]:
        stats["missing_ports"] = missing[:5]
    if wrong[:5]:
        stats["mismatch_sample"] = wrong[:5]
    if key == "integrity":
        result.update(stats)
    else:
        result[key] = stats
    return ok


def spill_files(node, db=DB):
    base = SPILL_ROOT
    return sorted(str(p) for p in base.rglob("*.spill")) + \
        sorted(str(p) for p in base.rglob("*.quarantine"))


# ---- scenarios ----------------------------------------------------------

def scenario_stale_promote(binary, label):
    """A node caches a column as scalar, another node promotes it to JSONB and
    commits in the gap between the node's batches, then the node submits its
    stale (scalar-encoded) batch. Every record must still land as complete
    JSONB. Deterministic via a trigger barrier + a held advisory lock."""
    schema = f"stale_{label}"
    reset_schema(schema)
    # Pre-create dis with the fixed columns and a scalar `site` plus a
    # previously committed row that must survive untouched.
    # entity_id_site is written by every entity_state PDU as a scalar int8;
    # the winner promotes exactly that column so the loser's buffered rows
    # are the ones whose encoding goes stale.
    psql(f'''
        CREATE TABLE "{schema}".dis (
            ts_us BIGINT, src_ip TEXT, dst_ip TEXT,
            src_port INTEGER, dst_port INTEGER, frame_len INTEGER,
            node TEXT, entity_id_site BIGINT, entity_id_entity BIGINT,
            entity_marking TEXT);
        INSERT INTO "{schema}".dis (src_port, node, entity_id_site, entity_id_entity, entity_marking)
            VALUES (1, 'preexisting', 7, 7, 'KEEPME');
        CREATE OR REPLACE FUNCTION "{schema}".barrier() RETURNS trigger
        LANGUAGE plpgsql AS $$
        BEGIN
            -- Only dbshark INSERTs rows here (the winner runs ALTER), so an
            -- unconditional wait blocks the loser's batch COPY regardless of
            -- which binary it is. The pre-existing row was inserted before
            -- this trigger existed.
            PERFORM pg_advisory_xact_lock({ADVISORY_KEY});
            RETURN NEW;
        END $$;
        CREATE TRIGGER barrier BEFORE INSERT ON "{schema}".dis
            FOR EACH ROW EXECUTE FUNCTION "{schema}".barrier();
    ''')
    # ~4.5 MiB of journal forces a mid-file batch1 before the finish batch2.
    n = 16000
    pcap = ART / f"stale_{label}.pcap"
    manifest = make_dis_pcap(pcap, n, base_port=20000, marking_prefix="L")

    holder = Psql()
    holder.send(f"SELECT pg_advisory_lock({ADVISORY_KEY});")
    time.sleep(0.4)  # let the holder take the lock before the loser starts

    loser = run_dbshark(binary, pcap, schema, "loser", [], f"stale_{label}_loser",
                        background=True)
    result = {"scenario": "stale_promote", "binary": label}
    try:
        if not wait_waiting(locktype="advisory", timeout=60):
            result["error"] = "loser never blocked on the barrier"
            loser.kill()
            return result
        # Winner promotes site -> JSONB; queues behind the loser's COPY lock.
        winner = subprocess.Popen(
            ["psql", "-q", "-d", DB, "-c",
             f'ALTER TABLE "{schema}".dis ALTER COLUMN entity_id_site TYPE JSONB '
             f'USING to_jsonb(entity_id_site)'],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env_for())
        wait_waiting(mode="AccessExclusiveLock", relation=f'"{schema}".dis', timeout=30)
        result["winner_queued"] = True
    finally:
        holder.send(f"SELECT pg_advisory_unlock({ADVISORY_KEY});")
        holder.close()
    loser.wait()
    loser._logf.close()  # type: ignore
    winner.wait()
    result["loser_rc"] = loser.returncode
    # The pre-existing row and the column type must be intact.
    coltype = psql(f"SELECT udt_name FROM information_schema.columns WHERE "
                   f"table_schema='{schema}' AND table_name='dis' AND column_name='entity_id_site'",
                   field=True)
    result["site_type_after"] = coltype
    keep = psql(f"SELECT count(*) FROM \"{schema}\".dis WHERE src_port=1 AND entity_marking='KEEPME' "
                f"AND entity_id_site::text='7' AND entity_id_entity::text='7'",
                field=True)
    result["preexisting_intact"] = keep == "1"
    # Replay any spill the loser left (fixed binary should have none pending).
    if supports_new_flags(binary):
        run_dbshark(binary, pcap, schema, "loser", ["--replay-spill"],
                    f"stale_{label}_loser_replay", spill_dir=str(SPILL_ROOT / f"stale_{label}_loser"))
    check_integrity(schema, manifest, result)
    result["spill_left"] = [str(p) for p in (SPILL_ROOT / f"stale_{label}_loser").rglob("*.spill")]
    result["passed"] = bool(result.get("integrity_ok") and result.get("preexisting_intact"))
    return result


def barrier_sql(schema):
    """A BEFORE INSERT trigger on dis that waits for ADVISORY_KEY. While the
    harness holds the key at session level, every dbshark COPY into dis
    blocks on its first row — a deterministic barrier with no sleeps."""
    return f'''
        CREATE OR REPLACE FUNCTION "{schema}".barrier() RETURNS trigger
        LANGUAGE plpgsql AS $$
        BEGIN
            PERFORM pg_advisory_xact_lock({ADVISORY_KEY});
            RETURN NEW;
        END $$;
        CREATE TRIGGER barrier BEFORE INSERT ON "{schema}".dis
            FOR EACH ROW EXECUTE FUNCTION "{schema}".barrier();
    '''


def wait_advisory_waiters(n, timeout=60):
    sql = "SELECT count(*) FROM pg_locks WHERE locktype='advisory' AND NOT granted"
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            if int(psql(sql, field=True) or "0") >= n:
                return True
        except RuntimeError:
            pass
        time.sleep(0.05)
    return False


def scenario_dual_promote(binary, label):
    """Two independent dbshark processes both cache entity_id_site as a
    scalar (their first batch is all entity_state), then both meet fire
    PDUs and both need to promote the same column. The barrier guarantees
    neither has promoted before the other cached the scalar type. One
    ALTER must win, the other must adopt the committed JSONB type, and
    every record of both nodes must land with its full payload."""
    schema = f"dual_{label}"
    reset_schema(schema)
    psql(f'''
        CREATE TABLE "{schema}".dis (
            ts_us BIGINT, src_ip TEXT, dst_ip TEXT,
            src_port INTEGER, dst_port INTEGER, frame_len INTEGER,
            node TEXT, entity_id_site BIGINT, entity_id_entity BIGINT,
            entity_marking TEXT);
        INSERT INTO "{schema}".dis (src_port, node, entity_id_site, entity_id_entity, entity_marking)
            VALUES (1, 'preexisting', 7, 7, 'KEEPME');
    ''' + barrier_sql(schema))
    # Batch 1 (~4 MiB) is scalar-only; the fire PDUs start after it.
    n = 16000
    pcaps, manifests = {}, {}
    for k, node in enumerate(("alpha", "beta")):
        pcap = ART / f"dual_{label}_{node}.pcap"
        # First 9000 frames scalar-only, then every 3rd frame is a fire PDU.
        manifest = make_dis_pcap(pcap, n, base_port=20000 + k * n,
                                 marking_prefix=node[0].upper(),
                                 fire_every=3, fire_from=9000)
        pcaps[node], manifests[node] = pcap, manifest

    holder = Psql()
    holder.send(f"SELECT pg_advisory_lock({ADVISORY_KEY});")
    time.sleep(0.4)
    procs = {node: run_dbshark(binary, pcaps[node], schema, node, [],
                               f"dual_{label}_{node}", background=True)
             for node in pcaps}
    result = {"scenario": "dual_promote", "binary": label}
    try:
        # Both nodes are inside their first COPY (scalar type cached).
        result["both_blocked"] = wait_advisory_waiters(2, timeout=90)
    finally:
        holder.send(f"SELECT pg_advisory_unlock({ADVISORY_KEY});")
        holder.close()
    for node, p in procs.items():
        p.wait()
        p._logf.close()  # type: ignore
        result[f"{node}_rc"] = p.returncode
    coltype = psql(f"SELECT udt_name FROM information_schema.columns WHERE "
                   f"table_schema='{schema}' AND table_name='dis' AND column_name='entity_id_site'",
                   field=True)
    result["site_type_after"] = coltype
    keep = psql(f"SELECT count(*) FROM \"{schema}\".dis WHERE src_port=1 AND entity_marking='KEEPME' "
                f"AND entity_id_site::text='7' AND entity_id_entity::text='7'", field=True)
    result["preexisting_intact"] = keep == "1"
    promotes = 0
    for node in pcaps:
        log = (ART / f"dual_{label}_{node}.log").read_text()
        promotes += log.count('promoting "entity_id_site"')
    result["alter_statements_total"] = promotes
    ok = True
    for node in pcaps:
        ok &= check_integrity(schema, manifests[node], result,
                              node=node if supports_new_flags(binary) else None,
                              key=f"integrity_{node}")
    total = psql(f'SELECT count(*) FROM "{schema}".dis', field=True)
    result["rows_total"] = int(total)
    result["passed"] = bool(ok and result["preexisting_intact"] and coltype == "jsonb"
                            and result["rows_total"] == 1 + 2 * n and result["both_blocked"])
    return result


def scenario_deadlock(binary, label):
    """A forced deadlock inside the batch transaction. dbshark holds
    RowExclusive on dis (COPY blocked at the barrier) while another
    session holds ACCESS EXCLUSIVE on dis_category and then asks for dis.
    When the barrier opens dbshark proceeds to COPY dis_category -> cycle
    -> Postgres cancels dbshark with 40P01. The whole batch (several
    tables, thousands of records) must be rolled back and replayed in full
    once the other session commits."""
    schema = f"deadlock_{label}"
    reset_schema(schema)
    # Seed the full column set with one frame so no DDL is needed later
    # (DDL would simply block behind the other session's lock).
    seed = ART / f"deadlock_{label}_seed.pcap"
    make_dis_pcap(seed, 1, base_port=19999, marking_prefix="SEED")
    run_dbshark(binary, seed, schema, "dlnode", [], f"deadlock_{label}_seed")
    psql(barrier_sql(schema))
    n = 6000
    pcap = ART / f"deadlock_{label}.pcap"
    manifest = make_dis_pcap(pcap, n, base_port=20000, marking_prefix="D")

    holder = Psql()
    holder.send(f"SELECT pg_advisory_lock({ADVISORY_KEY});")
    time.sleep(0.4)
    other = Psql()
    # Postgres cancels whichever waiter *detects* the cycle. Push the other
    # session's deadlock check far out so dbshark's own (default 1 s)
    # check is the one that fires, making dbshark the victim every time.
    other.send("SET deadlock_timeout = '120s';")
    other.send("BEGIN;")
    other.send(f'LOCK TABLE "{schema}".dis_category IN ACCESS EXCLUSIVE MODE;')
    time.sleep(0.3)
    p = run_dbshark(binary, pcap, schema, "dlnode", [], f"deadlock_{label}_run",
                    background=True)
    result = {"scenario": "deadlock", "binary": label}
    try:
        result["dbshark_blocked"] = wait_waiting(locktype="advisory", timeout=60)
        # Now the other session queues for dis, behind dbshark's RowExclusive.
        other.send(f'LOCK TABLE "{schema}".dis IN ACCESS EXCLUSIVE MODE;')
        result["other_queued"] = wait_waiting(mode="AccessExclusiveLock",
                                              relation=f'"{schema}".dis', timeout=30)
    finally:
        holder.send(f"SELECT pg_advisory_unlock({ADVISORY_KEY});")
        holder.close()
    # dbshark: COPY dis completes, COPY dis_category waits on `other`,
    # `other` waits on dbshark -> deadlock detector cancels dbshark.
    deadline = time.monotonic() + 60
    log_path = ART / f"deadlock_{label}_run.log"
    while time.monotonic() < deadline:
        if "deadlock detected" in log_path.read_text():
            break
        time.sleep(0.1)
    result["deadlock_detected"] = "deadlock detected" in log_path.read_text()
    other.send("COMMIT;")
    other.close()
    p.wait()
    p._logf.close()  # type: ignore
    result["run_rc"] = p.returncode
    check_integrity(schema, manifest, result,
                    node="dlnode" if supports_new_flags(binary) else None)
    # The seed row and every subtable must be consistent with dis.
    cat = psql(f'SELECT count(*) FROM "{schema}".dis_category WHERE src_port BETWEEN 20000 AND {20000 + n - 1}',
               field=True)
    result["dis_category_rows"] = int(cat)
    result["passed"] = bool(result.get("integrity_ok") and result["deadlock_detected"]
                            and result["dis_category_rows"] == n and result["run_rc"] == 0)
    return result


def scenario_fault(binary, label, kind):
    """Connection lost before COMMIT / COMMIT reply dropped. The node must
    recover every record (via spill + marker lookup) without duplicating the
    batch whose outcome was uncertain."""
    schema = f"{kind}_{label}".replace("-", "_")
    reset_schema(schema)
    n = 1200
    pcap = ART / f"{schema}.pcap"
    manifest = make_dis_pcap(pcap, n, base_port=30000, marking_prefix="F")
    sdir = SPILL_ROOT / schema
    # Break the connection around the 1st data COMMIT.
    rc = run_dbshark(binary, pcap, schema, "faultnode", [],
                     f"{schema}_run1", fault=f"{kind}@1", spill_dir=str(sdir))
    result = {"scenario": kind, "binary": label, "run1_rc": rc}
    # Restart: startup replays spill, resolves the uncertain batch via marker.
    rc2 = run_dbshark(binary, pcap, schema, "faultnode", ["--replay-spill"],
                      f"{schema}_replay", spill_dir=str(sdir))
    result["replay_rc"] = rc2
    check_integrity(schema, manifest, result)
    result["spill_left"] = [str(p) for p in sdir.rglob("*.spill")]
    result["passed"] = bool(result.get("integrity_ok")) and not result["spill_left"]
    return result


def scenario_retry_exhaust_spill(binary, label):
    """Postgres refuses the batch past the retry budget (a competing session
    holds ACCESS EXCLUSIVE on the table). The rows must go to a durable spill
    file, never dropped, and --replay-spill must write the full dataset once
    the lock is released."""
    schema = f"exhaust_{label}"
    reset_schema(schema)
    psql(f'CREATE TABLE "{schema}".dis (ts_us BIGINT, src_ip TEXT, dst_ip TEXT, '
         f'src_port INTEGER, dst_port INTEGER, frame_len INTEGER, node TEXT, '
         f'site BIGINT, entity_marking TEXT);')
    n = 800
    pcap = ART / f"exhaust_{label}.pcap"
    manifest = make_dis_pcap(pcap, n, base_port=40000, marking_prefix="E")
    sdir = SPILL_ROOT / f"exhaust_{label}"
    holder = Psql()
    holder.send("BEGIN;")
    holder.send(f'LOCK TABLE "{schema}".dis IN ACCESS EXCLUSIVE MODE;')
    time.sleep(0.4)
    # lock_timeout makes each blocked COPY fail fast with 55P03 (TRANSIENT)
    # so the bounded retry budget is what decides the outcome, not a hang.
    rc = run_dbshark(binary, pcap, schema, "exnode", ["--db-retries", "3"],
                     f"exhaust_{label}_run", spill_dir=str(sdir),
                     gucs={"lock_timeout": "2000"})
    result = {"scenario": "retry_exhaust_spill", "binary": label, "run_rc": rc}
    # The lock blocked every attempt; rows should now be on disk.
    spilled = sorted(sdir.rglob("*.spill"))
    result["spill_after_run"] = len(spilled)
    holder.send("COMMIT;")
    holder.close()
    # Replay now that the table is free.
    rc2 = run_dbshark(binary, pcap, schema, "exnode", ["--replay-spill"],
                      f"exhaust_{label}_replay", spill_dir=str(sdir))
    result["replay_rc"] = rc2
    check_integrity(schema, manifest, result)
    left = sorted(sdir.rglob("*.spill"))
    result["spill_left"] = len(left)
    result["passed"] = bool(result.get("integrity_ok") and result["spill_after_run"] > 0
                            and result["spill_left"] == 0)
    return result


def scenario_value_types(binary, label):
    """Numbers, booleans, hostile strings, NaN/Inf, arrays, missing fields and
    SQL NULL all survive a promotion rebuild intact."""
    schema = f"values_{label}"
    reset_schema(schema)
    frames = []
    manifest = []
    ts = pcapgen.T0_US
    hostile = 'x"y\\z\'w;--'  # quotes, backslash, SQL comment, 10 chars
    det_want = ("", "[1, 1, 1]",
                f"[{dis_pdus.FIRE_ENT}, {dis_pdus.TGT_ENT}, {dis_pdus.MUN_ENT}]", "3")
    # Scalar row -> fire (repeated ids force JSONB) -> detonation -> scalar
    # rows written *after* promotion (numbers into JSONB) -> NaN/Inf doubles
    # -> a marking that needs escaping. Fire/detonation have no marking:
    # SQL NULL must stay NULL ('' in psql -tA), not become JSON null or "".
    specs = [
        (dis_pdus.pdu_entity_state(entity=10, marking_text="TEST01"), want_entity_state(10, "TEST01")),
        (dis_pdus.pdu_fire(), WANT_FIRE),
        (dis_pdus.pdu_detonation(), det_want),
        (dis_pdus.pdu_entity_state(entity=4242, marking_text="AFTER"), want_entity_state(4242, "AFTER")),
        (pcapgen.dis_nan_inf(), want_entity_state(10, "NANINF")),
        (dis_pdus.pdu_entity_state(entity=99, marking_text=hostile), want_entity_state(99, hostile)),
    ]
    for i, (pdu, want) in enumerate(specs):
        fr = pcapgen.frame_udp(pdu, dport=3000, sport=50000 + i)
        frames.append((ts + i, fr, len(fr)))
        manifest.append({"src_port": 50000 + i, "want": want})
    pcapgen.write_pcap(ART / f"values_{label}.pcap", frames)
    rc = run_dbshark(binary, ART / f"values_{label}.pcap", schema, "valnode", [],
                     f"values_{label}_run", spill_dir=str(SPILL_ROOT / f"values_{label}"))
    result = {"scenario": "value_types", "binary": label, "run_rc": rc}
    check_integrity(schema, manifest, result, node="valnode")
    # Non-finite doubles survive into the float8 subtable.
    loc = psql(f'SELECT x::text, y::text, z::text FROM "{schema}".dis_entity_location '
               f"WHERE src_port=50004", field=True)
    result["nan_inf_row"] = loc
    nulls = psql(f'SELECT count(*) FROM "{schema}".dis WHERE src_port IN (50001, 50002) '
                 f"AND entity_marking IS NULL", field=True)
    result["sql_null_kept"] = nulls == "2"
    types = psql(f"SELECT jsonb_typeof(entity_id_site) FROM \"{schema}\".dis "
                 f"WHERE src_port IN (50001, 50003) ORDER BY src_port", field=True)
    result["jsonb_types_fire_then_scalar"] = types.split()
    result["passed"] = bool(result.get("integrity_ok") and rc == 0
                            and loc == "NaN|Infinity|-Infinity" and result["sql_null_kept"]
                            and result["jsonb_types_fire_then_scalar"] == ["array", "number"])
    return result


def main():
    if not DBSHARK.exists():
        print(f"missing {DBSHARK}", file=sys.stderr)
        return 2
    ensure_db()
    binaries = [(DBSHARK, "after")]
    if DBSHARK_BEFORE and Path(DBSHARK_BEFORE).exists():
        binaries.append((Path(DBSHARK_BEFORE), "before"))

    only = set(sys.argv[1:])

    def wanted(name):
        return not only or name in only

    report = {"results": [], "dbshark": str(DBSHARK), "dbshark_before": DBSHARK_BEFORE}
    # The concurrency regressions run on both binaries: the pre-fix one is
    # expected to lose or duplicate records, the fixed one must not.
    for binary, label in binaries:
        if wanted("stale_promote"):
            report["results"].append(scenario_stale_promote(binary, label))
        if wanted("dual_promote"):
            report["results"].append(scenario_dual_promote(binary, label))
        if wanted("deadlock"):
            report["results"].append(scenario_deadlock(binary, label))

    # Recovery scenarios need the fault hooks / spill flags of the fixed binary.
    if wanted("conn-lost-before-commit"):
        report["results"].append(scenario_fault(DBSHARK, "after", "conn-lost-before-commit"))
    if wanted("commit-lost"):
        report["results"].append(scenario_fault(DBSHARK, "after", "commit-lost"))
    if wanted("retry_exhaust_spill"):
        report["results"].append(scenario_retry_exhaust_spill(DBSHARK, "after"))
    if wanted("value_types"):
        report["results"].append(scenario_value_types(DBSHARK, "after"))

    (ART / "recovery_report.json").write_text(json.dumps(report, indent=2, default=str))

    print("\n== dbshark recovery matrix ==")
    failed = 0
    for r in report["results"]:
        name = f"{r['scenario']}/{r['binary']}"
        status = "PASS" if r.get("passed") else "FAIL"
        parts = []
        for key in ("integrity_alpha", "integrity_beta"):
            if key in r:
                s = r[key]
                parts.append(f"{key[10:]}={s['present']}/{s['expected']} miss={s['missing']} "
                             f"dup={s['duplicates']} bad={s['payload_mismatch']}")
        if "expected" in r:
            parts.append(f"present={r['present']}/{r['expected']} missing={r['missing']} "
                         f"dup={r['duplicates']} bad={r['payload_mismatch']}")
        if "site_type_after" in r:
            parts.append(f"site={r['site_type_after']}")
        if "deadlock_detected" in r:
            parts.append(f"40P01={r['deadlock_detected']}")
        if "spill_after_run" in r:
            parts.append(f"spilled_files={r['spill_after_run']} left={r['spill_left']}")
        extra = " ".join(parts)
        # The pre-fix binary is expected to fail the concurrency scenarios.
        expect_fail = r["binary"] == "before"
        verdict = status
        if expect_fail:
            verdict = "XFAIL(before)" if not r.get("passed") else "UNEXPECTED-PASS"
            if r["scenario"] == "deadlock" and not r.get("deadlock_detected"):
                # The pre-fix binary opens tables lazily and simply hangs on
                # the other session's lock; no cycle forms, so there is no
                # before/after comparison for this scenario.
                verdict = "N/A(no cycle)"
        elif status == "FAIL":
            failed += 1
        print(f"  {verdict:16} {name:34} {extra}")
        if r.get("error"):
            print(f"      error: {r['error']}")

    print(f"\nreport: {ART / 'recovery_report.json'}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
