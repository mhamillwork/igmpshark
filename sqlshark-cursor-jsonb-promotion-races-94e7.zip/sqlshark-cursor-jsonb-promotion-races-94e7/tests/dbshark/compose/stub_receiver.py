#!/usr/bin/env python3
"""Bind UDP :3000 so the sender's DIS datagrams are not ICMP-unreached."""
from __future__ import annotations

import os
import socket
import time
from pathlib import Path

SHARED = Path(os.environ.get("SHARED", "/shared"))
PORT = int(os.environ.get("STUB_PORT", "3000"))
# One stub per capture node that receives unicast; each has its own
# ready marker and receive counter (stub.ready/recv_count for the receiver).
TAG = os.environ.get("STUB_TAG", "")
READY = f"{TAG}_stub.ready" if TAG else "stub.ready"
COUNT = f"{TAG}_recv_count" if TAG else "recv_count"


def main() -> int:
    SHARED.mkdir(parents=True, exist_ok=True)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", PORT))
    sock.settimeout(0.25)
    (SHARED / READY).write_text("1\n")
    n = 0
    last = 0
    try:
        while not (SHARED / "stop").exists():
            try:
                data, _ = sock.recvfrom(65535)
                if data:
                    n += 1
                    last = int(time.time())
            except socket.timeout:
                continue
    finally:
        sock.close()
        (SHARED / COUNT).write_text(f"{n}\n")
        (SHARED / (f"{TAG}_recv_last_unix" if TAG else "recv_last_unix")).write_text(f"{last}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
