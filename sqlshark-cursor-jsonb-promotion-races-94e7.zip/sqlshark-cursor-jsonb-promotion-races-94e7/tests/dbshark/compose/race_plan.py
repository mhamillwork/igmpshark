"""Traffic plans shared by the DIS driver and the judge.

A plan is an ordered list of steps. The judge walks the steps, runs its
scenario hooks around each one (hold a lock, wait for a waiter in
pg_locks, ...) and publishes the step's phase name; the driver sends the
step's datagrams when it sees that phase and records every datagram in
the manifest. Record identity is the UDP source port, which is unique
across the whole run, plus the node that captured it.

Node visibility on the compose network: the sender captures its own
egress, so it sees every datagram; a unicast to the receiver is also
seen by the receiver, a unicast to the witness also by the witness.
"""
from __future__ import annotations

import dis_pdus

NODES = ("sender", "receiver", "witness")

# Expected (entity_marking, entity_id_site, entity_id_entity, pdu_type) as
# psql -tA prints them, identical for a BIGINT and a JSONB-promoted column.
WANT_FIRE = ("", "[1, 2, 3]",
             f"[{dis_pdus.FIRE_ENT}, {dis_pdus.TGT_ENT}, {dis_pdus.MUN_ENT}]",
             str(dis_pdus.PDU_FIRE))
WANT_DETONATION = ("", "[1, 1, 1]",
                   f"[{dis_pdus.FIRE_ENT}, {dis_pdus.TGT_ENT}, {dis_pdus.MUN_ENT}]",
                   str(dis_pdus.PDU_DETONATION))


def want_entity_state(entity: int, marking: str) -> tuple:
    return (marking, str(dis_pdus.SITE), str(entity), str(dis_pdus.PDU_ENTITY_STATE))


def step(phase: str, kind: str, count: int, dest: str, sport_base: int) -> dict:
    return {"phase": phase, "kind": kind, "count": count, "dest": dest,
            "sport_base": sport_base}


# The original three-phase plan (corpus, fire burst, unique entity states).
LEGACY = [
    step("cold", "corpus", 0, "receiver", 40000),
    step("fire", "fire", 50, "receiver", 41000),
    step("unique", "entity_state", 500, "receiver", 42000),
]

PLANS = {
    "cold-burst": LEGACY,
    "stagger": LEGACY,
    "unlogged": LEGACY,
    "unlogged-kill-pg": LEGACY,
    "locks": LEGACY,
    # Two nodes cache entity_id_site as BIGINT and are held inside their
    # first COPY; the witness then meets fire PDUs and promotes the column.
    "promote-race": [
        step("scalar1", "entity_state", 3000, "receiver", 20000),
        step("fire", "fire", 60, "witness", 24000),
        step("scalar2", "entity_state", 1500, "receiver", 25000),
        step("fire2", "fire", 30, "receiver", 27000),
        step("tail", "entity_state", 300, "witness", 28000),
    ],
    # Forced 40P01 inside a multi-table batch on two nodes at once.
    "deadlock": [
        step("seed", "entity_state", 1, "receiver", 19999),
        step("burst", "entity_state", 3000, "receiver", 20000),
        step("tail", "entity_state", 500, "witness", 24000),
    ],
    # dis stays ACCESS EXCLUSIVE locked for the whole capture; rows must
    # reach a spill file and be written in full by --replay-spill.
    "lock-exhaust-spill": [
        step("seed", "entity_state", 1, "receiver", 19999),
        step("burst", "entity_state", 2000, "receiver", 20000),
        step("fire", "fire", 40, "witness", 23000),
    ],
    # Connection drops before COMMIT / lost COMMIT reply on live nodes.
    "conn-loss": [
        step("b1", "entity_state", 800, "receiver", 20000),
        step("b2", "entity_state", 800, "witness", 21000),
        step("b3", "fire", 40, "receiver", 22000),
        step("b4", "entity_state", 800, "receiver", 23000),
        step("b5", "entity_state", 800, "witness", 24000),
    ],
    # Repeated promotion / stale-batch contention across three nodes with
    # a fast batch cadence, starting from an empty schema.
    "contention": [
        s
        for r in range(6)
        for s in (
            step(f"r{r}_scalar", "entity_state", 400, "receiver", 20000 + r * 1500),
            step(f"r{r}_fire", "fire", 20, "witness", 20400 + r * 1500),
            step(f"r{r}_det", "detonation", 20, "receiver", 20450 + r * 1500),
            step(f"r{r}_scalar_w", "entity_state", 300, "witness", 20500 + r * 1500),
        )
    ],
}


def plan_for(scenario: str) -> list[dict]:
    return PLANS.get(scenario, LEGACY)


def nodes_for_dest(dest: str) -> list[str]:
    return ["sender", dest] if dest != "sender" else ["sender"]


def build_step(st: dict) -> list[tuple[int, bytes, tuple | None]]:
    """(src_port, payload, want) for every datagram of a step."""
    kind, n, base = st["kind"], st["count"], st["sport_base"]
    out = []
    if kind == "corpus":
        for i, (_, pdu) in enumerate(dis_pdus.build_all()):
            out.append((base + i, pdu, None))
        return out
    for i in range(n):
        sport = base + i
        if kind == "entity_state":
            entity = (sport % 65535) or 1
            marking = f"P{sport:05d}"[:11]
            out.append((sport, dis_pdus.pdu_entity_state(entity=entity, marking_text=marking),
                        want_entity_state(entity, marking)))
        elif kind == "fire":
            out.append((sport, dis_pdus.pdu_fire(), WANT_FIRE))
        elif kind == "detonation":
            out.append((sport, dis_pdus.pdu_detonation(), WANT_DETONATION))
        else:
            raise ValueError(kind)
    return out
