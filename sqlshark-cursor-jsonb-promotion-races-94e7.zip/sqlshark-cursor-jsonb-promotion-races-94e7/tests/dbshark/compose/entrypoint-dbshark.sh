#!/bin/sh
# Spawn dbshark (do not exec) so the resource sampler can watch its PID.
set -eu

HARNESS_DIR=$(cd "$(dirname "$0")" && pwd)
NODE=${NODE:-node}
SHARED=${SHARED:-/shared}
IFACE=${CAPTURE_IFACE:-eth0}
CONN="host=${PGHOST:-postgres} port=${PGPORT:-5432} user=${PGUSER:-postgres} password=${PGPASSWORD:-postgres} dbname=${PGDATABASE:-logshark_race}"
BIN=${DBSHARK_BIN:-/opt/logshark/dbshark}
LOG=$SHARED/$NODE.log
EXITF=$SHARED/$NODE.exit
READY=$SHARED/$NODE.ready
PIDF=$SHARED/$NODE.pid

mkdir -p "$SHARED"
rm -f "$READY" "$EXITF" "$PIDF"
: >"$LOG"

wait_tcp() {
    host=$1
    port=$2
    i=0
    while [ "$i" -lt 60 ]; do
        if python3 -c "import socket,sys; s=socket.socket(); s.settimeout(0.4); s.connect((sys.argv[1], int(sys.argv[2]))); s.close()" "$host" "$port" 2>/dev/null; then
            return 0
        fi
        i=$((i + 1))
        sleep 0.25
    done
    echo "timeout waiting for $host:$port" >&2
    return 1
}

# With db+dis, the container has two NICs. Capture the one that is not
# the route to Postgres so UDP DIS is on the sniffed iface.
pick_iface() {
    python3 - "$IFACE" "${PGHOST:-postgres}" <<'PY'
import socket, struct, sys
from pathlib import Path

prefer = sys.argv[1]
pghost = sys.argv[2]
ifaces = sorted(p.name for p in Path("/sys/class/net").iterdir() if p.name != "lo")
if not ifaces:
    print(prefer or "eth0")
    raise SystemExit
if len(ifaces) == 1:
    print(ifaces[0])
    raise SystemExit

def le32(h):
    return struct.unpack("<I", bytes.fromhex(h))[0]

def ip4(name):
    try:
        return socket.getaddrinfo(name, None, socket.AF_INET)[0][4][0]
    except OSError:
        return ""

def iface_for(dest_ip):
    dest = struct.unpack("!I", socket.inet_aton(dest_ip))[0]
    best, best_len = "", -1
    try:
        lines = Path("/proc/net/route").read_text().splitlines()[1:]
    except OSError:
        return ""
    for line in lines:
        parts = line.split()
        if len(parts) < 8:
            continue
        iface, dest_h, flags_h, mask_h = parts[0], parts[1], parts[3], parts[7]
        if int(flags_h, 16) & 1 == 0:
            continue
        net, mask = le32(dest_h), le32(mask_h)
        if dest & mask == net & mask:
            n = bin(mask).count("1")
            if n > best_len:
                best, best_len = iface, n
    return best

pgip = ip4(pghost)
pgdev = iface_for(pgip) if pgip else ""
dis = [i for i in ifaces if i != pgdev]
if dis:
    print(dis[0])
elif prefer in ifaces:
    print(prefer)
else:
    print(ifaces[0])
PY
}

if [ ! -x "$BIN" ]; then
    echo "missing dbshark binary at $BIN (bind-mount the host build)" >&2
    echo 127 >"$EXITF"
    exit 127
fi

wait_tcp "${PGHOST:-postgres}" "${PGPORT:-5432}"
IFACE=$(pick_iface)
echo "$NODE: capture iface=$IFACE" >&2

stagger=${STAGGER_MS:-0}
if [ "$stagger" -gt 0 ] 2>/dev/null; then
    echo "$NODE: stagger ${stagger}ms" >&2
    python3 -c "import time,sys; time.sleep(int(sys.argv[1])/1000.0)" "$stagger"
fi

# Node identity, durable spill and batch cadence exist only in the fixed
# binary. A pre-fix build (the regression column) gets the bare command.
SPILL=$SHARED/spill/$NODE
NEW_FLAGS=0
if "$BIN" --help 2>&1 | grep -q -- '--node-id'; then
    NEW_FLAGS=1
fi
# shellcheck disable=SC2086
set -- "$BIN" -i "$IFACE" -p dis -f "udp port 3000" -o "$CONN" --log-level info
if [ "$NEW_FLAGS" = 1 ]; then
    mkdir -p "$SPILL"
    set -- "$@" --node-id "$NODE" --node-column node --spill-dir "$SPILL"
    if [ -n "${FLUSH_MS:-}" ]; then
        set -- "$@" --flush-ms "$FLUSH_MS"
    fi
    if [ -n "${DB_RETRIES:-}" ]; then
        set -- "$@" --db-retries "$DB_RETRIES"
    fi
fi
if [ -n "${DBSHARK_FLAGS:-}" ]; then
    # Intentional word-split of extra flags (--unlogged, etc.).
    # shellcheck disable=SC2086
    set -- "$@" $DBSHARK_FLAGS
fi
# Per-node fault injection (DBSHARK_FAULT_<NODE> -> DBSHARK_FAULT) and
# per-node libpq options (PGOPTIONS_<NODE> -> PGOPTIONS, e.g. lock_timeout).
node_upper=$(echo "$NODE" | tr '[:lower:]-' '[:upper:]_')
fault=$(eval "printf '%s' \"\${DBSHARK_FAULT_${node_upper}:-}\"")
if [ -n "$fault" ]; then
    export DBSHARK_FAULT=$fault
    echo "$NODE: DBSHARK_FAULT=$fault" >&2
fi
pgopts=$(eval "printf '%s' \"\${PGOPTIONS_${node_upper}:-}\"")
if [ -n "$pgopts" ]; then
    export PGOPTIONS=$pgopts
    echo "$NODE: PGOPTIONS=$pgopts" >&2
fi

echo "$NODE: $*" >&2
# Postgres can still be restarting after the healthcheck. A connect
# failure that says "starting up" is not a capture result; try again.
child=""
for attempt in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
    : >"$LOG"
    "$@" >>"$LOG" 2>&1 &
    child=$!
    echo "$child" >"$PIDF"
    i=0
    while [ "$i" -lt 40 ]; do
        if grep -q "capturing on" "$LOG" 2>/dev/null; then
            break
        fi
        if ! kill -0 "$child" 2>/dev/null; then
            break
        fi
        i=$((i + 1))
        sleep 0.25
    done
    if grep -q "capturing on" "$LOG" 2>/dev/null; then
        break
    fi
    if grep -q "starting up" "$LOG" 2>/dev/null; then
        wait "$child" 2>/dev/null || true
        echo "$NODE: postgres still starting (attempt $attempt); retrying" >&2
        sleep 1
        continue
    fi
    break
done

python3 "$HARNESS_DIR/resource_sampler.py" \
    --pid "$child" \
    --node "$NODE" \
    --shared "$SHARED" \
    --interval-ms "${SAMPLE_MS:-100}" \
    >>"$SHARED/$NODE.sampler.log" 2>&1 &
sampler=$!

# Ready once live capture has started (or if dbshark already died).
i=0
while [ "$i" -lt 120 ]; do
    if grep -q "capturing on" "$LOG" 2>/dev/null; then
        date -u +%Y-%m-%dT%H:%M:%SZ >"$READY"
        break
    fi
    if ! kill -0 "$child" 2>/dev/null; then
        echo "$NODE: dbshark exited before capture started" >&2
        date -u +%Y-%m-%dT%H:%M:%SZ >"$READY"
        break
    fi
    i=$((i + 1))
    sleep 0.25
done
if [ ! -f "$READY" ]; then
    echo "$NODE: capture banner not seen; marking ready anyway" >&2
    date -u +%Y-%m-%dT%H:%M:%SZ >"$READY"
fi

while [ ! -f "$SHARED/stop" ] && kill -0 "$child" 2>/dev/null; do
    sleep 0.1
done

if kill -0 "$child" 2>/dev/null; then
    kill -TERM "$child" 2>/dev/null || true
fi
rc=0
wait "$child" || rc=$?
# 143 = 128+SIGTERM. The fixed binary reports its own outcome: it exits 0
# after a clean final flush (recovered errors are logged but are not a
# loss) and 3 when spill files remain, so only the bare signal status is
# mapped. The pre-fix binary has no such contract; keep the old rule.
if [ "$rc" -eq 143 ]; then
    if [ "$NEW_FLAGS" = 1 ]; then
        if grep -q "summary " "$LOG"; then
            rc=0
        fi
    elif grep -q "errors=0" "$LOG" && grep -q "summary " "$LOG"; then
        rc=0
    elif grep -q "summary " "$LOG" && ! grep -q "ERROR" "$LOG"; then
        rc=0
    fi
fi

# The capture's own exit code, before any replay: the judge waits for
# every node to be out of the database before it releases held locks.
echo "$rc" >"$SHARED/$NODE.capture.exit"

# Rows that could not be confirmed are on disk under $SPILL. Scenarios
# that blocked the database (lock-exhaust-spill) release it and then
# write replay_go; the restart path is the same binary in --replay-spill
# mode, so the exit code below describes the node *after* its replay.
# dbshark keeps files under <spill-dir>/<node-id>/<database>/.
has_spill() {
    find "$SPILL" -name '*.spill' 2>/dev/null | grep -q .
}
if [ "$NEW_FLAGS" = 1 ] && has_spill; then
    echo "$NODE: spill files remain; waiting for replay_go" >&2
    i=0
    while [ "$i" -lt 6000 ] && [ ! -f "$SHARED/replay_go" ] && [ ! -f "$SHARED/no_replay" ]; do
        i=$((i + 1))
        sleep 0.1
    done
    if [ -f "$SHARED/replay_go" ]; then
        echo "$NODE: replaying spill (capture rc=$rc)" >&2
        rc=0
        "$BIN" --replay-spill -p dis -o "$CONN" --log-level info \
            --node-id "$NODE" --node-column node --spill-dir "$SPILL" \
            >"$SHARED/$NODE.replay.log" 2>&1 || rc=$?
    fi
fi
# Sampler writes the summary when the PID vanishes (or on SIGTERM).
# Wait for that file before publishing the exit code so the judge sees it.
kill -TERM "$sampler" 2>/dev/null || true
wait "$sampler" 2>/dev/null || true
i=0
while [ "$i" -lt 50 ] && [ ! -f "$SHARED/$NODE.resources.summary.json" ]; do
    i=$((i + 1))
    sleep 0.1
done
echo "$rc" >"$EXITF"
# Keep this netns alive so compose sidecars can attach and the judge can
# still read logs if dbshark died on the first packet.
while [ ! -f "$SHARED/stop" ]; do
    sleep 0.1
done
exit "$rc"
