#!/usr/bin/env bash
# One-command multi-node race: three dbsharks, DIS driver, UDP stubs, Postgres.
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/../../.." && pwd)
COMPOSE_DIR=$ROOT/tests/dbshark/compose
WS=${WS:-$HOME/wireshark-4.2.6}
WS_LIB=${WS_LIB:-$WS/build/run}
SCENARIO=${SCENARIO:-cold-burst}

# Where the capture nodes get dbshark from:
#   DBSHARK_IMAGE unset: host build/run/dbshark + $WS_LIB bind-mounted into
#                        ubuntu:22.04 (compose.host.yaml)
#   DBSHARK_IMAGE=name:  prebuilt image with dbshark and libs baked in, e.g.
#                        dbshark-test:rhel9 from tests/dbshark/build/Dockerfile.rhel
#                        (compose.image.yaml)
DBSHARK_IMAGE=${DBSHARK_IMAGE:-}
if [ -n "$DBSHARK_IMAGE" ]; then
    OVERLAY=$COMPOSE_DIR/compose.image.yaml
    if ! docker image inspect "$DBSHARK_IMAGE" >/dev/null 2>&1; then
        echo "error: image $DBSHARK_IMAGE not found. Build it with tests/dbshark/run-rhel.sh or docker build -f tests/dbshark/build/Dockerfile.rhel" >&2
        exit 2
    fi
else
    OVERLAY=$COMPOSE_DIR/compose.host.yaml
    dbshark=$ROOT/build/run/dbshark
    if [ ! -x "$dbshark" ]; then
        echo "error: $dbshark is not executable. Build it with ./tests/dbshark/build/build.sh" >&2
        exit 2
    fi
    if [ ! -e "$WS_LIB/libwireshark.so" ] && ! ls "$WS_LIB"/libwireshark.so.* >/dev/null 2>&1; then
        echo "error: Wireshark libs not found in $WS_LIB (set WS= or WS_LIB=)" >&2
        exit 2
    fi
fi
if [ ! -f "$COMPOSE_DIR/dis_pdus.py" ]; then
    echo "error: $COMPOSE_DIR/dis_pdus.py missing (needed by the DIS sender)" >&2
    exit 2
fi
COMPOSE="docker compose -f $COMPOSE_DIR/compose.yaml -f $OVERLAY"

export WS_LIB
export DBSHARK_IMAGE
export SCENARIO
export SAMPLE_MS=${SAMPLE_MS:-100}
export MEMORY_CEILING_KB=${MEMORY_CEILING_KB:-}
export STAGGER_MS=0
export DBSHARK_FLAGS=${DBSHARK_FLAGS:-}
export PG_MAX_LOCKS=${PG_MAX_LOCKS:-64}
# DBSHARK_HOST_BIN: another host binary for the capture nodes (host overlay
# only), e.g. a pre-fix build to produce the regression column.
export DBSHARK_HOST_BIN=${DBSHARK_HOST_BIN:-$ROOT/build/run/dbshark}
export FLUSH_MS=${FLUSH_MS:-}
export DB_RETRIES=${DB_RETRIES:-}
export DBSHARK_FAULT_SENDER=${DBSHARK_FAULT_SENDER:-}
export DBSHARK_FAULT_RECEIVER=${DBSHARK_FAULT_RECEIVER:-}
export DBSHARK_FAULT_WITNESS=${DBSHARK_FAULT_WITNESS:-}
export PGOPTIONS_SENDER=${PGOPTIONS_SENDER:-}
export PGOPTIONS_RECEIVER=${PGOPTIONS_RECEIVER:-}
export PGOPTIONS_WITNESS=${PGOPTIONS_WITNESS:-}

ALL_SCENARIOS="cold-burst stagger unlogged unlogged-kill-pg locks promote-race deadlock lock-exhaust-spill conn-loss contention"
case "$SCENARIO" in
    cold-burst) ;;
    stagger) STAGGER_MS=${STAGGER_MS_OVERRIDE:-50} ;;
    unlogged) DBSHARK_FLAGS="${DBSHARK_FLAGS} --unlogged" ;;
    unlogged-kill-pg) DBSHARK_FLAGS="${DBSHARK_FLAGS} --unlogged" ;;
    locks) PG_MAX_LOCKS=32 ;;
    # Two nodes held inside their first COPY while the witness promotes the
    # column they cached as BIGINT; their stale batches must be rebuilt.
    promote-race) FLUSH_MS=${FLUSH_MS:-1000} ;;
    # Forced 40P01 inside a multi-table batch on two nodes at once.
    deadlock) FLUSH_MS=${FLUSH_MS:-1000} ;;
    # dis locked for the whole capture: bounded retries, durable spill,
    # --replay-spill after the judge releases the table.
    lock-exhaust-spill)
        FLUSH_MS=${FLUSH_MS:-1000}
        DB_RETRIES=${DB_RETRIES:-3}
        PGOPTIONS_SENDER=${PGOPTIONS_SENDER:--c lock_timeout=1500}
        PGOPTIONS_RECEIVER=${PGOPTIONS_RECEIVER:--c lock_timeout=1500}
        PGOPTIONS_WITNESS=${PGOPTIONS_WITNESS:--c lock_timeout=1500}
        ;;
    # Connection dropped before COMMIT / COMMIT reply lost, one node each.
    conn-loss)
        FLUSH_MS=${FLUSH_MS:-1000}
        DBSHARK_FAULT_SENDER=${DBSHARK_FAULT_SENDER:-commit-lost@2}
        DBSHARK_FAULT_RECEIVER=${DBSHARK_FAULT_RECEIVER:-conn-lost-before-commit@2}
        DBSHARK_FAULT_WITNESS=${DBSHARK_FAULT_WITNESS:-conn-lost-before-commit@1}
        ;;
    # Repeated promotion / stale-batch contention, fast cadence, empty schema.
    contention) FLUSH_MS=${FLUSH_MS:-300} ;;
    *)
        echo "error: unknown SCENARIO=$SCENARIO ($(echo $ALL_SCENARIOS | tr ' ' '|'))" >&2
        exit 2
        ;;
esac
export STAGGER_MS DBSHARK_FLAGS PG_MAX_LOCKS FLUSH_MS DB_RETRIES
export DBSHARK_FAULT_SENDER DBSHARK_FAULT_RECEIVER DBSHARK_FAULT_WITNESS
export PGOPTIONS_SENDER PGOPTIONS_RECEIVER PGOPTIONS_WITNESS

SHARED_HOST=${RACE_SHARED:-$COMPOSE_DIR/.shared}
# Compose interpolates RACE_SHARED; keep it absolute so cwd does not matter.
export RACE_SHARED=$SHARED_HOST
rm -rf "$SHARED_HOST" 2>/dev/null || true
if [ -e "$SHARED_HOST" ]; then
    # Spill files are written by root inside the nodes (mode 0700); a
    # leftover from a previous run must not be replayed into this one.
    docker run --rm -v "$SHARED_HOST:/s" busybox:1.36 sh -c 'rm -rf /s/* /s/.[!.]* 2>/dev/null' >/dev/null 2>&1 || true
    rm -rf "$SHARED_HOST" 2>/dev/null || true
fi
mkdir -p "$SHARED_HOST"

cd "$COMPOSE_DIR"

$COMPOSE down -v --remove-orphans >/dev/null 2>&1 || true
if ! $COMPOSE up --build -d; then
    echo "compose up failed; container logs:" >&2
    $COMPOSE ps -a >&2 || true
    $COMPOSE logs >&2 || true
    $COMPOSE down -v --remove-orphans >/dev/null 2>&1 || true
    exit 2
fi

JUDGE_TIMEOUT=${JUDGE_TIMEOUT:-600}
python3 "$COMPOSE_DIR/show_logs.py" --dir "$SHARED_HOST" --follow \
    --stop-file "$SHARED_HOST/report.json" --timeout "$JUDGE_TIMEOUT" &
logpid=$!

i=0
jstatus=""
while [ "$i" -lt "$JUDGE_TIMEOUT" ]; do
    jstatus=$($COMPOSE ps -a --format '{{.Service}} {{.State}}' | awk '$1=="judge"{print $2}')
    case "$jstatus" in
        exited|dead)
            break
            ;;
    esac
    i=$((i + 1))
    sleep 1
done

wait "$logpid" 2>/dev/null || true

# A judge that is still running after JUDGE_TIMEOUT has no exit code yet
# (docker reports 0 for a live container); that is a failure, not a pass.
jid=$($COMPOSE ps -aq judge | head -n 1)
rc=1
if [ -n "$jid" ]; then
    if docker inspect -f '{{.State.Running}}' "$jid" 2>/dev/null | grep -q true; then
        echo "judge still running after ${JUDGE_TIMEOUT}s; node wrappers:" >&2
        for n in sender receiver witness; do
            echo "--- $n (last lines)" >&2
            tail -n 5 "$SHARED_HOST/$n.log" 2>/dev/null >&2 || true
        done
        $COMPOSE logs --no-color --tail 20 sender receiver witness judge >&2 || true
        rc=124
    else
        rc=$(docker inspect -f '{{.State.ExitCode}}' "$jid")
    fi
fi
if [ ! -f "$SHARED_HOST/report.json" ]; then
    echo "no report.json in $SHARED_HOST (judge rc=$rc)" >&2
    [ "$rc" = 0 ] && rc=1
fi
# The judge's own narrative (phases, lock waits, per-node verdicts) lives
# in its container log; keep it next to the report.
$COMPOSE logs --no-color --no-log-prefix judge >"$SHARED_HOST/judge.log" 2>/dev/null || true
if [ -f "$SHARED_HOST/judge.log" ]; then
    grep -E "^judge: (PASS|FAIL|  )" "$SHARED_HOST/judge.log" >&2 || true
fi

$COMPOSE down --remove-orphans >/dev/null 2>&1 || true
exit "${rc:-1}"
