#!/usr/bin/env python3
"""Print sender and receiver dbshark logs as two terminal columns."""
from __future__ import annotations

import argparse
import shutil
import sys
import time
from pathlib import Path


def term_width() -> int:
    return max(shutil.get_terminal_size((100, 24)).columns, 60)


def col_width(total: int) -> int:
    return max((total - 3) // 2, 24)


def clip(text: str, width: int) -> str:
    text = text.replace("\t", " ").replace("\r", "").rstrip("\n")
    if len(text) <= width:
        return text.ljust(width)
    if width <= 1:
        return text[:width]
    return text[: width - 1] + "…"


def paint(text: str, color: bool) -> str:
    if not color:
        return text
    raw = text.rstrip()
    if "ERROR" in raw:
        return f"\033[31m{text}\033[0m"
    if "WARN" in raw:
        return f"\033[33m{text}\033[0m"
    return text


def header(width: int, color: bool) -> str:
    left = clip("sender", width)
    right = clip("receiver", width)
    if color:
        left = f"\033[1m{left}\033[0m"
        right = f"\033[1m{right}\033[0m"
    rule = "-" * width
    return f"{left} | {right}\n{rule} | {rule}"


def pair_line(left: str | None, right: str | None, width: int, color: bool) -> str:
    l = paint(clip(left or "", width), color)
    r = paint(clip(right or "", width), color)
    return f"{l} | {r}"


def read_new(path: Path, offset: int) -> tuple[list[str], int]:
    if not path.is_file():
        return [], offset
    try:
        size = path.stat().st_size
    except OSError:
        return [], offset
    if size < offset:
        offset = 0
    if size == offset:
        return [], offset
    with path.open("r", errors="replace") as fh:
        fh.seek(offset)
        chunk = fh.read()
        offset = fh.tell()
    return chunk.splitlines(), offset


def emit_pairs(lefts: list[str], rights: list[str], width: int, color: bool, out) -> None:
    n = max(len(lefts), len(rights))
    for i in range(n):
        print(
            pair_line(
                lefts[i] if i < len(lefts) else None,
                rights[i] if i < len(rights) else None,
                width,
                color,
            ),
            file=out,
            flush=True,
        )


def dump(shared: Path, out) -> None:
    color = out.isatty()
    width = col_width(term_width())
    print(header(width, color), file=out, flush=True)
    left = []
    right = []
    sl = shared / "sender.log"
    rl = shared / "receiver.log"
    if sl.is_file():
        left = sl.read_text(errors="replace").splitlines()
    if rl.is_file():
        right = rl.read_text(errors="replace").splitlines()
    emit_pairs(left, right, width, color, out)
    if not left and not right:
        print("(no sender.log / receiver.log yet)", file=out, flush=True)


def follow(shared: Path, out, stop: Path | None, timeout_s: float) -> None:
    color = out.isatty()
    width = col_width(term_width())
    print(header(width, color), file=out, flush=True)
    off_l = off_r = 0
    deadline = time.monotonic() + timeout_s
    saw_stop = False
    idle = 0
    while time.monotonic() < deadline:
        if stop is not None and stop.exists():
            saw_stop = True
        left, off_l = read_new(shared / "sender.log", off_l)
        right, off_r = read_new(shared / "receiver.log", off_r)
        if left or right:
            emit_pairs(left, right, width, color, out)
            idle = 0
        else:
            idle += 1
            if saw_stop and idle > 8:
                break
        time.sleep(0.1)
    left, off_l = read_new(shared / "sender.log", off_l)
    right, off_r = read_new(shared / "receiver.log", off_r)
    if left or right:
        emit_pairs(left, right, width, color, out)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dir", default=".", help="host directory mounted as /shared")
    ap.add_argument("--follow", action="store_true")
    ap.add_argument("--stop-file", default="", help="exit follow shortly after this file appears")
    ap.add_argument("--timeout", type=float, default=240.0)
    args = ap.parse_args()
    shared = Path(args.dir)
    out = sys.stderr
    if args.follow:
        stop = Path(args.stop_file) if args.stop_file else None
        follow(shared, out, stop, args.timeout)
    else:
        dump(shared, out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
