# Multi-node dbshark race harness

Three independent live-capture nodes (separate containers, separate
dbshark processes) write the same DIS traffic to one Postgres. The judge
checks the database **per record and per node**: every datagram the driver
sent must be present exactly once for every node that captured it, with
its payload intact, nothing extra, nothing duplicated, previously
committed rows untouched and no spill files left behind. Row counts alone
never pass a scenario.

## Topology

| Service | Role |
|---|---|
| `postgres` | `postgres:18.6`, database `logshark_race`, network `db` |
| `sender` | dbshark capturing the `dis` NIC; the DIS driver shares its netns, so it sees **every** datagram (its own egress) |
| `receiver` | dbshark; sees unicast sent to `dis-receiver:3000` (plus a UDP stub so the port answers) |
| `witness` | dbshark; sees unicast sent to `dis-witness:3000` only. Lets a scenario make one node observe a schema-changing PDU that the receiver never captures |
| `dis-driver` | phased DIS sender (`dis_sender.py`), writes the manifest `sent_records.json` |
| `judge` | walks the plan (`race_plan.py`), runs scenario hooks against Postgres, stops the nodes, verifies |
| `pg-killer` | SIGKILLs a postmaster child for `unlogged-kill-pg` |

Each node runs `--node-id <name> --node-column node --spill-dir /shared/spill/<name>`
(the fixed binary only; a pre-fix build used as regression column gets the
bare command and is judged by source port). `FLUSH_MS` sets the batch
cadence so a short capture has several batch boundaries.

## Run

```bash
# capture nodes from a prebuilt image (RHEL 8/9 test image; see ../run-rhel.sh)
DBSHARK_IMAGE=dbshark-test:rhel9 SCENARIO=promote-race ./tests/dbshark/compose/run.sh

# host build bind-mounted into ubuntu:22.04 (the host binary must be linked
# on a glibc-compatible distro)
SCENARIO=promote-race ./tests/dbshark/compose/run.sh

# regression column: same scenario, pre-fix binary/image
DBSHARK_IMAGE=dbshark-test:rhel9-before SCENARIO=promote-race ./tests/dbshark/compose/run.sh
DBSHARK_HOST_BIN=/path/to/old/dbshark SCENARIO=promote-race ./tests/dbshark/compose/run.sh
```

Files land in `RACE_SHARED` (default `tests/dbshark/compose/.shared/`):
`report.json` (verdict, per-node record accounting, scenario facts, node
counters, resources), `judge.log`, `<node>.log`, `<node>.replay.log`,
`sent_records.json`, `spill/<node>/…`.

## Scenarios

Synchronisation is never a sleep. The *barrier* is a `BEFORE INSERT`
trigger on `dis` that calls `pg_advisory_xact_lock(424242)` while the judge
holds that key at session level: a node's COPY blocks on its first row
and the judge sees it in `pg_locks`. Lock queue order in Postgres is FIFO,
so "the ALTER is granted before the blocked node's next batch" is a
guarantee, not a race the test hopes to win.

| `SCENARIO` | What is forced | Must hold |
|---|---|---|
| `promote-race` | `dis.entity_id_site` pre-created as BIGINT plus one committed row. Sender and receiver journal 3000 Entity States and are held inside their first COPY (both cached the scalar type). Fire PDUs go to the witness only; its `ALTER … TYPE JSONB` queues behind the two COPYs; the judge releases the barrier only once that waiter is visible. The held nodes then submit batches encoded against the stale type. | Every record of all three nodes present once with full payload (JSONB arrays for fire rows, numbers for scalar rows), column is `jsonb`, pre-existing row intact |
| `deadlock` | After a seed commit, the judge holds `ACCESS EXCLUSIVE` on `dis_category` and, once both nodes are inside `COPY dis`, asks for `dis`. Barrier opens → nodes reach `COPY dis_category` → cycle → Postgres cancels **both nodes** with 40P01 (the judge's own `deadlock_timeout` is pushed out so it is never the victim). | Both nodes logged `deadlock detected`; every record of the rolled-back multi-table batches replayed; 0 duplicates |
| `lock-exhaust-spill` | `dis` stays `ACCESS EXCLUSIVE` locked for the entire capture; nodes run `--db-retries 3` with `lock_timeout=1500`. Batches fail 55P03 three times and go to `/shared/spill/<node>/`. After the nodes exit the judge releases the table and writes `replay_go`; each node wrapper then runs `dbshark --replay-spill` (the restart path). | Spill files existed for sender and receiver before release; after replay every record present once; no spill file left |
| `conn-loss` | `DBSHARK_FAULT`: sender `commit-lost@2` (COMMIT sent, reply never read), receiver `conn-lost-before-commit@2`, witness `conn-lost-before-commit@1`, five traffic bursts with batch boundaries between them | Every record once — the lost-reply batch is resolved through `dbshark_batches`, not re-sent |
| `contention` | Empty schema, `FLUSH_MS=300`, six rounds of scalar / fire / detonation / scalar bursts alternating between receiver and witness: repeated promotions of several columns while other nodes hold stale batches, concurrent table and column creation at the start | Strict per-node integrity, 0 duplicates, no spill left |
| `cold-burst` (default) | Original: simultaneous first packet, 43-type corpus, fire burst, 500 unique Entity States | Strict per-node integrity (corpus rows by presence, Entity State / fire rows by payload) |
| `stagger` | Receiver starts 50 ms later | as `cold-burst` |
| `unlogged` | `--unlogged` on all nodes | as `cold-burst`, `dis` is UNLOGGED |
| `unlogged-kill-pg` | `--unlogged`, then SIGKILL a postmaster child | empty heap after restart |
| `locks` | `max_locks_per_transaction=32` | as `cold-burst` |

The judge fails a scenario on any missing / duplicated / wrong-payload
(node, record), on any row no node sent, on a non-zero node exit, on
`dropped_rows>0` in a node summary, on leftover `.spill` / `.quarantine`
files, and on log lines that mean rows were discarded (`dropping
uncommitted rows`, `they are lost`). Recovered failures (`unsupported jsonb
version`, `deadlock detected`, `lock timeout`) are expected on the fixed
binary and are judged through the data.

## Resource files

Each dbshark container samples **its own process** every 100 ms
(`SAMPLE_MS`): `/shared/<node>.resources.csv` (time series) and
`/shared/<node>.resources.summary.json` (peaks), merged into
`report.json`. Columns: `vmrss_kb` / `vmhwm_kb` (RSS), `pss_kb`, cgroup
`memory.current` / `memory.peak`, CPU user/sys seconds, FD count; `phase`
is the judge's current step. `MEMORY_CEILING_KB` is optional.
