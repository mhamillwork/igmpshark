#!/usr/bin/env python3
"""Sample one dbshark PID plus this container's cgroup. Do not sample sidecars."""
from __future__ import annotations

import argparse
import csv
import json
import os
import signal
import time
from pathlib import Path


def clk_tck() -> float:
    try:
        return float(os.sysconf("SC_CLK_TCK"))
    except (ValueError, OSError):
        return 100.0


def read_status(pid: int) -> dict[str, int]:
    out = {"vmrss_kb": -1, "vmhwm_kb": -1, "vmsize_kb": -1, "threads": -1}
    try:
        text = Path(f"/proc/{pid}/status").read_text()
    except OSError:
        return out
    keys = {
        "VmRSS:": "vmrss_kb",
        "VmHWM:": "vmhwm_kb",
        "VmSize:": "vmsize_kb",
        "Threads:": "threads",
    }
    for line in text.splitlines():
        for prefix, name in keys.items():
            if line.startswith(prefix):
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        out[name] = int(parts[1])
                    except ValueError:
                        pass
    return out


def read_pss_kb(pid: int) -> int:
    try:
        text = Path(f"/proc/{pid}/smaps_rollup").read_text()
    except OSError:
        return -1
    for line in text.splitlines():
        if line.startswith("Pss:"):
            try:
                return int(line.split()[1])
            except (IndexError, ValueError):
                return -1
    return -1


def read_stat_cpu(pid: int, hz: float) -> tuple[float, float]:
    try:
        raw = Path(f"/proc/{pid}/stat").read_text()
        close = raw.rfind(")")
        rest = raw[close + 2 :].split()
        utime = int(rest[11]) / hz
        stime = int(rest[12]) / hz
        return utime, stime
    except (OSError, IndexError, ValueError):
        return -1.0, -1.0


def read_io(pid: int) -> tuple[int, int]:
    try:
        text = Path(f"/proc/{pid}/io").read_text()
    except OSError:
        return -1, -1
    rbytes = wbytes = -1
    for line in text.splitlines():
        if line.startswith("read_bytes:"):
            rbytes = int(line.split()[1])
        elif line.startswith("write_bytes:"):
            wbytes = int(line.split()[1])
    return rbytes, wbytes


def fd_count(pid: int) -> int:
    try:
        return len(os.listdir(f"/proc/{pid}/fd"))
    except OSError:
        return -1


def cgroup_paths() -> dict[str, Path]:
    root = Path("/sys/fs/cgroup")
    return {
        "mem": root / "memory.current",
        "peak": root / "memory.peak",
        "cpu": root / "cpu.stat",
    }


def read_cgroup() -> tuple[int, int, int]:
    p = cgroup_paths()
    cur = peak = cpu = -1
    try:
        cur = int(p["mem"].read_text().strip())
    except (OSError, ValueError):
        pass
    try:
        peak = int(p["peak"].read_text().strip())
    except (OSError, ValueError):
        pass
    try:
        for line in p["cpu"].read_text().splitlines():
            if line.startswith("usage_usec"):
                cpu = int(line.split()[1])
                break
    except (OSError, ValueError):
        pass
    return cur, peak, cpu


def current_phase(shared: Path) -> str:
    f = shared / "phase"
    try:
        return f.read_text().strip() or "idle"
    except OSError:
        return "idle"


def summarize(rows: list[dict], node: str, seconds: float) -> dict:
    def mx(key: str) -> int | float:
        vals = [r[key] for r in rows if isinstance(r.get(key), (int, float)) and r[key] >= 0]
        return max(vals) if vals else -1

    by_phase: dict[str, dict] = {}
    for r in rows:
        ph = str(r.get("phase") or "idle")
        slot = by_phase.setdefault(ph, {"peak_rss_kb": -1, "peak_pss_kb": -1, "n": 0})
        slot["n"] += 1
        if r.get("vmrss_kb", -1) > slot["peak_rss_kb"]:
            slot["peak_rss_kb"] = r["vmrss_kb"]
        if r.get("pss_kb", -1) > slot["peak_pss_kb"]:
            slot["peak_pss_kb"] = r["pss_kb"]

    first = rows[0] if rows else {}
    last = rows[-1] if rows else {}
    return {
        "node": node,
        "samples": len(rows),
        "seconds": round(seconds, 3),
        "first_rss_kb": first.get("vmrss_kb", -1),
        "last_rss_kb": last.get("vmrss_kb", -1),
        "peak_rss_kb": mx("vmrss_kb"),
        "peak_hwm_kb": mx("vmhwm_kb"),
        "peak_pss_kb": mx("pss_kb"),
        "peak_cgroup_bytes": mx("cgroup_mem_peak_bytes")
        if mx("cgroup_mem_peak_bytes") >= 0
        else mx("cgroup_mem_current_bytes"),
        "cpu_user_s": last.get("cpu_user_s", -1),
        "cpu_sys_s": last.get("cpu_sys_s", -1),
        "max_fds": mx("num_fds"),
        "max_threads": mx("threads"),
        "by_phase": by_phase,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pid", type=int, required=True)
    ap.add_argument("--node", required=True)
    ap.add_argument("--shared", default="/shared")
    ap.add_argument("--interval-ms", type=int, default=100)
    args = ap.parse_args()

    shared = Path(args.shared)
    csv_path = shared / f"{args.node}.resources.csv"
    summary_path = shared / f"{args.node}.resources.summary.json"
    hz = clk_tck()
    fields = [
        "ts_mono_s",
        "phase",
        "vmrss_kb",
        "vmhwm_kb",
        "vmsize_kb",
        "pss_kb",
        "threads",
        "num_fds",
        "cpu_user_s",
        "cpu_sys_s",
        "io_read_bytes",
        "io_write_bytes",
        "cgroup_mem_current_bytes",
        "cgroup_mem_peak_bytes",
        "cgroup_cpu_usec",
    ]
    rows: list[dict] = []
    t0 = time.monotonic()
    interval = max(args.interval_ms, 20) / 1000.0
    stop = False

    def _stop(_signum=None, _frame=None) -> None:
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)

    try:
        with csv_path.open("w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=fields)
            w.writeheader()
            fh.flush()
            while not stop and Path(f"/proc/{args.pid}").is_dir():
                st = read_status(args.pid)
                ut, stime = read_stat_cpu(args.pid, hz)
                rb, wb = read_io(args.pid)
                cur, peak, cpu = read_cgroup()
                row = {
                    "ts_mono_s": round(time.monotonic() - t0, 3),
                    "phase": current_phase(shared),
                    **st,
                    "pss_kb": read_pss_kb(args.pid),
                    "num_fds": fd_count(args.pid),
                    "cpu_user_s": round(ut, 4) if ut >= 0 else -1,
                    "cpu_sys_s": round(stime, 4) if stime >= 0 else -1,
                    "io_read_bytes": rb,
                    "io_write_bytes": wb,
                    "cgroup_mem_current_bytes": cur,
                    "cgroup_mem_peak_bytes": peak,
                    "cgroup_cpu_usec": cpu,
                }
                rows.append(row)
                w.writerow(row)
                fh.flush()
                # Wake early on SIGTERM so we can flush the summary.
                deadline = time.monotonic() + interval
                while not stop and time.monotonic() < deadline:
                    time.sleep(min(0.02, max(0.0, deadline - time.monotonic())))
    finally:
        summary = summarize(rows, args.node, time.monotonic() - t0)
        summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
