#!/usr/bin/env python3
"""Phased DIS UDP driver. Shares the sender dbshark netns.

Walks the scenario plan (race_plan.py): for every step it waits for the
judge to publish the step's phase, sends the datagrams unicast to the
step's destination node, appends each one to the manifest and touches
sent_<phase>. The manifest (sent_records.json) is what the judge checks
the database against: one entry per datagram with its source port, the
nodes that must have captured it and the expected payload.
"""
from __future__ import annotations

import json
import os
import socket
import sys
import time
from pathlib import Path

SHARED = Path(os.environ.get("SHARED", "/shared"))
PORT = int(os.environ.get("RECEIVER_PORT", "3000"))
SCENARIO = os.environ.get("SCENARIO", "cold-burst")
HOSTS = {
    "receiver": os.environ.get("RECEIVER_HOST", "dis-receiver"),
    "witness": os.environ.get("WITNESS_HOST", "dis-witness"),
}

sys.path.insert(0, str(Path(__file__).resolve().parent))
import race_plan  # noqa: E402


def wait_file(path: Path, timeout: float = 90.0) -> None:
    deadline = time.monotonic() + timeout
    while not path.exists():
        if time.monotonic() > deadline:
            raise SystemExit(f"timeout waiting for {path}")
        time.sleep(0.05)


def wait_phase(name: str, timeout: float = 600.0) -> None:
    deadline = time.monotonic() + timeout
    f = SHARED / "phase"
    while True:
        try:
            if f.read_text().strip() == name:
                return
        except OSError:
            pass
        if (SHARED / "stop").exists():
            raise SystemExit(0)
        if time.monotonic() > deadline:
            raise SystemExit(f"timeout waiting for phase={name}")
        time.sleep(0.05)


def send_step(st: dict, manifest: list) -> int:
    dest = (HOSTS[st["dest"]], PORT)
    n = 0
    for sport, pdu, want in race_plan.build_step(st):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # One socket per datagram: the bound port is the record id.
            sock.bind(("0.0.0.0", sport))
            sock.sendto(pdu, dest)
            n += 1
            manifest.append({"src_port": sport, "phase": st["phase"], "kind": st["kind"],
                             "dest": st["dest"], "nodes": race_plan.nodes_for_dest(st["dest"]),
                             "want": want})
        finally:
            sock.close()
    return n


def main() -> int:
    SHARED.mkdir(parents=True, exist_ok=True)
    for name in ("sender.ready", "receiver.ready", "witness.ready", "stub.ready", "witness_stub.ready"):
        wait_file(SHARED / name, 180)
    (SHARED / "driver.ready").write_text("1\n")

    plan = race_plan.plan_for(SCENARIO)
    manifest: list = []
    counts: dict = {"total": 0}
    for st in plan:
        wait_phase(st["phase"])
        sent = send_step(st, manifest)
        counts[st["phase"]] = sent
        counts["total"] += sent
        # Legacy keys the old reports used.
        if st["kind"] == "corpus":
            counts["cold"] = sent
        elif st["phase"] in ("fire", "unique"):
            counts[st["phase"]] = sent
        (SHARED / "sent_records.json").write_text(json.dumps(manifest) + "\n")
        (SHARED / "sent.json").write_text(json.dumps(counts, indent=2) + "\n")
        (SHARED / f"sent_{st['phase']}").write_text("1\n")
    while not (SHARED / "stop").exists():
        time.sleep(0.1)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
