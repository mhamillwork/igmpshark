#!/usr/bin/env python3
"""Coordinate the scenario, stop the dbshark nodes, judge the database.

The judge walks the scenario plan (race_plan.py). Around each step it
runs the scenario's hooks: hold or release the barrier (a BEFORE INSERT
trigger on dis that waits for an advisory lock), take table locks, wait
for a specific waiter in pg_locks, release the database for the replay.
Nothing is synchronised with sleeps: every "the other node is now inside
its COPY" is read from pg_locks.

Integrity is per record and per node. The driver's manifest names every
datagram (source port), the nodes that captured it and the expected
payload; the judge requires each (node, record) exactly once with that
payload, nothing extra, nothing duplicated, previously committed rows
untouched and no spill files left behind.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import race_plan  # noqa: E402

SHARED = Path(os.environ.get("SHARED", "/shared"))
SCENARIO = os.environ.get("SCENARIO", "cold-burst")
CEILING = os.environ.get("MEMORY_CEILING_KB", "").strip()
NODES = list(race_plan.NODES)
ADVISORY_KEY = 424242

# Log lines that mean a *bug* even on the fixed binary. Recovered
# failures (a stale COPY, a deadlock victim, a lock timeout) are logged
# at ERROR by design and judged through the data, not the log.
ERROR_NEEDLES = (
    "pg_type_typname_nsp_index",
    "dropping uncommitted rows",
    "dropping row on",
    "they are lost",
    "corrupt journal",
    "cannot be replayed",
)


def log(msg: str) -> None:
    print(f"judge: {msg}", flush=True)


def wait_file(path: Path, timeout: float = 120.0) -> bool:
    deadline = time.monotonic() + timeout
    while not path.exists():
        if time.monotonic() > deadline:
            return False
        time.sleep(0.05)
    return True


def set_phase(name: str) -> None:
    (SHARED / "phase").write_text(name + "\n")
    log(f"phase={name}")


def psql(sql: str) -> str:
    # One-shot queries must never hang behind a lock a scenario holds on
    # purpose; the persistent Psql sessions below are the ones that wait.
    env = os.environ.copy()
    env["PGOPTIONS"] = "-c lock_timeout=10000 -c statement_timeout=60000"
    r = subprocess.run(
        ["psql", "-X", "-A", "-t", "-v", "ON_ERROR_STOP=1", "-c", sql],
        env=env, capture_output=True, text=True,
    )
    if r.returncode != 0:
        return f"__PSQL_ERR__ {r.stderr.strip()}"
    return r.stdout.strip()


class Psql:
    """A persistent psql session (session-level advisory lock, open txn)."""

    def __init__(self):
        self.p = subprocess.Popen(
            ["psql", "-q", "-X", "-v", "ON_ERROR_STOP=0"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, env=os.environ.copy(),
        )

    def send(self, sql: str) -> None:
        self.p.stdin.write(sql + "\n")
        self.p.stdin.flush()

    def close(self) -> None:
        try:
            self.p.stdin.write("\\q\n")
            self.p.stdin.flush()
            self.p.wait(timeout=10)
        except Exception:
            self.p.kill()


def wait_sql_true(sql: str, timeout: float, what: str) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        out = psql(sql)
        if out == "t" or (out.isdigit() and int(out) > 0):
            return True
        time.sleep(0.05)
    log(f"timeout waiting for {what}")
    return False


def wait_waiters(cond: str, n: int, timeout: float, what: str) -> bool:
    return wait_sql_true(
        f"SELECT count(*) >= {n} FROM pg_locks l WHERE NOT l.granted AND {cond}",
        timeout, what)


def wait_log(node: str, needle: str, timeout: float) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if needle in log_text(node):
            return True
        time.sleep(0.1)
    return False


def load_json(path: Path):
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError:
        return {}


def log_text(node: str) -> str:
    try:
        return (SHARED / f"{node}.log").read_text(errors="replace")
    except OSError:
        return ""


def exit_code(node: str) -> int | None:
    p = SHARED / f"{node}.exit"
    if not p.is_file():
        return None
    try:
        return int(p.read_text().strip())
    except ValueError:
        return None


def summary_counter(node: str, name: str) -> int | None:
    m = None
    for m in re.finditer(rf"\b{name}=(\d+)", log_text(node)):
        pass
    return int(m.group(1)) if m else None


def pg_stats() -> dict:
    raw = psql(
        "SELECT json_build_object('xact_commit', xact_commit, 'blks_read', blks_read, "
        "'blks_hit', blks_hit) FROM pg_stat_database WHERE datname = current_database();")
    if raw.startswith("__PSQL_ERR__") or not raw:
        return {"error": raw}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"raw": raw}


# ---- fixtures ------------------------------------------------------------

SCALAR_DIS = (
    "CREATE TABLE IF NOT EXISTS dis (ts_us BIGINT, src_ip TEXT, dst_ip TEXT, "
    "src_port INTEGER, dst_port INTEGER, frame_len INTEGER, node TEXT, "
    "entity_id_site BIGINT, entity_id_entity BIGINT, entity_marking TEXT);"
)
PREEXISTING = (
    "INSERT INTO dis (src_port, node, entity_id_site, entity_id_entity, entity_marking) "
    "VALUES (1, 'preexisting', 7, 7, 'KEEPME');"
)
BARRIER = f"""
CREATE OR REPLACE FUNCTION dis_barrier() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    PERFORM pg_advisory_xact_lock({ADVISORY_KEY});
    RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS barrier ON dis;
CREATE TRIGGER barrier BEFORE INSERT ON dis FOR EACH ROW EXECUTE FUNCTION dis_barrier();
"""


class Hooks:
    """Scenario hooks. before(step)/after(step) run around each step's
    send; finish() runs before stop; released() after the nodes exit."""

    def __init__(self, failures: list[str], facts: dict):
        self.failures = failures
        self.facts = facts
        self.holder: Psql | None = None
        self.other: Psql | None = None

    def hold_barrier(self) -> None:
        self.holder = Psql()
        self.holder.send(f"SELECT pg_advisory_lock({ADVISORY_KEY});")
        if not wait_sql_true(
                f"SELECT count(*) FROM pg_locks WHERE locktype='advisory' AND granted "
                f"AND objid={ADVISORY_KEY}", 30, "barrier lock"):
            self.failures.append("barrier lock not acquired")

    def release_barrier(self) -> None:
        if self.holder:
            self.holder.send(f"SELECT pg_advisory_unlock({ADVISORY_KEY});")
            self.holder.close()
            self.holder = None

    def before(self, st: dict) -> None:
        pass

    def after(self, st: dict) -> None:
        pass

    def finish(self) -> None:
        self.release_barrier()

    def released(self) -> None:
        pass


class PromoteRace(Hooks):
    def before(self, st):
        if st["phase"] == "scalar1":
            out = psql(SCALAR_DIS + PREEXISTING + BARRIER)
            if out.startswith("__PSQL_ERR__"):
                self.failures.append(f"fixture: {out}")
            self.hold_barrier()

    def after(self, st):
        if st["phase"] == "scalar1":
            # Sender and receiver are inside their first COPY, both holding
            # the scalar column type in memory.
            self.facts["both_blocked"] = wait_waiters(
                "l.locktype='advisory'", 2, 180, "two nodes at the barrier")
        elif st["phase"] == "fire":
            # The witness's ALTER ... TYPE JSONB queues for ACCESS EXCLUSIVE
            # behind the two blocked COPYs; only then open the barrier.
            self.facts["witness_alter_queued"] = wait_waiters(
                "l.mode='AccessExclusiveLock' AND l.relation='dis'::regclass", 1, 120,
                "witness ALTER queued on dis")
            self.release_barrier()
            # Promotion must have committed before the next step.
            self.facts["promoted"] = wait_sql_true(
                "SELECT count(*) FROM information_schema.columns WHERE table_name='dis' "
                "AND column_name='entity_id_site' AND data_type='jsonb'", 120, "jsonb promotion")

    def released(self):
        keep = psql("SELECT count(*) FROM dis WHERE src_port=1 AND entity_marking='KEEPME' "
                    "AND entity_id_site::text='7' AND entity_id_entity::text='7'")
        self.facts["preexisting_intact"] = keep == "1"
        if keep != "1":
            self.failures.append(f"pre-existing row damaged (count={keep})")
        if not self.facts.get("both_blocked"):
            self.failures.append("precondition: both nodes were not held at the barrier")
        if not self.facts.get("promoted"):
            self.failures.append("precondition: entity_id_site was not promoted")


class Deadlock(Hooks):
    def after(self, st):
        if st["phase"] == "seed":
            # Every table and column exists once both nodes committed the
            # seed; DDL inside the locked window would just block.
            if not wait_sql_true("SELECT count(*) >= 2 FROM dis", 120, "seed rows"):
                self.failures.append("seed rows not committed")
            psql(BARRIER)
            self.hold_barrier()
            self.other = Psql()
            # Postgres cancels the waiter that *detects* the cycle; push the
            # judge's own check far out so a dbshark node is the victim.
            self.other.send("SET deadlock_timeout = '120s';")
            self.other.send("BEGIN;")
            self.other.send("LOCK TABLE dis_category IN ACCESS EXCLUSIVE MODE;")
            wait_sql_true("SELECT count(*) FROM pg_locks WHERE relation='dis_category'::regclass "
                          "AND mode='AccessExclusiveLock' AND granted", 30, "dis_category lock")
        elif st["phase"] == "burst":
            self.facts["both_blocked"] = wait_waiters(
                "l.locktype='advisory'", 2, 180, "two nodes at the barrier")
            self.other.send("LOCK TABLE dis IN ACCESS EXCLUSIVE MODE;")
            self.facts["judge_queued_on_dis"] = wait_waiters(
                "l.mode='AccessExclusiveLock' AND l.relation='dis'::regclass", 1, 60,
                "judge queued on dis")
            self.release_barrier()
            victims = [n for n in ("sender", "receiver") if wait_log(n, "deadlock detected", 60)]
            self.facts["deadlock_victims"] = victims
            self.other.send("COMMIT;")
            self.other.close()
            self.other = None
            if not victims:
                self.failures.append("precondition: no node was a deadlock victim")


class LockExhaust(Hooks):
    def after(self, st):
        if st["phase"] == "seed":
            if not wait_sql_true("SELECT count(*) >= 2 FROM dis", 120, "seed rows"):
                self.failures.append("seed rows not committed")
            self.other = Psql()
            self.other.send("BEGIN;")
            self.other.send("LOCK TABLE dis IN ACCESS EXCLUSIVE MODE;")
            wait_sql_true("SELECT count(*) FROM pg_locks WHERE relation='dis'::regclass "
                          "AND mode='AccessExclusiveLock' AND granted", 30, "dis lock")
        elif st["phase"] == "fire":
            # Retry budget spent -> spill files on the shared volume.
            deadline = time.monotonic() + 300
            while time.monotonic() < deadline:
                have = {n for n in ("sender", "receiver") if list((SHARED / "spill" / n).rglob("*.spill"))}
                if have == {"sender", "receiver"}:
                    break
                time.sleep(0.2)
            self.facts["spill_files_before_release"] = {
                n: len(list((SHARED / "spill" / n).rglob("*.spill"))) for n in NODES}
            if have != {"sender", "receiver"}:
                self.failures.append(f"precondition: spill files not written by both nodes ({have})")

    def released(self):
        # Nodes have exited (their capture rc published later, after the
        # replay); free the table and let the restart path replay.
        # dis is still ACCESS EXCLUSIVE locked here; read the statistics
        # view rather than the table.
        self.facts["rows_while_locked"] = psql(
            "SELECT n_live_tup FROM pg_stat_user_tables WHERE relname='dis'")
        if self.other:
            self.other.send("COMMIT;")
            self.other.close()
            self.other = None
        (SHARED / "replay_go").write_text("1\n")


class ConnLoss(Hooks):
    def after(self, st):
        # Make sure batches actually happen between bursts so the fault
        # indices (batch N) are reached while traffic is still coming.
        n = {"b1": 1, "b2": 2, "b3": 3, "b4": 4, "b5": 5}[st["phase"]]
        if "node_id=" not in log_text("receiver"):
            return  # pre-fix binary: no batch markers, no fault hooks
        wait_sql_true(
            f"SELECT count(*) >= {n} FROM (SELECT DISTINCT node_id, batch_id FROM dbshark_batches "
            f"WHERE node_id='receiver') x", 60, f"receiver batch {n}")


HOOKS = {
    "promote-race": PromoteRace,
    "deadlock": Deadlock,
    "lock-exhaust-spill": LockExhaust,
    "conn-loss": ConnLoss,
}


# ---- integrity -----------------------------------------------------------

def check_records(manifest: list, has_node_col: bool, facts: dict) -> list[str]:
    """Every (node, record) once with the expected payload."""
    failures: list[str] = []
    if not manifest:
        return ["no manifest (sent_records.json)"]
    ports = [m["src_port"] for m in manifest]
    lo, hi = min(ports), max(ports)
    cols = "coalesce(node,''), src_port, coalesce(entity_marking,''), "
    cols += "coalesce(entity_id_site::text,''), coalesce(entity_id_entity::text,''), coalesce(pdu_type::text,'')"
    if not has_node_col:
        cols = "'', " + cols.split(", ", 1)[1]
    raw = psql(f"SELECT {cols} FROM dis WHERE src_port BETWEEN {lo} AND {hi}")
    if raw.startswith("__PSQL_ERR__"):
        return [f"dis query: {raw}"]
    seen: dict[tuple, list[tuple]] = {}
    for line in raw.splitlines():
        if not line:
            continue
        node, sp, mark, site, ent, pdu = (line.split("|") + [""] * 6)[:6]
        seen.setdefault((node, int(sp)), []).append((mark, site, ent, pdu))

    per_node = {n: {"expected": 0, "present": 0, "missing": 0, "duplicates": 0,
                    "payload_mismatch": 0} for n in (NODES if has_node_col else ["all"])}
    missing_sample, mismatch_sample = [], []
    expected_keys = set()
    for rec in manifest:
        want = tuple(rec["want"]) if rec.get("want") else None
        if has_node_col:
            for node in rec["nodes"]:
                key = (node, rec["src_port"])
                expected_keys.add(key)
                st = per_node[node]
                st["expected"] += 1
                rows = seen.get(key, [])
                if not rows:
                    st["missing"] += 1
                    if len(missing_sample) < 5:
                        missing_sample.append(key)
                    continue
                st["present"] += 1
                if len(rows) > 1:
                    st["duplicates"] += len(rows) - 1
                if want and rows[0] != want:
                    st["payload_mismatch"] += 1
                    if len(mismatch_sample) < 5:
                        mismatch_sample.append((key, want, rows[0]))
        else:
            # Pre-fix binary: no node column. The record must appear
            # exactly once per capturing node, payload intact.
            key = ("", rec["src_port"])
            expected_keys.add(key)
            rows = seen.get(key, [])
            n_exp = len(rec["nodes"])
            st = per_node["all"]
            st["expected"] += n_exp
            st["present"] += min(len(rows), n_exp)
            if len(rows) < n_exp:
                st["missing"] += n_exp - len(rows)
                if len(missing_sample) < 5:
                    missing_sample.append(key)
            elif len(rows) > n_exp:
                st["duplicates"] += len(rows) - n_exp
            if want:
                st["payload_mismatch"] += sum(1 for r in rows if r != want)
    extras = [k for k in seen if k not in expected_keys]
    facts["per_node"] = per_node
    facts["unexpected_rows"] = len(extras)
    facts["missing_sample"] = missing_sample
    facts["mismatch_sample"] = mismatch_sample
    for node, st in per_node.items():
        if st["expected"] == 0:
            continue
        if st["missing"]:
            drops = summary_counter(node, "capture_drop") or 0
            failures.append(f"{node}: {st['missing']}/{st['expected']} records missing"
                            + (f" (capture_drop={drops})" if drops else ""))
        if st["duplicates"]:
            failures.append(f"{node}: {st['duplicates']} duplicate records")
        if st["payload_mismatch"]:
            failures.append(f"{node}: {st['payload_mismatch']} records with wrong payload")
    if extras:
        failures.append(f"{len(extras)} rows in dis that no node sent (sample {extras[:3]})")
    return failures


def main() -> int:
    SHARED.mkdir(parents=True, exist_ok=True)
    set_phase("idle")
    failures: list[str] = []
    facts: dict = {}
    hooks = HOOKS.get(SCENARIO, Hooks)(failures, facts)
    plan = race_plan.plan_for(SCENARIO)

    for name in ("sender.ready", "receiver.ready", "witness.ready", "stub.ready",
                 "witness_stub.ready", "driver.ready"):
        if not wait_file(SHARED / name, 180):
            failures.append(f"timeout waiting for {name}")
            log(failures[-1])
    if failures:
        (SHARED / "stop").write_text("1\n")
        (SHARED / "no_replay").write_text("1\n")
        report = {"ok": False, "failures": failures, "scenario": SCENARIO}
        (SHARED / "report.json").write_text(json.dumps(report, indent=2) + "\n")
        return 1

    for st in plan:
        hooks.before(st)
        set_phase(st["phase"])
        if not wait_file(SHARED / f"sent_{st['phase']}", 300):
            failures.append(f"timeout waiting for send of {st['phase']}")
            break
        hooks.after(st)
    hooks.finish()
    time.sleep(0.5)

    set_phase("stop")
    (SHARED / "stop").write_text("1\n")
    # Nodes publish <node>.capture.exit once the capture process is gone,
    # and <node>.exit after the sampler summary and any spill replay (which
    # needs released() to have freed the database first).
    deadline = time.monotonic() + 300
    while time.monotonic() < deadline:
        if all((SHARED / f"{n}.capture.exit").exists() for n in NODES):
            break
        time.sleep(0.1)
    else:
        failures.append("timeout waiting for the capture processes to exit")
    hooks.released()
    if SCENARIO != "lock-exhaust-spill":
        (SHARED / "no_replay").write_text("1\n")
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:
        if all((SHARED / f"{n}.exit").exists() for n in NODES):
            break
        time.sleep(0.1)
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        if all((SHARED / f"{n}.resources.summary.json").is_file() for n in NODES):
            break
        time.sleep(0.1)

    sent = load_json(SHARED / "sent.json")
    manifest = load_json(SHARED / "sent_records.json") or []
    total_sent = int(sent.get("total") or 0)
    rows_after_crash = None
    rcs = {n: exit_code(n) for n in NODES}

    if SCENARIO != "unlogged-kill-pg":
        for n in NODES:
            if rcs[n] != 0:
                failures.append(f"{n} exit {rcs[n]}")

    for node in NODES:
        hits = []
        for line in log_text(node).splitlines():
            if "ERROR" not in line:
                continue
            for needle in ERROR_NEEDLES:
                if needle in line:
                    hits.append(f"{node} log: {line.strip()[:200]}")
                    break
        failures.extend(hits[:5])
        if len(hits) > 5:
            failures.append(f"{node} log: ... {len(hits) - 5} more lines like these")

    tables = psql(
        "SELECT coalesce(string_agg(relname || '=' || n_live_tup, ',' ORDER BY relname), '') "
        "FROM pg_stat_user_tables;")
    dis_pers = psql(
        "SELECT c.relpersistence::text FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace "
        "WHERE n.nspname = current_schema() AND c.relname = 'dis' AND c.relkind = 'r';")
    if SCENARIO in ("unlogged", "unlogged-kill-pg"):
        if dis_pers.strip() != "u":
            failures.append(f"dis relpersistence={dis_pers!r} (expected u)")
    elif dis_pers.strip() == "u":
        failures.append("dis relpersistence=u without --unlogged")

    dis_rows_s = psql("SELECT count(*) FROM dis;")
    dis_rows = int(dis_rows_s) if dis_rows_s.isdigit() else -1
    if dis_rows < 0:
        failures.append(f"dis table: {dis_rows_s}")

    types = psql(
        "SELECT coalesce(string_agg(column_name || ':' || data_type, ',' ORDER BY 1), '') "
        "FROM information_schema.columns WHERE table_name='dis' AND column_name LIKE 'entity_id%';")
    if types and not types.startswith("__PSQL_ERR__"):
        kinds = {part.split(":")[-1] for part in types.split(",") if ":" in part}
        if len(kinds) > 1:
            failures.append(f"mixed entity_id types: {types}")
    # The fixed binary announces its identity at start and fills the node
    # column; a pre-fix build leaves the column (a fixture may create it)
    # empty, so the records are then judged by source port alone.
    fixed_binary = all("node_id=" in log_text(n) for n in NODES)
    has_node_col = fixed_binary and psql(
        "SELECT count(*) FROM information_schema.columns "
        "WHERE table_name='dis' AND column_name='node'") == "1"
    facts["fixed_binary"] = fixed_binary
    facts["node_column"] = has_node_col

    if SCENARIO == "unlogged-kill-pg":
        rows_before = dis_rows
        log("killing postgres to test unlogged wipe")
        (SHARED / "kill_pg").write_text("1\n")
        down = wiped = False
        for _ in range(80):
            probe = psql("SELECT count(*) FROM dis;")
            if probe.startswith("__PSQL_ERR__"):
                down = True
                break
            if rows_before > 0 and probe.strip() == "0":
                wiped = True
                break
            time.sleep(0.25)
        if not down and not wiped:
            fired = (SHARED / "killer_fired").read_text().strip() if (SHARED / "killer_fired").is_file() else ""
            failures.append(f"postgres stayed up after kill_pg (killer_fired={fired or 'missing'})")
        up = wiped
        if down:
            for _ in range(60):
                if psql("SELECT 1;").strip() == "1":
                    up = True
                    break
                time.sleep(0.5)
        if down and not up:
            failures.append("postgres did not restart after SIGKILL")
        elif up:
            after = psql("SELECT count(*) FROM dis;")
            rows_after_crash = int(after) if after.isdigit() else 0
            if rows_after_crash > 0:
                failures.append(f"unlogged table still has {rows_after_crash} rows after crash "
                                f"(before={rows_before})")
        dis_rows = rows_before
    elif dis_rows >= 0:
        failures.extend(check_records(manifest, has_node_col, facts))

    # Durability bookkeeping from the nodes themselves.
    for node in NODES:
        for name in ("dropped_rows", "spilled_rows", "spill_replayed_rows", "quarantined_rows",
                     "batch_retries", "uncertain_commits", "capture_drop"):
            v = summary_counter(node, name)
            if v is not None:
                facts.setdefault("counters", {}).setdefault(node, {})[name] = v
        dropped = summary_counter(node, "dropped_rows")
        if dropped:
            failures.append(f"{node}: dropped_rows={dropped}")
    spill_left = sorted(str(p.relative_to(SHARED)) for p in (SHARED / "spill").rglob("*.spill")) \
        if (SHARED / "spill").is_dir() else []
    quarantine = sorted(str(p.relative_to(SHARED)) for p in (SHARED / "spill").rglob("*.quarantine")) \
        if (SHARED / "spill").is_dir() else []
    facts["spill_files_left"] = spill_left
    facts["quarantine_files"] = quarantine
    if spill_left and SCENARIO != "unlogged-kill-pg":
        failures.append(f"spill files left: {spill_left}")
    if quarantine:
        failures.append(f"quarantine files: {quarantine}")

    resources = {n: load_json(SHARED / f"{n}.resources.summary.json") for n in NODES}
    if CEILING:
        try:
            cap = int(CEILING)
            for name, res in resources.items():
                peak = int(res.get("peak_rss_kb") or 0)
                if peak > cap:
                    failures.append(f"{name} peak_rss_kb={peak} exceeds MEMORY_CEILING_KB={cap}")
        except ValueError:
            failures.append(f"bad MEMORY_CEILING_KB={CEILING!r}")

    report = {
        "ok": not failures,
        "scenario": SCENARIO,
        "failures": failures,
        "sent": sent,
        "records_sent": len(manifest),
        "exit": rcs,
        "dis_rows": dis_rows,
        "dis_persistence": dis_pers.strip(),
        "dis_rows_after_pg_crash": rows_after_crash,
        "facts": facts,
        "tables": tables,
        "entity_id_types": types,
        "pg": pg_stats(),
        "resources": resources,
    }
    (SHARED / "report.json").write_text(json.dumps(report, indent=2, default=str) + "\n")

    log(f"exit={rcs} sent={total_sent} records={len(manifest)} dis_rows={dis_rows}")
    for node, st in (facts.get("per_node") or {}).items():
        if st["expected"]:
            log(f"  {node:9s} records {st['present']}/{st['expected']} missing={st['missing']} "
                f"dup={st['duplicates']} bad_payload={st['payload_mismatch']}")
    for node, c in (facts.get("counters") or {}).items():
        log(f"  {node:9s} counters {c}")
    log("resources (process RSS / PSS / cgroup peak):")
    for name, res in resources.items():
        log(f"  {name:8s} peak_rss_kb={res.get('peak_rss_kb')} peak_pss_kb={res.get('peak_pss_kb')} "
            f"peak_cgroup_bytes={res.get('peak_cgroup_bytes')} cpu_user_s={res.get('cpu_user_s')} "
            f"cpu_sys_s={res.get('cpu_sys_s')} max_fds={res.get('max_fds')}")
    if failures:
        for f in failures:
            log(f"FAIL {f}")
        return 1
    log("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
