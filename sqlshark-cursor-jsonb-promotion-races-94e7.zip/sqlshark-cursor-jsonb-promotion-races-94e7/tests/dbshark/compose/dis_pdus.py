"""IEEE 1278.1 DIS PDU builders aligned with Wireshark 4.2 packet-dis.c.

PDUs are version 6 (IEEE 1278.1A-1998) unless noted. Layouts match the
Wireshark parsers so epan fills the tree; known constants are chosen so
dbshark ingest tests can assert exact values.
"""

from __future__ import annotations

import struct
from typing import Callable

# Protocol version / family / PDU type (SISO-REF-010)
VER_1998 = 6
VER_2012 = 7

FAM_ENTITY = 1
FAM_WARFARE = 2
FAM_LOGISTICS = 3
FAM_RADIO = 4
FAM_SIMAN = 5
FAM_DER = 6
FAM_ENTITY_MGMT = 7
FAM_SIMAN_R = 10
FAM_LIVE = 11
FAM_IO = 13
FAM_EXPERIMENTAL_VDIS = 130
FAM_PO = 140

PDU_ENTITY_STATE = 1
PDU_FIRE = 2
PDU_DETONATION = 3
PDU_COLLISION = 4
PDU_CREATE_ENTITY = 11
PDU_REMOVE_ENTITY = 12
PDU_START_RESUME = 13
PDU_STOP_FREEZE = 14
PDU_ACKNOWLEDGE = 15
PDU_ACTION_REQUEST = 16
PDU_ACTION_RESPONSE = 17
PDU_DATA_QUERY = 18
PDU_SET_DATA = 19
PDU_DATA = 20
PDU_EVENT_REPORT = 21
PDU_COMMENT = 22
PDU_EM_EMISSION = 23
PDU_DESIGNATOR = 24
PDU_TRANSMITTER = 25
PDU_SIGNAL = 26
PDU_RECEIVER = 27
PDU_IFF = 28
PDU_UA = 29
PDU_INTERCOM_SIGNAL = 31
PDU_INTERCOM_CONTROL = 32
PDU_AGGREGATE_STATE = 33
PDU_START_RESUME_R = 53
PDU_STOP_FREEZE_R = 54
PDU_ACKNOWLEDGE_R = 55
PDU_ACTION_REQUEST_R = 56
PDU_ACTION_RESPONSE_R = 57
PDU_DATA_QUERY_R = 58
PDU_SET_DATA_R = 59
PDU_DATA_R = 60
PDU_EVENT_REPORT_R = 61
PDU_COMMENT_R = 62
PDU_ENTITY_STATE_UPDATE = 67
PDU_APPLICATION_CONTROL = 200
PDU_CREATE_ENTITY_R = 51
PDU_REMOVE_ENTITY_R = 52
PDU_ENVIRONMENTAL_PROCESS = 41

# Known test identities
SITE, APP, ENT = 1, 2, 10
FIRE_ENT, TGT_ENT, MUN_ENT = 10, 20, 30
EXERCISE = 1

# ECEF meters (roughly Washington DC area) — easy to spot in Postgres
ECEF = (1115809.0, -4844532.0, 3987943.0)


def _u8(n: int) -> bytes:
    return struct.pack("!B", n & 0xFF)


def _u16(n: int) -> bytes:
    return struct.pack("!H", n & 0xFFFF)


def _u32(n: int) -> bytes:
    return struct.pack("!I", n & 0xFFFFFFFF)


def _i16(n: int) -> bytes:
    return struct.pack("!h", n)


def _f32(x: float) -> bytes:
    return struct.pack("!f", x)


def _f64(x: float) -> bytes:
    return struct.pack("!d", x)


def entity_id(site: int = SITE, app: int = APP, entity: int = ENT) -> bytes:
    return _u16(site) + _u16(app) + _u16(entity)


def event_id(site: int = SITE, app: int = APP, event: int = 1) -> bytes:
    return _u16(site) + _u16(app) + _u16(event)


def entity_type(
    kind: int = 1,
    domain: int = 1,
    country: int = 225,
    category: int = 1,
    subcategory: int = 1,
    specific: int = 0,
    extra: int = 0,
) -> bytes:
    return struct.pack("!BBHBBBB", kind, domain, country, category, subcategory, specific, extra)


def vec3f(x: float = 0.0, y: float = 0.0, z: float = 0.0) -> bytes:
    return _f32(x) + _f32(y) + _f32(z)


def vec3d(x: float | None = None, y: float | None = None, z: float | None = None) -> bytes:
    xx, yy, zz = ECEF
    return _f64(xx if x is None else x) + _f64(yy if y is None else y) + _f64(zz if z is None else z)


def clock_time(hour: int = 0, time_past_hour: int = 0) -> bytes:
    return _u32(hour) + _u32(time_past_hour)


def burst_descriptor() -> bytes:
    return entity_type(kind=2, domain=1, category=1) + _u16(0) + _u16(0) + _u16(1) + _u16(0)


def marking(text: str = "TEST01") -> bytes:
    body = text.encode("ascii")[:11].ljust(11, b"\x00")
    return _u8(1) + body  # ASCII character set


def vp_articulated(change: int, part: int, ptype: int, value: float) -> bytes:
    # 16-byte variable parameter: type 0 + articulated part
    return (
        _u8(0)
        + _u8(change)
        + _u16(part)
        + _u32(ptype)
        + _f32(value)
        + _u32(0)
    )


def fixed_datum(datum_id: int, value: bytes) -> bytes:
    if len(value) != 4:
        raise ValueError("fixed datum value must be 4 bytes")
    return _u32(datum_id) + value


def variable_datum(datum_id: int, text: bytes) -> bytes:
    bit_len = len(text) * 8
    pad = (8 - (len(text) % 8)) % 8
    return _u32(datum_id) + _u32(bit_len) + text + (b"\x00" * pad)


def wrap_header(
    pdu_type: int,
    family: int,
    payload: bytes,
    version: int = VER_1998,
    pdu_status: int = 0,
) -> bytes:
    length = 12 + len(payload)
    hdr = _u8(version) + _u8(EXERCISE) + _u8(pdu_type) + _u8(family) + _u32(0) + _u16(length)
    if version >= VER_2012:
        hdr += _u8(pdu_status) + _u8(0)
    else:
        hdr += _u16(0)
    return hdr + payload


def pdu_entity_state(
    *,
    entity: int = ENT,
    n_articulated: int = 0,
    version: int = VER_1998,
    marking_text: str = "TEST01",
) -> bytes:
    vps = b"".join(
        vp_articulated(i, 0, 1024 + i, 0.1 * (i + 1)) for i in range(n_articulated)
    )
    payload = (
        entity_id(entity=entity)
        + _u8(1)  # force Friendly
        + _u8(n_articulated)
        + entity_type()
        + entity_type()
        + vec3f(1.0, 0.0, 0.0)
        + vec3d()
        + vec3f(0.1, 0.0, 0.0)  # psi, theta, phi
        + _u32(0)  # appearance
        + _u8(2)  # DR algorithm
        + (b"\x00" * 15)
        + vec3f()
        + vec3f()
        + marking(marking_text)
        + _u32(0)  # capabilities
        + vps
    )
    return wrap_header(PDU_ENTITY_STATE, FAM_ENTITY, payload, version=version)


def pdu_entity_state_update(entity: int = ENT) -> bytes:
    payload = (
        entity_id(entity=entity)
        + _u8(0)
        + _u8(0)  # no variable records
        + vec3f(1.0, 0.0, 0.0)
        + vec3d()
        + vec3f(0.1, 0.0, 0.0)
        + _u32(0)
    )
    return wrap_header(PDU_ENTITY_STATE_UPDATE, FAM_ENTITY, payload)


def pdu_fire() -> bytes:
    payload = (
        entity_id(site=1, entity=FIRE_ENT)
        + entity_id(site=2, entity=TGT_ENT)
        + entity_id(site=3, entity=MUN_ENT)
        + event_id(event=7)
        + _u32(42)
        + vec3d()
        + burst_descriptor()
        + vec3f(100.0, 0.0, -10.0)
        + _f32(2500.0)
    )
    return wrap_header(PDU_FIRE, FAM_WARFARE, payload)


def pdu_detonation() -> bytes:
    payload = (
        entity_id(entity=FIRE_ENT)
        + entity_id(entity=TGT_ENT)
        + entity_id(entity=MUN_ENT)
        + event_id(event=8)
        + vec3f(10.0, 0.0, -5.0)
        + vec3d()
        + burst_descriptor()
        + vec3f(1.0, 2.0, 3.0)  # entity coords — FLOAT dis.entity_location.*
        + _u8(1)  # result
        + _u8(0)  # no VP
        + _u16(0)
    )
    return wrap_header(PDU_DETONATION, FAM_WARFARE, payload)


def pdu_collision() -> bytes:
    payload = (
        entity_id(entity=FIRE_ENT)
        + entity_id(entity=TGT_ENT)
        + event_id(event=9)
        + _u8(1)
        + _u8(0)
        + vec3f(5.0, 0.0, 0.0)
        + _f32(15000.0)
        + vec3f(0.5, 0.0, 0.0)
    )
    return wrap_header(PDU_COLLISION, FAM_ENTITY, payload)


def _siman_pair(extra: bytes = b"") -> bytes:
    return entity_id(entity=1) + entity_id(entity=2) + extra


def pdu_start_resume() -> bytes:
    return wrap_header(
        PDU_START_RESUME,
        FAM_SIMAN,
        _siman_pair(clock_time() + clock_time() + _u32(100)),
    )


def pdu_stop_freeze() -> bytes:
    return wrap_header(
        PDU_STOP_FREEZE,
        FAM_SIMAN,
        _siman_pair(clock_time() + _u8(2) + _u8(0) + _u16(0) + _u32(101)),
    )


def pdu_acknowledge() -> bytes:
    return wrap_header(
        PDU_ACKNOWLEDGE,
        FAM_SIMAN,
        _siman_pair(_u16(1) + _u16(0) + _u32(100)),
    )


def pdu_create_entity() -> bytes:
    return wrap_header(PDU_CREATE_ENTITY, FAM_SIMAN, _siman_pair(_u32(200)))


def pdu_remove_entity() -> bytes:
    return wrap_header(PDU_REMOVE_ENTITY, FAM_SIMAN, _siman_pair(_u32(201)))


def pdu_action_request() -> bytes:
    extra = _u32(102) + _u32(1) + _u32(1) + _u32(0)
    extra += fixed_datum(1000, _u32(99))
    return wrap_header(PDU_ACTION_REQUEST, FAM_SIMAN, _siman_pair(extra))


def pdu_action_response() -> bytes:
    extra = _u32(102) + _u32(0) + _u32(0) + _u32(0)
    return wrap_header(PDU_ACTION_RESPONSE, FAM_SIMAN, _siman_pair(extra))


def pdu_data(n_fixed: int = 3, n_var: int = 2) -> bytes:
    extra = _u32(300) + _u32(0) + _u32(n_fixed) + _u32(n_var)
    extra += b"".join(fixed_datum(10 + i, _u32(100 + i)) for i in range(n_fixed))
    extra += b"".join(
        variable_datum(50 + i, f"DATUM{i}".encode("ascii")) for i in range(n_var)
    )
    return wrap_header(PDU_DATA, FAM_SIMAN, _siman_pair(extra))


def pdu_set_data() -> bytes:
    extra = _u32(301) + _u32(0) + _u32(1) + _u32(0)
    extra += fixed_datum(11, _u32(7))
    return wrap_header(PDU_SET_DATA, FAM_SIMAN, _siman_pair(extra))


def pdu_data_query() -> bytes:
    extra = _u32(302) + _u32(0) + _u32(2) + _u32(1)
    extra += _u32(10) + _u32(11) + _u32(50)
    return wrap_header(PDU_DATA_QUERY, FAM_SIMAN, _siman_pair(extra))


def pdu_event_report() -> bytes:
    extra = _u32(3) + _u32(0) + _u32(1) + _u32(0)
    extra += fixed_datum(12, _u32(1))
    return wrap_header(PDU_EVENT_REPORT, FAM_SIMAN, _siman_pair(extra))


def pdu_comment() -> bytes:
    extra = _u32(0) + _u32(1)
    extra += variable_datum(1, b"hello dis")
    return wrap_header(PDU_COMMENT, FAM_SIMAN, _siman_pair(extra))


def pdu_start_resume_r() -> bytes:
    extra = clock_time() + clock_time() + _u8(1) + b"\x00\x00\x00" + _u32(110)
    return wrap_header(PDU_START_RESUME_R, FAM_SIMAN_R, _siman_pair(extra))


def pdu_stop_freeze_r() -> bytes:
    extra = clock_time() + _u8(2) + _u8(0) + _u8(1) + _u8(0) + _u32(111)
    return wrap_header(PDU_STOP_FREEZE_R, FAM_SIMAN_R, _siman_pair(extra))


def pdu_acknowledge_r() -> bytes:
    return wrap_header(
        PDU_ACKNOWLEDGE_R,
        FAM_SIMAN_R,
        _siman_pair(_u16(1) + _u16(0) + _u32(110)),
    )


def pdu_action_request_r() -> bytes:
    extra = _u8(1) + b"\x00\x00\x00" + _u32(112) + _u32(1) + _u32(0) + _u32(0)
    return wrap_header(PDU_ACTION_REQUEST_R, FAM_SIMAN_R, _siman_pair(extra))


def pdu_action_response_r() -> bytes:
    extra = _u32(112) + _u32(0) + _u32(0) + _u32(0)
    return wrap_header(PDU_ACTION_RESPONSE_R, FAM_SIMAN_R, _siman_pair(extra))


def pdu_data_r() -> bytes:
    extra = _u8(1) + b"\x00\x00\x00" + _u32(310) + _u32(1) + _u32(0)
    extra += fixed_datum(13, _u32(8))
    return wrap_header(PDU_DATA_R, FAM_SIMAN_R, _siman_pair(extra))


def pdu_set_data_r() -> bytes:
    extra = _u8(1) + b"\x00\x00\x00" + _u32(311) + _u32(0) + _u32(0)
    return wrap_header(PDU_SET_DATA_R, FAM_SIMAN_R, _siman_pair(extra))


def pdu_data_query_r() -> bytes:
    extra = _u8(1) + b"\x00\x00\x00" + _u32(312) + _u32(0) + _u32(1) + _u32(0)
    extra += _u32(10)
    return wrap_header(PDU_DATA_QUERY_R, FAM_SIMAN_R, _siman_pair(extra))


def pdu_comment_r() -> bytes:
    extra = _u32(0) + _u32(1)
    extra += variable_datum(1, b"reliable")
    return wrap_header(PDU_COMMENT_R, FAM_SIMAN_R, _siman_pair(extra))


def pdu_create_entity_r() -> bytes:
    extra = _u8(1) + b"\x00\x00\x00" + _u32(210)
    return wrap_header(PDU_CREATE_ENTITY_R, FAM_SIMAN_R, _siman_pair(extra))


def pdu_remove_entity_r() -> bytes:
    extra = _u8(1) + b"\x00\x00\x00" + _u32(211)
    return wrap_header(PDU_REMOVE_ENTITY_R, FAM_SIMAN_R, _siman_pair(extra))


def pdu_em_emission(*, n_systems: int = 2, n_beams: int = 2, n_tracks: int = 2) -> bytes:
    tracks = b"".join(
        entity_id(entity=40 + k) + _u8(k + 1) + _u8(k + 1) for k in range(n_tracks)
    )
    # beam: 52 + 8*n_tracks bytes; length field is 32-bit words
    beam_bytes = 52 + 8 * n_tracks
    beam = (
        _u8(beam_bytes // 4)
        + _u8(1)
        + _u16(0)
        + (_f32(0.0) * 10)  # placeholder overwritten below
        + _u8(1)
        + _u8(n_tracks)
        + _u8(0)
        + _u8(0)
        + _u32(0)
        + tracks
    )
    # rebuild beam with real fundamental floats
    fund = b"".join(_f32(v) for v in (3000.0, 100.0, 40.0, 800.0, 1.0, 0.0, 1.0, 0.0, 0.5, 0.0))
    beam = (
        _u8(beam_bytes // 4)
        + _u8(1)
        + _u16(0)
        + fund
        + _u8(1)
        + _u8(n_tracks)
        + _u8(0)
        + _u8(0)
        + _u32(0)
        + tracks
    )
    beams = b""
    for j in range(n_beams):
        b = bytearray(beam)
        b[1] = j + 1  # beam id
        beams += bytes(b)
    sys_bytes = 20 + len(beams)
    system = (
        _u8(sys_bytes // 4)
        + _u8(n_beams)
        + _u16(0)
        + _u16(2001)  # emitter name
        + _u8(1)
        + _u8(1)
        + vec3f(0.0, 0.0, 1.0)
        + beams
    )
    systems = system * n_systems
    payload = entity_id() + event_id(event=11) + _u8(0) + _u8(n_systems) + _u16(0) + systems
    return wrap_header(PDU_EM_EMISSION, FAM_DER, payload)


def pdu_underwater_acoustic() -> bytes:
    payload = (
        entity_id()
        + event_id(event=12)
        + _u8(0)
        + _u8(0)
        + _u16(0)
        + _u8(0)
        + _u8(0)  # shafts
        + _u8(0)  # apas
        + _u8(0)  # emitters
    )
    return wrap_header(PDU_UA, FAM_DER, payload)


def pdu_designator() -> bytes:
    payload = (
        entity_id(entity=FIRE_ENT)
        + _u16(1)
        + entity_id(entity=TGT_ENT)
        + _u16(1)
        + _f32(50.0)
        + _f32(1.06)
        + vec3f()
        + vec3d()
        + _u8(0)
        + (b"\x00" * 15)
        + vec3f()
        + _u8(0)
        + _u8(0)
        + _u16(0)
    )
    return wrap_header(PDU_DESIGNATOR, FAM_DER, payload)


def pdu_transmitter() -> bytes:
    payload = (
        entity_id()
        + _u16(1)  # radio id
        + entity_type(kind=7, domain=1, category=1)  # radio entity type-ish
        + _u8(2)  # on
        + _u8(1)
        + _u16(0)
        + vec3d()
        + vec3f()
        + _u16(0)  # antenna pattern type
        + _u16(0)
        + _f64(2.4e9)
        + _f32(1e6)
        + _f32(20.0)
        + _u16(0)  # spread spectrum
        + _u16(0)  # major
        + _u16(0)
        + _u16(0)
        + _u16(0)  # crypto system
        + _u16(0)
        + _u8(0)  # mod param length
        + b"\x00\x00\x00"
    )
    return wrap_header(PDU_TRANSMITTER, FAM_RADIO, payload)


def pdu_signal() -> bytes:
    data = b"\x00\x01\x02\x03"
    payload = (
        entity_id()
        + _u16(1)
        + _u16(0)
        + _u16(0)
        + _u32(8000)
        + _u16(len(data) * 8)
        + _u16(1)
        + data
    )
    return wrap_header(PDU_SIGNAL, FAM_RADIO, payload)


def pdu_intercom_signal() -> bytes:
    data = b"\xaa\xbb"
    payload = (
        entity_id()
        + _u16(2)
        + _u16(0)
        + _u16(0)
        + _u32(8000)
        + _u16(len(data) * 8)
        + _u16(1)
        + data
    )
    return wrap_header(PDU_INTERCOM_SIGNAL, FAM_RADIO, payload)


def pdu_receiver() -> bytes:
    payload = (
        entity_id()
        + _u16(1)
        + _u16(2)
        + _u16(0)
        + _f32(-70.0)
        + entity_id(entity=FIRE_ENT)
        + _u16(1)
    )
    return wrap_header(PDU_RECEIVER, FAM_RADIO, payload)


def pdu_intercom_control() -> bytes:
    # Entity, radio, control type, source, etc. — enough for the parser to start
    payload = (
        entity_id()
        + _u16(1)
        + _u8(1)
        + _u8(1)
        + _u8(0)
        + _u8(0)
        + entity_id(entity=TGT_ENT)
        + _u16(1)
        + _u16(0)
        + _u32(0)
        + _u16(0)
        + _u16(0)
    )
    return wrap_header(PDU_INTERCOM_CONTROL, FAM_RADIO, payload)


def pdu_iff() -> bytes:
    payload = (
        entity_id()
        + event_id(event=13)
        + vec3f()
        + _u16(1)
        + _u16(1)
        + _u8(1)
        + _u8(0)
        + _u16(0)
        + (b"\x00" * 16)  # fundamental operational data
    )
    return wrap_header(PDU_IFF, FAM_DER, payload)


def pdu_aggregate_state() -> bytes:
    payload = (
        entity_id()
        + _u8(1)
        + _u8(1)
        + entity_type()
        + _u32(0)
        + vec3d()
        + vec3f()
        + vec3f()
        + vec3f()
        + marking("AGGR01")
        + _u32(0)
        + _u16(0)  # silent aggregates
        + _u16(0)  # silent entities
        + _u16(0)  # subaggregates
        + _u16(0)  # entities
        + _u32(0)  # variable datums
    )
    return wrap_header(PDU_AGGREGATE_STATE, FAM_ENTITY_MGMT, payload)


def pdu_environmental_process() -> bytes:
    payload = (
        entity_id()
        + entity_type()
        + _u8(0)
        + _u8(0)
        + _u16(0)
        + _u16(0)
        + _u16(0)
        + _u32(0)
    )
    return wrap_header(PDU_ENVIRONMENTAL_PROCESS, FAM_ENTITY_MGMT, payload)


def pdu_application_control() -> bytes:
    payload = (
        _siman_pair()
        + _u8(1)
        + _u8(0)
        + _u8(1)
        + _u8(0)
        + _u16(0)
        + _u16(0)
        + _u32(400)
        + _u8(1)
        + _u8(1)
        + _u16(0)
    )
    return wrap_header(200, FAM_EXPERIMENTAL_VDIS, payload)


def pdu_po_simulator_present() -> bytes:
    po_hdr = _u8(1) + _u8(1) + _u8(EXERCISE) + _u8(1) + _u16(8) + _u16(1)
    return wrap_header(0, FAM_PO, po_hdr)


Builder = Callable[[], bytes]

# Order is load-bearing for the JSON-promote test: a single-instance field
# (entity_id_site on Entity State) must be COPY'd as BIGINT before Fire
# repeats it as a JSON array.
CORPUS: list[tuple[str, Builder]] = [
    ("entity_state", lambda: pdu_entity_state(n_articulated=0)),
    ("entity_state_v7", lambda: pdu_entity_state(n_articulated=0, version=VER_2012)),
    ("entity_state_articulated", lambda: pdu_entity_state(n_articulated=3, marking_text="GUN01")),
    ("entity_state_update", pdu_entity_state_update),
    ("fire", pdu_fire),
    ("detonation", pdu_detonation),
    ("collision", pdu_collision),
    ("data", lambda: pdu_data(3, 2)),
    ("set_data", pdu_set_data),
    ("data_query", pdu_data_query),
    ("comment", pdu_comment),
    ("event_report", pdu_event_report),
    ("action_request", pdu_action_request),
    ("action_response", pdu_action_response),
    ("start_resume", pdu_start_resume),
    ("stop_freeze", pdu_stop_freeze),
    ("acknowledge", pdu_acknowledge),
    ("create_entity", pdu_create_entity),
    ("remove_entity", pdu_remove_entity),
    ("start_resume_r", pdu_start_resume_r),
    ("stop_freeze_r", pdu_stop_freeze_r),
    ("acknowledge_r", pdu_acknowledge_r),
    ("action_request_r", pdu_action_request_r),
    ("action_response_r", pdu_action_response_r),
    ("data_r", pdu_data_r),
    ("set_data_r", pdu_set_data_r),
    ("data_query_r", pdu_data_query_r),
    ("comment_r", pdu_comment_r),
    ("create_entity_r", pdu_create_entity_r),
    ("remove_entity_r", pdu_remove_entity_r),
    ("em_emission", pdu_em_emission),
    ("underwater_acoustic", pdu_underwater_acoustic),
    ("designator", pdu_designator),
    ("transmitter", pdu_transmitter),
    ("signal", pdu_signal),
    ("intercom_signal", pdu_intercom_signal),
    ("receiver", pdu_receiver),
    ("intercom_control", pdu_intercom_control),
    ("iff", pdu_iff),
    ("aggregate_state", pdu_aggregate_state),
    ("environmental_process", pdu_environmental_process),
    ("application_control", pdu_application_control),
    ("po_simulator_present", pdu_po_simulator_present),
]


def list_pdus() -> list[str]:
    return [name for name, _ in CORPUS]


def build_named(name: str) -> bytes:
    for n, fn in CORPUS:
        if n == name:
            return fn()
    raise KeyError(name)


def build_all(only: set[str] | None = None) -> list[tuple[str, bytes]]:
    out = []
    for name, fn in CORPUS:
        if only is not None and name not in only:
            continue
        out.append((name, fn()))
    return out
