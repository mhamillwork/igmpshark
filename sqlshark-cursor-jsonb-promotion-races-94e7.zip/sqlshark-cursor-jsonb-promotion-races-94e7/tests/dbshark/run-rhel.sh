#!/usr/bin/env bash
# Run the whole dbshark test suite inside isolated RHEL 8 and/or RHEL 9
# environments: build the image (Wireshark 4.2.6 libs + dbshark compiled on
# that OS, local PostgreSQL, the tests), run the reassembly unit test, the
# Postgres recovery suite and the durability catalog inside it, then the
# multi-node compose scenarios with the capture nodes running from that image.
#
#   ./tests/dbshark/run-rhel.sh              # RHEL 8 and 9, all suites
#   ./tests/dbshark/run-rhel.sh 9            # RHEL 9 only
#   SUITES=unit,recovery,break ./tests/dbshark/run-rhel.sh 8
#   SCENARIOS=cold-burst,stagger,unlogged ./tests/dbshark/run-rhel.sh
#   BEFORE_IMAGE=dbshark-test:rhel9-before ./tests/dbshark/run-rhel.sh 9  # also run the
#       compose scenarios on a pre-fix image (regression column, expected to fail)
#   NO_BUILD=1 ./tests/dbshark/run-rhel.sh 9 # reuse dbshark-test:rhel9
#   BASE_IMAGE=registry.access.redhat.com/ubi9/ubi ./tests/dbshark/run-rhel.sh 9   # entitled host + podman
#
# Results land in tests/dbshark/.rhel-results/rhel<N>/ (RESULTS=... to move):
#   suite-summary.txt, unit.log, break.log, break-report.json,
#   compose-<scenario>/report.json and node logs.
#
# Exit status: 0 only if every selected suite on every selected version
# ran and passed (unit cases, catalog harness ran, compose judge passed).
# Catalog "exited" cases are findings in break-report.json, not failures.
set -uo pipefail

ROOT=$(cd "$(dirname "$0")/../.." && pwd)
VERSIONS=${1:-all}
SUITES=${SUITES:-unit,recovery,break,compose}
SCENARIOS=${SCENARIOS:-cold-burst,promote-race,deadlock,lock-exhaust-spill,conn-loss,contention}
RESULTS=${RESULTS:-$ROOT/tests/dbshark/.rhel-results}
IMAGE_PREFIX=${IMAGE_PREFIX:-dbshark-test}
JOBS=${JOBS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 4)}
DOCKER=${DOCKER:-docker}

case "$VERSIONS" in
    all) VERSIONS="8 9" ;;
    8|9) ;;
    "8 9"|"9 8") ;;
    *) echo "usage: $0 [8|9|all]" >&2; exit 2 ;;
esac

if ! command -v "$DOCKER" >/dev/null 2>&1; then
    echo "error: $DOCKER not found; the RHEL environments are containers" >&2
    exit 2
fi

has() { case ",$SUITES," in *",$1,"*) return 0 ;; esac; return 1; }

overall=0
for v in $VERSIONS; do
    image=$IMAGE_PREFIX:rhel$v
    out=$RESULTS/rhel$v
    mkdir -p "$out"
    echo "=== RHEL $v: image $image, results $out"

    if [ "${NO_BUILD:-}" != "1" ]; then
        build_args=(--build-arg "RHEL_VERSION=$v" --build-arg "JOBS=$JOBS")
        if [ -n "${BASE_IMAGE:-}" ]; then
            build_args+=(--build-arg "BASE_IMAGE=$BASE_IMAGE")
        fi
        if [ -n "${PG_VERSION:-}" ]; then
            build_args+=(--build-arg "PG_VERSION=$PG_VERSION")
        fi
        "$DOCKER" build -f "$ROOT/tests/dbshark/build/Dockerfile.rhel" "${build_args[@]}" \
            -t "$image" "$ROOT" 2>&1 | tee "$out/build.log"
        if [ "${PIPESTATUS[0]}" != 0 ]; then
            echo "RHEL $v: image build failed (see $out/build.log)" >&2
            overall=1
            continue
        fi
    fi

    in_container=()
    has unit && in_container+=(unit)
    has recovery && in_container+=(recovery)
    has break && in_container+=(break)
    if [ ${#in_container[@]} -gt 0 ]; then
        # Live-capture catalog cases sniff lo; NET_RAW/NET_ADMIN are needed in
        # the container's bounding set. /shared collects logs and reports.
        "$DOCKER" run --rm --cap-add NET_RAW --cap-add NET_ADMIN \
            -v "$out:/shared" "$image" "${in_container[@]}"
        rc=$?
        echo "RHEL $v: in-container suites (${in_container[*]}) rc=$rc"
        [ "$rc" = 0 ] || overall=1
    fi

    if has compose; then
        for sc in ${SCENARIOS//,/ }; do
            shared=$out/compose-$sc
            echo "--- RHEL $v compose scenario $sc"
            DBSHARK_IMAGE=$image SCENARIO=$sc RACE_SHARED=$shared \
                COMPOSE_PROJECT_NAME="dbshark-race-rhel$v" \
                "$ROOT/tests/dbshark/compose/run.sh"
            rc=$?
            echo "RHEL $v compose $sc: judge rc=$rc (report: $shared/report.json)"
            echo "compose $sc rc=$rc" >>"$out/suite-summary.txt"
            [ "$rc" = 0 ] || overall=1
            # Regression column: the same scenario on a pre-fix image. Its
            # verdict is recorded, not counted; it is expected to fail.
            if [ -n "${BEFORE_IMAGE:-}" ]; then
                DBSHARK_IMAGE=$BEFORE_IMAGE SCENARIO=$sc RACE_SHARED=$out/compose-$sc-before \
                    COMPOSE_PROJECT_NAME="dbshark-race-rhel$v-before" \
                    "$ROOT/tests/dbshark/compose/run.sh"
                brc=$?
                echo "RHEL $v compose $sc on $BEFORE_IMAGE: judge rc=$brc (expected non-zero)"
                echo "compose $sc before-image rc=$brc" >>"$out/suite-summary.txt"
            fi
        done
    fi

    # Containers write results as root; hand them back to the invoking user
    # so the host can read and delete them without sudo.
    if [ "$(stat -c %u "$out")" != "$(id -u)" ] || [ -n "$(find "$out" ! -user "$(id -u)" -print -quit 2>/dev/null)" ]; then
        "$DOCKER" run --rm --entrypoint chown -v "$out:/shared" "$image" \
            -R "$(id -u):$(id -g)" /shared >/dev/null 2>&1 || true
    fi
done

echo "=== run-rhel: overall=$overall (results under $RESULTS)"
exit "$overall"
