#!/usr/bin/env python3
"""Reassembly across Wireshark session rotation.

Builds deterministic Ethernet pcaps and ingests them with dbshark twice:
once with -M (session rotation) and once without. Split TCP messages and
IP fragments that cross the rotation must produce the same rows as the
no-reset run, exactly once. Idle expiry and the hold cap must drop
unfinished messages and count that loss separately from capture drops
and database failures.

Requires PostgreSQL reachable as the current user and build/run/dbshark.

    python3 tests/dbshark/test_reassembly_rotate.py
    python3 tests/dbshark/test_reassembly_rotate.py split ooo
"""

import os
import socket
import struct
import subprocess
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DBSHARK = os.environ.get("DBSHARK", os.path.join(ROOT, "build", "run", "dbshark"))
DB = os.environ.get("DBSHARK_TEST_DB", "dbshark_reassembly")
ART = os.environ.get("DBSHARK_ARTIFACTS", "/opt/cursor/artifacts/reassembly")
PCAP_DIR = os.path.join(ART, "pcaps")

SYN, ACK, PSH = 0x02, 0x10, 0x08
FAILURES = []


def reset_db():
    subprocess.check_call(
        [
            "psql", "-d", DB, "-v", "ON_ERROR_STOP=1", "-q",
            "-c", "DROP SCHEMA IF EXISTS public CASCADE; CREATE SCHEMA public;",
        ],
        stdout=subprocess.DEVNULL,
    )


def table_counts():
    sql = r"""
    SELECT table_name FROM information_schema.tables
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
    ORDER BY table_name
    """
    names = subprocess.check_output(["psql", "-d", DB, "-At", "-c", sql], text=True)
    counts = {}
    for name in [n for n in names.splitlines() if n]:
        n = subprocess.check_output(
            ["psql", "-d", DB, "-At", "-c", f'SELECT count(*) FROM "{name}"'],
            text=True,
        ).strip()
        counts[name] = int(n)
    return counts


def scalar(sql):
    out = subprocess.check_output(["psql", "-d", DB, "-At", "-c", sql], text=True).strip()
    return int(out or "0")


def pcap_write(path, packets):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(struct.pack("<IHHIIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1))
        for ts_us, frame in packets:
            sec, usec = divmod(int(ts_us), 1_000_000)
            f.write(struct.pack("<IIII", sec, usec, len(frame), len(frame)))
            f.write(frame)


def eth_ipv4(src, dst, proto, l4, ident=1, frag_off=0, mf=False):
    tot = 20 + len(l4)
    if tot > 65535:
        raise ValueError(f"IP packet too large: {tot}")
    frag = (0x2000 if mf else 0) | (frag_off // 8)
    ip = struct.pack(
        "!BBHHHBBH4s4s",
        0x45, 0, tot, ident & 0xFFFF, frag, 64, proto, 0,
        socket.inet_aton(src), socket.inet_aton(dst),
    )
    eth = bytes.fromhex("0000000000020000000000010800")
    return eth + ip + l4


def tcp_seg(sport, dport, seq, ack, flags, payload=b""):
    hdr = struct.pack("!HHIIBBHHH", sport, dport, seq & 0xFFFFFFFF, ack & 0xFFFFFFFF,
                      5 << 4, flags, 65535, 0, 0)
    return hdr + payload


def udp_dgram(sport, dport, payload):
    return struct.pack("!HHHH", sport, dport, 8 + len(payload), 0) + payload


class Clock:
    def __init__(self, start=1_700_000_000_000_000):
        self.t = start

    def add(self, frame, dt=1000):
        self.t += dt
        return (self.t, frame)


class TcpStream:
    def __init__(self, src, dst, sport, dport, isn=1000, sisn=5000):
        self.src, self.dst = src, dst
        self.sport, self.dport = sport, dport
        self.cseq, self.sseq = isn, sisn
        self.ident = 1

    def _c(self, payload, flags):
        seg = tcp_seg(self.sport, self.dport, self.cseq, self.sseq, flags, payload)
        pkt = eth_ipv4(self.src, self.dst, 6, seg, self.ident)
        self.ident = (self.ident + 1) & 0xFFFF
        self.cseq = (self.cseq + len(payload) + (1 if flags & SYN else 0)) & 0xFFFFFFFF
        return pkt

    def _s(self, payload, flags):
        seg = tcp_seg(self.dport, self.sport, self.sseq, self.cseq, flags, payload)
        pkt = eth_ipv4(self.dst, self.src, 6, seg, self.ident)
        self.ident = (self.ident + 1) & 0xFFFF
        self.sseq = (self.sseq + len(payload) + (1 if flags & SYN else 0)) & 0xFFFFFFFF
        return pkt

    def handshake(self):
        syn = self._c(b"", SYN)
        synack = self._s(b"", SYN | ACK)
        ack = self._c(b"", ACK)
        return [syn, synack, ack]

    def client(self, payload, psh=True):
        return self._c(payload, ACK | PSH if psh else ACK)

    def client_at(self, seq, payload):
        """Segment that does not advance the stream cursor (retransmission or OOO)."""
        seg = tcp_seg(self.sport, self.dport, seq, self.sseq, ACK | PSH, payload)
        pkt = eth_ipv4(self.src, self.dst, 6, seg, self.ident)
        self.ident = (self.ident + 1) & 0xFFFF
        return pkt


def udp_filler(ident, src="10.9.0.1", dst="10.9.0.2", sport=9000):
    return eth_ipv4(src, dst, 17, udp_dgram(sport, 9, b"filler"), ident & 0xFFFF)


def tcp_filler(ident, sport):
    """One in-order TCP segment on its own 5-tuple. Creates a conversation."""
    seg = tcp_seg(sport, 9, 1, 0, ACK | PSH, b"abc")
    return eth_ipv4("10.8.0.1", "10.8.0.2", 6, seg, ident & 0xFFFF)


def http_req(path, host="h"):
    return f"GET {path} HTTP/1.1\r\nHost: {host}\r\n\r\n".encode()


def parse_log(text):
    summary, reassembly, rss = {}, {}, {}
    for line in text.splitlines():
        for label, dest in ((" summary ", summary), (" reassembly ", reassembly)):
            if label in line:
                body = line.split(label, 1)[1]
                for tok in body.split():
                    if "=" not in tok:
                        continue
                    k, v = tok.split("=", 1)
                    if v.endswith("s") and k == "elapsed_s":
                        continue
                    try:
                        dest[k] = int(v) if v.isdigit() or (v.startswith("-") and v[1:].isdigit()) else float(v)
                    except ValueError:
                        dest[k] = v
        if " rss_kib=" in line:
            body = line.split("rss_kib=", 1)[1]
            rss["rss_kib"] = int(body.split()[0])
            if "hwm_kib=" in line:
                rss["hwm_kib"] = int(line.split("hwm_kib=", 1)[1].split()[0])
    return summary, reassembly, rss


def run_dbshark(pcap, args, log_name, sample=False):
    reset_db()
    os.makedirs(ART, exist_ok=True)
    log_path = os.path.join(ART, log_name)
    cmd = [DBSHARK, "-r", pcap, "-o", f"dbname={DB}", *args]
    env = dict(os.environ)
    env.setdefault("DBSHARK_SPILL_DIR", os.path.join(ART, "spill"))
    samples = []
    t0 = time.monotonic()
    with open(log_path, "w") as logf:
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=logf, env=env)
        if sample:
            while proc.poll() is None:
                rss = None
                try:
                    with open(f"/proc/{proc.pid}/status") as sf:
                        for line in sf:
                            if line.startswith("VmRSS:"):
                                rss = int(line.split()[1])
                                break
                except FileNotFoundError:
                    pass
                if rss is not None:
                    samples.append((time.monotonic() - t0, rss))
                time.sleep(0.2)
        rc = proc.wait()
    text = open(log_path, encoding="utf-8", errors="replace").read()
    summary, reassembly, rss = parse_log(text)
    if sample and samples:
        sp = os.path.join(ART, log_name + ".rss")
        with open(sp, "w") as f:
            f.write("t_s\trss_kib\n")
            for t, r in samples:
                f.write(f"{t:.3f}\t{r}\n")
    return {
        "rc": rc,
        "log": log_path,
        "summary": summary,
        "reassembly": reassembly,
        "rss": rss,
        "counts": table_counts() if rc == 0 else {},
        "samples": samples,
        "text": text,
    }


def check(cond, msg):
    if cond:
        print(f"  ok  {msg}")
    else:
        print(f"  FAIL {msg}")
        FAILURES.append(msg)


def uri_count(path):
    exists = scalar(
        "SELECT count(*) FROM information_schema.tables "
        "WHERE table_schema='public' AND table_name='http_request'"
    )
    if not exists:
        return 0
    return scalar("SELECT count(*) FROM http_request WHERE uri = " + quote(path))


def quote(s):
    return "'" + s.replace("'", "''") + "'"


def counts_equal(a, b, label):
    keys = sorted(set(a) | set(b))
    mismatch = [(k, a.get(k, 0), b.get(k, 0)) for k in keys if a.get(k, 0) != b.get(k, 0)]
    check(not mismatch, f"{label}: table counts match ({sum(a.values())} rows)")
    if mismatch:
        print("    mismatches:", mismatch[:12])


def require_clean(run, label):
    check(run["rc"] == 0, f"{label}: exit 0 (got {run['rc']})")
    s, r = run["summary"], run["reassembly"]
    check(s.get("errors", 1) == 0, f"{label}: summary errors=0")
    check(r.get("capture_drop", 1) == 0, f"{label}: capture_drop=0")
    check(r.get("capture_ifdrop", 1) == 0, f"{label}: capture_ifdrop=0")
    check(r.get("db_failures", 1) == 0, f"{label}: db_failures=0")
    check(r.get("dissect_failures", 1) == 0, f"{label}: dissect_failures=0")
    check(s.get("rows", -1) == s.get("committed_rows", -2), f"{label}: rows committed")


def test_split():
    print("\n== split HTTP across -M ==")
    clk = Clock()
    flow = TcpStream("10.0.0.1", "10.0.0.2", 40000, 80)
    pkts = []
    for fr in flow.handshake():
        pkts.append(clk.add(fr))
    msg = http_req("/split-across-reset")
    cut = 12
    pkts.append(clk.add(flow.client(msg[:cut])))
    for i in range(500):
        pkts.append(clk.add(udp_filler(i + 1)))
    pkts.append(clk.add(flow.client(msg[cut:])))
    path = os.path.join(PCAP_DIR, "split.pcap")
    pcap_write(path, pkts)
    common = ["-p", "http", "--reassembly-idle-ms", "0"]
    base = run_dbshark(path, common, "split-baseline.log")
    rot = run_dbshark(path, common + ["-M", "50"], "split-rotate.log")
    require_clean(base, "split baseline")
    require_clean(rot, "split -M")
    check(uri_count("/split-across-reset") == 1, "split -M: uri stored once")
    # Re-count baseline by running the query against the last DB, so compare via saved counts.
    # uri was counted on the rotate DB. Baseline count is in base log's DB which was reset.
    # Recover baseline uri from the fact we only have one request: http_request rows.
    check(base["counts"].get("http_request", 0) == 1, "split baseline: one http_request row")
    check(rot["counts"].get("http_request", 0) == 1, "split -M: one http_request row")
    counts_equal(base["counts"], rot["counts"], "split")
    check(base["reassembly"].get("resets", 1) == 0, "split baseline: no reset")
    check(rot["reassembly"].get("resets", 0) > 0, f"split -M: resets={rot['reassembly'].get('resets')}")
    check(rot["reassembly"].get("replayed", 0) > 0, f"split -M: replayed={rot['reassembly'].get('replayed')}")
    check(rot["reassembly"].get("completed", 0) >= 1, "split -M: completed spanning message")
    check(rot["summary"].get("rows", 0) > 0, "split -M: rows written")
    check(rot["summary"].get("rows") == base["summary"].get("rows"), "split: summary rows match baseline")


def test_long_lived():
    print("\n== long-lived connection, many complete messages ==")
    clk = Clock()
    flow = TcpStream("10.0.0.3", "10.0.0.4", 41000, 80)
    pkts = []
    for fr in flow.handshake():
        pkts.append(clk.add(fr))
    for i in range(20):
        pkts.append(clk.add(flow.client(http_req(f"/live/{i}"))))
        for j in range(25):
            pkts.append(clk.add(udp_filler(i * 25 + j + 1, sport=9100)))
    path = os.path.join(PCAP_DIR, "longlived.pcap")
    pcap_write(path, pkts)
    common = ["-p", "http", "--reassembly-idle-ms", "0"]
    base = run_dbshark(path, common, "long-baseline.log")
    rot = run_dbshark(path, common + ["-M", "10"], "long-rotate.log")
    require_clean(base, "long baseline")
    require_clean(rot, "long -M")
    counts_equal(base["counts"], rot["counts"], "long-lived")
    check(rot["counts"].get("http_request", 0) == 20, "long -M: 20 requests")
    check(rot["reassembly"].get("replayed", 1) == 0, "long -M: completed messages were not replayed")
    check(rot["reassembly"].get("resets", 0) > 0, "long -M: rotated between messages")
    check(rot["reassembly"].get("suppressed_retransmissions", 0) == 0, "long -M: no false retransmission suppression")


def test_ooo():
    print("\n== out-of-order TCP split ==")
    clk = Clock()
    flow = TcpStream("10.0.0.5", "10.0.0.6", 42000, 80)
    pkts = []
    for fr in flow.handshake():
        pkts.append(clk.add(fr))
    msg = http_req("/ooo-across-reset")
    cut = 10
    first, second = msg[:cut], msg[cut:]
    seq1 = flow.cseq
    # Second half arrives before the first. Cursor stays put so the real first half uses seq1.
    pkts.append(clk.add(flow.client_at(seq1 + len(first), second)))
    for i in range(80):
        pkts.append(clk.add(udp_filler(i + 1, sport=9200)))
    pkts.append(clk.add(flow.client(first)))
    # client() advanced cseq by len(first) only. Account for the already-sent second half.
    flow.cseq = (flow.cseq + len(second)) & 0xFFFFFFFF
    path = os.path.join(PCAP_DIR, "ooo.pcap")
    pcap_write(path, pkts)
    common = ["-p", "http", "--reassembly-idle-ms", "0"]
    base = run_dbshark(path, common, "ooo-baseline.log")
    rot = run_dbshark(path, common + ["-M", "20"], "ooo-rotate.log")
    require_clean(base, "ooo baseline")
    require_clean(rot, "ooo -M")
    check(base["counts"].get("http_request", 0) == 1, "ooo baseline: one request")
    check(rot["counts"].get("http_request", 0) == 1, "ooo -M: one request")
    counts_equal(base["counts"], rot["counts"], "ooo")
    check(rot["reassembly"].get("replayed", 0) > 0, "ooo -M: replayed the early segment")


def test_incomplete():
    print("\n== incomplete message retained until exit ==")
    clk = Clock()
    flow = TcpStream("10.0.0.7", "10.0.0.8", 43000, 80)
    pkts = []
    for fr in flow.handshake():
        pkts.append(clk.add(fr))
    pkts.append(clk.add(flow.client(b"GET /never-finishes HTTP/1.1\r\nHost: h\r\n")))
    for i in range(10):
        pkts.append(clk.add(udp_filler(i + 1, sport=9300)))
    path = os.path.join(PCAP_DIR, "incomplete.pcap")
    pcap_write(path, pkts)
    rot = run_dbshark(path, ["-p", "http", "-M", "100", "--reassembly-idle-ms", "0"], "incomplete.log")
    require_clean(rot, "incomplete")
    check(rot["counts"].get("http_request", 0) == 0, "incomplete: no http_request row")
    check(rot["reassembly"].get("incomplete_flows", 0) >= 1, "incomplete: unfinished flow counted")
    check(rot["reassembly"].get("incomplete_packets", 0) >= 1, "incomplete: unfinished packet counted")
    check(rot["reassembly"].get("expired_packets", 1) == 0, "incomplete: not expired")


def test_expiry():
    print("\n== idle expiry then a late tail is lost ==")
    clk = Clock()
    flow = TcpStream("10.0.0.9", "10.0.0.10", 44000, 80)
    pkts = []
    for fr in flow.handshake():
        pkts.append(clk.add(fr, dt=1000))
    msg = http_req("/expired-message")
    cut = 8
    pkts.append(clk.add(flow.client(msg[:cut]), dt=1000))
    # Capture time jumps 5s. Rotation happens on these fillers, after the hold is idle.
    for i in range(46):
        pkts.append(clk.add(udp_filler(i + 1, sport=9400), dt=1000 if i else 5_000_000))
    pkts.append(clk.add(flow.client(msg[cut:]), dt=1000))
    path = os.path.join(PCAP_DIR, "expiry.pcap")
    pcap_write(path, pkts)
    # 3 handshake + seg1 + 46 fillers = 50 packets, then the tail.
    rot = run_dbshark(
        path,
        ["-p", "http", "-M", "50", "--reassembly-idle-ms", "1000"],
        "expiry.log",
    )
    require_clean(rot, "expiry")
    check(rot["counts"].get("http_request", 0) == 0, "expiry: late tail produced no row")
    check(rot["reassembly"].get("expired_packets", 0) >= 1, "expiry: expired_packets counted")
    check(rot["reassembly"].get("expired_flows", 0) >= 1, "expiry: expired_flows counted")
    check(rot["reassembly"].get("capture_drop", 1) == 0, "expiry: loss is not a capture drop")
    base = run_dbshark(path, ["-p", "http", "--reassembly-idle-ms", "0"], "expiry-baseline.log")
    require_clean(base, "expiry baseline")
    check(base["counts"].get("http_request", 0) == 1, "expiry baseline: same bytes complete without -M")


def test_retrans():
    print("\n== retransmission after rotation is not a second row ==")
    clk = Clock()
    flow = TcpStream("10.0.0.11", "10.0.0.12", 45000, 80)
    pkts = []
    for fr in flow.handshake():
        pkts.append(clk.add(fr))
    payload = http_req("/retrans-once")
    seq = flow.cseq
    original = flow.client(payload)
    pkts.append(clk.add(original))
    for i in range(40):
        pkts.append(clk.add(udp_filler(i + 1, sport=9500)))
    pkts.append(clk.add(flow.client_at(seq, payload)))
    path = os.path.join(PCAP_DIR, "retrans.pcap")
    pcap_write(path, pkts)
    common = ["-p", "http", "--reassembly-idle-ms", "0"]
    base = run_dbshark(path, common, "retrans-baseline.log")
    rot = run_dbshark(path, common + ["-M", "20"], "retrans-rotate.log")
    require_clean(base, "retrans baseline")
    require_clean(rot, "retrans -M")
    check(base["counts"].get("http_request", 0) == 1, "retrans baseline: one row")
    check(rot["counts"].get("http_request", 0) == 1, "retrans -M: one row")
    counts_equal(base["counts"], rot["counts"], "retrans")
    check(rot["reassembly"].get("suppressed_retransmissions", 0) >= 1,
          f"retrans -M: suppressed={rot['reassembly'].get('suppressed_retransmissions')}")
    check(rot["reassembly"].get("resets", 0) > 0, "retrans -M: rotated before the copy")


def dns_query(name):
    q = b""
    for label in name.split("."):
        q += bytes([len(label)]) + label.encode()
    q += b"\x00"
    return struct.pack("!HHHHHH", 0x1A2B, 0x0100, 1, 0, 0, 0) + q + struct.pack("!HH", 1, 1)


def test_ip_frag():
    print("\n== IP-fragmented DNS across -M ==")
    clk = Clock()
    dgram = udp_dgram(46000, 53, dns_query("across.reset.example"))
    cut = 16
    frag1 = eth_ipv4("10.0.0.13", "10.0.0.14", 17, dgram[:cut], ident=0x42, frag_off=0, mf=True)
    frag2 = eth_ipv4("10.0.0.13", "10.0.0.14", 17, dgram[cut:], ident=0x42, frag_off=cut, mf=False)
    pkts = [clk.add(frag1)]
    for i in range(40):
        pkts.append(clk.add(udp_filler(i + 1, src="10.7.0.1", dst="10.7.0.2", sport=9600)))
    pkts.append(clk.add(frag2))
    path = os.path.join(PCAP_DIR, "ipfrag.pcap")
    pcap_write(path, pkts)
    common = ["-p", "dns", "--reassembly-idle-ms", "0"]
    base = run_dbshark(path, common, "ipfrag-baseline.log")
    rot = run_dbshark(path, common + ["-M", "15"], "ipfrag-rotate.log")
    require_clean(base, "ipfrag baseline")
    require_clean(rot, "ipfrag -M")
    counts_equal(base["counts"], rot["counts"], "ipfrag")
    check(sum(rot["counts"].values()) > 0, "ipfrag -M: dns rows written")
    check(rot["reassembly"].get("replayed", 0) > 0, "ipfrag -M: replayed the first fragment")
    check(rot["reassembly"].get("resets", 0) > 0, "ipfrag -M: rotated between fragments")
    # Name column is dns.qry.name → dns_qry.name when that table exists.
    if "dns_qry" in rot["counts"]:
        n = scalar("SELECT count(*) FROM dns_qry WHERE name = 'across.reset.example'")
        check(n == 1, f"ipfrag -M: query name stored once (n={n})")


def test_cap():
    print("\n== hold cap expires the oldest unfinished message ==")
    clk = Clock()
    pkts = []
    nflows = 60
    flows = []
    for i in range(nflows):
        flow = TcpStream("10.1.0.1", "10.1.0.2", 20000 + i, 80, isn=1000 + i)
        flows.append(flow)
        body = f"GET /capflow/{i} HTTP/1.1\r\nHost: h\r\nX: ".encode()
        body += b"A" * (20000 - len(body))
        pkts.append(clk.add(flow.client(body), dt=100))
    for i in range(940):
        pkts.append(clk.add(udp_filler(i + 1, sport=9700), dt=100))
    tails = []
    for flow in flows:
        tails.append(clk.add(flow.client(b"\r\n\r\n"), dt=100))
    path = os.path.join(PCAP_DIR, "cap.pcap")
    pcap_write(path, pkts + tails)
    common = ["-p", "http", "--reassembly-idle-ms", "0"]
    base = run_dbshark(path, common, "cap-baseline.log")
    rot = run_dbshark(
        path,
        common + ["-M", "1000", "--reassembly-hold-mib", "1"],
        "cap-rotate.log",
    )
    require_clean(base, "cap baseline")
    require_clean(rot, "cap -M")
    check(base["counts"].get("http_request", 0) == nflows, f"cap baseline: all {nflows} requests")
    got = rot["counts"].get("http_request", 0)
    check(0 < got < nflows, f"cap -M: partial completion {got}/{nflows}")
    check(rot["reassembly"].get("expired_packets", 0) > 0, "cap -M: expired_packets > 0")
    check(rot["reassembly"].get("capture_drop", 1) == 0, "cap: overload is not a capture drop")
    check(rot["reassembly"].get("db_failures", 1) == 0, "cap: overload is not a database failure")
    # No URI twice.
    if got:
        dup = scalar("SELECT count(*) FROM (SELECT uri FROM http_request GROUP BY uri HAVING count(*) > 1) d")
        check(dup == 0, "cap -M: no duplicate uris")


def test_volume():
    print("\n== volume: unique flows plus one spanning HTTP message ==")
    n = int(os.environ.get("DBSHARK_VOLUME_FLOWS", "20000"))
    clk = Clock()
    flow = TcpStream("10.2.0.1", "10.2.0.2", 47000, 80)
    pkts = []
    for fr in flow.handshake():
        pkts.append(clk.add(fr, dt=100))
    msg = http_req("/volume-split")
    cut = 15
    pkts.append(clk.add(flow.client(msg[:cut]), dt=100))
    for i in range(n):
        pkts.append(clk.add(tcp_filler(i + 1, 1024 + (i % 50000)), dt=50))
    pkts.append(clk.add(flow.client(msg[cut:]), dt=100))
    # One unfinished request left open, so -M must report it and still not invent a row.
    hung = TcpStream("10.2.0.3", "10.2.0.4", 48000, 80)
    pkts.append(clk.add(hung.client(b"GET /volume-hung HTTP/1.1\r\nHost: h\r\n"), dt=100))
    path = os.path.join(PCAP_DIR, "volume.pcap")
    pcap_write(path, pkts)
    common = ["-p", "http", "--reassembly-idle-ms", "0"]
    print(f"  capture packets={len(pkts)} flows={n}")
    base = run_dbshark(path, common, "volume-baseline.log", sample=True)
    rot = run_dbshark(path, common + ["-M", "1000"], "volume-rotate.log", sample=True)
    require_clean(base, "volume baseline")
    require_clean(rot, "volume -M")
    counts_equal(base["counts"], rot["counts"], "volume")
    check(base["counts"].get("http_request", 0) == 1, "volume baseline: only the completed request")
    check(rot["counts"].get("http_request", 0) == 1, "volume -M: completed request once")
    check(rot["reassembly"].get("resets", 0) > 1, "volume -M: multiple rotations")
    check(rot["reassembly"].get("replayed", 0) > 0, "volume -M: replayed the open segment")
    check(rot["reassembly"].get("incomplete_packets", 0) >= 1, "volume -M: hung request still incomplete")
    check(base["reassembly"].get("incomplete_packets", 0) == 0, "volume baseline: hold inactive, no incomplete counter")
    bh, rh = base["rss"].get("hwm_kib", 0), rot["rss"].get("hwm_kib", 0)
    br, rr = base["rss"].get("rss_kib", 0), rot["rss"].get("rss_kib", 0)
    print(f"  rss baseline hwm={bh} exit={br}  -M hwm={rh} exit={rr}")
    check(bh > 0 and rh > 0, "volume: rss counters present")
    check(rh + 8192 < bh, f"volume: -M peak RSS lower by >8 MiB ({bh - rh} KiB)")
    check(rr + 8192 < br, f"volume: -M exit RSS lower by >8 MiB ({br - rr} KiB)")
    check(rot["reassembly"].get("capture_drop", 1) == 0, "volume: capture_drop stays 0 offline")
    # Steady state: -M samples after the first quarter should not track the no-reset climb.
    def tail_growth(samples):
        if len(samples) < 8:
            return None
        cut_i = len(samples) // 4
        return samples[-1][1] - samples[cut_i][1]
    bg, rg = tail_growth(base["samples"]), tail_growth(rot["samples"])
    print(f"  sample growth after first quarter: baseline={bg} KiB -M={rg} KiB points={len(base['samples'])}/{len(rot['samples'])}")
    if bg is not None and rg is not None and bg > 4096:
        check(rg + 4096 < bg, f"volume: -M RSS growth flattens ({rg} vs {bg} KiB)")


TESTS = {
    "split": test_split,
    "long": test_long_lived,
    "ooo": test_ooo,
    "incomplete": test_incomplete,
    "expiry": test_expiry,
    "retrans": test_retrans,
    "ipfrag": test_ip_frag,
    "cap": test_cap,
    "volume": test_volume,
}


def main():
    os.makedirs(ART, exist_ok=True)
    if not os.path.isfile(DBSHARK):
        print(f"missing {DBSHARK}; build with WS=$HOME/wireshark-4.2.6 ./tests/dbshark/build/build.sh", file=sys.stderr)
        return 2
    names = sys.argv[1:] or list(TESTS)
    for name in names:
        if name not in TESTS:
            print(f"unknown test {name}", file=sys.stderr)
            return 2
        TESTS[name]()
    print("\n== result ==")
    if FAILURES:
        print(f"{len(FAILURES)} failure(s):")
        for msg in FAILURES:
            print(f"  - {msg}")
        return 1
    print("all checks passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
