=========================
Current dbshark bugs
=========================

This document records bugs found while running **more than one dbshark
process against the same PostgreSQL database**. That is the intended
multi-node deployment: separate capture hosts, one shared catalog.

It describes ``src/dbshark.c`` on the ``codex/dbshark-cpu-efficiency``
branch. The program was **not** changed for this write-up. Measurements
are from 2 October 2026 against PostgreSQL 16.15 (docker ``logshark-pg``)
using a binary rebuilt from this source. The design of a single process
is in `DBSHARK_DESIGN.rst`.

.. contents:: In this document
   :depth: 2
   :local:

Status
======

These bugs are **reproduced and understood**. They are not theoretical.
Two dbsharks that first see the same protocol on an empty (or still-narrow)
schema will crash one of the processes almost every time. The loser
commits nothing. A later schema-shape mismatch can also fail COPY with a
JSONB format error even after the table already exists.

Single-node ingest of the same pcaps succeeds. Sequential ingest (process
A finishes and commits, then process B starts) also succeeds. The failure
is concurrent schema change, not the DIS/NTP/syslog dissectors.

Intended use versus what the code assumes
=========================================

`DBSHARK_DESIGN.rst` states the process model clearly: one dbshark, one
packet worker, one PostgreSQL connection. Schema work was written for that
model. Tables and columns are created lazily the first time a field
appears, inside the same transaction that later runs ``COPY``.

Multi-node use breaks that assumption. Each node has its own in-memory
map (``in_pg``, ``is_json``, ``copy_cmd``). None of them take a lock that
the others can see, except the locks PostgreSQL takes for ``CREATE`` /
``ALTER``. Those locks do not make ``CREATE TABLE IF NOT EXISTS`` safe
while the first transaction is still open, and they do not make
``ADD COLUMN`` without ``IF NOT EXISTS`` safe.

The user-visible symptom on two hosts that exchange the same packet is:
the sender reaches PostgreSQL first, "takes" the table, and the receiver
dies because that identity is already in use.

Bug 1 — concurrent CREATE TABLE (the "table id" crash)
======================================================

Symptom
-------

The second process exits with ``rc=1`` on the first matching packet.
``committed_rows=0``. Typical log::

    ERROR:  duplicate key value violates unique constraint "pg_type_typname_nsp_index"
    DETAIL:  Key (typname, typnamespace)=(dis, 2200) already exists.
    SQL: CREATE TABLE IF NOT EXISTS "dis" (ts_us BIGINT, src_ip TEXT, dst_ip TEXT,
         src_port INTEGER, dst_port INTEGER, frame_len INTEGER)
    create table "dis" failed

``2200`` is the schema OID (``public`` in the test database), not a
dbshark identifier. ``dis`` is the **composite row type** PostgreSQL
creates for every table. Creating a table inserts into both ``pg_class``
and ``pg_type``. The unique index on ``(typname, typnamespace)`` is what
the loser hits. That is the "table id already in use."

The same failure occurs for ``--unlogged`` (``CREATE UNLOGGED TABLE IF
NOT EXISTS``). Unlogged tables still get a row type.

Why ``IF NOT EXISTS`` does not help
-----------------------------------

``CREATE TABLE IF NOT EXISTS`` only skips when the table is **already
visible** to the current transaction. Visibility requires the creator to
have committed.

dbshark does this::

    BEGIN;                          /* process_file / live capture */
    ... first matching packet ...
    CREATE TABLE IF NOT EXISTS "dis" (...);   /* still uncommitted */
    ALTER TABLE "dis" ADD COLUMN ...;
    COPY "dis" (...) FROM STDIN WITH (FORMAT binary);
    ... more packets, same transaction ...
    COMMIT;                         /* 4 MiB, 60 s, or end of input */

Until that ``COMMIT``, the other node cannot see ``dis``. Its own
``IF NOT EXISTS`` therefore tries a real create, races in the catalog,
and fails.

The commit is delayed on purpose. `DBSHARK_DESIGN.rst` documents the
flush rules: 4 MiB of pending COPY bytes, or 60 seconds with pending
rows, or a clean shutdown. A short capture (two Entity State packets)
holds the uncommitted ``CREATE`` for the entire run. A long capture
still holds it until the first flush. Starting the second process 50 ms
into an 8600-packet ingest was enough to lose.

Relevant code
-------------

* ``process_file`` / live loop: ``BEGIN`` once at start
  (``src/dbshark.c``, around the offline ``BEGIN`` and the live
  ``BEGIN``).
* ``ensure_table_exists``: ``CREATE %sTABLE IF NOT EXISTS`` with optional
  ``UNLOGGED``, then treat any ``pg_exec`` failure as fatal.
* ``pg_exec``: any status other than ``COMMAND_OK`` / ``TUPLES_OK`` sets
  ``ingest_ok = 0`` and returns false. There is no retry and no special
  case for ``unique_violation`` (``23505``) or ``duplicate_table``
  (``42P07``).
* ``append_subtable_row``: schema failure calls ``db_fail("alter")``,
  which also sets ``stop_loop``.
* ``finish_txn``: on failure, ``ROLLBACK``. The loser's in-flight
  ``CREATE`` disappears. The winner's committed rows remain.

What was measured
-----------------

Every cold-schema dual ingest crashed exactly one process:

* 2-packet Entity State, 15 independent trials: **15/15** one crash.
* 43-type DIS corpus (one of each PDU): one crash, winner wrote 43
  ``dis`` rows (plus subtables).
* 50 Fire PDUs; 8600-packet corpus (200× each type); mixed
  DIS+NTP+syslog+CoAP+DNS+ASTERIX (500 of each): same pattern.
* Four concurrent processes on an empty database: **three** fail, one
  wins. The winner's row count equals one copy of the input, not four.
* ``--unlogged`` dual runs: same crash, same ``pg_type`` constraint.

SQL isolation (two ``psql`` sessions, no dbshark) reproduces it:
concurrent ``BEGIN; CREATE TABLE IF NOT EXISTS dis (...);`` — one
session succeeds, the other errors. So this is PostgreSQL catalog
behavior plus dbshark treating it as fatal, not a libpq misuse.

When it does **not** fail
-------------------------

* Process B starts only after process A has **committed** and exited:
  ``CREATE TABLE IF NOT EXISTS`` is a no-op, columns already exist,
  both runs succeed.
* The schema is fully warmed (one process ingested the full corpus and
  committed), then two processes ingest that corpus again: both
  ``rc=0``. No DDL remains to race.
* ``ALTER TABLE ... ADD COLUMN IF NOT EXISTS`` run from two ``psql``
  sessions both succeed. That form is safe; dbshark does not use it for
  payload columns.

Bug 2 — concurrent ADD COLUMN
=============================

Symptom
-------

The table already exists (committed). Two nodes then see a **new** field
at the same time. One dies with::

    ERROR:  column "proto_ver" of relation "dis" already exists
    ERROR:  column "category" of relation "dis" already exists

``materialize_hit_columns`` builds::

    ALTER TABLE "dis" ADD COLUMN "proto_ver" BIGINT, ADD COLUMN ...

There is no ``IF NOT EXISTS`` on those payload columns. The six metadata
columns do use ``ADD COLUMN IF NOT EXISTS``. The interesting fields do
not.

How this shows up in a real deployment
--------------------------------------

Day 1: one node (or a quiet pair after a successful create) commits an
Entity State–shaped ``dis`` table. Day 2: both nodes see Fire, Comment,
or a fuller corpus. Each process's ``in_pg`` flags still say those
columns are missing. Both issue ``ADD COLUMN``. One wins; the other hits
``duplicate_column`` and ``pg_exec`` kills ingest.

Measured: pre-create a metadata-only ``dis``, then dual full DIS corpus
— loser dies on ``proto_ver already exists``. Entity State schema
already committed, then dual Fire — loser dies on ``category already
exists``. The winner also promotes ``entity_id_site`` /
``entity_id_application`` / ``entity_id_entity`` to JSONB (Fire has
three entity IDs).

Bug 3 — JSONB promote versus COPY binary format
===============================================

Symptom
-------

After a narrow schema exists, dual ingest of a wider capture can fail
with::

    ERROR:  unsupported jsonb version number 0

This is not a lock timeout. It is a **wire-format mismatch**.

What dbshark writes
-------------------

Binary COPY for JSONB must send a version byte ``1`` followed by UTF-8
JSON (see ``write_json_cell`` and the comment on ``st_refresh_binary``).
Scalar ``BIGINT`` cells send an 8-byte integer with a 4-byte length
prefix. If the on-disk column is JSONB and the process still believes
it is scalar (``is_json == 0``), those eight bytes are parsed as JSONB.
The first byte is often ``0``, which PostgreSQL rejects as an unknown
jsonb version.

``is_json`` is per-process. It is set when:

* this process added the column as JSONB because ``n_hit > 1`` on first
  materialize, or
* this process ran ``ALTER COLUMN ... TYPE JSONB USING to_jsonb(...)``,
  or
* ``mark_existing_json_cols`` saw ``json`` / ``jsonb`` **at table-open
  time**.

It is **not** refreshed immediately before each ``COPY``. If the other
node promoted a column after this process opened the table (or after
this process cached ``in_pg``), COPY uses the stale encoder.

Measured: Entity State was ingested first (scalar ``entity_id_*``).
Then two processes ingested the 43-type corpus together. The winner
promoted those columns to JSONB. The loser still encoded BIGINT, and
COPY failed with jsonb version 0. ``information_schema`` on the
surviving database showed ``entity_id_site`` / ``_application`` /
``_entity`` as ``jsonb``. Row count was the winner's packets only; the
loser rolled back (``committed_rows=0``).

``promote_col_to_json`` itself is also racy: two ``ALTER ... TYPE JSONB``
statements, or one promote plus one ``ADD COLUMN``, interleave with
COPY. There is no advisory lock and no "already jsonb" short-circuit
that treats a concurrent promote as success and re-reads the catalog.

Why the loser writes nothing
============================

On any of the errors above:

1. ``pg_exec`` or COPY completion sets ``ingest_ok = 0``.
2. ``db_fail`` may set ``stop_loop``.
3. Later packets return immediately from ``process_packet`` because
   ``!ingest_ok``.
4. ``finish_txn`` rolls back the current transaction.

So the crashing node is not "almost done." It typically processed
**one** packet, created zero durable rows, and exited. The winner
continues and commits its own copy of the traffic. You do not get
two-node redundancy; you get one writer and one hard failure.

Memory growth and ``--unlogged``
================================

What was tested
---------------

Single-process ingest, RSS from ``/proc/<pid>/status`` ``VmRSS``:

* 20 000 identical Entity State PDUs, logged: peak **157 304 KiB**,
  success, 140 000 rows committed.
* Same pcap, ``--unlogged``: peak **157 360 KiB** (within 60 KiB),
  **faster** (about 12.4k vs 9.2k packets/s).
* Same pcap, ``--packet-local``: peak **157 280 KiB**.
* 8 600-packet full DIS corpus: ~157 MB.
* Mixed six protocols × 500: ~153 MB.
* 40 000 Entity State PDUs with **unique source IP/port**: peak
  **~191 MB**, second-half RSS about **33 MB** above the first half,
  with or without ``--unlogged``.

``--unlogged`` is **not** a distinct client-side leak on these runs.
The large constant is Wireshark/epan plus the DIS registrar map (32
subtables registered at startup). The slope on unique 5-tuples is
conversation / dissector state, which `DBSHARK_DESIGN.rst` already
warns is unbounded for a long session.

Where memory actually goes
--------------------------

* **epan + ``hf_arr`` + field maps.** Paid once at startup. Dominates
  the ~150–160 MB baseline.
* **COPY ``GString``s.** Created on first use of a table. Grow to the
  batch size (flush target 4 MiB per the pending-byte counter, but a
  wide packet can exceed that). ``allocated_len`` is **not shrunk**
  after a successful flush. N live tables × high-water mark stays
  until exit.
* **``field_col_t.extra[]``.** Grow-only occurrence overflow. Reused;
  the high-water mark remains until shutdown.
* **Wireshark conversations, reassembly, streams.** Grow with distinct
  flows and time. ``--packet-local`` disables some reassembly and can
  disable unused protocols; it did not remove the unique-flow RSS
  slope in the 40k test (peak still ~191 MB; RSS at exit dropped
  toward ~157 MB).
* **Timestamp spill file.** 16 bytes per spilled frame after 8 192
  in-memory slots. On a tmpfs this is RAM; it is not the 150 MB
  baseline.

What ``--unlogged`` *does* change
---------------------------------

* New tables are created ``UNLOGGED``. WAL is skipped for those
  heaps. Ingest is faster. The 4 MiB / 60 s client buffer is
  unchanged.
* After an **unclean PostgreSQL shutdown** (OOM killer, ``kill -9``,
  host crash), PostgreSQL **truncates unlogged tables** on recovery.
  Logged tables keep committed rows.

That combination matches the field report "everything crashed because
we ran out of memory and nothing was logged":

1. Two nodes race; the loser never committed.
2. Memory pressure (dbshark RSS + Postgres ``shared_buffers`` + kernel
   cache) trips the OOM killer or the processes die.
3. If tables were ``--unlogged``, recovery leaves them empty. Even the
   winner's committed rows are gone.

Default (logged) tables survive a crash after ``COMMIT``. Rows still
sitting in dbshark's COPY buffers or the open transaction are lost
either way. ``committed_rows`` only advances after a confirmed
``COMMIT``.

Other risks (not fully exploded in the harness)
-----------------------------------------------

* **Lock table pressure.** Default ``max_locks_per_transaction`` is 64.
  One transaction that ``CREATE``s many DIS subtables and ``ALTER``s
  them can approach that. ``out of shared memory`` during first-packet
  schema storms is plausible on a busy server; it was not the error
  seen in these tests.
* **COPY vs ALTER waits.** ``COPY FROM`` takes ``RowExclusiveLock``;
  ``ALTER TABLE`` needs ``AccessExclusiveLock``. One session waits
  (measured ~1.9 s behind a 2 s sleep in a ``COPY``). That is blocking,
  not a crash, unless a deadlock is reported. Dual dbshark did not
  need a deadlock to fail; the catalog unique constraint was enough.
* **No reconnect.** A failed connection ends the process. There is no
  retry of DDL or COPY.

Workaround until the code is fixed
==================================

Do **not** start two dbsharks against a cold schema.

1. On one node only, ingest a representative capture (or run until
   every expected table and column exists) and let it **commit**.
2. Confirm tables in ``\\dt`` / ``information_schema.columns``.
3. Start the other nodes. Dual ingest of the **same already-seen
   shape** succeeded in testing.

Alternatively, pre-create tables and columns out of band (migration)
so the first packet on every node is ``CREATE TABLE IF NOT EXISTS``
against an already-committed relation and ``in_pg`` is filled from
``ensure_fixed_columns``.

Do **not** use ``--unlogged`` for multi-node production if a crash
must not wipe the heap. Keep it for single-node, replayable loads.

Fix plan
========

Priority 0 — stop dying and stop writing the wrong cell format
--------------------------------------------------------------

1. **Treat concurrent DDL as success.** On ``unique_violation``
   (``23505``), ``duplicate_table`` (``42P07``), and
   ``duplicate_column`` (``42701``), log and continue. Re-run
   ``ensure_table_exists`` / column listing instead of
   ``ingest_ok = 0``.
2. **``ADD COLUMN IF NOT EXISTS``** for payload columns, matching the
   metadata columns. Proven safe in the SQL isolation test.
3. **Re-read ``pg_attribute`` (or ``information_schema``) after every
   DDL and immediately before ``COPY``.** Refresh ``in_pg``, SQL
   types, and ``is_json``. Rebuild ``copy_cmd``. This is what stops
   ``jsonb version number 0``.
4. **Take DDL out of the long COPY transaction.** Options:

   * a second libpq connection used only for autocommit DDL, or
   * ``COMMIT`` / ``BEGIN`` around schema changes (flush COPY first,
     which the code already does before ``ALTER``).

   After the winner commits the ``CREATE``, the loser's
   ``IF NOT EXISTS`` can skip. The race window shrinks from "until
   4 MiB or 60 s" to the duration of one DDL statement.

Priority 1 — serialize first-seen schema
----------------------------------------

5. **``pg_advisory_lock`` / ``pg_advisory_xact_lock``** keyed by
   schema + table name around create, add-column, and JSON promote.
   One node finishes DDL and catalog refresh; the other waits, then
   sees the committed shape.
6. **Promote path:** if the column is already ``jsonb``, skip
   ``ALTER TYPE`` and set ``is_json`` from the catalog. Do not fail
   if a concurrent session already promoted.

Priority 2 — memory and operations
----------------------------------

7. **Do not stop the capture** after a recovered schema race. Only
   fail on real incompatibility (wrong udt, not "already exists").
8. **Log RSS and ``pending_bytes``** periodically. Optionally shrink
   COPY ``GString``s after flush if they are far above the next batch.
9. **Optional conversation cap / periodic epan reset** for multi-day
   live capture (behavior change; document it). ``--packet-local`` is
   not a complete substitute.
10. **Document** that ``--unlogged`` is wipe-on-crash and is not a
    multi-node durability mode.
11. **Watch ``max_locks_per_transaction``** if many protocols create
    many subtables in one transaction. Splitting DDL into autocommit
    statements also reduces lock-table hold time.

Suggested implementation order: (1–4) so two cold nodes survive and
COPY matches disk; (5–6) so the first packet storm cannot interleave
promote and scalar encode; then tests below; then memory/ops.

Tests the fix must pass
=======================

All of these failed or were used as controls during the investigation.
They should become automated tests, not one-off ``/tmp`` scripts.

Cold schema
-----------

* Two processes, empty database, 2-packet Entity State: both ``rc=0``,
  ``dis`` row count **4** (2+2), not 2.
* Two processes, 43-type DIS corpus: both ``rc=0``, row counts **sum**.
* Two processes, 200× corpus, mixed six protocols, ``--unlogged``
  variants: same.
* Four processes, empty database, Entity State: all ``rc=0``, rows
  scale with process count.

Stagger and warm
----------------

* B starts 50 ms after A on a large pcap: both succeed.
* B starts only after A exits: still succeed (control).
* Full schema warmed, then dual same corpus: both succeed (control).

Second-wave DDL
---------------

* Entity State committed, then dual Fire / full corpus: both ``rc=0``.
  ``entity_id_*`` end as JSONB. No jsonb version errors. Row counts
  sum.
* Metadata-only ``dis`` pre-created, then dual corpus: both succeed.

Memory / durability
-------------------

* 20 k Entity State logged vs ``--unlogged``: RSS within noise;
  both commit the same row count.
* 40 k unique 5-tuples: RSS may rise; process must still commit;
  no unbounded growth in dbshark's own COPY buffers beyond the flush
  cap (Wireshark conversation growth is separate and should be
  documented if still present).
* Kill PostgreSQL after a committed ``--unlogged`` run and restart:
  document that heaps are empty (expected). Same test with logged
  tables: committed rows remain.

SQL unit checks (no dbshark)
----------------------------

* Concurrent ``CREATE TABLE IF NOT EXISTS`` still races in PostgreSQL;
  the **application** retry must hide it.
* Concurrent ``ADD COLUMN IF NOT EXISTS`` succeeds without retry.

Multi-node compose harness
==========================

Two live-capture nodes, one DIS driver, one UDP stub, and Postgres:

::

    ./tests/dbshark/compose/run.sh

See ``tests/dbshark/compose/README.md``. The judge fails on current
code (one node dies; ``dis`` rows ≈ one sender). After the fixes above
it should pass. Per-dbshark RSS/PSS/cgroup samples are in the compose
``shared`` volume (``*.resources.csv``) and ``report.json``.

``SCENARIO`` may be ``cold-burst`` (default), ``stagger``,
``unlogged``, ``unlogged-kill-pg``, or ``locks``.

Reproduction notes (investigation harness)
==========================================

These artifacts were used on 2 October 2026 and are **not** in the
repo (``scripts/`` is gitignored; pcaps were under ``/tmp``):

* ``/tmp/dbshark-test`` — rebuild of ``src/dbshark.c``
* ``/tmp/dis-es-2.pcap``, ``dis-corpus-once.pcap``,
  ``dis-corpus-200.pcap``, ``dis-es-20k.pcap``,
  ``dis-es-40k-unique.pcap``, ``dis-fire-50.pcap``,
  ``mixed-500.pcap``
* ``/tmp/dbshark_race_harness.py`` and
  ``/tmp/dbshark_race_results.json`` (20 harness cases: 12
  ``REPRO``, 8 ``ok``)

PDU builders: ``scripts/drivers/dis_pdus.py`` (43 named PDUs).

Related documentation
=====================

* `DBSHARK_DESIGN.rst` — single-process model, flush rules, ``--unlogged``,
  where memory goes, failure/rollback behavior.
* `PERFORMANCE.rst` — CPU and throughput; not multi-node safety.
* `README.md` (repo root) — Decode As / ``WIRESHARK_CONFIG_DIR`` (port mapping is
  unrelated to this catalog race).
