===================================
dbshark performance and correctness
===================================

Scope
=====

This review starts from ``wireshark-4.2.6`` commit
``8cdd8cb5b4bb3f5e7885be97047e1dabebb2384b``. Implementation work is on
``codex/dbshark-cpu-efficiency``. The measured implementation is commit
``5cecfa004a41fa920a26ac94a60f9c24d08c7a18``; subsequent report-only changes
do not change that executable. Other branches and dependency source are
unchanged.

The constraint is one dbshark capture/dissection worker and one database
connection. PostgreSQL remains a separate server. This is an optimization
of the existing Wireshark-to-PostgreSQL design, with the same table naming
and packet-to-row model. ``DBSHARK_DESIGN.rst`` explains the complete design.

Measured throughput
===================

These are full-process, end-to-end frames per second, including startup,
dissection, PostgreSQL COPY, final COMMIT, and shutdown. They are offline
replay measurements of deterministic generated captures, not NIC line-rate
measurements. Every measured run returned success and stored the expected
row counts. Values below are medians, with the minimum and maximum runs
shown in parentheses.

.. list-table:: Matching replayable settings
   :header-rows: 1

   * - Platform / workload
     - Original frames/s
     - Revised frames/s
     - Median change
   * - Windows / DIS Fire
     - 36,415 (35,457-37,149)
     - 43,546 (42,253-44,955)
     - +19.6%
   * - Linux / DIS Fire
     - 42,184 (42,135-43,071)
     - 49,051 (48,569-49,578)
     - +16.3%
   * - Windows / dense DNS
     - 8,547 (8,384-8,804)
     - 8,656 (8,490-9,057)
     - +1.3%
   * - Linux / dense DNS
     - 9,788 (9,545-9,809)
     - 10,214 (10,195-10,287)
     - +4.4%

The original program always requested unlogged tables, asynchronous commit,
and packet-local dissection. The revised runs in this comparison explicitly
use ``--unlogged --async-commit --packet-local`` to match those choices.
The change in Windows DNS throughput is small relative to the overlap in
run ranges; it does not establish a reliable speedup on its own.

Default settings now preserve reassembly preferences and use logged tables
with synchronous commit. For DIS Fire, measured default-setting medians
were **40,761 frames/s on Windows** (37,511-40,772) and **35,103 frames/s
on Linux** (32,028-36,200). These perform different durability and dissection
work from the original defaults and must not be advertised as an equivalent
before/after comparison. They show the practical cost of the safer settings
on these particular systems.

Windows DIS runs used 300,000 frames, five repetitions for the comparison
and three for default settings. Linux DIS used 100,000 frames and three
repetitions. Dense DNS used 50,000 frames, five repetitions on Windows and
three on Linux. DIS produces three rows per frame; dense DNS produces six.
Thus, for example, each Windows DIS comparison run stored 900,000 rows.

CPU cost and memory
===================

CPU time below belongs to the dbshark client process. PostgreSQL server CPU
is not included. Wall-clock throughput above does include its effect on
the client's progress.

.. list-table:: Median client CPU cost per input frame
   :header-rows: 1

   * - Platform / workload
     - Original CPU microseconds
     - Revised CPU microseconds
     - Original scheduled cycles
     - Revised scheduled cycles
   * - Windows / DIS
     - 21.25
     - 16.67
     - 68,346
     - 52,143
   * - Windows / DNS
     - 63.12
     - 62.50
     - 201,085
     - 194,528
   * - Linux / DIS
     - 19.00
     - 15.60
     - Not collected
     - Not collected
   * - Linux / DNS
     - 59.60
     - 55.20
     - Not collected
     - Not collected

Windows uses ``GetProcessTimes`` and ``QueryProcessCycleTime``. The latter
is the operating system's scheduled-cycle accounting, not a hardware
performance-counter measurement of retired instructions or unhalted core
cycles. Frequency changes and scheduling affect its interpretation. Linux
uses GNU time's per-child user/system CPU time and maximum resident set.
No Linux hardware-cycle, cache-miss, branch-miss, or instruction counters
were collected; the report does not infer those counts from clock speed.

Maximum measured resident memory across the replayable comparison runs:

.. list-table:: Client peak memory in MiB
   :header-rows: 1

   * - Platform / workload
     - Original
     - Revised
   * - Windows / DIS
     - 112.68
     - 111.09
   * - Windows / DNS
     - 94.59
     - 92.80
   * - Linux / DIS
     - 164.29
     - 163.61
   * - Linux / DNS
     - 165.82
     - 160.98

The savings in dbshark's own allocations are larger than this small change
in total resident memory suggests. Untouched allocations can reserve
address space without occupying resident pages, and the Wireshark runtime
and its session state dominate much of the process. These measurements
also exclude PostgreSQL memory, kernel buffers, and file-cache accounting.
They are not evidence of bounded memory for indefinitely growing
conversation state.

Where the remaining time goes
=============================

Separate instrumented runs used ``--profile`` with matching replayable
settings. The following values are elapsed microseconds per frame within
the measured categories:

.. list-table:: Instrumented stages
   :header-rows: 1

   * - Platform / workload
     - Dissection and reset
     - Encoding and associated local work
     - Database calls and waits
   * - Windows / DIS
     - 13.58
     - 0.94
     - 5.44
   * - Windows / DNS
     - 45.49
     - 5.44
     - 55.37
   * - Linux / DIS
     - 12.95
     - 0.90
     - 4.89
   * - Linux / DNS
     - 47.61
     - 6.79
     - 43.47

These counters omit startup, input reading, timestamp spilling, and some
catalog queries. Instrumentation itself costs time, so its throughput is
kept separate from the uninstrumented comparison.

Dissection dominates the categorized DIS time. Dense DNS divides most of
its time between dissection and the database. Removing the entire measured
encoding category would eliminate about 4.7% of the categorized Windows
DIS time or 5.1% of its DNS time. That arithmetic explains why another small
serializer optimization cannot produce a tenfold end-to-end improvement.
It is not a proof that the rest of dbshark cannot improve.

The original code's general claim that dissection consumes roughly 90% of
CPU is not a suitable workload-independent premise. The observed split
depends on traffic structure and on which measurements include database
waits. Profile each actual capture before choosing the next change.

What was already well designed
==============================

The baseline already avoids one INSERT per packet, uses a hidden Wireshark
field tree, indexes fields by numeric ID, uses packet markers instead of
clearing every field, stores common repeats inline, reuses buffers, and
tracks only tables touched by a packet. Those choices were retained.

The remaining unnecessary work was mostly around those structures:
scanning all possible columns to discover there was no schema change,
preparing unused fields on every packet, converting whole tables to text
COPY after one repeated field, duplicating metadata work, and repeatedly
calling generic append/formatting helpers for small scalar values.

Changes made
============

.. list-table:: Performance changes and their reason
   :header-rows: 1
   :widths: 30 70

   * - Change
     - Reason
   * - Compact, aligned column state
     - Reduce the tested 64-bit structure from 88 to 64 bytes. Keep the
       common occurrence pointers and flags together; remove unused per-column
       copies of the registration-ID lists.
   * - Schema-change flag and compact SQL column list
     - Stable packets visit materialized columns. Full registrar scans run
       only when a new field or new repeat needs a schema change.
   * - Incremental priming after dissection reset
     - Restore only the selected IDs whose flags Wireshark 4.2.6 cleared.
       Initially unseen fields stay prepared for their first appearance.
   * - Binary COPY for every table
     - Repeated JSON fields no longer cause decimal formatting and COPY-text
       escaping for every other cell in that table.
   * - Direct scalar writes
     - Reserve sufficient buffer room once, then write the length and value
       with fixed-size copies and explicit byte-order conversion.
   * - Direct JSON output and copying ordinary text in runs
     - Remove the scratch-to-table cell copy and avoid updating the output
       string one ordinary character at a time.
   * - Shared metadata and cached addresses
     - Format metadata once per packet and reuse it across subtables.
   * - Integer protocol-layer selection
     - Walk the layer list once and avoid repeated protocol-name comparisons.
   * - Incremental pending-byte accounting
     - A single counter replaces summing all table buffers for each packet.
   * - Lazy COPY buffers and batched column additions
     - Unused subtables allocate no COPY buffer. Related new columns use one
       ALTER statement; fields that immediately repeat start as JSONB.
   * - Borrow live packet bytes and reuse the record wrapper
     - Remove an unnecessary copy and repeated record/buffer construction.

These changes were measured together. The report does not assign the total
speedup to any one of them without an individual comparison. In particular,
a 64-byte structure alone is not a claim of a certain cache-miss reduction.

Correctness findings and fixes
==============================

.. list-table:: Findings
   :header-rows: 1
   :widths: 38 62

   * - Original problem or unsafe assumption
     - Behavior in this branch
   * - JSON escaping fed through text COPY without the required second
       escaping layer could corrupt values or fail ingestion.
     - Binary cells carry escaped JSON directly. Quotes, backslashes, tabs,
       and newlines round-trip through real PostgreSQL.
   * - Unsigned 64-bit fields could exceed signed BIGINT.
     - Use exact NUMERIC encoding and upgrade existing BIGINT columns.
   * - Sixteen-bit occurrence counts/capacities could wrap under dense repeats.
     - Use checked 32-bit counts and checked allocation growth; directly
       exercise 70,000 occurrences.
   * - The 8,192-frame timestamp ring silently forgot old request times.
     - Spill completed timestamp blocks to a temporary file and keep recent
       lookups in memory; test a response 9,001 frames after its request.
   * - Disabling reassembly and dependency dissectors could hide complete messages.
     - Preserve them by default; make the restrictive mode explicit.
   * - Unlogged tables and asynchronous commits were unconditional defaults.
     - Use logged tables and synchronous commits by default; require explicit
       opt-in, including when an existing table is unlogged.
   * - Quiet live interfaces could leave a small batch pending until another packet arrived.
     - Check the commit timer during idle waits.
   * - Truncated offline input could be treated as normal completion.
     - Fail and roll back the current batch on a short read.
   * - Transport port zero was treated as missing.
     - Preserve zero when Wireshark reports a transport protocol.
   * - An unknown live link type could be interpreted as Ethernet.
     - Refuse unsupported live link types instead of decoding with a guess.
   * - COPY lengths, result draining, error handling, and success counters
       could misrepresent what reached the database.
     - Chunk writes, drain and check completion results, verify row counts,
       and advance committed counts only after a confirmed commit.
   * - Wrong existing SQL types or name collisions could merge or misencode fields.
     - Validate types, detect collisions and column limits, and keep catalog
       inspection and writes in the same selected schema.
   * - Promotion could change bytes or booleans into a representation
       inconsistent with later JSON rows.
     - Convert existing bytes to hex strings and booleans to JSON booleans.
   * - Non-finite numbers and empty byte fields could be confused with missing values.
     - Preserve scalar floating-point values; use explicit JSON special-value
       strings and an empty hex string for empty bytes.
   * - Frame-number wrap could reuse IDs while old conversation state remained.
     - Fail explicitly before the 32-bit Wireshark frame number wraps.

Some findings are covered by direct database regressions; others, such as
the practical 32-bit frame-number boundary, are checked by code review and
guarded in code rather than by processing billions of test frames. Failure
to allocate memory can still terminate the process and lose its current
uncommitted batch.

The DNS embedded-zero test records a dependency limitation: Wireshark 4.2.6
has already truncated that field before dbshark receives it. This branch
preserves the value the dissector supplied and documents the missing suffix.
It does not label the upstream truncation as repaired.

CPU architecture research
=========================

Why small data structures matter
--------------------------------

A CPU fetches data in cache lines, not one requested byte at a time. AMD's
Zen 3 overview specifies 64-byte lines, 32 KiB of first-level data cache,
and 512 KiB of private second-level cache per core. This is relevant to the
Zen 3 family of the Windows test machine; its exact product cache totals
are recorded separately. See `AMD Zen 3 overview`_.

At 88 bytes per column, 1,500 column records occupy about 129 KiB before
their pointed-to data. At 64 bytes they occupy about 94 KiB. Both exceed
a 32 KiB first-level cache. Therefore packing alone is insufficient:
avoiding most of that scan on stable packets is the larger architectural
opportunity. The compact materialized-column list, packet markers, and
schema-change flag serve that purpose.

Modern AMD cores do not remove this constraint. AMD's published ZenDNN
architecture table lists 32 KiB data cache and 1 MiB private L2 for Zen 4.
AMD's Zen 5 white paper describes a 48 KiB data cache, 1 MiB private L2,
wider integer issue, and wider data paths. See `AMD architecture table`_
and `AMD Zen 5 white paper`_. These improvements increase capacity and
parallel execution, but a loop that fetches unnecessary field state still
spends instructions, load bandwidth, and cache space doing so.

Instructions, branches, and pointer chains
------------------------------------------

Mainstream out-of-order CPUs can overlap independent work, but a pointer
chain requires each address before the next load can be issued. A hash
probe followed by another pointer lookup is less predictable than an
indexed field lookup followed by a compact loop. dbshark already had the
indexed lookup; the new column list and shorter record reduce the remaining
work around it. This is an architectural rationale, not a measured count
of eliminated cache misses.

The common branch now asks whether the schema changed. Detailed CREATE,
ALTER, and catalog-inspection code stays in separate functions. This keeps
infrequent work away from the instruction stream that processes stable
packets. Removing formatting and repeated library calls also reduces work
for the processor's instruction decoder and branch predictor. Wider cores
benefit from useful independent instructions, not merely a larger source file.

Intel hybrid CPUs and scheduling
--------------------------------

Intel's 12th-generation architecture documentation distinguishes performance
cores from efficiency cores; groups of efficiency cores share an L2 cache,
and the operating system chooses where work runs. It also documents that
AVX-512 is unavailable on those hybrid processors. See `Intel hybrid guide`_.
Do not assume every logical CPU has the same speed or available cache.

For a one-worker ingest process, placement on a suitable core, competition
with its simultaneous-multithreading sibling, and PostgreSQL placement can
change results. This branch leaves scheduling to the OS. A deployment can
measure explicit affinity on the intended machine; hard-coding a CPU number
would not be portable. The Linux test VM exposes an Intel Xeon Platinum
8573C and two logical CPUs. Its reported cache hierarchy is included with
the results; a VM's reported topology is not a guarantee of exclusive
physical cores or memory bandwidth.

Intel's optimization manual remains the reference for architecture-specific
instruction and memory tuning; use its current index rather than assuming
one historical Intel core describes every current model. See `Intel
optimization manuals`_. No instruction-throughput table has been used here
as a substitute for measuring the complete program.

ARM and portable implementation choices
---------------------------------------

Arm's Neoverse N2 subsystem specification lists 64 KiB instruction and data
caches per core and up to 1 MiB of private L2. Arm's GCC discussion also
describes 64-byte cache-line defaults for Neoverse. See `Arm N2 specification`_
and `Arm compiler cache-line note`_. These systems reward compact working
sets too, but their instruction scheduling and vector capabilities differ
from x86. They have not been benchmarked in this work.

The implementation uses ordinary C, explicit byte-order conversion, and
fixed-size copies rather than unaligned integer pointer casts or mandatory
x86 intrinsics. The compiler can generate the appropriate stores for its
target. A different cache-line size can change the performance benefit of
alignment; it does not change the correctness of the row encoding.

Why there is no new hand-written SIMD or prefetch loop
------------------------------------------------------

Most dbshark work around dissection consists of heterogeneous values and
short pointer-dependent operations. JSON string scanning has some contiguous
bytes, but it is only part of an already small encoding category. An AVX-512
requirement would exclude relevant CPUs, including Intel hybrid examples.
Dispatch overhead, short strings, and extra copied bytes can erase the gain
from a wider instruction.

Similarly, a software prefetch is useful only if it arrives early enough
and the data is used. Dense sequential arrays already give hardware a
predictable access pattern. No unmeasured prefetch scheme, architecture-
specific assembly, global huge-page setting, or non-temporal store was
added. COPY buffers are used again shortly by libpq, which makes bypassing
the cache a questionable default. These are candidates for a targeted
measurement if a representative capture shows that category matters.

Correctness evidence
====================

Both native Windows and Linux passed the production-function C regression
executable and 17 real Wireshark-to-PostgreSQL integration cases. They cover:

* Exact complete stored-row comparisons against the original for ordinary
  DIS Fire and dense DNS captures.
* All unsigned 64-bit boundaries through UINT64_MAX, including migration
  of an existing BIGINT column.
* New fields on later packets, missing columns, repeated values, and
  scalar-to-array promotion without changing earlier scalar values.
* Quotes, backslashes, tabs, newlines, existing JSON/JSONB columns, port
  zero, and fragmented DNS under the default reassembly settings.
* Delayed response timing beyond the former timestamp ring.
* Truncated input, incompatible SQL columns, explicit unlogged-table
  permission, and a deliberate COPY constraint failure with rollback.
* The documented Wireshark DNS zero-byte limitation.

Linux also passed a real loopback capture test. It sent 32 DIS datagrams,
then left the interface idle. All 96 rows became visible after about 60.15
seconds. One further datagram followed by SIGINT committed the final three
rows. The final database contained 33 rows in each of three tables, and
libpcap reported zero drops. This validates idle flushing and graceful
stopping; 33 loopback packets are not a high-rate live capture benchmark.

Windows live capture was not exercised because this host did not have a
working Npcap capture driver. MSVC and ARM builds were not executed. Both
platforms' measured offline builds use the real Wireshark and PostgreSQL
libraries, not mocks.

Measurement environment and reproducibility
===========================================

Windows
-------

* Windows 11 build 26200, AMD Ryzen 7 6800H, 8 cores / 16 logical CPUs.
* Zig 0.14.1's Clang 19.1.7, ``-O3 -march=native -g`` for both sources.
  No LTO in these measurements. The CMake build also passed; its portable
  Zig toolchain lacked the archiver wrappers for CMake's LTO check, so it
  correctly built without LTO.
* Unmodified official Wireshark 4.2.6 Windows DLLs and matching GLib headers;
  libpcap 1.10.1 Windows SDK/library package.
* Unmodified PostgreSQL 17.6 binaries, temporary local cluster on loopback,
  normal durability configuration, 128 MiB shared buffers. Fast comparisons
  changed only the connection/table choices described above.

Linux
-----

* Ubuntu 24.04 GitHub runner, Linux 6.17 Azure kernel, Intel Xeon Platinum
  8573C, two exposed logical CPUs, PostgreSQL 17.11 in the CI service.
* GCC 13.3.0, Release ``-O3``, native CPU tuning, and LTO for both dbshark
  sources. Unchanged Wireshark 4.2.6 libraries built in Release mode.
* Passing run: `Linux validation run`_. Machine details, compiler output,
  regressions, live-capture result, and throughput JSON are checked in under
  ``bench/results`` so the report does not depend on expiring CI artifacts.

Method
------

The runner generates captures locally, creates an isolated random schema,
warms the schema with 32 frames, and truncates the tables before each timed
run. Schema creation during this warmup is excluded; process startup and
inspection of the existing schema are included in every measured run.
Unexpected schema changes in real traffic can cost much more than this
stable-schema case.

Timing ends after the process exits and its final commit has completed.
Row counting is outside the timed interval and verifies that the protocol's
anchor table contains one row per generated frame; all other table counts
are recorded too. Separate integration cases compare complete row values.
Only the randomly named benchmark schema is removed afterward.

The captures are generated Ethernet/IPv4/UDP DIS Fire packets and DNS
responses with 24 TXT answers each. They have predictable addresses and
field shapes. They do not represent an arbitrary production mix, encrypted
traffic, or every dissector. No production capture was supplied.

The two versions run sequentially; there is no concurrent competing
benchmark process. Repetitions are grouped by version, not randomized.
CPU affinity, fixed frequency, thermal state, filesystem cache state, and
background host activity were not fully controlled. Run ranges are shown
instead of treating small differences as certain. Do not attribute the
Windows/Linux difference to the operating system: hardware, compiler,
library builds, database version, and some sample sizes differ.

Binary hashes, input hashes for the final runs, arguments, exit statuses,
row counts, process timings, memory peaks, and logs are in the JSON files.
The Wireshark source archive's verified SHA-256 is
``5ec6028df29068d889c98489bf194a884b00831106fea1e921fea3c65f2003f5``.
``bench/results/dependency-downloads.json`` records the downloaded Windows
packages and whether each hash was checked against a published manifest.

To repeat the Linux comparison, use the workflow or run these commands
after building both executables against the same Wireshark libraries and
setting ``DATABASE_URL`` to a disposable test database::

    python3 bench/run.py --binary build/run/dbshark-baseline \
      --workload dis-fire --output bench/results/baseline-dis.json
    python3 bench/run.py --binary build/run/dbshark --workload dis-fire \
      --extra-arg=--unlogged --extra-arg=--async-commit \
      --extra-arg=--packet-local --output bench/results/revised-dis.json
    python3 bench/run.py --binary build/run/dbshark --workload dis-fire \
      --output bench/results/default-dis.json

Use ``--workload dns-dense --packets 50000`` for the DNS comparison. Add
``--extra-arg=--profile`` only to a separate diagnostic run. The same Python
runner works on Windows with executable and psql paths and a disposable DSN.

Remaining constraints and next useful measurements
==================================================

This is a measured improvement, not proof of a physical optimum. The
largest remaining costs in these captures belong to dissection and
PostgreSQL, which this task keeps unchanged. Live line-rate guarantees
cannot be obtained from the offline numbers.

Within the current design, further work is best driven by a representative
production capture and the actual target CPU. Measure hardware instruction,
cache, branch, and page-translation counters where available. Use AMD
uProf, Intel VTune, or Linux perf with symbols to locate the expensive
functions. Record server CPU and I/O separately from the client's costs.
Do not change global CPU or database settings merely to inflate a result.

Other useful experiments are compiler profile-guided optimization with a
representative training capture, packet mixes with changing addresses and
schemas, expected repeated columns precreated as JSONB, different batch
sizes, and placement of the client and server on appropriate cores. Any
adopted change should retain exact-value tests and report the latency,
memory, portability, and durability costs alongside throughput.

Large live bursts, real Npcap capture, long TCP streams, nested tunnels,
large schema promotions, timestamp-history disk exhaustion, and prolonged
conversation-memory growth remain deployment tests. The current
implementation makes relevant failures visible but cannot guarantee
lossless ingestion for unlimited traffic with finite resources.

Primary sources
===============

The architectural facts above come from vendor material; the dbshark
tradeoffs are conclusions drawn from its source and measurements.
PostgreSQL's binary COPY contract and JSONB receive implementation were
also checked directly. Wireshark reset behavior was inspected in the
unchanged 4.2.6 ``epan/proto.c`` source used for the builds.

* `AMD Zen 3 overview`_, section 2.1.
* `AMD architecture table`_, Zen 4/Zen 5 cache and dispatch context.
* `AMD Zen 5 white paper`_, core and cache design.
* `Intel hybrid guide`_, topology, instruction-set limits, and scheduling.
* `Intel optimization manuals`_, current vendor reference index.
* `Arm N2 specification`_ and `Arm compiler cache-line note`_.
* `PostgreSQL COPY format`_, `libpq COPY API`_, and `JSONB receive source`_.
* `PostgreSQL unlogged tables`_.
* `Wireshark 4.2.6 protocol-tree source`_.

.. _AMD Zen 3 overview: https://www.amd.com/content/dam/amd/en/documents/epyc-technical-docs/white-papers/overview-amd-epyc7003-series-processors-microarchitecture.pdf
.. _AMD architecture table: https://github.com/amd/zendnn/blob/main/benchdnn/doc/perf_counters.md
.. _AMD Zen 5 white paper: https://www.amd.com/content/dam/amd/en/documents/epyc-business-docs/white-papers/5th-gen-amd-epyc-processor-architecture-white-paper.pdf
.. _Intel hybrid guide: https://www.intel.com/content/www/us/en/developer/articles/guide/12th-gen-intel-core-processor-gamedev-guide.html
.. _Intel optimization manuals: https://www.intel.com/content/www/us/en/developer/articles/technical/intel64-and-ia32-architectures-optimization.html
.. _Arm N2 specification: https://developer.arm.com/Compute%20Subsystems/Neoverse%20N2%20Compute%20Subsystem
.. _Arm compiler cache-line note: https://developer.arm.com/community/arm-community-blogs/b/tools-software-ides-blog/posts/gcc-15-continuously-improving
.. _PostgreSQL COPY format: https://www.postgresql.org/docs/17/sql-copy.html
.. _libpq COPY API: https://www.postgresql.org/docs/17/libpq-copy.html
.. _JSONB receive source: https://github.com/postgres/postgres/blob/REL_17_STABLE/src/backend/utils/adt/jsonb.c
.. _PostgreSQL unlogged tables: https://www.postgresql.org/docs/17/sql-createtable.html
.. _Wireshark 4.2.6 protocol-tree source: https://gitlab.com/wireshark/wireshark/-/blob/v4.2.6/epan/proto.c
.. _Linux validation run: https://github.com/ryanharvey22/sqlshark/actions/runs/36289841381
