=======================
How dbshark is designed
=======================

This document describes ``src/dbshark.c`` on the
``codex/dbshark-cpu-efficiency`` branch, based on ``wireshark-4.2.6`` at
commit ``8cdd8cb5b4bb3f5e7885be97047e1dabebb2384b``. It explains the program
in plain English, including its performance choices and its limits.

.. contents:: In this document
   :depth: 2
   :local:

Purpose and boundaries
======================

dbshark reads captured network packets, asks Wireshark what they contain,
and stores selected protocol fields in PostgreSQL. It can read a capture
file or listen on a network interface. It links directly to Wireshark's
libraries; it does not start tshark or parse tshark's printed output.

There is one dbshark process, one packet-processing worker, one Wireshark
session, and one PostgreSQL connection. The database server is a separate
program and uses its own processes and resources. "One process" in the
benchmark means one dbshark ingest process, not an entire database system
inside that process. dbshark introduces no packet-worker pool or database
writer thread. Its dependencies may have their own internal activity.

The program stores the field values that Wireshark exposes. It is not a
replacement packet dissector, a raw-packet archive, or a lossless copy of
the original capture. Keep the source capture if exact replay is required.
No Wireshark, PostgreSQL, libpcap, GLib, or other dependency source is
changed by this branch.

The complete path through the program
=====================================

The two input paths meet at the same packet-processing function::

    Capture file -> Wiretap ---------+
                                    |
    Network interface -> libpcap ----+-> Wireshark dissection
                                          |
                                          v
                                   Selected field values
                                          |
                                          v
                                   Rows grouped by table
                                          |
                                          v
                                   Binary COPY buffers
                                          |
                                          v
                                   PostgreSQL transaction
                                          |
                                          v
                                   Confirmed commit

Each packet finishes dissection and row encoding before the next packet
is processed. Database writes also happen on this worker. A slow database
therefore pauses packet processing. The capture driver's buffer can absorb
a short pause; it cannot absorb a permanently higher arrival rate.

Starting the program
====================

Startup follows this order:

1. Read command-line options and environment defaults. Require exactly
   one input source, a database connection, and at least one protocol.
2. Check the loaded Wireshark library version. This implementation requires
   exactly 4.2.6 because a dissection optimization depends on that version's
   reset behavior.
3. On Windows, initialize Winsock. Initialize Wireshark's process policies,
   configuration paths, logging, capture-file support, and dissectors.
4. Load saved Wireshark settings. Apply dbshark's preferences described
   below.
5. Connect to PostgreSQL, use UTF-8 for text, and select the first existing
   schema in the connection's search path. Restrict this connection's
   search path to that schema so table inspection and writes agree.
6. Set the requested commit policy and turn off PostgreSQL query JIT for
   this connection where supported. These are session settings.
7. Look up the requested protocols and build the in-memory field map.
   Allocate the reusable metadata buffer. No capture tables are created yet.
8. Create the Wireshark session and its reusable dissection object, prepare
   the selected fields, and install shutdown handlers.
9. Open the input and begin a database transaction.

An unknown protocol or failed required initialization ends the run with a
nonzero exit status. Repeating the same protocol option prints a warning
and keeps one copy of that selection.

What protocol selection means
=============================

``-p`` takes a Wireshark protocol filter name, such as ``dis`` or ``dns``.
It selects fields to store. It does not tell Wireshark that arbitrary
traffic should be decoded as that protocol. Traffic on an unusual port
may need saved Wireshark port preferences or Decode As settings.

By default, dbshark retains the loaded reassembly preferences and leaves
other enabled dissectors available. Those dissectors may be needed to
reach the requested protocol inside fragments, streams, or tunnels.
Name resolution and IP, UDP, and TCP checksum validation are disabled.
Consequently, this program does not provide a full checksum-validation
record. Name resolution is unnecessary for the numeric address metadata.

``--packet-local`` requests the older, more restrictive behavior. It turns
off IP fragmentation reassembly and TCP stream reassembly, disables
unselected protocols, and re-enables the selected protocols plus a small
Ethernet/IP/transport set. Use it only when packets can be decoded
independently with those dependencies. It can omit messages in fragmented,
segmented, or tunneled traffic. It is not a transparent speed switch.

Reading a capture file
======================

Wiretap, Wireshark's capture-file library, opens the file and determines its
format. dbshark reuses one record object and one packet-byte buffer. For
each packet record it passes the timestamp, lengths, link type, and bytes
to the shared processing path. Non-packet records do not become rows.

The file's link type is used directly. It is not assumed to be Ethernet.
A normal end of file leads to a final flush and commit. A read error,
including a truncated final record, causes failure and rolls back the
current transaction. Transactions already committed remain in the database.

``-f`` is a live capture filter and is ignored with ``-r``. Selecting a
protocol also does not avoid the initial dissection of unrelated packets
in an offline file.

Reading a live interface
========================

dbshark creates a libpcap capture handle and asks for:

* Promiscuous capture, subject to the device and driver.
* A maximum captured packet size of 262,144 bytes.
* A 100 millisecond packet-buffer timeout.
* A capture buffer of 16 MiB by default, adjustable from 1 to 1,024 MiB.

After activation, it makes the handle nonblocking and applies the optional
BPF capture filter. Supported link types are explicitly translated into
Wiretap's numbering: Ethernet, raw IP, IPv4, IPv6, null/loopback, and Linux
cooked capture versions 1 and 2 where the libpcap headers define them.
An unknown live link type is rejected.

Each dispatch requests up to 64 packets. The callback wraps the borrowed
libpcap bytes in a reusable Wiretap record. Those bytes remain valid until
the callback returns. Dissection, serialization, and dissection reset all
finish within that callback, so dbshark does not make another packet copy.
The driver and libraries can still copy data internally.

When no packets are ready, the program checks whether buffered rows need
committing. Windows waits on libpcap's event; Linux waits on its selectable
file descriptor. The wait is at most 100 milliseconds. Where no waitable
handle exists, the program sleeps for 10 milliseconds between attempts.
This avoids spinning and allows sparse traffic to be committed even when
the interface becomes quiet.

At shutdown, driver-reported received and dropped packet counters are
logged when available. Reported drops or a capture read failure produce
a nonzero status after complete received rows are committed. These
counters cannot prove that no loss occurred before the capture driver.

What happens to one packet
==========================

The common processing function validates the captured and original packet
lengths, assigns a frame number, and remembers the capture timestamp.
It calls ``epan_dissect_run`` to interpret the bytes.

After dissection, an integer lookup checks Wireshark's list of protocol
layers against the requested protocols. A packet with no selected protocol
does not need field extraction or database row encoding.

For a match, dbshark walks the resulting field tree in its original order.
It follows containers even if their own protocol was not selected, because
they can contain a selected protocol. Each selected field is assigned to
its table and column. The program records pointers to the field values
without copying their contents at this stage.

Next it prepares the six shared metadata values once, updates the schema
if needed, and encodes one row for each table that received fields from
this packet. It checks whether the accumulated rows should be committed.
Finally, it resets the dissection and releases that packet's temporary
Wireshark state. Pointers to its fields must never be used after reset.

How Wireshark's field tree is kept small
========================================

dbshark asks for a tree without GUI display labels. Before dissection it
marks selected fields as needed; Wireshark calls this "priming". That
allows Wireshark to omit much of the unnecessary field-tree work while
still providing real values for the requested fields. Protocol containers
are kept available for walking the tree.

Every selected field is primed initially. In Wireshark 4.2.6, resetting a
tree clears reference flags for fields recorded in its
``interesting_hfids`` collection. Fields that did not occur keep their
flags. dbshark records the mapped IDs in that collection before reset and
primes only those IDs again afterward. It also primes the selected
protocol roots.

This avoids preparing thousands of unused fields on every packet. It is
not permission to skip priming altogether: doing so can lose values on
later packets. The regression suite checks both repeated values and fields
that first appear after earlier packets have already been reset. Revisit
this assumption before supporting another Wireshark version.

How fields become tables and columns
====================================

Wireshark registers a name, numeric ID, and value type for each field.
At startup, dbshark reads this registration list for each selected
protocol. It ignores structural fields that have no value to store.

The dotted field name determines the SQL names. At the default
``--split-depth 2``:

.. list-table:: Examples
   :header-rows: 1

   * - Wireshark field
     - Table
     - Column
   * - ``dns.qry.name``
     - ``dns_qry``
     - ``name``
   * - ``http.request.uri``
     - ``http_request``
     - ``uri``
   * - ``dns.id``
     - ``dns``
     - ``id``

For names longer than the chosen depth, the first segments form the table
and the remaining segments form the column. When the name has no more
segments than the depth, the first segment is the table and the rest form
the column. A name with one segment uses the selected protocol as its table.

Dots become underscores. SQL names are lowercased, other unsuitable
characters become underscores, and names are limited to 63 characters.
A leading underscore is added when required. SQL identifiers are quoted.

Multiple registrations of the same field name can share a column. Distinct
field names that collapse to the same column, incompatible types, metadata
name collisions, or selected protocols that collide on a table name are
errors. The program does not silently merge those meanings. Changing the
split depth can resolve some collisions and overly wide tables.

There are limits of 32 selected protocols, 512 registered subtables, and
1,590 materialized protocol columns per table. The six metadata columns
are additional. PostgreSQL can impose further limits, including limits
affected by old dropped columns or very wide rows. Such database errors
fail the transaction rather than silently omitting fields.

What a database row represents
==============================

A row represents one packet's fields for one subtable. One packet can
produce several rows in different tables. A table receives no row when
none of its mapped fields occur in that packet.

Every row begins with these metadata columns:

.. list-table:: Shared metadata
   :header-rows: 1

   * - Column
     - PostgreSQL type
     - Meaning
   * - ``ts_us``
     - ``BIGINT``
     - Capture time in microseconds; finer timestamp precision is truncated.
   * - ``src_ip`` and ``dst_ip``
     - ``TEXT``
     - Wireshark's selected network addresses, or SQL NULL when absent.
   * - ``src_port`` and ``dst_port``
     - ``INTEGER``
     - Wireshark's transport ports. Port zero is a value; absent transport is NULL.
   * - ``frame_len``
     - ``INTEGER``
     - Original frame length, which can exceed the number of captured bytes.

The table then contains protocol fields in the order chosen from the
registrar. The COPY command explicitly lists this order; physical table
column order does not have to match it. A field that does not occur in the
current packet is SQL NULL, even if it occurred in the previous packet.

There is no stored frame-number key, unique constraint, or automatic
deduplication. Metadata timestamps are not guaranteed unique. Replaying
input into the same tables appends rows. Multiple occurrences of a protocol
within one frame share the same subtable row; repeated fields become arrays.
Those arrays preserve field occurrence order, but are not a separate
relational model of each application message or nested structure.

Value types and repeated fields
===============================

.. list-table:: Value conversion
   :header-rows: 1

   * - Wireshark value
     - Initial SQL representation
   * - Boolean
     - ``BIGINT`` containing zero or one
   * - Signed integers, unsigned integers through 56 bits, frame references
     - ``BIGINT``
   * - Unsigned 64-bit integer
     - ``NUMERIC(20,0)``; values through 18,446,744,073,709,551,615 remain exact
   * - Floating-point number
     - ``DOUBLE PRECISION``
   * - Absolute or relative time field
     - ``DOUBLE PRECISION`` seconds
   * - Bytes
     - ``BYTEA``
   * - String
     - ``TEXT``
   * - Other supported value types
     - Wireshark's display representation in ``TEXT``

When a field appears several times in one packet, its column becomes JSONB.
For example, one value is ``7`` and three values are ``[7, 8, 9]``. A column
that has become JSONB stays JSONB; a later packet with one value uses a JSON
scalar, and an absent field uses SQL NULL. Independent field arrays are not
zipped together or sorted.

In JSON, booleans use ``true`` or ``false``, bytes use lowercase hexadecimal
strings without a prefix, and numeric values remain numbers. Non-finite
floating-point values use the strings ``"NaN"``, ``"Infinity"``, and
``"-Infinity"`` because JSON has no numeric spelling for them. Floating
numbers use a locale-independent decimal point.

JSON strings escape quotes, backslashes, and control characters. Normal
text is copied in runs. If a Wireshark string value still contains an
embedded zero byte, dbshark uses Wireshark's escaped display form because
PostgreSQL text and JSONB cannot store that character directly. A dissector
may already have discarded text after that byte; see the limitations below.

Creating and changing the schema
================================

The startup map describes possible fields, not tables that must all be
created. A table is opened or created only when a packet first supplies
one of its fields. Only fields actually encountered are added. This keeps
large protocol registries from producing thousands of unused SQL columns.

Existing columns are inspected before binary writes. Their types must
match the encoder, or already be JSON/JSONB. In particular, binary COPY
cannot send an eight-byte integer to a four-byte integer column and rely
on PostgreSQL to convert it.

An existing ``BIGINT`` column for an unsigned 64-bit field is changed to
``NUMERIC(20,0)``. Existing incorrect negative values from older dbshark
versions are not reconstructed; repair those by replaying the source data.
Existing ``json`` columns are supported using their own binary input
format, which differs from JSONB.

New columns needed by the same packet are added in one ALTER statement.
If a new field already repeats on its first appearance, it is created as
JSONB immediately. If a scalar column starts repeating later, dbshark first
flushes rows encoded for its old shape, then changes that column to JSONB.
Historical scalar values are converted to equivalent JSON values. Bytes
are converted to hexadecimal strings and booleans to JSON booleans.

Schema changes happen inside the ingest transaction. They can take locks
and rewrite existing data. A late scalar-to-JSONB change on a large table
can therefore cause a substantial pause. Precreating expected repeated
columns as JSONB can avoid that pause when the traffic structure is known.
Concurrent writers or schema changes against the same destination are not
coordinated by dbshark.

Why the program uses binary COPY
================================

COPY transfers many rows with less command overhead than issuing one INSERT
per row. Each table has a reusable byte buffer containing its COPY data.
All tables use PostgreSQL's binary COPY format, including tables with JSONB.

The stream begins with a binary header. Each row gives its column count.
Each cell gives its byte length followed by the value; a length of minus
one means SQL NULL. Integers and floating-point bits use the byte order and
width expected by PostgreSQL. A two-byte marker ends the stream.

An unsigned 64-bit number is encoded as PostgreSQL's base-10,000 numeric
digits, avoiding a signed overflow or a decimal-string round trip. A JSONB
cell contains format-version byte 1 followed by UTF-8 JSON text. An existing
``json`` cell contains the JSON text without that byte. JSON therefore does
not force the other cells in its table back to textual COPY.

Only one COPY operation can use this connection at a time. dbshark sends
table buffers in turn, in chunks no larger than 1 MiB, and then ends COPY.
It reads and releases every completion result and checks the reported row
count. Buffer contents are cleared only after a successful COPY. PostgreSQL
still parses JSONB and performs its normal storage work on the server.

Buffering, transactions, and durability
=======================================

The program keeps a running total of pending row bytes. It flushes all
tables and commits when that total reaches 4 MiB, when 60 seconds have
elapsed with pending rows, or when input ends normally. The clock is sampled
every 256 packets during a busy stream and during idle live-capture waits.
Schema changes can flush one table earlier without committing the transaction.

The 4 MiB threshold is checked after encoding a complete packet. It is not
a hard memory ceiling: a wide packet can exceed it, and buffer allocations
remain available for reuse. The 60-second interval is also not a deadline
while dissection or a blocking database operation is still running.

By default, new tables are logged and ``synchronous_commit`` is set to
``on``. Existing unlogged or temporary tables are rejected in this mode.
The program does not silently convert an existing unlogged table, since
that can be a large operation. Normal durability still depends on the
database server's configuration, storage, and hardware.

``--unlogged`` permits tables whose data is not protected by PostgreSQL's
normal write-ahead logging. It creates new tables as unlogged, but does not
change existing logged tables. PostgreSQL can empty unlogged tables after
an unclean shutdown. ``--async-commit`` separately requests commits that
may be acknowledged before their recovery information is durable. These
options are intended for data that can be replayed. They are independent
of ``--packet-local``.

Rows waiting in dbshark's memory or its open transaction are not committed
data. A process crash can lose that batch even under the default settings.
The ``committed_rows`` counter advances only after a confirmed COMMIT.

Failure, stopping, and recovery
===============================

A database error, serialization failure, invalid input length, timestamp
history I/O error, or offline read failure stops ingestion and rolls back
the current transaction. Earlier commits remain. A failed COPY is ended
and its results are drained before rollback. A COMMIT response that says
ROLLBACK is not counted as success.

There is no automatic reconnect or retry. If the connection disappears
during COMMIT, the client may not know whether the server committed. Since
rows have no replay identifier, blindly retrying can create duplicates.
An operator must decide how to replay or replace the affected data.

An ordinary interrupt asks the loop to stop after completing the current
packet, then flush and commit complete rows. Windows uses console control
events; Linux uses SIGINT and SIGTERM. Abrupt termination or forced window
closure is not guaranteed to allow enough time for a final commit.

Cleanup closes capture, frees the dissection and session, releases dbshark's
maps and buffers, closes the database connection, then shuts down Wireshark
and Wiretap. Windows also releases Winsock. Temporary timestamp storage is
removed when its handle closes, including abnormal process termination.

Where memory goes
=================

The main data structures have specific jobs:

``hf_arr``
    An array indexed by Wireshark field ID. Each entry is either empty or
    points to a table and column. Field lookup avoids a hash-table search.
    The array contains holes, so it is not scanned for every packet.

``field_col_t``
    One column's current state: last packet marker, occurrence count,
    four inline field pointers, overflow pointer, SQL flags, type, and
    column name. It is 64 bytes on the tested 64-bit targets. Column
    storage starts at a 64-byte boundary.

Packet markers, also called epochs
    Each packet gets a new marker. A column whose marker differs has no
    current value. This avoids clearing all possible columns on every
    packet. Marker wrap explicitly clears stale markers before reuse.

Overflow occurrence arrays
    A fifth occurrence requires additional pointer storage. The allocation
    grows when needed and is reused. Counts use 32 bits, avoiding the old
    16-bit wrap at 65,536 occurrences. This storage retains its largest
    allocation until shutdown.

``live_tables``
    A compact list of tables touched by this packet. Row emission visits
    this list instead of every registered table.

``pg_fields`` and the schema-change flag
    Each table has a compact list of columns that actually exist in SQL.
    Encoding visits only those columns. Full registrar scans run only
    when a new field or newly repeated field requires a schema change.

Shared metadata buffer
    Packet metadata reuses its allocation. Small address
    caches avoid formatting unchanged source and destination addresses
    again. All rows from one packet reuse the encoded metadata.

JSON output
    JSON is written directly into the table's COPY buffer. The encoder
    reserves room for the cell length and fills that length in afterward.
    It remembers a byte offset, so a buffer growth cannot leave a stale
    pointer. This removes an intermediate allocation and cell copy.

COPY buffers
    A table requests 16 KiB of initial buffer space on first use; GLib can
    round the actual allocation upward. Unused
    registrar tables have no COPY buffer. Buffers grow to their required
    size and keep that capacity for subsequent batches.

Timestamp history
    The latest 8,192 frame timestamps stay in a ring in memory. Before
    overwriting a complete ring, the program appends it to a temporary
    file. Older request/response lookups read the file and keep the result
    alive for the rest of that packet. Recent lookups remain in memory.
    Disk use grows by ``sizeof(nstime_t)`` per spilled frame, 16 bytes on
    the tested 64-bit builds, or about 16 MB per million frames. The
    temporary directory must have space. A memory-backed Linux temporary
    directory uses memory for that storage too.

These changes reduce dbshark's working memory, but do not impose a constant
limit on the whole process. Wireshark can retain conversations, fragments,
and stream state for the capture session. Database storage, the kernel's
file cache, and capture-driver buffers are separate resource costs.

Session rotation (``-M``)
=========================

Wireshark 4.2.6 keeps conversations, TCP multisegment PDUs, IP fragment
bodies, and other reassembly tables in one process-wide **file scope**.
``epan_t`` only stores the packet-provider callbacks. ``epan_free`` leaves
that scope and frees every buffer allocated in it; ``epan_new`` enters a
new empty one. There is no supported way to copy a live conversation or
reassembly table into another session: the fragment bytes and MSP trees
are file-scope pointers, and a second ``epan_new`` cannot own a second
file scope (``wmem_enter_file_scope`` asserts the scope is not already
entered).

``-M N`` used to call that reset every N packets. A message whose first
segment was dissected before the reset and whose last segment arrived
after it could not be completed, so the row was missing. Per-packet
``epan_dissect_reset`` already frees the tree, tvb, and packet scope; it
is not what bounds a long capture. COPY buffers keep their high-water
mark up to the 4 MiB flush and are not the unbounded slope.

With ``-M``, dbshark still rotates the session on that packet boundary,
but it first copies out packets that Wireshark still considers unfinished:

* TCP: either direction has an MSP without ``MSP_FLAGS_GOT_ALL_SEGMENTS``,
  a non-empty out-of-order segment list, or ``TCP_FLOW_REASSEMBLE_UNTIL_FIN``.
  The public ``tcp_analysis`` / ``tcp_multisegment_pdu`` structures from
  Wireshark 4.2.6 expose those flags. ``get_tcp_conversation_data`` is a
  linked export.
* IPv4/IPv6: fragments of one datagram (same id, source, destination, and
  protocol) until the byte range is covered.

Those packets are replayed, in capture order, into the new session with
database output suppressed. Replay rebuilds the MSP and fragment tables
from the original bytes. The later segment then completes the message and
is written once. Completed messages are not replayed. A fixed overlap is
not used; a message may sit unfinished across any number of other packets,
up to the hold cap.

``tcp.reassemble_out_of_order`` is turned on unless ``--packet-local`` is
set. Wireshark's default is off, which drops out-of-order segments instead
of buffering them. In-order streams still dissect as before. This preference
is what allows a reordered split, and a split that crosses ``-M``, to
complete.

Out-of-order gaps need one more step. ``packet-tcp.c`` only queues a
segment as out-of-order when the direction has a contiguous edge
(``maxnextseq``), which a fresh session learns from a SYN. If a held
direction has queued gaps, replay is preceded by a payload-free SYN built
from the held packet's own link, IP and TCP headers, with sequence number
one below the lowest byte the new session will see (``synthetic_syns``).
``maxnextseq`` is stored relative when ``tcp.relative_sequence_numbers``
is on; the public ``base_seq`` converts it back to the wire value. The
synthetic SYN is never a row. It does change relative ``tcp.seq`` values
for that direction after a rotation if ``-p tcp`` is selected.

After ``epan_free`` the file scope's many small blocks are back in the
allocator's arenas, not in the kernel. On glibc ``malloc_trim(0)`` is
called at that point so RSS actually falls. Measured on 400 000 unique TCP
flows plus five spanning HTTP requests (``tests/dbshark`` volume
capture): no ``-M`` climbs to 447 MB; ``-M 100000`` sawtooths between
150 and 292 MB; ``-M 50000`` peaks at 251 MB. All three store the same
rows. The ~150 MB floor is epan and the registrar, paid once.

Long-lived connections are not pinned to one session. After each message
on the connection goes idle inside Wireshark (no unfinished MSP), nothing
from that connection is replayed, and the next rotation frees its
conversation. The next message is dissected in the new session. A
fully retransmitted TCP payload that was already stored is not dissected
again, so it does not become a second row after rotation.

Unfinished data that never completes is the limit. ``--reassembly-hold-mib``
(default 64) caps the copied packets. ``--reassembly-idle-ms`` (default
30000) drops a hold that has seen no packet for that long in capture time
or in wall time. Either expiry discards that flow's replay copy and counts
``expired_flows`` / ``expired_packets``. The next rotation then frees the
Wireshark copy as well. A later segment of that message is not a database
row. ``0`` on either option disables that limit; disabling both keeps an
unfinished flow until the process exits. ``incomplete_flows`` at exit is
that remainder. ``lost_packets`` counts payload that arrived on a flow
whose earlier bytes were already expired inside the current session.

``--packet-local`` still disables IP and TCP reassembly and does not hold
packets. Application reassembly that is neither TCP desegmentation nor IP
fragmentation (for example a private UDP fragment scheme that never sets
Wireshark's fragment flag) is not held. Nested tunnels are keyed by the
outer headers dbshark parses (Ethernet, Linux cooked capture, null, and
raw IP).

Counters on the ``reassembly`` log line: rotations (``resets``), replayed
packets, spanning completions, expirations, incomplete holds at exit,
lost packets, suppressed retransmissions, synthetic SYNs, hold bytes, capture drops
(``pcap_stats``, separate from reassembly loss), dissection failures,
database write failures, and COPY queue depth. ``rss_kib`` / ``hwm_kib``
are the process figures from ``/proc/self/status`` on Linux.

Windows and Linux
=================

Both platforms compile the same C source and use the same encoders and
database logic. Windows-specific code handles Winsock, console signals,
capture events, temporary-file opening, and 64-bit file seeking. Linux uses
poll, POSIX signals, and file seeking. No POSIX-only getopt dependency is
required: command-line parsing uses Wireshark's exported parser.

Integer writes use byte-order conversion and ``memcpy``. They do not assume
that arbitrary buffer addresses satisfy an integer's alignment rule. Text
and GLib-owned allocations are freed through the matching allocator. On
Windows, opening a temporary file and converting its descriptor to a C
stream use the same runtime, even when GLib uses a different runtime.

Native x86-64 Windows and Linux builds and database round trips are covered
by this work. The Windows test build uses Clang through Zig; the Linux
build uses GCC. MSVC and ARM are build targets for further validation,
not measured configurations in the accompanying results. A working
Windows live-capture installation also needs a compatible Npcap driver
and capture DLL/import library pair.

Building and running
====================

``tests/dbshark/build/CMakeLists.txt`` builds dbshark without rebuilding or modifying its
dependencies. Supply matching Wireshark 4.2.6 headers and libraries, GLib,
libpcap or Npcap, and libpq development files. They must agree on architecture
and ABI. The library search path must also contain their runtime libraries.

For an existing Linux Wireshark source/build tree::

    cmake -S tests/dbshark/build -B build -DCMAKE_BUILD_TYPE=Release \
      -DWIRESHARK_ROOT=/path/to/wireshark-4.2.6 \
      -DWIRESHARK_LIBRARY_DIR=/path/to/wireshark-4.2.6/build/run
    cmake --build build
    ./build/run/dbshark -r traffic.pcap -p dis -o "dbname=packets"

For Windows, run CMake with a configured C compiler and use the same
``WIRESHARK_ROOT`` and ``WIRESHARK_LIBRARY_DIR`` options. Additional search
roots are ``GLIB_ROOT``, ``PCAP_ROOT``, and ``PostgreSQL_ROOT``. Explicit
``GLIB_LIBRARY`` and ``PostgreSQL_LIBRARY`` paths can select the matching
libraries when several import-library formats are installed. Non-MSVC
linkers that support direct DLL linking can use the official Wireshark
DLLs; MSVC needs matching import libraries. Put the corresponding runtime
DLL directories on PATH, then run ``dbshark.exe`` with the same options.

``DBSHARK_NATIVE=ON`` allows optimization for the build machine's CPU.
Leave it off for a binary intended for other machines. ``DBSHARK_LTO``
defaults to on, but is enabled only when the toolchain check succeeds.
It optimizes dbshark; it does not optimize across the separately built
Wireshark shared library. ``tests/dbshark/build/deps-debian.sh`` and
``deps-rhel.sh`` install the dependencies; ``build.sh`` in the same
directory is the one-command build; ``Dockerfile.rhel`` builds and tests
in isolated RHEL 8/9 containers (``tests/dbshark/run-rhel.sh``).

Live capture requires the operating system's capture permissions. The
database role needs permission to create and alter tables in the selected
schema and load their rows. Choose a destination schema through the
connection settings, for example PostgreSQL's ``options``/``PGOPTIONS``
search-path setting. Schema creation itself is the operator's responsibility.

Command-line reference
======================

.. list-table:: Options
   :header-rows: 1

   * - Option
     - Meaning
   * - ``-r FILE``
     - Read a capture file; mutually exclusive with ``-i``.
   * - ``-i IFACE``
     - Capture a live interface using its libpcap/Npcap name.
   * - ``-o CONN``
     - libpq connection string or PostgreSQL URI. Falls back to ``DATABASE_URL``.
   * - ``-p PROTO``
     - Protocol filter name to store; repeat for multiple protocols.
   * - ``-f BPF``
     - Live capture filter; ignored for capture files.
   * - ``-M N``
     - Rotate the Wireshark session every N packets. Unfinished TCP streams and IP fragments are replayed so a split message is stored once. See "Session rotation (``-M``)".
   * - ``--reassembly-hold-mib N``
     - Cap on bytes copied for that replay. Default 64. ``0`` disables the cap. Over the cap, the oldest unfinished flow is expired and counted.
   * - ``--reassembly-idle-ms N``
     - Drop an unfinished hold after this much capture-time or wall-time silence. Default 30000. ``0`` disables the timer.
   * - ``--split-depth N``
     - Positive number of dotted-name segments used for table splitting; default 2.
   * - ``--log-level LEVEL``
     - error, warn, info, or debug; default info, also settable with ``DBSHARK_LOG``.
   * - ``--capture-buffer-mib N``
     - Requested live driver buffer size; default 16, allowed range 1 to 1,024.
   * - ``--unlogged``
     - Permit replayable, non-crash-safe tables and create new tables as unlogged.
   * - ``--async-commit``
     - Request asynchronous PostgreSQL commits; recent acknowledged rows can be lost after a crash.
   * - ``--packet-local``
     - Disable reassembly and unselected dependency protocols; changes which traffic can be decoded.
   * - ``--profile``
     - Instrument dissection, encoding, and database waits; adds measurement overhead.
   * - ``-h`` or ``--help``
     - Print usage and exit.

Logs, counters, and measurements
================================

Logs go to standard error with UTC time and a severity. They include schema
changes, failures, and an end-of-run summary. ``packets`` counts processed
input packets, ``matched`` counts packets containing selected protocols,
and ``rows`` counts encoded subtable rows. These numbers are different.
``promotes`` counts scalar-to-JSONB changes; ``errors`` counts error logs.
``committed_rows`` counts rows in confirmed committed transactions.

The summary's elapsed time covers the capture-processing loop through its
final transaction work. Its frames-per-second value divides input packets
by that time. The external benchmark uses a broader interval: full process
startup through exit, including library initialization and final commit.

``--profile`` reports elapsed microseconds around dissection/reset,
encoding, and database operations. Encoding excludes the timed database
work nested inside it. Startup, file reading, timestamp spilling, and some
catalog inspection are outside these stage counters. They are useful
localization measurements, not a complete CPU-cycle accounting. Database
time includes waiting on a separate server. Use uninstrumented runs for
the primary throughput comparison.

``PERFORMANCE.rst`` records the review, CPU research, measured throughput,
and remaining optimization opportunities. Raw results and commands are
kept under ``bench`` and in the GitHub workflow.

Limits that matter in production
================================

* There is one blocking worker. Sustained capture above its end-to-end
  capacity can overflow the driver's buffer. No finite buffer fixes that
  mismatch, and dbshark cannot backpressure an ordinary network sender.
* A captured packet can already be truncated. dbshark passes the captured
  and original lengths to Wireshark; it cannot restore missing bytes.
* Stored rows are Wireshark's one-pass results. A request row already
  written is not revisited when its response arrives later.
* Wireshark 4.2.6 truncates some strings inside its own field creation
  path. The DNS TXT zero-byte regression demonstrates this. dbshark cannot
  recover a suffix absent from the field value without changing the
  dissector or replacing its interpretation of the packet.
* Wireshark frame numbers are 32-bit. At the last frame number dbshark
  rotates the session the same way ``-M`` does, replaying unfinished
  reassembly, instead of wrapping the frame number inside one session.
* A message larger than ``--reassembly-hold-mib``, or silent longer than
  ``--reassembly-idle-ms``, is expired. That loss is counted. It is not
  recovered by a later segment.
* Protocol time fields stored as floating-point seconds may lose precision;
  metadata timestamps have microsecond precision. This is the existing
  data-model choice, not nanosecond-exact archival storage.
* PostgreSQL locks, disk latency, JSON processing, late schema rewrites,
  and Wireshark conversation memory can dominate the small surrounding
  loops. Their cost remains visible in the end-to-end measurements.

Files to read when changing the program
=======================================

``src/dbshark.c``
    The complete ingest implementation. ``main`` initializes it;
    ``process_file`` and ``on_pkt`` supply input; ``process_packet`` ties
    together dissection, ``walk_node``, ``bucket_fi``, and row encoding.
    ``ensure_table_exists``, ``materialize_hit_columns``, and
    ``maybe_promote_bucket`` manage the schema. ``copy_flush_table``,
    ``maybe_flush``, and ``finish_txn`` manage database batches.

``tests/dbshark/compose/run.sh``
    Two-node live-capture race against one Postgres.

``bench/generate.py`` and ``bench/run.py``
    Deterministic packet fixtures and an end-to-end measurement runner.
    The runner counts actual stored rows and records process measurements.

``.github/workflows/dbshark-perf.yml``
    A reproducible Linux build of unchanged dependencies, baseline and
    current dbshark builds, correctness checks, and throughput measurements.

When making a change, preserve field occurrence order, exact binary cell
types, field-pointer lifetimes, and the rule that all rows from a completed
packet share the same transaction outcome. Treat a faster run with fewer
or altered required values as a correctness failure.
