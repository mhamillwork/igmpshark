"""Deterministic Ethernet/IP capture fixtures; standard library only."""
import argparse
import struct
from pathlib import Path


def checksum(data):
    data += b'\0' * (len(data) % 2)
    total = sum(struct.unpack('!' + 'H' * (len(data) // 2), data))
    while total >> 16:
        total = (total & 65535) + (total >> 16)
    return (~total) & 65535


def ethernet_ip(payload, ident=0, protocol=17, fragment=0, reverse=False):
    src, dst = b'\xc0\x00\x02\x01', b'\xc6\x33\x64\x02'
    if reverse:
        src, dst = dst, src
    ip = struct.pack('!BBHHHBBH4s4s', 0x45, 0, 20 + len(payload), ident & 65535,
                     fragment, 64, protocol, 0, src, dst)
    ip = ip[:10] + struct.pack('!H', checksum(ip)) + ip[12:]
    return bytes.fromhex('0200000000020200000000010800') + ip + payload


def udp(payload, port, source=40000):
    return struct.pack('!HHHH', source, port, len(payload) + 8, 0) + payload


def dis_fire(index=0):
    body = b''.join(struct.pack('!HHH', site, 100 + site, 1000 + site) for site in (1, 2, 3))
    body += struct.pack('!HHHI', 4, 104, index & 65535, index)
    body += struct.pack('!ddd', 1234567.0, 2345678.0, 3456789.0)
    body += struct.pack('!BBHBBBBHHHH', 2, 1, 225, 2, 3, 4, 0, 1000, 1000, 1, 0)
    body += struct.pack('!ffff', 100.0, 200.0, 300.0, 10000.0)
    payload = struct.pack('!BBBBIHH', 6, 1, 2, 2, index, len(body) + 12, 0) + body
    assert len(payload) == 96
    return ethernet_ip(udp(payload, 3000), index)


def dis_transmitter(index=0):
    values = (0, (1 << 63) - 1, 1 << 63, (1 << 64) - 1)
    body = struct.pack('!HHHH', 7, 107, 1007, 1)
    body += struct.pack('!BBHBBH', 7, 1, 225, 1, 0, 0)
    body += struct.pack('!BBHdddfffHHQffHHHHHHB3s', 2, 1, 0,
                        1.0, 2.0, 3.0, 0.0, 0.0, 0.0, 0, 0, values[index % 4],
                        1000.0, 1.0, 0, 0, 0, 0, 0, 0, 0, b'\0\0\0')
    assert len(body) == 92
    payload = struct.pack('!BBBBIHH', 6, 1, 25, 4, index, len(body) + 12, 0) + body
    return ethernet_ip(udp(payload, 3000), index)


def dns_payload(index=0, answers=24, escaped=False, embedded_nul=False):
    name = b'\x04load\x07example\x04test\0'
    header = struct.pack('!HHHHHH', index & 65535, 0x8180, 1, answers, 0, 0)
    query = name + struct.pack('!HH', 16, 1)
    records = []
    for n in range(answers):
        text = (f'answer-{n:02d}-' + 'abcdefghijklmnopqrstuvwxyz0123456789' * 2).encode()
        if escaped:
            text += b' "quoted" \\backslash\tTAB\nNEWLINE'
        if embedded_nul:
            text += b'\0SUFFIX_AFTER_NUL'
        value = bytes([len(text)]) + text
        records.append(b'\xc0\x0c' + struct.pack('!HHIH', 16, 1, 60, len(value)) + value)
    return header + query + b''.join(records)


def frames(workload, index):
    if workload == 'dns-delayed':
        if index == 0:
            data = dns_payload(42, answers=0)
            data = data[:2] + b'\x01\x00' + data[4:]
            return [ethernet_ip(udp(data, 53))]
        if index == 9001:
            return [ethernet_ip(udp(dns_payload(42, answers=1), 40000, source=53), reverse=True)]
        return [dis_fire(index)]
    if workload == 'dis-fire':
        return [dis_fire(index)]
    if workload == 'dis-uint64':
        return [dis_transmitter(index)]
    if workload == 'dis-mixed':
        return [dis_fire(index) if index % 2 == 0 else dis_transmitter(index)]
    if workload == 'dns-fragmented':
        data = udp(dns_payload(index, answers=4), 53)
        split = 160  # fragment offsets are in 8-byte units
        return [ethernet_ip(data[:split], index, fragment=0x2000),
                ethernet_ip(data[split:], index, fragment=split // 8)]
    if workload == 'dns-alternating':
        count = 1 if index % 2 == 0 else 3
    else:
        count = 24 if workload == 'dns-dense' else 3
    return [ethernet_ip(udp(dns_payload(index, count, workload == 'dns-escaped', workload == 'dns-nul'), 53,
                               source=0 if workload == 'dns-port-zero' else 40000), index)]


def generate(path, workload, packets):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    emitted = 0
    with path.open('wb') as out:
        out.write(struct.pack('<IHHIIII', 0xa1b2c3d4, 2, 4, 0, 0, 262144, 1))
        for index in range(packets):
            for frame in frames(workload, index):
                out.write(struct.pack('<IIII', 1800000000 + emitted // 1000000,
                                      emitted % 1000000, len(frame), len(frame)))
                out.write(frame)
                emitted += 1
    return emitted


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('--workload', default='dis-fire')
    parser.add_argument('--packets', type=int, default=100000)
    args = parser.parse_args()
    print(generate(args.output, args.workload, args.packets), 'frames')
