"""Measure one dbshark process, including startup, dissection, COPY and commit.

Creates and removes only a randomly named schema owned by this invocation.
The supplied database must be a disposable benchmark database.
"""
import argparse
import ctypes
import hashlib
import json
import os
import platform
import re
import statistics
import subprocess
import tempfile
import time
import uuid
from pathlib import Path

from generate import generate


def query(psql, dsn, sql):
    result = subprocess.run([str(psql), '-X', '-A', '-t', '-v', 'ON_ERROR_STOP=1',
                             '-d', dsn, '-c', sql], capture_output=True, text=True, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(result.stderr)
    return result.stdout.strip()


def measure(command, env):
    # GNU time reports usage for this child only, including peak RSS;
    # RUSAGE_CHILDREN's peak would include earlier benchmark children.
    usage_path = None
    if platform.system() == 'Linux' and Path('/usr/bin/time').exists():
        fd, usage_path = tempfile.mkstemp(prefix='dbshark-usage-')
        os.close(fd)
        command = ['/usr/bin/time', '-f', '%U %S %M', '-o', usage_path, *command]
    started = time.perf_counter()
    child = subprocess.Popen(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = child.communicate()
    elapsed = time.perf_counter() - started
    cpu_s = None
    cycles = None
    peak_working_set = None
    if os.name == 'nt':
        class FileTime(ctypes.Structure):
            _fields_ = [('low', ctypes.c_uint32), ('high', ctypes.c_uint32)]
        class MemoryCounters(ctypes.Structure):
            _fields_ = [('cb', ctypes.c_uint32), ('faults', ctypes.c_uint32),
                        ('peak_ws', ctypes.c_size_t), ('ws', ctypes.c_size_t),
                        ('peak_paged', ctypes.c_size_t), ('paged', ctypes.c_size_t),
                        ('peak_nonpaged', ctypes.c_size_t), ('nonpaged', ctypes.c_size_t),
                        ('pagefile', ctypes.c_size_t), ('peak_pagefile', ctypes.c_size_t)]
        handle = ctypes.c_void_p(int(child._handle))
        created, exited, kernel, user = (FileTime() for _ in range(4))
        if ctypes.windll.kernel32.GetProcessTimes(handle, ctypes.byref(created), ctypes.byref(exited), ctypes.byref(kernel), ctypes.byref(user)):
            cpu_s = (((kernel.high << 32) | kernel.low) + ((user.high << 32) | user.low)) / 1e7
        count = ctypes.c_ulonglong()
        if ctypes.windll.kernel32.QueryProcessCycleTime(handle, ctypes.byref(count)):
            cycles = count.value
        memory = MemoryCounters()
        memory.cb = ctypes.sizeof(memory)
        if ctypes.windll.psapi.GetProcessMemoryInfo(handle, ctypes.byref(memory), memory.cb):
            peak_working_set = memory.peak_ws
    elif usage_path:
        values = Path(usage_path).read_text().splitlines()[-1].split()
        if len(values) == 3:
            cpu_s = float(values[0]) + float(values[1])
            peak_working_set = int(values[2]) * 1024
        Path(usage_path).unlink()
    return {'exit_code': child.returncode, 'wall_seconds': elapsed, 'cpu_seconds': cpu_s,
            'scheduled_cpu_cycles': cycles, 'peak_working_set_bytes': peak_working_set,
            'stderr': err.decode('utf-8', errors='replace'), 'stdout': out.decode('utf-8', errors='replace')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', required=True, type=Path)
    parser.add_argument('--psql', default='psql')
    parser.add_argument('--dsn', default=os.getenv('DATABASE_URL'))
    parser.add_argument('--workload', default='dis-fire', choices=['dis-fire', 'dns-dense'])
    parser.add_argument('--packets', type=int, default=100000)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--extra-arg', action='append', default=[])
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if not args.dsn or args.packets < 1 or args.repeats < 1:
        parser.error('a disposable --dsn and positive packet/repeat counts are required')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    capture = args.output.parent / (args.workload + '.pcap')
    warm = args.output.parent / (args.workload + '-warm.pcap')
    count = generate(capture, args.workload, args.packets)
    generate(warm, args.workload, 32)
    schema = 'dbshark_bench_' + uuid.uuid4().hex
    proto = 'dis' if args.workload.startswith('dis') else 'dns'
    env = os.environ.copy()
    env['PGOPTIONS'] = (env.get('PGOPTIONS', '') + f' -c search_path={schema}').strip()
    command = [str(args.binary.resolve()), '-r', str(capture.resolve()), '-o', args.dsn,
               '-p', proto, *args.extra_arg]
    result = {'platform': platform.platform(), 'machine': platform.machine(),
              'binary': args.binary.name, 'binary_sha256': hashlib.file_digest(args.binary.open('rb'), 'sha256').hexdigest(),
              'workload': args.workload, 'frames': count, 'pcap_bytes': capture.stat().st_size,
              'pcap_sha256': hashlib.file_digest(capture.open('rb'), 'sha256').hexdigest(),
              'extra_args': args.extra_arg, 'definition': 'one dbshark process; full process wall time including startup and final commit; PostgreSQL is a separate server',
              'postgres_version': query(args.psql, args.dsn, 'SHOW server_version'), 'runs': []}
    query(args.psql, args.dsn, f'CREATE SCHEMA {schema}')
    try:
        warm_command = command.copy()
        warm_command[2] = str(warm.resolve())
        result['warmup'] = measure(warm_command, env)
        if result['warmup']['exit_code']:
            raise RuntimeError(result['warmup']['stderr'])
        names = query(args.psql, args.dsn, f"SELECT tablename FROM pg_tables WHERE schemaname='{schema}' ORDER BY tablename").splitlines()
        if not names:
            raise RuntimeError('no tables/rows were written during warmup')
        truncate = 'TRUNCATE ' + ','.join(f'{schema}."{name}"' for name in names)
        for _ in range(args.repeats):
            query(args.psql, args.dsn, truncate)
            run = measure(command, env)
            run['frames_per_second'] = count / run['wall_seconds']
            run['scheduled_cycles_per_frame'] = run['scheduled_cpu_cycles'] / count if run['scheduled_cpu_cycles'] else None
            run['row_counts'] = {name: int(query(args.psql, args.dsn, f'SELECT count(*) FROM {schema}."{name}"')) for name in names}
            result['runs'].append(run)
            if run['exit_code'] or run['row_counts'].get(proto) != count:
                raise RuntimeError('ingestion failed or anchor table row count does not match input: ' + run['stderr'])
            print(f'{args.binary.name} {args.workload}: {run["frames_per_second"]:.2f} frames/s; {sum(run["row_counts"].values())} rows', flush=True)
        result['median_frames_per_second'] = statistics.median(run['frames_per_second'] for run in result['runs'])
    except Exception as exc:
        result['error'] = str(exc)
        raise
    finally:
        args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
        query(args.psql, args.dsn, f'DROP SCHEMA {schema} CASCADE')


if __name__ == '__main__':
    main()
