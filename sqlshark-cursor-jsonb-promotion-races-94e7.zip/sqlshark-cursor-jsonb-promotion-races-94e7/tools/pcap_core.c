#ifndef _WIN32
#define _GNU_SOURCE
#endif
#include "pcap_core.h"

#include <ctype.h>
#include <inttypes.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#ifdef _WIN32
#include <io.h>
#include <windows.h>
#define pcap_isatty(fd) _isatty(fd)
#ifndef STDERR_FILENO
#define STDERR_FILENO 2
#endif
#else
#include <unistd.h>
#define pcap_isatty(fd) isatty(fd)
#endif

#include <epan/epan.h>
#include <epan/epan_dissect.h>
#include <epan/prefs.h>
#include <epan/tvbuff.h>
#include <epan/address.h>
#include <epan/to_str.h>
#include <epan/register.h>
#include <epan/wmem_scopes.h>
#include <epan/ftypes/ftypes.h>
#include <wiretap/wtap.h>
#include <wsutil/buffer.h>
#include <wsutil/filesystem.h>
#include <wsutil/privileges.h>
#include <wsutil/wslog.h>

#ifdef __GNUC__
#define NOINLINE __attribute__((noinline))
#else
#define NOINLINE
#endif

/*
 * Subtable = one dbshark Postgres table = one SQLite table = one HDF5
 * group. fields[] is the registrar map built at startup (every persist
 * field of -p). in_sink is 0 until that column is first *seen* in a
 * packet, then the sink ADD COLUMNs it. That is the format contract:
 * unused Wireshark fields never appear in the output file.
 */
typedef struct {
    const char  *proto_name;
    int          proto_id;
    char        *table_name;
    field_col_t *fields;
    size_t       n;
    size_t       n_sink;
    int          opened;
    unsigned     pkt_epoch;
} subtable_t;

typedef struct {
    subtable_t  *st;
    field_col_t *fc;
} hf_bind_t;

typedef struct {
    const char *name;
    int         id;
} proto_cfg_t;

typedef struct {
    GPtrArray  *fields;
    GHashTable *col_map;
} tbl_build_t;

typedef struct {
    GArray *hf;
    int     ft;
    char   *col;
} field_build_t;

static epan_t         *sess;
static epan_dissect_t *edt;
static subtable_t     *tables;
static size_t          n_tables;
static hf_bind_t     **hf_arr;
static int             hf_arr_n;
static int            *prime_ids;
static size_t          n_prime_ids;
static unsigned        pkt_epoch;
static proto_cfg_t    *protos;
static size_t          n_protos;
static guint32         fno;
static int             split_depth = 2;
static int             log_level = PCAP_LOG_INFO;
static volatile sig_atomic_t stop_loop;
static int             file_subtype = WTAP_FILE_TYPE_SUBTYPE_UNKNOWN;
static GString        *json_scratch;
static subtable_t     *live_tables[PCAP_MAX_TABLES];
static size_t          n_live;
static uint8_t        *keep_walk;
static uint8_t        *persist_proto;
static int             proto_flag_n;
static nstime_t        ts_ring[PCAP_TS_HIST_CAP];
static pcap_sink_t     sink;
static int             did_wtap;
static int             did_epan;
static int             ingest_ok = 1;
static guint64         stat_pkts;
static guint64         stat_matched;
static guint64         stat_rows;
static guint64         stat_promotes;
static guint64         stat_errors;
static int64_t         last_flush_mono_us;
static size_t          pending_hint_bytes;

static int             progress_on = 1;
static int             progress_bar_live;
static int64_t         progress_file_size;
static int64_t         progress_t0_us;
static int             progress_last_pct = -1;
static int             progress_last_milestone = -1;
static guint64         progress_pkts;
static int64_t         progress_last_draw_us;
#define PROGRESS_BAR_WIDTH 40
#define PROGRESS_MIN_INTERVAL_US 250000

static const char HEX[] = "0123456789abcdef";

static void proto_flag_ensure(int id);
static int  proto_flag_get(const uint8_t *arr, int id);
static void prime_all_hfids(void);

static void progress_clear_bar(void);

void pcap_core_log(int lvl, const char *fmt, ...) {
    static const char *tag[] = { "ERROR", "WARN", "INFO", "DEBUG" };
    if (lvl > log_level)
        return;
    if (lvl <= PCAP_LOG_ERROR)
        stat_errors++;
    progress_clear_bar();
    GDateTime *now = g_date_time_new_now_utc();
    gchar *iso = now ? g_date_time_format(now, "%Y-%m-%dT%H:%M:%SZ") : NULL;
    fprintf(stderr, "pcap-core %s %-5s ", iso ? iso : "-", tag[lvl]);
    g_free(iso);
    if (now)
        g_date_time_unref(now);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
}

static void vcmdarg_err(const char *fmt, va_list ap) {
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
}

static void on_sig(int s) {
    (void)s;
    stop_loop = 1;
}

#ifdef _WIN32
static BOOL WINAPI on_console(DWORD ev) {
    if (ev == CTRL_C_EVENT || ev == CTRL_BREAK_EVENT || ev == CTRL_CLOSE_EVENT) {
        on_sig(SIGINT);
        return TRUE;
    }
    return FALSE;
}
#endif

static void progress_clear_bar(void) {
    if (!progress_bar_live)
        return;
    if (pcap_isatty(STDERR_FILENO))
        fprintf(stderr, "\r%*s\r", 96, "");
    progress_bar_live = 0;
}

static void progress_init(wtap *wth) {
    int err = 0;
    progress_file_size = wtap_file_size(wth, &err);
    if (progress_file_size <= 0)
        progress_file_size = 0;
    progress_last_pct = -1;
    progress_last_milestone = -1;
    progress_pkts = 0;
    progress_last_draw_us = 0;
    progress_bar_live = 0;
    progress_t0_us = g_get_monotonic_time();
}

static void progress_draw(int64_t data_offset, int done) {
    if (!progress_on)
        return;
    /* Clock + fprintf are not free. 32-packet stride still looks smooth
     * next to the 250 ms throttle below. */
    if (!done && (progress_pkts & 31) != 0)
        return;
    int pct = -1;
    if (progress_file_size > 0) {
        pct = (int)((data_offset * 100) / progress_file_size);
        if (pct > 100)
            pct = 100;
    }
    int64_t now = g_get_monotonic_time();
    if (!done && pct >= 0 && pct == progress_last_pct &&
        (now - progress_last_draw_us) < PROGRESS_MIN_INTERVAL_US)
        return;
    progress_last_draw_us = now;
    if (pct >= 0)
        progress_last_pct = pct;

    int64_t elapsed = now - progress_t0_us;
    double pps = (elapsed > 0) ? (progress_pkts * 1e6 / (double)elapsed) : 0;
    int eta_s = -1;
    if (pct > 0 && pct < 100 && elapsed > 0)
        eta_s = (int)((elapsed * (100.0 - pct) / (double)pct) / 1e6);

    if (pcap_isatty(STDERR_FILENO)) {
        fprintf(stderr, "\r");
        if (pct >= 0) {
            int filled = (pct * PROGRESS_BAR_WIDTH) / 100;
            fputc('[', stderr);
            for (int i = 0; i < PROGRESS_BAR_WIDTH; i++)
                fputc(i < filled ? '=' : ' ', stderr);
            fprintf(stderr, "] %3d%%  ", pct);
        }
        fprintf(stderr, "%" PRIu64 " pkts  %" PRIu64 " rows  %.0f pkt/s",
                progress_pkts, stat_rows, pps);
        if (eta_s >= 0)
            fprintf(stderr, "  ETA %ds", eta_s);
        fprintf(stderr, "   ");
        if (done) {
            fputc('\n', stderr);
            progress_bar_live = 0;
        } else {
            progress_bar_live = 1;
        }
        fflush(stderr);
        return;
    }
    if (pct < 0) {
        if (done)
            fprintf(stderr, "done: %" PRIu64 " pkts  %" PRIu64 " rows  %.0f pkt/s\n",
                    progress_pkts, stat_rows, pps);
        return;
    }
    int milestone = (pct / 10) * 10;
    if (done)
        milestone = 100;
    if (milestone > progress_last_milestone) {
        fprintf(stderr, "progress: %3d%%  %" PRIu64 " pkts  %" PRIu64 " rows  %.0f pkt/s\n",
                milestone, progress_pkts, stat_rows, pps);
        progress_last_milestone = milestone;
    }
}

const char *ft2sql_name(int t) {
    switch (t) {
    case FT_NONE: case FT_PROTOCOL: return NULL;
    case FT_BOOLEAN: case FT_CHAR:
    case FT_UINT8: case FT_UINT16: case FT_UINT24: case FT_UINT32:
    case FT_UINT40: case FT_UINT48: case FT_UINT56: case FT_UINT64:
    case FT_INT8:  case FT_INT16:  case FT_INT24:  case FT_INT32:
    case FT_INT40: case FT_INT48:  case FT_INT56:  case FT_INT64:
    case FT_FRAMENUM:                             return "INTEGER";
    case FT_FLOAT: case FT_DOUBLE:
    case FT_ABSOLUTE_TIME: case FT_RELATIVE_TIME: return "REAL";
    case FT_BYTES: case FT_UINT_BYTES:            return "BLOB";
    default:                                      return "TEXT";
    }
}

void append_u64(GString *b, uint64_t v) {
    char tmp[24];
    char *p = tmp + sizeof tmp;
    if (v == 0) {
        g_string_append_c(b, '0');
        return;
    }
    while (v) {
        *--p = (char)('0' + (v % 10));
        v /= 10;
    }
    g_string_append_len(b, p, (gssize)((tmp + sizeof tmp) - p));
}

void append_i64(GString *b, int64_t v) {
    if (v < 0) {
        g_string_append_c(b, '-');
        append_u64(b, (uint64_t)(-(v + 1)) + 1);
        return;
    }
    append_u64(b, (uint64_t)v);
}

void append_hex(GString *b, const uint8_t *p, size_t n) {
    gsize need = b->len + n * 2 + 1;
    if (need > b->allocated_len) {
        gsize old = b->len;
        g_string_set_size(b, need);
        g_string_truncate(b, old);
    }
    char *d = b->str + b->len;
    for (size_t i = 0; i < n; i++) {
        d[i * 2]     = HEX[p[i] >> 4];
        d[i * 2 + 1] = HEX[p[i] & 15];
    }
    b->len += n * 2;
    b->str[b->len] = 0;
}

static char *san_trunc(const char *s) {
    size_t n = strlen(s);
    char *o = malloc(n + 2);
    size_t j = 0;
    if (!o)
        return NULL;
    if (!isalpha((unsigned char)s[0]) && s[0] != '_')
        o[j++] = '_';
    for (size_t i = 0; i < n && j < PCAP_MAX_IDENT; i++) {
        unsigned char c = s[i];
        o[j++] = (isalnum(c) || c == '_') ? (char)tolower(c) : '_';
    }
    o[j] = 0;
    return o;
}

static char *join_parts(char **parts, int from, int to) {
    GString *g = g_string_new(NULL);
    for (int i = from; i < to; i++) {
        if (i > from)
            g_string_append_c(g, '_');
        g_string_append(g, parts[i]);
    }
    return g_string_free(g, FALSE);
}

static void table_and_column(const char *abbrev, const char *proto_name,
                             char **tbl_out, char **col_out) {
    gchar **parts = g_strsplit(abbrev, ".", -1);
    int n = (int)g_strv_length(parts);
    char *joined;
    char *tbl = NULL;
    char *col = NULL;

    if (n <= 1) {
        tbl = san_trunc(proto_name);
        col = san_trunc(parts[0] ? parts[0] : "field");
    } else if (n <= split_depth) {
        tbl = san_trunc(parts[0]);
        joined = join_parts(parts, 1, n);
        col = san_trunc(joined);
        g_free(joined);
    } else {
        joined = join_parts(parts, 0, split_depth);
        tbl = san_trunc(joined);
        g_free(joined);
        joined = join_parts(parts, split_depth, n);
        col = san_trunc(joined);
        g_free(joined);
    }
    g_strfreev(parts);
    *tbl_out = tbl;
    *col_out = col;
}

static const nstime_t *prov_ts(struct packet_provider_data *p, guint32 num) {
    (void)p;
    if (num == 0 || num > fno)
        return NULL;
    if (fno - num >= (guint32)PCAP_TS_HIST_CAP)
        return NULL;
    return &ts_ring[(num - 1) % PCAP_TS_HIST_CAP];
}

static wtap_block_t prov_mbk(struct packet_provider_data *p, const frame_data *f) {
    (void)p;
    (void)f;
    return NULL;
}

static const struct packet_provider_funcs g_prov = {
    .get_frame_ts       = prov_ts,
    .get_modified_block = prov_mbk,
};

int field_hit(const field_col_t *fc) {
    return fc->epoch == pkt_epoch && fc->n_hit > 0;
}

field_info *fc_fi(const field_col_t *fc, unsigned i) {
    if (i < PCAP_HIT_INLINE)
        return fc->hit[i];
    return fc->extra[i - PCAP_HIT_INLINE];
}

int fi_int64(field_info *fi, int64_t *out) {
    if (!fi || !fi->hfinfo || !fi->value)
        return 0;
    fvalue_t *fv = fi->value;
    switch ((int)fi->hfinfo->type) {
    case FT_BOOLEAN:
        *out = fvalue_get_uinteger64(fv) ? 1 : 0; return 1;
    case FT_CHAR:
    case FT_UINT8: case FT_UINT16: case FT_UINT24: case FT_UINT32:
    case FT_FRAMENUM:
        *out = fvalue_get_uinteger(fv); return 1;
    case FT_UINT40: case FT_UINT48: case FT_UINT56: case FT_UINT64:
        *out = (int64_t)fvalue_get_uinteger64(fv); return 1;
    case FT_INT8: case FT_INT16: case FT_INT24: case FT_INT32:
        *out = fvalue_get_sinteger(fv); return 1;
    case FT_INT40: case FT_INT48: case FT_INT56: case FT_INT64:
        *out = fvalue_get_sinteger64(fv); return 1;
    default:
        return 0;
    }
}

int fi_double(field_info *fi, double *out) {
    if (!fi || !fi->hfinfo || !fi->value)
        return 0;
    fvalue_t *fv = fi->value;
    switch ((int)fi->hfinfo->type) {
    case FT_FLOAT: case FT_DOUBLE: {
        double d = fvalue_get_floating(fv);
        if (!isfinite(d))
            return 0;
        *out = d;
        return 1;
    }
    case FT_ABSOLUTE_TIME: case FT_RELATIVE_TIME: {
        const nstime_t *t = fvalue_get_time(fv);
        if (!t)
            return 0;
        *out = (double)t->secs + t->nsecs / 1e9;
        return 1;
    }
    default:
        return 0;
    }
}

static void json_str(GString *out, const char *s) {
    g_string_append_c(out, '"');
    for (const char *p = s; *p; p++) {
        unsigned char c = (unsigned char)*p;
        switch (c) {
        case '"':  g_string_append_len(out, "\\\"", 2); break;
        case '\\': g_string_append_len(out, "\\\\", 2); break;
        case '\b': g_string_append_len(out, "\\b", 2);  break;
        case '\f': g_string_append_len(out, "\\f", 2);  break;
        case '\n': g_string_append_len(out, "\\n", 2);  break;
        case '\r': g_string_append_len(out, "\\r", 2);  break;
        case '\t': g_string_append_len(out, "\\t", 2);  break;
        default:
            if (c < 0x20) g_string_append_printf(out, "\\u%04x", c);
            else          g_string_append_c(out, *p);
        }
    }
    g_string_append_c(out, '"');
}

void json_append_fi(GString *out, field_info *fi) {
    if (!fi || !fi->hfinfo) { g_string_append(out, "null"); return; }
    fvalue_t *fv = fi->value;
    switch ((int)fi->hfinfo->type) {
    case FT_BOOLEAN:
        g_string_append(out, fvalue_get_uinteger64(fv) ? "true" : "false"); return;
    case FT_CHAR:
    case FT_UINT8: case FT_UINT16: case FT_UINT24: case FT_UINT32:
    case FT_FRAMENUM:
        append_u64(out, fvalue_get_uinteger(fv)); return;
    case FT_UINT40: case FT_UINT48: case FT_UINT56: case FT_UINT64:
        append_u64(out, fvalue_get_uinteger64(fv)); return;
    case FT_INT8: case FT_INT16: case FT_INT24: case FT_INT32:
        append_i64(out, fvalue_get_sinteger(fv)); return;
    case FT_INT40: case FT_INT48: case FT_INT56: case FT_INT64:
        append_i64(out, fvalue_get_sinteger64(fv)); return;
    case FT_FLOAT: case FT_DOUBLE: {
        double d = fvalue_get_floating(fv);
        if (!isfinite(d)) { g_string_append(out, "null"); return; }
        g_string_append_printf(out, "%.17g", d); return;
    }
    case FT_ABSOLUTE_TIME: case FT_RELATIVE_TIME: {
        const nstime_t *t = fvalue_get_time(fv);
        if (!t) { g_string_append(out, "null"); return; }
        g_string_append_printf(out, "%.9f", (double)t->secs + t->nsecs / 1e9); return;
    }
    case FT_BYTES: case FT_UINT_BYTES: {
        const uint8_t *data = fvalue_get_bytes_data(fv);
        size_t sz = fvalue_get_bytes_size(fv);
        if (!data) { g_string_append(out, "null"); return; }
        g_string_append_c(out, '"');
        append_hex(out, data, sz);
        g_string_append_c(out, '"'); return;
    }
    case FT_STRING: case FT_STRINGZ: case FT_UINT_STRING:
    case FT_STRINGZPAD: case FT_STRINGZTRUNC: {
        const char *s = fvalue_get_string(fv);
        if (!s) g_string_append(out, "null"); else json_str(out, s);
        return;
    }
    default: {
        char *r = fvalue_to_string_repr(NULL, fv, FTREPR_DISPLAY, BASE_NONE);
        if (!r) g_string_append(out, "null"); else { json_str(out, r); g_free(r); }
        return;
    }
    }
}

void write_json_cell(GString *dst, field_col_t *fc) {
    g_string_truncate(json_scratch, 0);
    if (fc->n_hit == 1) {
        json_append_fi(json_scratch, fc_fi(fc, 0));
    } else {
        g_string_append_c(json_scratch, '[');
        for (unsigned i = 0; i < fc->n_hit; i++) {
            if (i)
                g_string_append_c(json_scratch, ',');
            json_append_fi(json_scratch, fc_fi(fc, i));
        }
        g_string_append_c(json_scratch, ']');
    }
    g_string_append_len(dst, json_scratch->str, json_scratch->len);
    /* One huge hex-blob cell can leave a multi-MB GString. Recreate after
     * the copy so the next packet does not keep that high-water mark.
     * g_string_set_size does not shrink allocated_len. */
    if (json_scratch->allocated_len > (1u << 20)) {
        g_string_free(json_scratch, TRUE);
        json_scratch = g_string_sized_new(256);
    }
}

static void hf_arr_set(int id, hf_bind_t *b) {
    if (id < 0)
        return;
    if (id >= hf_arr_n) {
        int n = hf_arr_n ? hf_arr_n : 8192;
        while (n <= id)
            n *= 2;
        hf_bind_t **p = realloc(hf_arr, (size_t)n * sizeof(*p));
        if (!p)
            return;
        memset(p + hf_arr_n, 0, (size_t)(n - hf_arr_n) * sizeof(*p));
        hf_arr = p;
        hf_arr_n = n;
    }
    hf_arr[id] = b;
    int *p = realloc(prime_ids, (n_prime_ids + 1) * sizeof(*p));
    if (p) {
        prime_ids = p;
        prime_ids[n_prime_ids++] = id;
    }
}

static void hf_map_add(subtable_t *st, field_col_t *fc) {
    for (size_t i = 0; i < fc->n_hf; i++) {
        hf_bind_t *b = g_malloc(sizeof(*b));
        b->st = st;
        b->fc = fc;
        hf_arr_set(fc->hf[i], b);
    }
}

static int build_tables_for_proto(const char *name, int proto_id) {
    GHashTable *buckets = g_hash_table_new_full(g_str_hash, g_str_equal, g_free, NULL);
    GHashTable *hf_seen = g_hash_table_new(g_direct_hash, g_direct_equal);
    void *ck = NULL;
    header_field_info *h;

    for (h = proto_get_first_protocol_field(proto_id, &ck); h;
         h = proto_get_next_protocol_field(proto_id, &ck)) {
        if (!h->abbrev || !ft2sql_name(h->type))
            continue;
        if (g_hash_table_contains(hf_seen, GINT_TO_POINTER(h->id)))
            continue;
        g_hash_table_add(hf_seen, GINT_TO_POINTER(h->id));

        char *tbl = NULL, *col = NULL;
        table_and_column(h->abbrev, name, &tbl, &col);
        if (!tbl || !col) {
            g_free(tbl);
            g_free(col);
            continue;
        }

        tbl_build_t *tb = g_hash_table_lookup(buckets, tbl);
        if (!tb) {
            tb = g_malloc0(sizeof(tbl_build_t));
            tb->fields = g_ptr_array_new();
            tb->col_map = g_hash_table_new(g_str_hash, g_str_equal);
            g_hash_table_insert(buckets, tbl, tb);
            tbl = NULL;
        } else {
            g_free(tbl);
        }

        field_build_t *fb = g_hash_table_lookup(tb->col_map, col);
        if (fb) {
            int id = h->id;
            g_array_append_val(fb->hf, id);
            g_free(col);
            continue;
        }

        fb = g_malloc0(sizeof(field_build_t));
        fb->hf = g_array_new(FALSE, FALSE, sizeof(int));
        int id = h->id;
        g_array_append_val(fb->hf, id);
        fb->ft = h->type;
        fb->col = col;
        g_ptr_array_add(tb->fields, fb);
        g_hash_table_insert(tb->col_map, fb->col, fb);
    }
    g_hash_table_destroy(hf_seen);

    size_t before = n_tables;
    GHashTableIter it;
    gpointer tkey, tval;
    g_hash_table_iter_init(&it, buckets);
    while (g_hash_table_iter_next(&it, &tkey, &tval)) {
        const char *table_name = tkey;
        tbl_build_t *tb = tval;
        size_t n = tb->fields->len;
        if (n == 0) {
            g_hash_table_destroy(tb->col_map);
            g_ptr_array_free(tb->fields, TRUE);
            g_free(tb);
            g_hash_table_iter_replace(&it, NULL);
            continue;
        }
        if (n_tables >= PCAP_MAX_TABLES) {
            pcap_core_log(PCAP_LOG_ERROR, "too many sub-tables (max %d)", PCAP_MAX_TABLES);
            GHashTableIter it2;
            gpointer k2, v2;
            g_hash_table_iter_init(&it2, buckets);
            while (g_hash_table_iter_next(&it2, &k2, &v2)) {
                tbl_build_t *left = v2;
                if (!left)
                    continue;
                for (guint fi = 0; fi < left->fields->len; fi++) {
                    field_build_t *fb = g_ptr_array_index(left->fields, fi);
                    if (fb->hf)
                        g_array_free(fb->hf, TRUE);
                    g_free(fb->col);
                    g_free(fb);
                }
                g_hash_table_destroy(left->col_map);
                g_ptr_array_free(left->fields, TRUE);
                g_free(left);
            }
            g_hash_table_destroy(buckets);
            return 0;
        }

        subtable_t *st = &tables[n_tables++];
        st->proto_name = name;
        st->proto_id = proto_id;
        st->table_name = g_strdup(table_name);
        st->n = n;
        st->n_sink = 0;
        st->opened = 0;
        st->pkt_epoch = 0;
        st->fields = g_malloc0(n * sizeof(field_col_t));
        for (size_t i = 0; i < n; i++) {
            field_build_t *fb = g_ptr_array_index(tb->fields, i);
            st->fields[i].n_hf = fb->hf->len;
            st->fields[i].hf = (int *)g_array_free(fb->hf, FALSE);
            st->fields[i].ft = (uint8_t)fb->ft;
            st->fields[i].col = fb->col;
            hf_map_add(st, &st->fields[i]);
            g_free(fb);
        }
        g_hash_table_destroy(tb->col_map);
        g_ptr_array_free(tb->fields, TRUE);
        g_free(tb);
        g_hash_table_iter_replace(&it, NULL);
    }
    g_hash_table_destroy(buckets);
    pcap_core_log(PCAP_LOG_INFO, "[%s] %zu subtables registered (columns added on first use)",
                  name, n_tables - before);
    return 1;
}

static int NOINLINE ensure_table(subtable_t *st) {
    if (st->opened)
        return 1;
    if (sink.open_table && sink.open_table(sink.ctx, st->table_name) != 0) {
        ingest_ok = 0;
        return 0;
    }
    st->opened = 1;
    return 1;
}

static int NOINLINE materialize_hit_columns(subtable_t *st) {
    if (!ensure_table(st))
        return 0;
    int adding = 0;
    for (size_t i = 0; i < st->n; i++) {
        if (!st->fields[i].in_sink && field_hit(&st->fields[i])) {
            adding = 1;
            break;
        }
    }
    if (!adding)
        return 1;
    if (sink.flush && sink.flush(sink.ctx) != 0)
        return 0;
    for (size_t i = 0; i < st->n; i++) {
        field_col_t *fc = &st->fields[i];
        if (fc->in_sink || !field_hit(fc))
            continue;
        if (st->n_sink >= PCAP_MAX_COLS_PER_TABLE) {
            pcap_core_log(PCAP_LOG_WARN, "[%s] column limit %d reached, skipping %s",
                          st->table_name, PCAP_MAX_COLS_PER_TABLE, fc->col);
            continue;
        }
        if (!ft2sql_name(fc->ft))
            continue;
        if (sink.add_column && sink.add_column(sink.ctx, st->table_name, fc->col, fc->ft) != 0)
            return 0;
        fc->in_sink = 1;
        st->n_sink++;
        pcap_core_log(PCAP_LOG_INFO, "adding column \"%s\".\"%s\"", st->table_name, fc->col);
    }
    return 1;
}

static int NOINLINE maybe_promote_bucket(subtable_t *st) {
    int flushed = 0;
    for (size_t i = 0; i < st->n; i++) {
        if (!st->fields[i].in_sink || st->fields[i].is_json)
            continue;
        if (!field_hit(&st->fields[i]) || st->fields[i].n_hit <= 1)
            continue;
        if (!flushed) {
            if (sink.flush && sink.flush(sink.ctx) != 0)
                return 0;
            flushed = 1;
        }
        pcap_core_log(PCAP_LOG_INFO, "[%s] promoting \"%s\" to JSON (repeated field)",
                      st->table_name, st->fields[i].col);
        if (sink.promote_json &&
            sink.promote_json(sink.ctx, st->table_name, st->fields[i].col) != 0)
            return 0;
        st->fields[i].is_json = 1;
        stat_promotes++;
    }
    return 1;
}

static void bucket_fi(hf_bind_t *b, field_info *fi) {
    field_col_t *fc = b->fc;
    subtable_t *st = b->st;
    if (fc->epoch != pkt_epoch) {
        fc->epoch = pkt_epoch;
        fc->n_hit = 0;
        fc->extra_n = 0;
    }
    if (st->pkt_epoch != pkt_epoch) {
        st->pkt_epoch = pkt_epoch;
        if (n_live < PCAP_MAX_TABLES)
            live_tables[n_live++] = st;
    }
    /* uint16 n_hit: refuse to wrap. Extra[] is reused across packets so a
     * one-packet flood cannot grow it forever past 64k-4 pointers. */
    if (fc->n_hit == 0xffff)
        return;
    if (fc->n_hit < PCAP_HIT_INLINE) {
        fc->hit[fc->n_hit] = fi;
    } else {
        uint16_t ei = (uint16_t)(fc->n_hit - PCAP_HIT_INLINE);
        if (ei >= fc->extra_cap) {
            unsigned cap = fc->extra_cap ? (unsigned)fc->extra_cap * 2 : 8;
            if (cap > 0xffff)
                cap = 0xffff;
            if (ei >= cap)
                return;
            field_info **p = realloc(fc->extra, cap * sizeof(*p));
            if (!p)
                return;
            fc->extra = p;
            fc->extra_cap = (uint16_t)cap;
        }
        fc->extra[ei] = fi;
        fc->extra_n = (uint16_t)(ei + 1);
    }
    fc->n_hit++;
}

/*
 * Same walk as dbshark:
 *   FT_PROTOCOL in keep_walk  → recurse (path to DIS / -p)
 *   other FT_PROTOCOL         → skip the whole subtree
 *   in_persist                → hf_arr[] + recurse children (bitfields)
 *   L2/L4 leaves              → never load field_info / 240-byte GUI labels
 * With a hidden tree, unprimed L2/L4 items are often siblings of the
 * protocol nodes (TRY_TO_FAKE returns the parent), so frame/eth/ip/udp
 * may have no children — even better.
 */
static void walk_node(proto_node *node, int in_persist) {
    for (; node; node = node->next) {
        field_info *fi = node->finfo;
        if (!fi || !fi->hfinfo) {
            if (node->first_child)
                walk_node(node->first_child, in_persist);
            continue;
        }
        header_field_info *hfi = fi->hfinfo;
        if (hfi->type == FT_PROTOCOL) {
            int pid = hfi->id;
            int keep = proto_flag_get(keep_walk, pid);
            int next = proto_flag_get(persist_proto, pid);
            if (!keep && hfi->abbrev) {
                int id = proto_get_id_by_filter_name(hfi->abbrev);
                keep = proto_flag_get(keep_walk, id);
                if (keep)
                    next = proto_flag_get(persist_proto, id);
            }
            if (!keep)
                continue;
            if (node->first_child)
                walk_node(node->first_child, next);
            continue;
        }
        if (!in_persist)
            continue;
        int id = hfi->id;
        if ((unsigned)id < (unsigned)hf_arr_n) {
            hf_bind_t *b = hf_arr[id];
            if (b)
                bucket_fi(b, fi);
        }
        if (node->first_child)
            walk_node(node->first_child, 1);
    }
}

static void maybe_flush(void) {
    if (pending_hint_bytes < PCAP_FLUSH_EVERY_BYTES) {
        if ((stat_pkts & 255) != 0)
            return;
        int64_t now = g_get_monotonic_time();
        if (now - last_flush_mono_us < PCAP_FLUSH_EVERY_US)
            return;
    }
    if (sink.flush && sink.flush(sink.ctx) != 0) {
        ingest_ok = 0;
        stop_loop = 1;
    }
    pending_hint_bytes = 0;
    last_flush_mono_us = g_get_monotonic_time();
}

static void process_packet(wtap_rec *r, Buffer *buf, int64_t ts_us, int packet_len,
                           int64_t file_offset) {
    if (!r || !buf || !edt)
        return;
    guint32 caplen = r->rec_header.packet_header.caplen;
    if (caplen == 0 || ws_buffer_length(buf) < caplen) {
        pcap_core_log(PCAP_LOG_WARN,
                      "skipping packet with empty or short capture buffer (caplen=%u)",
                      caplen);
        return;
    }

    frame_data fd;
    frame_data_init(&fd, ++fno, r, file_offset, 0);
    ts_ring[(fno - 1) % PCAP_TS_HIST_CAP] = fd.abs_ts;
    stat_pkts++;
    progress_pkts++;

    prime_all_hfids();
    epan_dissect_run(edt, file_subtype, r,
                     tvb_new_real_data(ws_buffer_start_ptr(buf), caplen,
                                       r->rec_header.packet_header.len),
                     &fd, NULL);

    packet_info *pi = &edt->pi;
    uint8_t seen[32];
    int any_proto = 0;
    for (size_t p = 0; p < n_protos; p++) {
        seen[p] = (uint8_t)(pi->layers && proto_is_frame_protocol(pi->layers, protos[p].name));
        any_proto |= seen[p];
    }
    if (!any_proto || !edt->tree || !hf_arr) {
        maybe_flush();
        progress_draw(file_offset, 0);
        epan_dissect_reset(edt);
        frame_data_destroy(&fd);
        return;
    }

    n_live = 0;
    pkt_epoch++;
    if (pkt_epoch == 0)
        pkt_epoch = 1;
    walk_node(edt->tree->first_child, 0);

    char src_buf[64], dst_buf[64];
    pcap_meta_t meta;
    meta.ts_us = ts_us;
    meta.src_ip = NULL;
    meta.dst_ip = NULL;
    meta.src_port = pi->srcport;
    meta.dst_port = pi->destport;
    meta.frame_len = packet_len;
    if (pi->net_src.type) {
        address_to_str_buf(&pi->net_src, src_buf, sizeof src_buf);
        meta.src_ip = src_buf;
    }
    if (pi->net_dst.type) {
        address_to_str_buf(&pi->net_dst, dst_buf, sizeof dst_buf);
        meta.dst_ip = dst_buf;
    }

    for (size_t p = 0; p < n_protos; p++) {
        if (!seen[p])
            continue;
        stat_matched++;
        for (size_t t = 0; t < n_live; t++) {
            if (live_tables[t]->proto_id != protos[p].id)
                continue;
            if (!materialize_hit_columns(live_tables[t]) ||
                !maybe_promote_bucket(live_tables[t])) {
                ingest_ok = 0;
                stop_loop = 1;
                break;
            }
            if (sink.write_row &&
                sink.write_row(sink.ctx, live_tables[t]->table_name, &meta,
                               live_tables[t]->fields, live_tables[t]->n) != 0) {
                ingest_ok = 0;
                stop_loop = 1;
                break;
            }
            stat_rows++;
            pending_hint_bytes += 256;
        }
    }

    maybe_flush();
    progress_draw(file_offset, 0);
    epan_dissect_reset(edt);
    frame_data_destroy(&fd);
}

static void proto_flag_ensure(int id) {
    if (id < 0 || id < proto_flag_n)
        return;
    int n = proto_flag_n ? proto_flag_n : 8192;
    while (n <= id)
        n *= 2;
    uint8_t *k = realloc(keep_walk, (size_t)n);
    if (!k)
        return;
    uint8_t *p = realloc(persist_proto, (size_t)n);
    if (!p) {
        keep_walk = k;
        return;
    }
    memset(k + proto_flag_n, 0, (size_t)(n - proto_flag_n));
    memset(p + proto_flag_n, 0, (size_t)(n - proto_flag_n));
    keep_walk = k;
    persist_proto = p;
    proto_flag_n = n;
}

static int proto_flag_get(const uint8_t *arr, int id) {
    return id >= 0 && id < proto_flag_n && arr[id];
}

static void enable_proto_name(const char *name, int persist) {
    int id = proto_get_id_by_filter_name(name);
    if (id < 0)
        return;
    proto_flag_ensure(id);
    if (id < proto_flag_n) {
        keep_walk[id] = 1;
        if (persist)
            persist_proto[id] = 1;
    }
    if (proto_can_toggle_protocol(id))
        proto_set_decoding(id, TRUE);
}

static void set_pref_false(const char *name) {
    char buf[128];
    char *err = NULL;
    snprintf(buf, sizeof buf, "%s:FALSE", name);
    prefs_set_pref_e rc = prefs_set_pref(buf, &err);
    if (rc == PREFS_SET_SYNTAX_ERR)
        g_free(err);
}

static void apply_epan_speed_prefs(const char * const *plist, int np) {
    set_pref_false("nameres.mac_name");
    set_pref_false("nameres.network_name");
    set_pref_false("nameres.transport_name");
    set_pref_false("nameres.dns_pkt_addr_resolution");
    set_pref_false("nameres.use_external_name_resolver");
    set_pref_false("ip.check_checksum");
    set_pref_false("udp.check_checksum");
    set_pref_false("tcp.check_checksum");
    set_pref_false("ip.defragment");
    set_pref_false("ipv6.defragment");
    set_pref_false("tcp.desegment_tcp_streams");
    set_pref_false("tcp.reassemble_out_of_order");
    prefs_apply_all();

    proto_disable_all();
    static const char *const walk[] = {
        "frame", "eth", "ethertype", "ip", "ipv6", "udp", "tcp", "sll", "vlan", "data"
    };
    for (size_t i = 0; i < G_N_ELEMENTS(walk); i++)
        enable_proto_name(walk[i], 0);
    for (int i = 0; i < np; i++)
        enable_proto_name(plist[i], 1);
}

static void prime_all_hfids(void) {
    for (size_t i = 0; i < n_prime_ids; i++)
        epan_dissect_prime_with_hfid(edt, prime_ids[i]);
}

static void core_cleanup(void) {
    if (sink.close)
        sink.close(sink.ctx);
    if (edt) {
        epan_dissect_free(edt);
        edt = NULL;
    }
    if (sess) {
        epan_free(sess);
        sess = NULL;
    }
    if (json_scratch) {
        g_string_free(json_scratch, TRUE);
        json_scratch = NULL;
    }
    if (hf_arr) {
        for (int i = 0; i < hf_arr_n; i++)
            g_free(hf_arr[i]);
        free(hf_arr);
        hf_arr = NULL;
        hf_arr_n = 0;
    }
    free(prime_ids);
    prime_ids = NULL;
    n_prime_ids = 0;
    free(keep_walk);
    keep_walk = NULL;
    free(persist_proto);
    persist_proto = NULL;
    proto_flag_n = 0;
    if (tables) {
        for (size_t i = 0; i < n_tables; i++) {
            g_free(tables[i].table_name);
            for (size_t j = 0; j < tables[i].n; j++) {
                g_free(tables[i].fields[j].hf);
                g_free(tables[i].fields[j].col);
                free(tables[i].fields[j].extra);
            }
            g_free(tables[i].fields);
        }
        g_free(tables);
        tables = NULL;
        n_tables = 0;
    }
    g_free(protos);
    protos = NULL;
    n_protos = 0;
    if (did_epan) {
        epan_cleanup();
        did_epan = 0;
    }
    if (did_wtap) {
        wtap_cleanup();
        did_wtap = 0;
    }
}

static int process_file(const char *path) {
    int err = 0;
    char *err_info = NULL;
    wtap *wth = wtap_open_offline(path, WTAP_TYPE_AUTO, &err, &err_info, FALSE);
    if (!wth) {
        pcap_core_log(PCAP_LOG_ERROR, "wtap_open_offline(%s): %s", path,
                      err_info ? err_info : wtap_strerror(err));
        g_free(err_info);
        return 1;
    }
    file_subtype = wtap_file_type_subtype(wth);
    progress_init(wth);
    if (progress_file_size > 0)
        pcap_core_log(PCAP_LOG_INFO, "reading %s (%.1f MB)", path,
                      progress_file_size / (1024.0 * 1024.0));
    else
        pcap_core_log(PCAP_LOG_INFO, "reading %s", path);
    last_flush_mono_us = g_get_monotonic_time();
    progress_draw(0, 0);

    wtap_rec rec;
    Buffer buf;
    int64_t data_offset = 0;
    wtap_rec_init(&rec);
    ws_buffer_init(&buf, 1514);
    while (!stop_loop && wtap_read(wth, &rec, &buf, &err, &err_info, &data_offset)) {
        if (rec.rec_type == REC_TYPE_PACKET) {
            int64_t ts_us = (int64_t)rec.ts.secs * 1000000LL
                          + (int64_t)rec.ts.nsecs / 1000;
            process_packet(&rec, &buf, ts_us, (int)rec.rec_header.packet_header.len,
                           data_offset);
        } else {
            progress_draw(data_offset, 0);
        }
        wtap_rec_reset(&rec);
    }
    progress_draw(data_offset, 1);
    wtap_rec_cleanup(&rec);
    ws_buffer_free(&buf);

    int rc = 0;
    if (err != 0 && err != WTAP_ERR_SHORT_READ) {
        pcap_core_log(PCAP_LOG_ERROR, "wtap_read: %s",
                      err_info ? err_info : wtap_strerror(err));
        rc = 1;
    }
    g_free(err_info);
    if (sink.flush && sink.flush(sink.ctx) != 0)
        rc = 1;
    if (!ingest_ok)
        rc = 1;
    wtap_close(wth);
    return rc;
}

int pcap_core_run(const pcap_core_cfg_t *cfg) {
    if (!cfg || !cfg->infile || cfg->np <= 0 || !cfg->sink.write_row)
        return 2;
    sink = cfg->sink;
    split_depth = cfg->split_depth < 1 ? 1 : cfg->split_depth;
    log_level = cfg->log_level;
    progress_on = cfg->progress;
    ingest_ok = 1;
    stop_loop = 0;
    fno = 0;
    stat_pkts = stat_matched = stat_rows = stat_promotes = stat_errors = 0;
    pending_hint_bytes = 0;

    g_setenv("WS_LOG_LEVEL", "warning", FALSE);
    ws_log_init(cfg->progname ? cfg->progname : "pcap-core", vcmdarg_err);
    ws_log_set_level(LOG_LEVEL_WARNING);
    init_process_policies();

    char *cfg_err = configuration_init(cfg->progname ? cfg->progname : "pcap-core", NULL);
    if (cfg_err) {
        pcap_core_log(PCAP_LOG_ERROR, "configuration_init: %s", cfg_err);
        g_free(cfg_err);
        return 1;
    }
    wtap_init(TRUE);
    did_wtap = 1;
    if (!epan_init(NULL, NULL, TRUE)) {
        pcap_core_log(PCAP_LOG_ERROR, "epan_init failed");
        core_cleanup();
        return 1;
    }
    did_epan = 1;
    epan_load_settings();
    apply_epan_speed_prefs(cfg->plist, cfg->np);

    json_scratch = g_string_sized_new(256);
    protos = calloc((size_t)cfg->np, sizeof(proto_cfg_t));
    n_protos = (size_t)cfg->np;
    for (int i = 0; i < cfg->np; i++) {
        protos[i].name = cfg->plist[i];
        protos[i].id = proto_get_id_by_filter_name(cfg->plist[i]);
        if (protos[i].id < 0) {
            pcap_core_log(PCAP_LOG_ERROR, "unknown protocol filter name: %s", cfg->plist[i]);
            core_cleanup();
            return 1;
        }
    }
    tables = calloc(PCAP_MAX_TABLES, sizeof(subtable_t));
    for (int i = 0; i < cfg->np; i++) {
        if (!build_tables_for_proto(cfg->plist[i], protos[i].id)) {
            core_cleanup();
            return 1;
        }
    }

    sess = epan_new(NULL, &g_prov);
    edt = epan_dissect_new(sess, TRUE, FALSE);
    if (!sess || !edt) {
        pcap_core_log(PCAP_LOG_ERROR, "epan session init failed");
        core_cleanup();
        return 1;
    }
    epan_dissect_fake_protocols(edt, FALSE);
    prime_all_hfids();

#ifdef _WIN32
    SetConsoleCtrlHandler(on_console, TRUE);
#else
    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);
#endif

    int rc = process_file(cfg->infile);
    pcap_core_log(PCAP_LOG_INFO,
                  "summary packets=%" G_GUINT64_FORMAT " matched=%" G_GUINT64_FORMAT
                  " rows=%" G_GUINT64_FORMAT " promotes=%" G_GUINT64_FORMAT
                  " errors=%" G_GUINT64_FORMAT,
                  stat_pkts, stat_matched, stat_rows, stat_promotes, stat_errors);
    core_cleanup();
    return rc;
}

/*
 * Portable argv walk (Windows has no POSIX getopt in the CRT). Same
 * flags as dbshark's offline mode: -r pcap, -o dest, repeated -p, plus
 * --split-depth / --no-progress / --log-level. Returns 0=run, 1=help,
 * 2=usage error so both writers share one parser and cannot drift.
 */
void pcap_core_usage(const char *argv0, const char *out_ext, const char *store) {
    fprintf(stderr,
        "usage: %s -r FILE -o OUT%s -p PROTO [-p PROTO ...] [--split-depth N]\n"
        "          [--no-progress] [--log-level error|warn|info|debug]\n"
        "\n"
        "  Offline pcap/pcapng → %s. Same logical tables as dbshark Postgres:\n"
        "  ts_us, src_ip, dst_ip, src_port, dst_port, frame_len, then field\n"
        "  columns created on first use. A field that repeats in one packet\n"
        "  is stored as JSON from then on. No live capture — file in, file out.\n"
        "\n"
        "  -r FILE          input pcap or pcapng\n"
        "  -o PATH          output file (%s)\n"
        "  -p PROTO         Wireshark filter name (repeatable: -p dns -p mdns)\n"
        "  --split-depth N  dots kept in the table name (default 2)\n"
        "  --no-progress    no stderr bar (piped logs still print 10%% steps)\n"
        "  --log-level      error|warn|info|debug (default info)\n",
        argv0, out_ext ? out_ext : "", store ? store : "store",
        out_ext ? out_ext : "");
}

int pcap_core_parse_args(int argc, char **argv, pcap_core_cfg_t *cfg,
                         const char **out_path, const char *progname,
                         const char *out_ext, const char *store) {
    if (!cfg || !out_path)
        return 2;
    memset(cfg, 0, sizeof *cfg);
    cfg->split_depth = 2;
    cfg->log_level = PCAP_LOG_INFO;
    cfg->progress = 1;
    cfg->progname = progname;
    *out_path = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
            pcap_core_usage(argv[0], out_ext, store);
            return 1;
        }
        if (!strcmp(argv[i], "--split-depth") && i + 1 < argc) {
            cfg->split_depth = atoi(argv[++i]);
            continue;
        }
        if (!strcmp(argv[i], "--no-progress")) {
            cfg->progress = 0;
            continue;
        }
        if (!strcmp(argv[i], "--log-level") && i + 1 < argc) {
            const char *s = argv[++i];
            if (!g_ascii_strcasecmp(s, "error")) cfg->log_level = PCAP_LOG_ERROR;
            else if (!g_ascii_strcasecmp(s, "warn")) cfg->log_level = PCAP_LOG_WARN;
            else if (!g_ascii_strcasecmp(s, "info")) cfg->log_level = PCAP_LOG_INFO;
            else if (!g_ascii_strcasecmp(s, "debug")) cfg->log_level = PCAP_LOG_DEBUG;
            else {
                fprintf(stderr, "invalid --log-level\n");
                return 2;
            }
            continue;
        }
        if (argv[i][0] == '-' && argv[i][1] && !argv[i][2] && i + 1 < argc) {
            char o = argv[i][1];
            const char *a = argv[++i];
            if (o == 'r') cfg->infile = a;
            else if (o == 'o') *out_path = a;
            else if (o == 'p') {
                if (cfg->np >= 32) {
                    fprintf(stderr, "too many -p\n");
                    return 2;
                }
                cfg->plist[cfg->np++] = a;
            } else {
                pcap_core_usage(argv[0], out_ext, store);
                return 2;
            }
            continue;
        }
        pcap_core_usage(argv[0], out_ext, store);
        return 2;
    }
    if (!cfg->infile || !*out_path || cfg->np == 0) {
        pcap_core_usage(argv[0], out_ext, store);
        return 2;
    }
    return 0;
}
