#ifndef _WIN32
#define _GNU_SOURCE
#endif
#include "pcap_core.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sqlite3.h>

/*
 * SQLite sink for the shared ingest core.
 *
 * Physical mapping of dbshark's Postgres schema
 * ---------------------------------------------
 *   BIGINT / INTEGER  → INTEGER
 *   DOUBLE PRECISION  → REAL
 *   BYTEA             → BLOB
 *   TEXT / JSONB      → TEXT (JSON text; SQLite's JSON1 can query it)
 *
 * Tables are created with only the six dbshark meta columns. Field
 * columns are ALTER TABLE ADD COLUMN on first use. A repeated field
 * promotes the column to JSON text (same cells dbshark would COPY as
 * JSONB). INSERT lists only materialized columns so we never bind a
 * field that is not on disk yet.
 *
 * Why a writer thread (and why not N dissectors)
 * ----------------------------------------------
 * epan_dissect_run is the bulk of CPU and is not safe to run on two
 * threads in one process — dissectors keep process-global state.
 * Splitting one pcap across processes also breaks the format contract:
 * lazy ALTER and "scalar until this packet repeats a field" are ordered
 * facts about the *whole* file, not about a slice.
 *
 * SQLite, though, is a single-writer btree. We can overlap it with
 * dissection: the core thread copies each row out of the proto tree
 * into a bounded queue, resets the tree, and starts the next packet.
 * One writer thread owns the sqlite3 handle (NOMUTEX) and drains the
 * queue. Schema ops (CREATE / ALTER / promote) wait so the next INSERT
 * sees the new shape. Ordinary COMMIT is asynchronous — that is what
 * actually hides fsync/WAL behind epan.
 *
 * Queue caps (256 jobs / 16 MiB) are the memory bound. If the disk is
 * slower than epan the producer blocks; a huge pcap cannot pin RAM.
 *
 * Bind lifetime
 * -------------
 * Tree pointers die at epan_dissect_reset, which now happens while the
 * row may still be queued. Cells are packed into an owned blob; the
 * writer binds SQLITE_STATIC against that blob, steps, then frees it.
 *
 * Windows
 * -------
 * No getopt, no unistd, no isatty, no pthread. GLib GThread/GMutex is
 * the portable wait queue. sqlite3_open_v2 takes a UTF-8 path; the
 * same source builds with MSVC + the official sqlite3 amalgamation.
 */

enum {
    Q_JOBS_MAX   = 256,
    Q_BYTES_MAX  = (16u * 1024u * 1024u),
    JOB_OPEN     = 1,
    JOB_ADD      = 2,
    JOB_PROMOTE  = 3,
    JOB_ROW      = 4,
    JOB_FLUSH    = 5,
    JOB_STOP     = 6,
    CK_NULL      = 0,
    CK_I64       = 1,
    CK_F64       = 2,
    CK_TEXT      = 3,
    CK_BLOB      = 4
};

typedef struct {
    char         *name;
    sqlite3_stmt *ins;
    char        **cols;   /* materialized field names, INSERT order */
    int           n_cols;
    int           n_bind; /* 6 meta + n_cols */
    int           dirty;
} sql_table_t;

typedef struct {
    uint8_t      op;
    uint8_t      wait;
    uint8_t      done;
    uint8_t      has_src;
    uint8_t      has_dst;
    int          rc;
    int          ft;
    int          n_cells;
    int          src_port;
    int          dst_port;
    int          frame_len;
    int64_t      ts_us;
    sql_table_t *t;
    char        *col;     /* ADD / PROMOTE */
    uint8_t     *blob;    /* packed field cells for ROW */
    size_t       blob_n;
    char         src_ip[64];
    char         dst_ip[64];
} sql_job_t;

typedef struct {
    sqlite3    *db;
    GHashTable *tables; /* name → sql_table_t* */
    GString    *js;     /* producer: JSON cell */
    GString    *pack;   /* producer: packed row blob */
    int         in_txn;
    int         failed;

    int         async;
    GThread    *thr;
    GMutex      mu;
    GCond       not_empty;
    GCond       not_full;
    GCond       job_done;
    GQueue     *q;
    guint       qlen;
    size_t      qbytes;
} sql_ctx_t;

static void db_fail(sql_ctx_t *c, const char *what) {
    pcap_core_log(PCAP_LOG_ERROR, "sqlite %s: %s", what,
                  c->db ? sqlite3_errmsg(c->db) : "no db");
    c->failed = 1;
    if (c->async) {
        g_mutex_lock(&c->mu);
        g_cond_broadcast(&c->not_full);
        g_cond_broadcast(&c->job_done);
        g_mutex_unlock(&c->mu);
    }
}

static sql_table_t *sql_tbl(sql_ctx_t *c, const char *name) {
    return g_hash_table_lookup(c->tables, name);
}

static void put_u8(GString *b, uint8_t v) {
    g_string_append_c(b, (char)v);
}

static void put_u32(GString *b, uint32_t v) {
    g_string_append_len(b, (const char *)&v, 4);
}

static void put_i64(GString *b, int64_t v) {
    g_string_append_len(b, (const char *)&v, 8);
}

static void put_f64(GString *b, double v) {
    g_string_append_len(b, (const char *)&v, 8);
}

static void put_bytes(GString *b, const void *p, uint32_t n) {
    put_u32(b, n);
    if (n)
        g_string_append_len(b, p, n);
}

static int get_u8(const uint8_t **p, const uint8_t *e, uint8_t *v) {
    if (*p >= e)
        return 0;
    *v = *(*p)++;
    return 1;
}

static int get_n(const uint8_t **p, const uint8_t *e, void *dst, size_t n) {
    if ((size_t)(e - *p) < n)
        return 0;
    memcpy(dst, *p, n);
    *p += n;
    return 1;
}

static void pack_fi(GString *b, field_info *fi) {
    if (!fi || !fi->hfinfo || !fi->value) {
        put_u8(b, CK_NULL);
        return;
    }
    int64_t iv;
    double dv;
    if (fi_int64(fi, &iv)) {
        put_u8(b, CK_I64);
        put_i64(b, iv);
        return;
    }
    if (fi_double(fi, &dv)) {
        put_u8(b, CK_F64);
        put_f64(b, dv);
        return;
    }
    fvalue_t *fv = fi->value;
    switch ((int)fi->hfinfo->type) {
    case FT_BYTES: case FT_UINT_BYTES: {
        const void *data = fvalue_get_bytes_data(fv);
        size_t sz = fvalue_get_bytes_size(fv);
        if (!data && sz > 0) {
            put_u8(b, CK_NULL);
            return;
        }
        put_u8(b, CK_BLOB);
        put_bytes(b, data, (uint32_t)sz);
        return;
    }
    case FT_STRING: case FT_STRINGZ: case FT_UINT_STRING:
    case FT_STRINGZPAD: case FT_STRINGZTRUNC: {
        const char *str = fvalue_get_string(fv);
        if (!str) {
            put_u8(b, CK_NULL);
            return;
        }
        put_u8(b, CK_TEXT);
        put_bytes(b, str, (uint32_t)strlen(str));
        return;
    }
    default: {
        char *r = fvalue_to_string_repr(NULL, fv, FTREPR_DISPLAY, BASE_NONE);
        if (!r) {
            put_u8(b, CK_NULL);
            return;
        }
        put_u8(b, CK_TEXT);
        put_bytes(b, r, (uint32_t)strlen(r));
        g_free(r);
    }
    }
}

static int writer_open(sql_ctx_t *c, sql_table_t *t) {
    char *sql = sqlite3_mprintf(
        "CREATE TABLE IF NOT EXISTS \"%w\" ("
        "ts_us INTEGER, src_ip TEXT, dst_ip TEXT, "
        "src_port INTEGER, dst_port INTEGER, frame_len INTEGER)",
        t->name);
    int rc = sqlite3_exec(c->db, sql, 0, 0, 0);
    sqlite3_free(sql);
    if (rc != SQLITE_OK) {
        db_fail(c, "create");
        return -1;
    }
    pcap_core_log(PCAP_LOG_INFO, "created table \"%s\"", t->name);
    return 0;
}

static int writer_add(sql_ctx_t *c, sql_table_t *t, const char *col, int ft) {
    const char *ty = ft2sql_name(ft);
    if (!ty)
        return 0;
    char *sql = sqlite3_mprintf(
        "ALTER TABLE \"%w\" ADD COLUMN \"%w\" %s", t->name, col, ty);
    int rc = sqlite3_exec(c->db, sql, 0, 0, 0);
    sqlite3_free(sql);
    if (rc != SQLITE_OK && !strstr(sqlite3_errmsg(c->db), "duplicate column")) {
        db_fail(c, "alter add");
        return -1;
    }
    char **p = g_realloc(t->cols, (size_t)(t->n_cols + 1) * sizeof(*p));
    if (!p)
        return -1;
    t->cols = p;
    t->cols[t->n_cols++] = g_strdup(col);
    if (t->ins) {
        sqlite3_finalize(t->ins);
        t->ins = NULL;
    }
    t->dirty = 1;
    return 0;
}

static int writer_promote(sql_ctx_t *c, sql_table_t *t, const char *col) {
    /*
     * SQLite has no ALTER TYPE. Rewrite committed scalars to the same
     * JSON text dbshark would store after to_jsonb:
     *   integer/real → JSON number (unquoted)
     *   blob         → JSON string of lowercase hex
     *   text         → JSON string, unless it already looks like JSON
     * A single UPDATE on a 50 M-row table can pin a huge journal. Walk
     * rowid in 100 k windows so peak extra pages stay bounded.
     */
    sqlite3_int64 lo = 0, hi = -1;
    char *q = sqlite3_mprintf("SELECT MIN(rowid), MAX(rowid) FROM \"%w\"", t->name);
    sqlite3_stmt *st = NULL;
    if (sqlite3_prepare_v2(c->db, q, -1, &st, NULL) == SQLITE_OK &&
        sqlite3_step(st) == SQLITE_ROW && sqlite3_column_type(st, 0) != SQLITE_NULL) {
        lo = sqlite3_column_int64(st, 0);
        hi = sqlite3_column_int64(st, 1);
    }
    sqlite3_finalize(st);
    sqlite3_free(q);

    const sqlite3_int64 STEP = 100000;
    for (sqlite3_int64 a = lo; a <= hi; a += STEP) {
        sqlite3_int64 b = a + STEP - 1;
        if (b > hi)
            b = hi;
        char *sql = sqlite3_mprintf(
            "UPDATE \"%w\" SET \"%w\" = CASE"
            " WHEN \"%w\" IS NULL THEN NULL"
            " WHEN typeof(\"%w\") IN ('integer','real') THEN CAST(\"%w\" AS TEXT)"
            " WHEN typeof(\"%w\") = 'blob' THEN '\"' || lower(hex(\"%w\")) || '\"'"
            " WHEN typeof(\"%w\") = 'text' AND substr(\"%w\",1,1) IN ('[','{','\"')"
            "  THEN \"%w\""
            " ELSE json_quote(\"%w\") END"
            " WHERE rowid BETWEEN %lld AND %lld",
            t->name, col, col, col, col, col, col, col, col, col, col,
            (long long)a, (long long)b);
        int rc = sqlite3_exec(c->db, sql, 0, 0, 0);
        sqlite3_free(sql);
        if (rc != SQLITE_OK) {
            pcap_core_log(PCAP_LOG_WARN, "sqlite promote %s.%s: %s (continuing as TEXT)",
                          t->name, col, sqlite3_errmsg(c->db));
            break;
        }
    }
    if (t->ins) {
        sqlite3_finalize(t->ins);
        t->ins = NULL;
    }
    t->dirty = 1;
    return 0;
}

static int writer_rebuild_ins(sql_ctx_t *c, sql_table_t *t) {
    GString *sql = g_string_new(NULL);
    g_string_printf(sql, "INSERT INTO \"%s\" (ts_us,src_ip,dst_ip,src_port,dst_port,frame_len",
                    t->name);
    int nbind = 6;
    for (int i = 0; i < t->n_cols; i++) {
        g_string_append_printf(sql, ",\"%s\"", t->cols[i]);
        nbind++;
    }
    g_string_append(sql, ") VALUES (?");
    for (int i = 1; i < nbind; i++)
        g_string_append(sql, ",?");
    g_string_append_c(sql, ')');
    if (t->ins)
        sqlite3_finalize(t->ins);
    int rc = sqlite3_prepare_v3(c->db, sql->str, -1, SQLITE_PREPARE_PERSISTENT, &t->ins, NULL);
    g_string_free(sql, TRUE);
    if (rc != SQLITE_OK) {
        db_fail(c, "prepare");
        return -1;
    }
    t->n_bind = nbind;
    t->dirty = 0;
    return 0;
}

static int writer_bind_cell(sqlite3_stmt *s, int idx,
                            const uint8_t **p, const uint8_t *e) {
    uint8_t k;
    if (!get_u8(p, e, &k))
        return -1;
    if (k == CK_NULL) {
        sqlite3_bind_null(s, idx);
        return 0;
    }
    if (k == CK_I64) {
        int64_t v;
        if (!get_n(p, e, &v, 8))
            return -1;
        sqlite3_bind_int64(s, idx, (sqlite3_int64)v);
        return 0;
    }
    if (k == CK_F64) {
        double v;
        if (!get_n(p, e, &v, 8))
            return -1;
        sqlite3_bind_double(s, idx, v);
        return 0;
    }
    if (k == CK_TEXT || k == CK_BLOB) {
        uint32_t n;
        if (!get_n(p, e, &n, 4))
            return -1;
        if ((size_t)(e - *p) < n)
            return -1;
        if (k == CK_TEXT)
            sqlite3_bind_text(s, idx, (const char *)*p, (int)n, SQLITE_STATIC);
        else
            sqlite3_bind_blob(s, idx, *p, (int)n, SQLITE_STATIC);
        *p += n;
        return 0;
    }
    return -1;
}

static int writer_flush(sql_ctx_t *c) {
    if (c->in_txn) {
        if (sqlite3_exec(c->db, "COMMIT", 0, 0, 0) != SQLITE_OK) {
            db_fail(c, "commit");
            return -1;
        }
        c->in_txn = 0;
    }
    if (sqlite3_exec(c->db, "BEGIN IMMEDIATE", 0, 0, 0) != SQLITE_OK) {
        db_fail(c, "begin");
        return -1;
    }
    c->in_txn = 1;
    return 0;
}

static int writer_row(sql_ctx_t *c, sql_job_t *j) {
    sql_table_t *t = j->t;
    if (!t)
        return -1;
    if (!t->ins || t->dirty) {
        if (writer_rebuild_ins(c, t) != 0)
            return -1;
    }
    sqlite3_stmt *s = t->ins;
    sqlite3_bind_int64(s, 1, (sqlite3_int64)j->ts_us);
    if (j->has_src)
        sqlite3_bind_text(s, 2, j->src_ip, -1, SQLITE_STATIC);
    else
        sqlite3_bind_null(s, 2);
    if (j->has_dst)
        sqlite3_bind_text(s, 3, j->dst_ip, -1, SQLITE_STATIC);
    else
        sqlite3_bind_null(s, 3);
    if (j->src_port)
        sqlite3_bind_int(s, 4, j->src_port);
    else
        sqlite3_bind_null(s, 4);
    if (j->dst_port)
        sqlite3_bind_int(s, 5, j->dst_port);
    else
        sqlite3_bind_null(s, 5);
    sqlite3_bind_int(s, 6, j->frame_len);

    const uint8_t *p = j->blob;
    const uint8_t *e = j->blob ? j->blob + j->blob_n : NULL;
    int idx = 7;
    for (int i = 0; i < j->n_cells; i++) {
        if (writer_bind_cell(s, idx++, &p, e) != 0) {
            db_fail(c, "row blob");
            sqlite3_reset(s);
            sqlite3_clear_bindings(s);
            return -1;
        }
    }
    int step = sqlite3_step(s);
    sqlite3_reset(s);
    sqlite3_clear_bindings(s);
    if (step != SQLITE_DONE) {
        db_fail(c, t->name);
        return -1;
    }
    return 0;
}

static int writer_handle(sql_ctx_t *c, sql_job_t *j) {
    switch (j->op) {
    case JOB_OPEN:    return writer_open(c, j->t);
    case JOB_ADD:     return writer_add(c, j->t, j->col, j->ft);
    case JOB_PROMOTE: return writer_promote(c, j->t, j->col);
    case JOB_ROW:     return writer_row(c, j);
    case JOB_FLUSH:   return writer_flush(c);
    case JOB_STOP:    return 0;
    default:          return -1;
    }
}

static void job_free(sql_job_t *j) {
    if (!j)
        return;
    g_free(j->blob);
    g_free(j->col);
    g_free(j);
}

static gpointer writer_main(gpointer arg) {
    sql_ctx_t *c = arg;
    if (sqlite3_exec(c->db, "BEGIN IMMEDIATE", 0, 0, 0) != SQLITE_OK)
        db_fail(c, "begin");
    else
        c->in_txn = 1;

    /* Always drain until STOP so close() cannot wait on a dead thread. */
    for (;;) {
        g_mutex_lock(&c->mu);
        while (c->qlen == 0)
            g_cond_wait(&c->not_empty, &c->mu);
        sql_job_t *j = g_queue_pop_head(c->q);
        c->qlen--;
        c->qbytes -= j->blob_n;
        g_cond_signal(&c->not_full);
        g_mutex_unlock(&c->mu);

        int stop = (j->op == JOB_STOP);
        int rc = 0;
        if (!c->failed && !stop)
            rc = writer_handle(c, j);
        j->rc = rc;

        if (j->wait) {
            g_mutex_lock(&c->mu);
            j->done = 1;
            g_cond_broadcast(&c->job_done);
            g_mutex_unlock(&c->mu);
            /* Producer frees the wait job after it sees done. */
        } else {
            job_free(j);
        }
        if (stop)
            break;
    }
    return NULL;
}

static int submit(sql_ctx_t *c, sql_job_t *j, int wait) {
    if (c->failed) {
        job_free(j);
        return -1;
    }
    j->wait = (uint8_t)wait;
    j->done = 0;
    j->rc = 0;

    if (!c->async) {
        int rc = writer_handle(c, j);
        job_free(j);
        return rc;
    }

    g_mutex_lock(&c->mu);
    while (!wait && !c->failed &&
           (c->qlen >= Q_JOBS_MAX || c->qbytes + j->blob_n > Q_BYTES_MAX))
        g_cond_wait(&c->not_full, &c->mu);
    if (c->failed) {
        g_mutex_unlock(&c->mu);
        job_free(j);
        return -1;
    }
    g_queue_push_tail(c->q, j);
    c->qlen++;
    c->qbytes += j->blob_n;
    g_cond_signal(&c->not_empty);
    if (!wait) {
        g_mutex_unlock(&c->mu);
        return 0;
    }
    while (!j->done && !c->failed)
        g_cond_wait(&c->job_done, &c->mu);
    int rc = c->failed ? -1 : j->rc;
    g_mutex_unlock(&c->mu);
    job_free(j);
    return rc;
}

static sql_job_t *job_new(uint8_t op, sql_table_t *t) {
    sql_job_t *j = g_malloc0(sizeof *j);
    j->op = op;
    j->t = t;
    return j;
}

static int sql_open_table(void *ctx, const char *table) {
    sql_ctx_t *c = ctx;
    if (sql_tbl(c, table))
        return 0;
    sql_table_t *t = g_malloc0(sizeof *t);
    t->name = g_strdup(table);
    g_hash_table_insert(c->tables, t->name, t);
    return submit(c, job_new(JOB_OPEN, t), 1);
}

static int sql_add_column(void *ctx, const char *table, const char *col, int ft) {
    sql_ctx_t *c = ctx;
    sql_table_t *t = sql_tbl(c, table);
    if (!t)
        return -1;
    sql_job_t *j = job_new(JOB_ADD, t);
    j->col = g_strdup(col);
    j->ft = ft;
    return submit(c, j, 1);
}

static int sql_promote_json(void *ctx, const char *table, const char *col) {
    sql_ctx_t *c = ctx;
    sql_table_t *t = sql_tbl(c, table);
    if (!t)
        return -1;
    sql_job_t *j = job_new(JOB_PROMOTE, t);
    j->col = g_strdup(col);
    return submit(c, j, 1);
}

static int sql_write_row(void *ctx, const char *table, const pcap_meta_t *meta,
                         field_col_t *fields, size_t n) {
    sql_ctx_t *c = ctx;
    sql_table_t *t = sql_tbl(c, table);
    if (!t)
        return -1;

    g_string_truncate(c->pack, 0);
    int n_cells = 0;
    for (size_t i = 0; i < n; i++) {
        if (!fields[i].in_sink)
            continue;
        n_cells++;
        if (!field_hit(&fields[i])) {
            put_u8(c->pack, CK_NULL);
            continue;
        }
        if (fields[i].is_json || fields[i].n_hit > 1) {
            g_string_truncate(c->js, 0);
            write_json_cell(c->js, &fields[i]);
            put_u8(c->pack, CK_TEXT);
            put_bytes(c->pack, c->js->str, (uint32_t)c->js->len);
            if (c->js->allocated_len > (1u << 20)) {
                g_string_free(c->js, TRUE);
                c->js = g_string_sized_new(128);
            }
        } else {
            pack_fi(c->pack, fc_fi(&fields[i], 0));
        }
    }

    sql_job_t *j = job_new(JOB_ROW, t);
    j->ts_us = meta->ts_us;
    j->src_port = meta->src_port ? (int)meta->src_port : 0;
    j->dst_port = meta->dst_port ? (int)meta->dst_port : 0;
    j->frame_len = meta->frame_len;
    j->n_cells = n_cells;
    if (meta->src_ip) {
        g_strlcpy(j->src_ip, meta->src_ip, sizeof j->src_ip);
        j->has_src = 1;
    }
    if (meta->dst_ip) {
        g_strlcpy(j->dst_ip, meta->dst_ip, sizeof j->dst_ip);
        j->has_dst = 1;
    }
    j->blob_n = c->pack->len;
    if (j->blob_n) {
        j->blob = g_malloc(j->blob_n);
        memcpy(j->blob, c->pack->str, j->blob_n);
    }
    if (c->pack->allocated_len > (1u << 20)) {
        g_string_free(c->pack, TRUE);
        c->pack = g_string_sized_new(256);
    }
    return submit(c, j, 0);
}

static int sql_flush(void *ctx) {
    sql_ctx_t *c = ctx;
    /* Async: keep epan running while WAL commits. Schema ops wait, so a
     * later ADD/PROMOTE still sees a committed table. */
    return submit(c, job_new(JOB_FLUSH, NULL), 0);
}

static void sql_table_free(gpointer p) {
    sql_table_t *t = p;
    if (t->ins)
        sqlite3_finalize(t->ins);
    for (int i = 0; i < t->n_cols; i++)
        g_free(t->cols[i]);
    g_free(t->cols);
    g_free(t->name);
    g_free(t);
}

static void sql_close(void *ctx) {
    sql_ctx_t *c = ctx;
    if (!c)
        return;
    if (c->async && c->thr) {
        submit(c, job_new(JOB_STOP, NULL), 1);
        g_thread_join(c->thr);
        c->thr = NULL;
    }
    if (c->db && c->in_txn)
        sqlite3_exec(c->db, "COMMIT", 0, 0, 0);
    c->in_txn = 0;
    if (c->q) {
        while (!g_queue_is_empty(c->q))
            job_free(g_queue_pop_head(c->q));
        g_queue_free(c->q);
    }
    if (c->async) {
        g_mutex_clear(&c->mu);
        g_cond_clear(&c->not_empty);
        g_cond_clear(&c->not_full);
        g_cond_clear(&c->job_done);
    }
    if (c->tables)
        g_hash_table_destroy(c->tables);
    if (c->js)
        g_string_free(c->js, TRUE);
    if (c->pack)
        g_string_free(c->pack, TRUE);
    if (c->db) {
        sqlite3_exec(c->db, "PRAGMA wal_checkpoint(TRUNCATE)", 0, 0, 0);
        sqlite3_close(c->db);
    }
    g_free(c);
}

int main(int argc, char **argv) {
    pcap_core_cfg_t cfg;
    const char *out = NULL;
    int prc = pcap_core_parse_args(argc, argv, &cfg, &out, "pcap2sqlite",
                                   ".sqlite", "SQLite");
    if (prc != 0)
        return prc == 1 ? 0 : prc;

    sql_ctx_t *c = g_malloc0(sizeof *c);
    /*
     * NOMUTEX: the writer thread is the only sqlite3 caller. The core
     * thread never touches the handle after open/pragma.
     */
    int orc = sqlite3_open_v2(out, &c->db,
                              SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_NOMUTEX,
                              NULL);
    if (orc != SQLITE_OK) {
        fprintf(stderr, "open %s: %s\n", out, c->db ? sqlite3_errmsg(c->db) : sqlite3_errstr(orc));
        if (c->db)
            sqlite3_close(c->db);
        g_free(c);
        return 1;
    }
    /*
     * Bulk-load PRAGMAs. locking_mode=EXCLUSIVE drops per-txn lock
     * round-trips. wal_autocheckpoint=0 defers WAL copy into the db
     * until close. synchronous=OFF skips fsync during ingest — a crash
     * mid-run can leave a torn file; a clean close checkpoints. mmap
     * + capped cache keep a multi-GB db from becoming a growing heap.
     * page_size only sticks on a brand-new file, before CREATE TABLE.
     */
    sqlite3_limit(c->db, SQLITE_LIMIT_LENGTH, 64 * 1024 * 1024);
    sqlite3_soft_heap_limit64(96LL * 1024 * 1024);
#if SQLITE_VERSION_NUMBER >= 3031000
    sqlite3_hard_heap_limit64(256LL * 1024 * 1024);
#endif
    sqlite3_exec(c->db,
        "PRAGMA page_size=8192;"
        "PRAGMA journal_mode=WAL;"
        "PRAGMA wal_autocheckpoint=0;"
        "PRAGMA locking_mode=EXCLUSIVE;"
        "PRAGMA synchronous=OFF;"
        "PRAGMA cache_size=-65536;"
        "PRAGMA cache_spill=1;"
        "PRAGMA temp_store=MEMORY;"
        "PRAGMA mmap_size=268435456;"
        "PRAGMA foreign_keys=OFF;"
        "PRAGMA recursive_triggers=OFF;",
        0, 0, 0);

    c->js = g_string_sized_new(128);
    c->pack = g_string_sized_new(256);
    c->tables = g_hash_table_new_full(g_str_hash, g_str_equal, NULL, sql_table_free);
    c->q = g_queue_new();
    g_mutex_init(&c->mu);
    g_cond_init(&c->not_empty);
    g_cond_init(&c->not_full);
    g_cond_init(&c->job_done);
    c->async = 1;
    GError *terr = NULL;
    c->thr = g_thread_try_new("sqlite-w", writer_main, c, &terr);
    if (!c->thr) {
        pcap_core_log(PCAP_LOG_WARN, "sqlite writer thread unavailable (%s); serial ingest",
                      terr ? terr->message : "unknown");
        g_clear_error(&terr);
        c->async = 0;
        g_mutex_clear(&c->mu);
        g_cond_clear(&c->not_empty);
        g_cond_clear(&c->not_full);
        g_cond_clear(&c->job_done);
        if (sqlite3_exec(c->db, "BEGIN IMMEDIATE", 0, 0, 0) != SQLITE_OK) {
            fprintf(stderr, "begin: %s\n", sqlite3_errmsg(c->db));
            sqlite3_close(c->db);
            g_queue_free(c->q);
            g_hash_table_destroy(c->tables);
            g_string_free(c->js, TRUE);
            g_string_free(c->pack, TRUE);
            g_free(c);
            return 1;
        }
        c->in_txn = 1;
    }

    cfg.sink.ctx = c;
    cfg.sink.open_table = sql_open_table;
    cfg.sink.add_column = sql_add_column;
    cfg.sink.promote_json = sql_promote_json;
    cfg.sink.write_row = sql_write_row;
    cfg.sink.flush = sql_flush;
    cfg.sink.close = sql_close;
    return pcap_core_run(&cfg);
}
