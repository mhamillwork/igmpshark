# Offline converters — pcap2sqlite / pcap2hdf5

Two small programs. Each reads a **pcap or pcapng file** and writes one output file. There is no live capture, no Postgres, no WebSocket.

They share one dissect/schema engine (`pcap_core`) with **dbshark**. A packet that dbshark would `COPY` into Postgres table `"dns_qry"` with columns `ts_us, src_ip, …, name` is the same row here: a SQLite table `dns_qry`, or an HDF5 group `/dns_qry` with one 1-D dataset per column.

```
pcap/pcapng  →  epan (libwireshark)  →  same tables as dbshark  →  .sqlite or .h5
```

| Binary | Store | Typical use |
|---|---|---|
| `pcap2sqlite` | SQLite 3 (WAL) | `sqlite3`, pandas, anything that speaks SQL |
| `pcap2hdf5` | HDF5 (chunked 1-D datasets) | Python `h5py`, MATLAB, columnar scans |

Build from this directory with `./build.sh` (the dbshark build in `tests/dbshark/build/` does not build these).

```bash
# Wireshark 4.2.x libs must already exist (repo root):
#   ./tests/dbshark/build/build-wireshark-4.2.6.sh

cd tools && ./build.sh          # → build/run/pcap2sqlite  build/run/pcap2hdf5
# optional:  WS=$HOME/wireshark-4.2.6 CC=gcc ./build.sh
```

Debian/Ubuntu packages: `libglib2.0-dev`, `libsqlite3-dev`, `libhdf5-dev`, `pkg-config`. The Wireshark tree is **not** the distro `libwireshark`; it is the one built next to logshark.

Windows: the same `.c` files (no `getopt` / `unistd`). Link the sqlite3 amalgamation and HDF5 with MSVC; `pcap_core_parse_args` walks `argv`.

## Run

```bash
./build/run/pcap2sqlite -r capture.pcap -o capture.sqlite -p dns
./build/run/pcap2hdf5   -r capture.pcap -o capture.h5     -p dns

# several protocols, same file:
./build/run/pcap2sqlite -r capture.pcapng -o out.sqlite -p dis -p asterix

./build/run/pcap2sqlite -h
```

| Flag | Meaning |
|---|---|
| `-r FILE` | Input pcap / pcapng |
| `-o PATH` | Output `.sqlite` or `.h5` |
| `-p PROTO` | Wireshark **filter name** (`dns`, `dis`, `http`, …). Repeatable. |
| `--split-depth N` | How many dotted segments stay in the **table** name (default **2**, same as dbshark) |
| `--no-progress` | No stderr bar (CI logs still get 10% lines when stderr is not a TTY) |
| `--log-level` | `error` \| `warn` \| `info` (default) \| `debug` |

Progress (TTY): a single rewriting line with percent (when the file size is known), packet count, row count, packet/s, and ETA. Schema messages (`created table`, `adding column`, JSON promote) print above the bar instead of overwriting it. `--no-progress` turns the bar off.

Non-default ports: these binaries have no `-d`. Set `WIRESHARK_CONFIG_DIR` the same way as dbshark/globeshark (see the repo-root README).

## Output structure (the dbshark contract)

dbshark is the source of truth. Both writers must produce the **same logical tables**. Only the physical cells change (SQL types vs HDF5 datasets).

### What a table is

Wireshark field abbrevs are dotted (`dns.qry.name`, `dis.entity_id.entity`). `--split-depth` (default 2) splits that name:

| Abbrev | Table | Column |
|---|---|---|
| `dns.qry.name` | `dns_qry` | `name` |
| `dns.flags.rcode` | `dns_flags` | `rcode` |
| `http.request.method` | `http_request` | `method` |
| `frame.time` (not persisted) | — | L2/L4 leaves are not stored |

Identifiers are sanitized like dbshark: lowercase, non-alnum → `_`, truncated to 63 characters.

A protocol passed with `-p` can yield **many** tables (DNS is dozens). Tables that never appear in the capture are **not** created. Columns that never appear are **not** added. That matches dbshark’s lazy `CREATE` / `ALTER`.

There is **no** `frame_no` column.

### Meta columns (every table)

Always present, in this order:

| Column | Meaning | Postgres (dbshark) | SQLite | HDF5 |
|---|---|---|---|---|
| `ts_us` | Packet timestamp, Unix microseconds | `BIGINT` | `INTEGER` | `int64` |
| `src_ip` | Network-layer source | `TEXT` | `TEXT` | variable UTF-8 (NULL if none) |
| `dst_ip` | Network-layer dest | `TEXT` | `TEXT` | variable UTF-8 |
| `src_port` | Transport source; missing → SQL NULL | `INTEGER` | `INTEGER` | `int64`; **missing = `INT64_MIN`** |
| `dst_port` | Transport dest | `INTEGER` | `INTEGER` | `int64`; **missing = `INT64_MIN`** |
| `frame_len` | On-wire length | `INTEGER` | `INTEGER` | `int64` |

HDF5 has no SQL NULL. Integers use `INT64_MIN` as the missing sentinel (same idea as R `NA_integer_`). Floats use IEEE NaN. Strings/blobs use a NULL pointer.

### Field columns

Created on **first use** in a packet (dbshark `ALTER TABLE ADD COLUMN`). Native type follows the Wireshark field:

| Wireshark | dbshark | SQLite | HDF5 |
|---|---|---|---|
| integers, boolean, char | `BIGINT` / `INTEGER` | `INTEGER` | `int64` |
| float, double, time | `DOUBLE PRECISION` | `REAL` | `float64` |
| bytes | `BYTEA` | `BLOB` | variable-length bytes |
| strings, addresses, … | `TEXT` | `TEXT` | variable UTF-8 |

Several Wireshark hf ids can share one column name (dbshark already merges those). Values from one packet go in that one cell.

### JSON promote

A field starts as a scalar. The **first time it appears more than once in a single packet**, that column becomes JSON for the rest of the file (dbshark: `ALTER … TYPE JSONB USING to_jsonb(...)`).

- One value after promote: a JSON scalar (`3`, `"foo"`).
- Several values: a JSON array (`[1,2,3]`).
- Already-written scalar rows are rewritten to the same JSON text dbshark would store.

SQLite keeps JSON as `TEXT` (JSON1 can query it). HDF5 replaces that dataset with variable-length UTF-8. Postgres uses `JSONB`. The **strings** match.

### SQLite layout

```text
capture.sqlite
  table "dns"          — meta + dns.* fields that appeared
  table "dns_qry"      — …
  table "dns_flags"    — …
```

```sql
.tables
PRAGMA table_info(dns_qry);
SELECT ts_us, src_ip, name FROM dns_qry LIMIT 5;
SELECT json_extract(type, '$[0]') FROM dhcp_option WHERE typeof(type) = 'text';
```

### HDF5 layout

One **root group per table**, named exactly the SQLite/Postgres identifier (not nested `/dns/qry`).

```text
capture.h5
  /dns
    ts_us      (int64, extendible, chunk 4096)
    src_ip     (variable UTF-8)
    dst_ip
    src_port
    dst_port
    frame_len
    flags      (field dataset, created when first seen)
    id
    …
  /dns_qry
    ts_us, src_ip, …, name, …
```

```python
import h5py
f = h5py.File("capture.h5", "r")
print(list(f.keys()))          # table names
g = f["dns_qry"]
print(list(g.keys()))          # column names
print(g["ts_us"][:5], g["name"][:5])
```

`h5ls -r capture.h5` lists the same groups/datasets.

### Rows

One input packet can write **several rows** — one per subtable that had a mapped field in that packet. That is how dbshark `COPY`s. Packet count on the progress bar is frames read; row count is sink rows.

## What these tools do not do

- Live capture (`-i`). That is dbshark / dbshark-lite / globeshark.
- Clock / upsert / globe ingest.
- Pre-create every Wireshark field for `-p dns` at startup. Unused fields stay out of the file.

## Smoke

```bash
./build/run/pcap2sqlite -r ~/wireshark-4.2.6/test/captures/dhcp.pcapng -o /tmp/dhcp.sqlite -p dhcp
./pcap2hdf5   -r ~/wireshark-4.2.6/test/captures/dhcp.pcapng -o /tmp/dhcp.h5     -p dhcp

sqlite3 /tmp/dhcp.sqlite '.tables'
h5ls /tmp/dhcp.h5
```

You should see the same names on both sides (`dhcp`, `dhcp_hw`, `dhcp_ip`, `dhcp_option`, …).
