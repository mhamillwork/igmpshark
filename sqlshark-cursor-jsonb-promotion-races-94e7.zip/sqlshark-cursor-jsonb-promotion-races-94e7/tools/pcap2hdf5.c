#ifndef _WIN32
#define _GNU_SOURCE
#endif
#include "pcap_core.h"

#include <inttypes.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <hdf5.h>

/*
 * HDF5 sink for the shared ingest core.
 *
 * Logical format (must match dbshark / pcap2sqlite)
 * -------------------------------------------------
 * One HDF5 group per dbshark table, named *exactly* the sanitized table
 * identifier (e.g. group "/http_request", not nested "/http/request").
 * Nested paths were the old writer's choice and made a table name that
 * Postgres would treat as one identifier split across groups. Readers
 * that join sqlite/postgres/hdf5 on table name need the same string.
 *
 * Each group holds 1-D extendible datasets:
 *   ts_us, src_ip, dst_ip, src_port, dst_port, frame_len
 * plus one dataset per field column, created on first use (same moment
 * dbshark ALTER TABLE ADD COLUMN). A repeated field in one packet
 * promotes that dataset to variable-length UTF-8 JSON text, with
 * already-written scalars rewritten in bounded chunks so a multi-GB
 * column never lands in RAM as a single allocation.
 *
 * NULL
 * ----
 * HDF5 native integers have no SQL NULL. Missing i64 cells use
 * INT64_MIN (same idea as R's NA_integer_). Missing f64 cells use
 * IEEE NaN. VL strings / VL bytes use a NULL pointer. src_port and
 * dst_port of 0 are stored as the i64 sentinel, matching dbshark's
 * "0 means no transport port → NULL".
 *
 * Memory
 * ------
 * write_row copies strings/blobs out of the epan tree (the tree dies
 * when the call returns). Batches are capped by row count *and* a 4 MiB
 * byte budget so a wide table cannot pin unbounded heap. The file
 * access property list caps the raw-data chunk cache (8 MiB) so HDF5
 * itself cannot grow a working set with the pcap. Promote reads at most
 * H5_PROMOTE_ROWS rows at a time.
 *
 * Cache / layout
 * --------------
 * Datasets are chunked (4096 rows) so H5Dset_extent is O(chunk) and
 * appends are sequential within a chunk — sequential write, the pattern
 * a cold-pcap ingest actually does. libver LATEST + alignment keeps
 * large objects on 4 KiB boundaries for the page cache.
 *
 * Windows
 * -------
 * No getopt, no unistd, no isatty. argv is walked by pcap_core_parse_args.
 * The HDF5 C API is the same on Win32 (link hdf5.lib / hdf5.dll). Paths
 * passed to H5Fcreate are UTF-8 when the HDF5 library is built that way
 * (1.10.6+ default); otherwise they are the process ANSI code page.
 */

#define H5_CHUNK_ROWS     4096
#define H5_BATCH_ROWS     512
#define H5_BATCH_BYTES    (4u * 1024u * 1024u)
#define H5_PROMOTE_ROWS   4096
#define H5_RDCC_NBYTES    (8u * 1024u * 1024u)
#define H5_RDCC_NSLOTS    521
#define H5_I64_NULL       INT64_MIN

typedef enum { COL_I64, COL_F64, COL_STR, COL_BYTES } col_kind_t;

typedef struct {
    char      *name;
    col_kind_t kind;
    hid_t      dset;
    hsize_t    nrows;
    GArray    *i64;
    GArray    *f64;
    GPtrArray *str;
    GArray    *blob;
} h5_col_t;

typedef struct {
    char       *name;
    hid_t       gid;
    h5_col_t    meta[6];
    GHashTable *cols;
    GPtrArray  *col_order; /* add order: sequential flush, not hash-walk */
    guint       batch_n;
} h5_table_t;

typedef struct {
    hid_t       file;
    hid_t       vstr;
    hid_t       vblob;
    GHashTable *tables;
    GString    *js;
    size_t      pending_bytes;
    int         failed;
} h5_ctx_t;

static hid_t h5_file_type(h5_ctx_t *c, col_kind_t k) {
    switch (k) {
    case COL_I64:   return H5T_NATIVE_INT64;
    case COL_F64:   return H5T_NATIVE_DOUBLE;
    case COL_STR:   return c->vstr;
    case COL_BYTES: return c->vblob;
    }
    return H5T_NATIVE_INT64;
}

static col_kind_t kind_from_ft(int ft) {
    const char *n = ft2sql_name(ft);
    if (!n)
        return COL_STR;
    if (!strcmp(n, "INTEGER"))
        return COL_I64;
    if (!strcmp(n, "REAL"))
        return COL_F64;
    if (!strcmp(n, "BLOB"))
        return COL_BYTES;
    return COL_STR;
}

static void col_init_bufs(h5_col_t *c) {
    if (c->kind == COL_I64)
        c->i64 = g_array_sized_new(FALSE, FALSE, sizeof(int64_t), H5_BATCH_ROWS);
    else if (c->kind == COL_F64)
        c->f64 = g_array_sized_new(FALSE, FALSE, sizeof(double), H5_BATCH_ROWS);
    else if (c->kind == COL_STR)
        c->str = g_ptr_array_sized_new(H5_BATCH_ROWS);
    else
        c->blob = g_array_sized_new(FALSE, FALSE, sizeof(hvl_t), H5_BATCH_ROWS);
}

static void col_clear_batch(h5_col_t *c) {
    if (c->i64)
        g_array_set_size(c->i64, 0);
    if (c->f64)
        g_array_set_size(c->f64, 0);
    if (c->str) {
        for (guint i = 0; i < c->str->len; i++)
            g_free(g_ptr_array_index(c->str, i));
        g_ptr_array_set_size(c->str, 0);
    }
    if (c->blob) {
        for (guint i = 0; i < c->blob->len; i++) {
            hvl_t *v = &g_array_index(c->blob, hvl_t, i);
            free(v->p);
        }
        g_array_set_size(c->blob, 0);
    }
}

static int col_create(h5_ctx_t *ctx, hid_t gid, h5_col_t *c,
                      const char *name, col_kind_t kind, hsize_t nrows) {
    memset(c, 0, sizeof *c);
    c->name = g_strdup(name);
    c->kind = kind;
    c->nrows = nrows;
    c->dset = H5I_INVALID_HID;
    col_init_bufs(c);

    hsize_t dims[1] = {nrows};
    hsize_t maxdims[1] = {H5S_UNLIMITED};
    hid_t space = H5Screate_simple(1, dims, maxdims);
    if (space < 0)
        return -1;
    hid_t dcpl = H5Pcreate(H5P_DATASET_CREATE);
    hsize_t chunk[1] = {H5_CHUNK_ROWS};
    H5Pset_chunk(dcpl, 1, chunk);
    /*
     * Incremental allocation: a new column on a 50 M-row table must not
     * preallocate 50 M fill values. Unwritten chunks read back as fill,
     * which is exactly "ADD COLUMN → old rows NULL".
     */
    H5Pset_alloc_time(dcpl, H5D_ALLOC_TIME_INCR);
    H5Pset_fill_time(dcpl, H5D_FILL_TIME_ALLOC);
    hid_t ftype = h5_file_type(ctx, kind);
    if (kind == COL_I64) {
        int64_t fill = H5_I64_NULL;
        H5Pset_fill_value(dcpl, H5T_NATIVE_INT64, &fill);
    } else if (kind == COL_F64) {
        double fill = NAN;
        H5Pset_fill_value(dcpl, H5T_NATIVE_DOUBLE, &fill);
    }
    c->dset = H5Dcreate2(gid, name, ftype, space, H5P_DEFAULT, dcpl, H5P_DEFAULT);
    H5Pclose(dcpl);
    H5Sclose(space);
    if (c->dset < 0) {
        pcap_core_log(PCAP_LOG_ERROR, "hdf5 dataset %s failed", name);
        return -1;
    }
    return 0;
}

static int col_flush(h5_ctx_t *ctx, h5_col_t *c, hsize_t count) {
    if (count == 0 || c->dset < 0)
        return 0;
    hsize_t newlen = c->nrows + count;
    if (H5Dset_extent(c->dset, &newlen) < 0) {
        pcap_core_log(PCAP_LOG_ERROR, "hdf5 extend %s failed", c->name);
        ctx->failed = 1;
        return -1;
    }
    hid_t fspace = H5Dget_space(c->dset);
    hsize_t offset = c->nrows;
    H5Sselect_hyperslab(fspace, H5S_SELECT_SET, &offset, NULL, &count, NULL);
    hid_t mspace = H5Screate_simple(1, &count, NULL);
    hid_t mt = h5_file_type(ctx, c->kind);
    herr_t wr = -1;
    switch (c->kind) {
    case COL_I64:
        wr = H5Dwrite(c->dset, mt, mspace, fspace, H5P_DEFAULT, c->i64->data);
        break;
    case COL_F64:
        wr = H5Dwrite(c->dset, mt, mspace, fspace, H5P_DEFAULT, c->f64->data);
        break;
    case COL_STR: {
        const char **ptrs = g_new(const char *, (guint)count);
        for (hsize_t i = 0; i < count; i++)
            ptrs[i] = g_ptr_array_index(c->str, (guint)i);
        wr = H5Dwrite(c->dset, mt, mspace, fspace, H5P_DEFAULT, ptrs);
        g_free(ptrs);
        break;
    }
    case COL_BYTES:
        wr = H5Dwrite(c->dset, mt, mspace, fspace, H5P_DEFAULT, c->blob->data);
        break;
    }
    H5Sclose(mspace);
    H5Sclose(fspace);
    if (wr < 0) {
        pcap_core_log(PCAP_LOG_ERROR, "hdf5 write %s failed", c->name);
        ctx->failed = 1;
        return -1;
    }
    c->nrows = newlen;
    col_clear_batch(c);
    return 0;
}

static void col_push_i64(h5_col_t *c, int64_t v) {
    g_array_append_val(c->i64, v);
}

static void col_push_f64(h5_col_t *c, double v) {
    g_array_append_val(c->f64, v);
}

static void col_push_str(h5_col_t *c, char *owned_or_null) {
    g_ptr_array_add(c->str, owned_or_null);
}

static void col_push_blob(h5_col_t *c, const void *p, size_t n) {
    hvl_t v = {0};
    if (p && n) {
        v.len = n;
        v.p = malloc(n);
        if (v.p)
            memcpy(v.p, p, n);
        else
            v.len = 0;
    }
    g_array_append_val(c->blob, v);
}

static void col_push_null(h5_col_t *c) {
    switch (c->kind) {
    case COL_I64:   col_push_i64(c, H5_I64_NULL); break;
    case COL_F64:   col_push_f64(c, NAN); break;
    case COL_STR:   col_push_str(c, NULL); break;
    case COL_BYTES: col_push_blob(c, NULL, 0); break;
    }
}

static void col_close(h5_col_t *c) {
    col_clear_batch(c);
    if (c->i64)  g_array_free(c->i64, TRUE);
    if (c->f64)  g_array_free(c->f64, TRUE);
    if (c->str)  g_ptr_array_free(c->str, TRUE);
    if (c->blob) g_array_free(c->blob, TRUE);
    if (c->dset >= 0)
        H5Dclose(c->dset);
    g_free(c->name);
}

static void col_free_ptr(gpointer p) {
    col_close(p);
    g_free(p);
}

static char *json_quote_cstr(const char *s) {
    GString *g = g_string_sized_new(16 + (s ? strlen(s) : 0));
    g_string_append_c(g, '"');
    for (const char *p = s ? s : ""; *p; p++) {
        unsigned char ch = (unsigned char)*p;
        switch (ch) {
        case '"':  g_string_append_len(g, "\\\"", 2); break;
        case '\\': g_string_append_len(g, "\\\\", 2); break;
        case '\b': g_string_append_len(g, "\\b", 2);  break;
        case '\f': g_string_append_len(g, "\\f", 2);  break;
        case '\n': g_string_append_len(g, "\\n", 2);  break;
        case '\r': g_string_append_len(g, "\\r", 2);  break;
        case '\t': g_string_append_len(g, "\\t", 2);  break;
        default:
            if (ch < 0x20) g_string_append_printf(g, "\\u%04x", ch);
            else           g_string_append_c(g, *p);
        }
    }
    g_string_append_c(g, '"');
    return g_string_free(g, FALSE);
}

static int looks_like_json(const char *s) {
    return s && (*s == '[' || *s == '{' || *s == '"');
}

static int table_flush_batch(h5_ctx_t *ctx, h5_table_t *t) {
    hsize_t n = (hsize_t)t->batch_n;
    if (n == 0)
        return 0;
    for (int i = 0; i < 6; i++) {
        if (col_flush(ctx, &t->meta[i], n) != 0)
            return -1;
    }
    for (guint i = 0; i < t->col_order->len; i++) {
        if (col_flush(ctx, g_ptr_array_index(t->col_order, i), n) != 0)
            return -1;
    }
    t->batch_n = 0;
    return 0;
}

static int flush_all(h5_ctx_t *ctx) {
    GHashTableIter it;
    gpointer k, v;
    g_hash_table_iter_init(&it, ctx->tables);
    while (g_hash_table_iter_next(&it, &k, &v)) {
        if (table_flush_batch(ctx, v) != 0)
            return -1;
    }
    ctx->pending_bytes = 0;
    if (ctx->file >= 0)
        H5Fflush(ctx->file, H5F_SCOPE_LOCAL);
    return ctx->failed ? -1 : 0;
}

static h5_table_t *h5_tbl(h5_ctx_t *c, const char *name) {
    return g_hash_table_lookup(c->tables, name);
}

static int h5_open_table(void *vctx, const char *table) {
    h5_ctx_t *c = vctx;
    if (h5_tbl(c, table))
        return 0;
    /*
     * Flat group: the identifier is the Postgres/SQLite table name.
     * H5Gcreate2 on the file handle creates /<table> in one hop.
     */
    hid_t gid = H5Gcreate2(c->file, table, H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
    if (gid < 0) {
        pcap_core_log(PCAP_LOG_ERROR, "hdf5 group %s failed", table);
        return -1;
    }
    h5_table_t *t = g_malloc0(sizeof *t);
    t->name = g_strdup(table);
    t->gid = gid;
    t->cols = g_hash_table_new_full(g_str_hash, g_str_equal, NULL, col_free_ptr);
    t->col_order = g_ptr_array_new();
    static const char *mn[] = {
        "ts_us", "src_ip", "dst_ip", "src_port", "dst_port", "frame_len"
    };
    static const col_kind_t mk[] = {
        COL_I64, COL_STR, COL_STR, COL_I64, COL_I64, COL_I64
    };
    for (int i = 0; i < 6; i++) {
        if (col_create(c, gid, &t->meta[i], mn[i], mk[i], 0) != 0) {
            g_ptr_array_free(t->col_order, TRUE);
            g_hash_table_destroy(t->cols);
            H5Gclose(gid);
            g_free(t->name);
            g_free(t);
            return -1;
        }
    }
    g_hash_table_insert(c->tables, t->name, t);
    pcap_core_log(PCAP_LOG_INFO, "created table \"%s\"", table);
    return 0;
}

static int h5_add_column(void *vctx, const char *table, const char *col, int ft) {
    h5_ctx_t *c = vctx;
    h5_table_t *t = h5_tbl(c, table);
    if (!t)
        return -1;
    if (g_hash_table_contains(t->cols, col))
        return 0;
    /* Core already flushed. meta[0].nrows is every committed row. */
    h5_col_t *hc = g_malloc0(sizeof *hc);
    if (col_create(c, t->gid, hc, col, kind_from_ft(ft), t->meta[0].nrows) != 0) {
        g_free(hc);
        return -1;
    }
    g_hash_table_insert(t->cols, hc->name, hc);
    g_ptr_array_add(t->col_order, hc);
    return 0;
}

static char *i64_to_json(int64_t v) {
    if (v == H5_I64_NULL)
        return NULL;
    char buf[32];
    snprintf(buf, sizeof buf, "%" PRId64, v);
    return g_strdup(buf);
}

static char *f64_to_json(double v) {
    if (!isfinite(v))
        return NULL;
    char buf[64];
    snprintf(buf, sizeof buf, "%.17g", v);
    return g_strdup(buf);
}

static char *bytes_to_json(const hvl_t *v) {
    if (!v || !v->p || v->len == 0)
        return NULL;
    GString *g = g_string_sized_new(2 + v->len * 2);
    g_string_append_c(g, '"');
    append_hex(g, v->p, v->len);
    g_string_append_c(g, '"');
    return g_string_free(g, FALSE);
}

static char *str_to_json(const char *s) {
    if (!s)
        return NULL;
    if (looks_like_json(s))
        return g_strdup(s);
    return json_quote_cstr(s);
}

static int promote_write_chunk(h5_ctx_t *ctx, hid_t dset, hid_t mt,
                               hsize_t offset, hsize_t count, char **ptrs) {
    hid_t fspace = H5Dget_space(dset);
    H5Sselect_hyperslab(fspace, H5S_SELECT_SET, &offset, NULL, &count, NULL);
    hid_t mspace = H5Screate_simple(1, &count, NULL);
    herr_t wr = H5Dwrite(dset, mt, mspace, fspace, H5P_DEFAULT, ptrs);
    H5Sclose(mspace);
    H5Sclose(fspace);
    for (hsize_t i = 0; i < count; i++)
        g_free(ptrs[i]);
    return wr < 0 ? -1 : 0;
}

static int h5_promote_json(void *vctx, const char *table, const char *col) {
    h5_ctx_t *c = vctx;
    h5_table_t *t = h5_tbl(c, table);
    if (!t)
        return -1;
    h5_col_t *hc = g_hash_table_lookup(t->cols, col);
    if (!hc)
        return -1;
    /*
     * Rewrite committed values to JSON text in H5_PROMOTE_ROWS windows.
     * Peak extra RAM is one window of source cells plus one window of
     * strdup'd JSON — not the whole column. Then swap the dataset name
     * so readers still see "<col>" with VL-string type.
     */
    hsize_t n = hc->nrows;
    const char *tmpn = "__promote_json";
    if (H5Lexists(t->gid, tmpn, H5P_DEFAULT) > 0)
        H5Ldelete(t->gid, tmpn, H5P_DEFAULT);
    h5_col_t neu;
    if (col_create(c, t->gid, &neu, tmpn, COL_STR, n) != 0)
        return -1;

    hid_t old_mt = h5_file_type(c, hc->kind);
    hid_t new_mt = c->vstr;
    int rc = 0;
    for (hsize_t off = 0; off < n && rc == 0; ) {
        hsize_t count = n - off;
        if (count > H5_PROMOTE_ROWS)
            count = H5_PROMOTE_ROWS;
        hid_t fspace = H5Dget_space(hc->dset);
        H5Sselect_hyperslab(fspace, H5S_SELECT_SET, &off, NULL, &count, NULL);
        hid_t mspace = H5Screate_simple(1, &count, NULL);
        char **ptrs = g_new0(char *, (guint)count);
        switch (hc->kind) {
        case COL_I64: {
            int64_t *buf = g_new(int64_t, (guint)count);
            if (H5Dread(hc->dset, old_mt, mspace, fspace, H5P_DEFAULT, buf) < 0)
                rc = -1;
            else {
                for (hsize_t i = 0; i < count; i++)
                    ptrs[i] = i64_to_json(buf[i]);
            }
            g_free(buf);
            break;
        }
        case COL_F64: {
            double *buf = g_new(double, (guint)count);
            if (H5Dread(hc->dset, old_mt, mspace, fspace, H5P_DEFAULT, buf) < 0)
                rc = -1;
            else {
                for (hsize_t i = 0; i < count; i++)
                    ptrs[i] = f64_to_json(buf[i]);
            }
            g_free(buf);
            break;
        }
        case COL_STR: {
            char **old = g_new0(char *, (guint)count);
            if (H5Dread(hc->dset, old_mt, mspace, fspace, H5P_DEFAULT, old) < 0)
                rc = -1;
            else {
                for (hsize_t i = 0; i < count; i++)
                    ptrs[i] = str_to_json(old[i]);
                H5Dvlen_reclaim(old_mt, mspace, H5P_DEFAULT, old);
            }
            g_free(old);
            break;
        }
        case COL_BYTES: {
            hvl_t *buf = g_new0(hvl_t, (guint)count);
            if (H5Dread(hc->dset, old_mt, mspace, fspace, H5P_DEFAULT, buf) < 0)
                rc = -1;
            else {
                for (hsize_t i = 0; i < count; i++)
                    ptrs[i] = bytes_to_json(&buf[i]);
                H5Dvlen_reclaim(old_mt, mspace, H5P_DEFAULT, buf);
            }
            g_free(buf);
            break;
        }
        }
        H5Sclose(mspace);
        H5Sclose(fspace);
        if (rc == 0)
            rc = promote_write_chunk(c, neu.dset, new_mt, off, count, ptrs);
        else {
            for (hsize_t i = 0; i < count; i++)
                g_free(ptrs[i]);
        }
        g_free(ptrs);
        off += count;
    }

    H5Dclose(hc->dset);
    hc->dset = H5I_INVALID_HID;
    col_close(&neu);
    if (rc != 0) {
        H5Ldelete(t->gid, tmpn, H5P_DEFAULT);
        return -1;
    }
    if (H5Ldelete(t->gid, hc->name, H5P_DEFAULT) < 0 ||
        H5Lmove(t->gid, tmpn, t->gid, hc->name, H5P_DEFAULT, H5P_DEFAULT) < 0) {
        pcap_core_log(PCAP_LOG_ERROR, "hdf5 rename %s.%s failed", table, col);
        return -1;
    }
    hc->dset = H5Dopen2(t->gid, hc->name, H5P_DEFAULT);
    if (hc->dset < 0)
        return -1;
    col_clear_batch(hc);
    if (hc->i64) { g_array_free(hc->i64, TRUE); hc->i64 = NULL; }
    if (hc->f64) { g_array_free(hc->f64, TRUE); hc->f64 = NULL; }
    if (hc->blob) { g_array_free(hc->blob, TRUE); hc->blob = NULL; }
    if (!hc->str)
        hc->str = g_ptr_array_sized_new(H5_BATCH_ROWS);
    hc->kind = COL_STR;
    return 0;
}

static void append_fi(h5_ctx_t *ctx, h5_col_t *c, field_info *fi) {
    if (!fi || !fi->hfinfo || !fi->value) {
        col_push_null(c);
        return;
    }
    int64_t iv;
    double dv;
    switch (c->kind) {
    case COL_I64:
        if (fi_int64(fi, &iv))
            col_push_i64(c, iv);
        else
            col_push_null(c);
        ctx->pending_bytes += 8;
        return;
    case COL_F64:
        if (fi_double(fi, &dv))
            col_push_f64(c, dv);
        else
            col_push_null(c);
        ctx->pending_bytes += 8;
        return;
    case COL_BYTES: {
        fvalue_t *fv = fi->value;
        const void *data = fvalue_get_bytes_data(fv);
        size_t sz = fvalue_get_bytes_size(fv);
        col_push_blob(c, data, sz);
        ctx->pending_bytes += sz;
        return;
    }
    case COL_STR: {
        const char *s = NULL;
        char *own = NULL;
        int ft = (int)fi->hfinfo->type;
        if (ft == FT_STRING || ft == FT_STRINGZ || ft == FT_UINT_STRING ||
            ft == FT_STRINGZPAD || ft == FT_STRINGZTRUNC) {
            s = fvalue_get_string(fi->value);
        } else {
            own = fvalue_to_string_repr(NULL, fi->value, FTREPR_DISPLAY, BASE_NONE);
            s = own;
        }
        col_push_str(c, s ? g_strdup(s) : NULL);
        if (s)
            ctx->pending_bytes += strlen(s);
        g_free(own);
        return;
    }
    }
}

static int h5_write_row(void *vctx, const char *table, const pcap_meta_t *meta,
                        field_col_t *fields, size_t n) {
    h5_ctx_t *c = vctx;
    h5_table_t *t = h5_tbl(c, table);
    if (!t)
        return -1;

    col_push_i64(&t->meta[0], meta->ts_us);
    col_push_str(&t->meta[1], meta->src_ip ? g_strdup(meta->src_ip) : NULL);
    col_push_str(&t->meta[2], meta->dst_ip ? g_strdup(meta->dst_ip) : NULL);
    col_push_i64(&t->meta[3], meta->src_port ? (int64_t)meta->src_port : H5_I64_NULL);
    col_push_i64(&t->meta[4], meta->dst_port ? (int64_t)meta->dst_port : H5_I64_NULL);
    col_push_i64(&t->meta[5], (int64_t)meta->frame_len);
    c->pending_bytes += 48 + (meta->src_ip ? strlen(meta->src_ip) : 0)
                            + (meta->dst_ip ? strlen(meta->dst_ip) : 0);

    for (size_t i = 0; i < n; i++) {
        if (!fields[i].in_sink)
            continue;
        h5_col_t *hc = g_hash_table_lookup(t->cols, fields[i].col);
        if (!hc) {
            pcap_core_log(PCAP_LOG_ERROR, "hdf5 missing dataset %s.%s", table, fields[i].col);
            return -1;
        }
        if (!field_hit(&fields[i])) {
            col_push_null(hc);
            continue;
        }
        if (fields[i].is_json || fields[i].n_hit > 1) {
            g_string_truncate(c->js, 0);
            write_json_cell(c->js, &fields[i]);
            col_push_str(hc, g_strdup(c->js->str));
            c->pending_bytes += c->js->len;
            if (c->js->allocated_len > (1u << 20)) {
                g_string_free(c->js, TRUE);
                c->js = g_string_sized_new(128);
            }
        } else {
            append_fi(c, hc, fc_fi(&fields[i], 0));
        }
    }

    t->batch_n++;
    if (t->batch_n >= H5_BATCH_ROWS || c->pending_bytes >= H5_BATCH_BYTES)
        return table_flush_batch(c, t);
    return 0;
}

static int h5_flush(void *vctx) {
    return flush_all(vctx);
}

static void table_free(gpointer p) {
    h5_table_t *t = p;
    /* Caller must have flushed. Drop any leftover batch so close is leak-free. */
    for (int i = 0; i < 6; i++)
        col_close(&t->meta[i]);
    if (t->col_order)
        g_ptr_array_free(t->col_order, TRUE);
    if (t->cols)
        g_hash_table_destroy(t->cols);
    if (t->gid >= 0)
        H5Gclose(t->gid);
    g_free(t->name);
    g_free(t);
}

static void h5_close(void *vctx) {
    h5_ctx_t *c = vctx;
    if (!c)
        return;
    flush_all(c);
    if (c->tables)
        g_hash_table_destroy(c->tables);
    if (c->js)
        g_string_free(c->js, TRUE);
    if (c->vstr >= 0)
        H5Tclose(c->vstr);
    if (c->vblob >= 0)
        H5Tclose(c->vblob);
    if (c->file >= 0)
        H5Fclose(c->file);
    g_free(c);
}

int main(int argc, char **argv) {
    pcap_core_cfg_t cfg;
    const char *out = NULL;
    int prc = pcap_core_parse_args(argc, argv, &cfg, &out, "pcap2hdf5",
                                   ".h5", "HDF5");
    if (prc != 0)
        return prc == 1 ? 0 : prc;

    H5Eset_auto2(H5E_DEFAULT, NULL, NULL);
    hid_t fapl = H5Pcreate(H5P_FILE_ACCESS);
    /*
     * Latest layout + a hard ceiling on the raw-data chunk cache. Without
     * the ceiling HDF5 will hold every recently-touched chunk of a wide
     * file; 8 MiB is enough for sequential append of a handful of live
     * tables and will not grow with pcap size. Alignment keeps objects
     * larger than 1 MiB on a 4 KiB boundary so the OS page cache can
     * absorb re-reads of the same chunk without extra copies.
     */
    H5Pset_libver_bounds(fapl, H5F_LIBVER_LATEST, H5F_LIBVER_LATEST);
    H5Pset_cache(fapl, 0, H5_RDCC_NSLOTS, H5_RDCC_NBYTES, 0.75);
    H5Pset_sieve_buf_size(fapl, 256 * 1024);
    H5Pset_alignment(fapl, 1024 * 1024, 4096);
    H5Pset_meta_block_size(fapl, 2 * 1024 * 1024);
    H5Pset_fclose_degree(fapl, H5F_CLOSE_STRONG);

    h5_ctx_t *c = g_malloc0(sizeof *c);
    c->file = H5I_INVALID_HID;
    c->vstr = H5I_INVALID_HID;
    c->vblob = H5I_INVALID_HID;
    c->file = H5Fcreate(out, H5F_ACC_TRUNC, H5P_DEFAULT, fapl);
    H5Pclose(fapl);
    if (c->file < 0) {
        fprintf(stderr, "hdf5 create %s failed\n", out);
        g_free(c);
        return 1;
    }
    c->vstr = H5Tcopy(H5T_C_S1);
    H5Tset_size(c->vstr, H5T_VARIABLE);
    H5Tset_cset(c->vstr, H5T_CSET_UTF8);
    hid_t bt = H5Tcopy(H5T_NATIVE_UCHAR);
    c->vblob = H5Tvlen_create(bt);
    H5Tclose(bt);
    c->tables = g_hash_table_new_full(g_str_hash, g_str_equal, NULL, table_free);
    c->js = g_string_sized_new(128);

    cfg.sink.ctx = c;
    cfg.sink.open_table = h5_open_table;
    cfg.sink.add_column = h5_add_column;
    cfg.sink.promote_json = h5_promote_json;
    cfg.sink.write_row = h5_write_row;
    cfg.sink.flush = h5_flush;
    cfg.sink.close = h5_close;
    return pcap_core_run(&cfg);
}
