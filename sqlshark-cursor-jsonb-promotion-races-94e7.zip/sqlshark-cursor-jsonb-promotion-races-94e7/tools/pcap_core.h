#ifndef PCAP_CORE_H
#define PCAP_CORE_H

/*
 * Shared offline ingest core for pcap2sqlite and pcap2hdf5.
 *
 * Goal
 * ----
 * Match dbshark's *logical* Postgres output: same table names, same six
 * meta columns, same per-protocol field columns, same first-use CREATE /
 * ALTER, same "scalar until a field repeats in one packet, then JSON".
 * The backends only change the physical store (SQLite rows vs HDF5
 * columnar datasets). They must not invent extra meta (no frame_no) and
 * must not pre-create every Wireshark field up front.
 *
 * Why a core instead of two copies
 * --------------------------------
 * The expensive, correctness-sensitive work is identical: epan session,
 * hidden proto tree, hfid priming, sibling walk that skips L2/L4, epoch
 * bucketing of field_info pointers, split-depth table/column names, and
 * JSON encoding of repeated cells. Duplicating that in each writer
 * drifted (pcap2sqlite used proto_find_finfo + unbounded ts history +
 * frame_no). One walk, two sinks.
 *
 * Memory
 * ------
 * Massive pcaps cannot keep a timestamp per frame or a proto_find_finfo
 * GPtrArray per column. Timestamps live in a 8192-slot ring (same as
 * dbshark). Hits are four inline pointers plus a grow-only extra[] that
 * is reused across packets. json_scratch is one GString. The sink is
 * required to flush on a byte budget so copy/insert buffers cannot grow
 * without bound. 16 MiB / 60 s is the commit cadence; the SQLite sink
 * overlaps those COMMITs on a writer thread.
 *
 * Cache
 * -----
 * hf_arr[hfid] is a direct load (Wireshark ids sit in the 60k–220k
 * range; the array is grown to max id). live_tables[] lists only
 * subtables that saw a mapped field this packet so emit does not scan
 * MAX_TABLES. field_col_t packs epoch/n_hit/is_json/in_sink/ft at the
 * front so "miss → NULL" is sequential. Hidden trees omit 240-byte GUI
 * labels. Prime mapped hfids every packet: proto_tree_reset() clears
 * ref_type and would otherwise fake repeated DIS fields.
 */

#include <stddef.h>
#include <stdint.h>
#include <glib.h>
#include <epan/proto.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PCAP_MAX_IDENT          63
#define PCAP_MAX_TABLES         512
#define PCAP_MAX_COLS_PER_TABLE 1590
#define PCAP_HIT_INLINE         4
#define PCAP_TS_HIST_CAP        8192
#define PCAP_FLUSH_EVERY_BYTES  (16u * 1024u * 1024u)
#define PCAP_FLUSH_EVERY_US     (60 * G_USEC_PER_SEC)

enum { PCAP_LOG_ERROR = 0, PCAP_LOG_WARN = 1, PCAP_LOG_INFO = 2, PCAP_LOG_DEBUG = 3 };

typedef struct field_col {
    unsigned     epoch;
    uint16_t     n_hit;
    uint8_t      is_json;
    uint8_t      in_sink;
    uint8_t      ft;
    field_info  *hit[PCAP_HIT_INLINE];
    field_info **extra;
    uint16_t     extra_n;
    uint16_t     extra_cap;
    int         *hf;
    size_t       n_hf;
    char        *col;
} field_col_t;

typedef struct {
    int64_t      ts_us;
    const char  *src_ip;
    const char  *dst_ip;
    unsigned     src_port;
    unsigned     dst_port;
    int          frame_len;
} pcap_meta_t;

/*
 * Backend contract. All pointers passed to write_row are valid only until
 * the call returns (they alias the current epan wmem tree). flush() must
 * make pending I/O durable enough that a later add_column / promote_json
 * can see a consistent on-disk shape.
 */
typedef struct pcap_sink {
    void *ctx;
    int (*open_table)(void *ctx, const char *table);
    int (*add_column)(void *ctx, const char *table, const char *col, int ft);
    int (*promote_json)(void *ctx, const char *table, const char *col);
    int (*write_row)(void *ctx, const char *table, const pcap_meta_t *meta,
                     field_col_t *fields, size_t n);
    int (*flush)(void *ctx);
    void (*close)(void *ctx);
} pcap_sink_t;

typedef struct {
    const char *infile;
    const char *plist[32];
    int         np;
    int         split_depth;
    int         log_level;
    int         progress;
    const char *progname;
    pcap_sink_t sink;
} pcap_core_cfg_t;

int         field_hit(const field_col_t *fc);
field_info *fc_fi(const field_col_t *fc, unsigned i);
int         fi_int64(field_info *fi, int64_t *out);
int         fi_double(field_info *fi, double *out);
void        json_append_fi(GString *out, field_info *fi);
void        write_json_cell(GString *dst, field_col_t *fc);
void        append_u64(GString *b, uint64_t v);
void        append_i64(GString *b, int64_t v);
void        append_hex(GString *b, const uint8_t *p, size_t n);
const char *ft2sql_name(int t);
int         pcap_core_run(const pcap_core_cfg_t *cfg);
void        pcap_core_log(int lvl, const char *fmt, ...);
void        pcap_core_usage(const char *argv0, const char *out_ext, const char *store);
int         pcap_core_parse_args(int argc, char **argv, pcap_core_cfg_t *cfg,
                                 const char **out_path, const char *progname,
                                 const char *out_ext, const char *store);

#ifdef __cplusplus
}
#endif

#endif
