#!/usr/bin/env perl
# Reset the one database dbshark writes.
#
# The result is an empty UTF-8 database: a writable public schema, the
# default search_path, and no statement, lock, or idle-in-transaction
# timeout. Other databases, roles, and server settings are left alone.
#
# Point it at that database the same way dbshark connects:
#
#   DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DBNAME
#   PGHOST=HOST PGPORT=5432 PGUSER=USER PGPASSWORD=... PGDATABASE=DBNAME
#
# PGHOST or a host in DATABASE_URL is required, so psql does not use a
# local socket. PGMAINT (default: postgres) is used only to drop and
# recreate PGDATABASE. If that is not allowed, the objects inside
# PGDATABASE are dropped instead.
use strict;
use warnings;
use Getopt::Long qw(GetOptions);

my $check = 0;
my $reset = 0;
my $help  = 0;
GetOptions(
    "check"  => \$check,
    "reset"  => \$reset,
    "help|h" => \$help,
) or die usage();
if ($help) {
    print usage();
    exit 0;
}
$reset = 1 if !$check;

sub first_env {
    for my $name (@_) {
        my $value = $ENV{$name};
        return $value if defined $value && $value ne "";
    }
    return undef;
}

my $url = first_env("DATABASE_URL", "POSTGRES_URL") // "";
my ($url_host, $url_port, $url_user, $url_pass, $url_db) = parse_url($url);

my $host     = first_env("PGHOST") // $url_host;
my $port     = first_env("PGPORT") // $url_port // "5432";
my $user     = first_env("PGUSER") // $url_user;
my $password = first_env("PGPASSWORD") // $url_pass;
my $workdb   = first_env("PGDATABASE") // $url_db;
my $maintdb  = first_env("PGMAINT") // "postgres";

$ENV{PGPASSWORD} = $password if defined $password && $password ne "";

sub usage {
    return <<'EOF';
usage: reset_pg.pl [--check|--reset]

Empty the database dbshark writes. Pass the same connection dbshark uses:

  DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DBNAME
  PGHOST=HOST PGPORT=5432 PGUSER=USER PGPASSWORD=... PGDATABASE=DBNAME

--reset is the default. It replaces that database when the maintenance
database (PGMAINT, default postgres) allows it, and otherwise drops the
objects inside it.

--check exits 1 when the database is not empty UTF-8 with a public
schema and no statement, lock, or idle-in-transaction timeout.
EOF
}

sub capture {
    my @cmd = @_;
    open(my $fh, "-|", @cmd) or return (1, "open failed: $!");
    local $/;
    my $out = <$fh> // "";
    close $fh;
    return ($? >> 8, $out);
}

sub parse_url {
    my ($u) = @_;
    return () unless $u;
    if ($u =~ m{^postgres(?:ql)?://
                ([^:/@]+)? (?::([^@]*))? @
                ([^:/]+) (?::(\d+))?
                /([^/?]+)}x) {
        my ($user, $pass, $host, $port, $db) = ($1, $2, $3, $4, $5);
        $pass =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/ge if defined $pass;
        return ($host, $port, $user, $pass, $db);
    }
    return ();
}

sub which {
    my ($bin) = @_;
    for my $dir (split /:/, ($ENV{PATH} // "")) {
        return "$dir/$bin" if $dir && -x "$dir/$bin";
    }
    return;
}

sub psql_cmd {
    my ($db, @extra) = @_;
    return ("psql", "-h", $host, "-p", $port, "-U", $user, "-d", $db,
            "-X", "-A", "-t", "-v", "ON_ERROR_STOP=1", @extra);
}

sub psql {
    my ($sql, $db) = @_;
    $db ||= $workdb;
    my ($rc, $out) = capture(psql_cmd($db, "-c", $sql));
    $out =~ s/\s+\z//;
    return ($rc, $out);
}

sub ident {
    my ($s) = @_;
    $s =~ s/"/""/g;
    return qq{"$s"};
}

sub lit {
    my ($s) = @_;
    $s =~ s/'/''/g;
    return qq{'$s'};
}

die "reset_pg: set PGDATABASE or DATABASE_URL to the database to reset.\n"
    unless $workdb;
die "reset_pg: set PGUSER or DATABASE_URL.\n" unless $user;
die "reset_pg: set PGHOST or DATABASE_URL. A host is required.\n" unless $host;
die "reset_pg: psql is not on PATH.\n" unless which("psql");

print "reset_pg: host=$host port=$port db=$workdb user=$user\n";
my ($prc, $pone) = psql("SELECT 1;", $workdb);
if ($prc != 0 && $workdb ne $maintdb) {
    ($prc, $pone) = psql("SELECT 1;", $maintdb);
}
die "reset_pg: cannot connect: $pone\n" if $prc != 0;

if ($reset) {
    print "reset_pg: resetting database $workdb\n";
    psql(
        "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
        . "WHERE pid <> pg_backend_pid() AND datname = " . lit($workdb) . ";",
        $workdb,
    );

    my ($mrc) = psql("SELECT 1;", $maintdb);
    if ($mrc == 0 && $workdb ne $maintdb) {
        psql("DROP DATABASE IF EXISTS " . ident($workdb) . " WITH (FORCE);", $maintdb);
        my ($crc, $cerr) = psql(
            "CREATE DATABASE " . ident($workdb) . " TEMPLATE template1 ENCODING 'UTF8';",
            $maintdb,
        );
        if ($crc != 0) {
            print "reset_pg: CREATE DATABASE failed ($cerr); wiping objects inside $workdb\n";
            psql("CREATE DATABASE " . ident($workdb) . ";", $maintdb);
        }
    }

    my ($wrc, $werr) = psql("SELECT 1;", $workdb);
    die "reset_pg: database $workdb is unreachable after reset: $werr\n" if $wrc != 0;

    psql("DROP SCHEMA IF EXISTS public CASCADE;", $workdb);
    psql("CREATE SCHEMA public;", $workdb);
    psql("GRANT USAGE, CREATE ON SCHEMA public TO PUBLIC;", $workdb);
    psql("GRANT ALL ON SCHEMA public TO " . ident($user) . ";", $workdb);
    psql("ALTER SCHEMA public OWNER TO " . ident($user) . ";", $workdb);

    psql("ALTER DATABASE " . ident($workdb) . " RESET ALL;", $maintdb) if $mrc == 0;
    psql("ALTER DATABASE " . ident($workdb) . " SET search_path TO \"\$user\", public;", $workdb);
    psql("ALTER DATABASE " . ident($workdb) . " SET statement_timeout = 0;", $workdb);
    psql("ALTER DATABASE " . ident($workdb) . " SET lock_timeout = 0;", $workdb);
    psql("ALTER DATABASE " . ident($workdb)
      . " SET idle_in_transaction_session_timeout = 0;", $workdb);
}

my $fail = 0;
my $ok = sub {
    my ($label, $cond, $detail) = @_;
    if ($cond) {
        print "ok   $label\n";
    }
    else {
        print "FAIL $label  $detail\n";
        $fail = 1;
    }
};

my ($rc, $enc) = psql(
    "SELECT pg_encoding_to_char(encoding) FROM pg_database WHERE datname = current_database();",
    $workdb,
);
$ok->("utf8", $rc == 0 && $enc eq "UTF8", $enc);

my ($rc2, $sp) = psql("SHOW search_path;", $workdb);
$ok->("search_path", $rc2 == 0 && $sp =~ /public/, $sp);

my ($rc3, $tabs) = psql(
    "SELECT count(*) FROM pg_tables WHERE schemaname NOT IN ('pg_catalog','information_schema');",
    $workdb,
);
$ok->("no leftover tables", $rc3 == 0 && $tabs eq "0", $tabs);

for my $guc (
    [ "statement_timeout",                   "0" ],
    [ "lock_timeout",                        "0" ],
    [ "idle_in_transaction_session_timeout", "0" ],
) {
    my ($grc, $gval) = psql("SHOW $guc->[0];", $workdb);
    my $clean = $gval;
    $clean =~ s/ms\z//;
    $ok->($guc->[0], $grc == 0 && $clean eq $guc->[1], $gval);
}

my ($rc6, $pub) = psql("SELECT nspname FROM pg_namespace WHERE nspname = 'public';", $workdb);
$ok->("public exists", $rc6 == 0 && $pub eq "public", $pub);

exit 1 if $check && $fail;
die "reset_pg: database $workdb is not in the expected state\n" if $fail;
print "reset_pg: $workdb is empty and ready\n" if $reset;
exit 0;
