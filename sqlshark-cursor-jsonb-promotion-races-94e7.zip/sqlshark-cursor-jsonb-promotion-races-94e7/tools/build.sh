#!/bin/sh
# Build the offline converters: pcap2sqlite and pcap2hdf5.
#
# Same Wireshark 4.2.x tree as the rest of logshark (libwireshark via rpath).
#   WS=$HOME/wireshark-4.2.6 ./tools/build.sh
#   CC=gcc ./tools/build.sh
#
# Output binaries land in $OUT (default: repo build/run). Offline only.

set -e
cd "$(dirname "$0")"
ROOT=$(cd .. && pwd)
OUT=${OUT:-$ROOT/build/run}
mkdir -p "$OUT"

WS=${WS:-$HOME/wireshark-4.2.6}
WSB=$WS/build
WSLIB=$WSB/run

find_wireshark_libdir() {
    if [ -f "$WSB/run/libwireshark.so" ] || ls "$WSB/run"/libwireshark.so.* >/dev/null 2>&1; then
        WSLIB=$WSB/run
        return 0
    fi
    if [ -f "$WSB/libwireshark.so" ] || ls "$WSB"/libwireshark.so.* >/dev/null 2>&1; then
        WSLIB=$WSB
        return 0
    fi
    return 1
}

if ! find_wireshark_libdir; then
    echo "error: libwireshark not found under $WSB/run or $WSB" >&2
    echo "build Wireshark 4.2.6 first (tests/dbshark/build/build-wireshark-4.2.6.sh), or set WS=." >&2
    exit 1
fi

if ! pkg-config --exists glib-2.0 2>/dev/null; then
    echo "error: glib-2.0 pkg-config not found." >&2
    echo "  Debian/Ubuntu: sudo apt-get install libglib2.0-dev pkg-config" >&2
    exit 1
fi

CC=${CC:-cc}
WS_CFLAGS="-I $WS -I $WS/include -I $WSB $(pkg-config --cflags glib-2.0)"
WS_LIBS="-L $WSLIB -Wl,-rpath,$WSLIB -lwireshark -lwiretap -lwsutil \
    $(pkg-config --libs glib-2.0) -lpcap -lpthread -lm -ldl"
COMMON_FLAGS="-O2 -g -Wall -Wextra -Wno-unused-parameter -std=gnu11"
OPT_FLAGS="-O3 -march=native -flto"

SQLITE_CFLAGS=$(pkg-config --cflags sqlite3 2>/dev/null || true)
SQLITE_LIBS=$(pkg-config --libs sqlite3 2>/dev/null || true)
if [ -z "$SQLITE_CFLAGS" ]; then
    for d in /usr/include /usr/local/include; do
        if [ -f "$d/sqlite3.h" ]; then
            SQLITE_CFLAGS="-I$d"
            SQLITE_LIBS="-lsqlite3"
            break
        fi
    done
fi
if [ -z "$SQLITE_LIBS" ]; then
    echo "warning: sqlite3 not found; skipping pcap2sqlite" >&2
    echo "  Debian/Ubuntu: sudo apt-get install libsqlite3-dev" >&2
else
    $CC $COMMON_FLAGS $OPT_FLAGS $WS_CFLAGS $SQLITE_CFLAGS \
        -o "$OUT/pcap2sqlite" pcap_core.c pcap2sqlite.c $WS_LIBS $SQLITE_LIBS
    echo "built $OUT/pcap2sqlite"
fi

HDF5_CFLAGS=${HDF5_CFLAGS:-$(pkg-config --cflags hdf5 2>/dev/null || pkg-config --cflags hdf5-serial 2>/dev/null || true)}
HDF5_LIBS=${HDF5_LIBS:-$(pkg-config --libs hdf5 2>/dev/null || pkg-config --libs hdf5-serial 2>/dev/null || true)}
if [ -z "$HDF5_CFLAGS" ]; then
    for d in /usr/include/hdf5/serial /usr/include /usr/local/include; do
        if [ -f "$d/hdf5.h" ]; then
            HDF5_CFLAGS="-I$d"
            HDF5_LIBS="-lhdf5"
            break
        fi
    done
fi
if [ -z "$HDF5_LIBS" ]; then
    echo "warning: hdf5 not found; skipping pcap2hdf5" >&2
    echo "  Debian/Ubuntu: sudo apt-get install libhdf5-dev" >&2
else
    $CC $COMMON_FLAGS $OPT_FLAGS $WS_CFLAGS $HDF5_CFLAGS \
        -o "$OUT/pcap2hdf5" pcap_core.c pcap2hdf5.c $WS_LIBS $HDF5_LIBS
    echo "built $OUT/pcap2hdf5"
fi
