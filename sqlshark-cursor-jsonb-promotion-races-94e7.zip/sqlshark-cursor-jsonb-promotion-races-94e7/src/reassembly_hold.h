#ifndef DBSHARK_REASSEMBLY_HOLD_H
#define DBSHARK_REASSEMBLY_HOLD_H

#include <stddef.h>
#include <stdint.h>

/* Packets that still belong to an unfinished TCP desegmentation or IP
 * fragmentation, copied out of Wireshark's file scope so a session
 * rotation can replay them. Wireshark 4.2.6 has one file scope; epan_t
 * does not own that state and it cannot be moved to another session.
 */

typedef struct {
    uint8_t *data;
    uint32_t caplen;
    int pkt_len;
    int encap;
    int64_t ts_us;
    uint64_t capture_seq;
    /* Built by the hold, not captured: a SYN that restores the
     * out-of-order edge of a direction. Never written as a row. */
    int synthetic;
} replay_pkt_t;

typedef struct {
    uint64_t completed;
    uint64_t expired_flows;
    uint64_t expired_packets;
    uint64_t incomplete_flows;
    uint64_t incomplete_packets;
    uint64_t lost_packets;
    uint64_t suppressed_retransmissions;
    uint64_t synthetic_syns;
    uint64_t hold_bytes;
    uint64_t hold_hwm;
} reassembly_counters_t;

/* active: rotation is on and reassembly was not disabled.
 * cap_bytes 0: no byte ceiling. idle_us 0: no time expiry.
 */
void reassembly_hold_configure(int active, uint64_t cap_bytes, int64_t idle_us);
int reassembly_hold_active(void);

/* Fully retransmitted TCP payload already stored. Caller skips dissection
 * so a later session does not treat it as a new message.
 */
int reassembly_hold_suppress(int encap, const uint8_t *data, uint32_t caplen);

void reassembly_hold_observe(int encap, const uint8_t *data, uint32_t caplen,
                             int pkt_len, int64_t ts_us, uint32_t session_frame,
                             uint64_t capture_seq, void *pinfo, int emitted_rows,
                             int is_replay);

/* Drop holds that have been idle in capture time or wall time. */
void reassembly_hold_tick(int64_t mono_us, int64_t capture_ts_us);

/* Move every held packet out, oldest capture_seq first. The new session
 * replays them; observe() copies back whatever is still unfinished.
 */
size_t reassembly_hold_take_replay(replay_pkt_t **out);
void reassembly_hold_release_replay(replay_pkt_t *pkts, size_t n);

void reassembly_hold_counters(reassembly_counters_t *out);
void reassembly_hold_shutdown(void);

#endif
