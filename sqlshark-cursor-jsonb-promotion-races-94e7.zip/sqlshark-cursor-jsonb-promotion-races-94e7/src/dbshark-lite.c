#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <ctype.h>
#include <glib.h>
#include <pcap/pcap.h>
#include <sqlite3.h>
#include <epan/epan.h>
#include <epan/epan_dissect.h>
#include <epan/proto.h>
#include <epan/tvbuff.h>
#include <epan/address.h>
#include <epan/to_str.h>
#include <epan/register.h>
#include <epan/wmem_scopes.h>
#include <epan/ftypes/ftypes.h>
#include <wiretap/wtap.h>
#include <wsutil/buffer.h>
#include <wsutil/filesystem.h>
#include <wsutil/privileges.h>
#include <wsutil/wslog.h>

/* Exported by libwireshark.so but not declared in any public header in 4.x;
 * the GUI/tshark/etc. each forward-declare these and wire them into
 * epan_app_data_t so epan_init can drive the per-dissector registration. */
extern void register_all_protocols(register_cb cb, void *client_data);
extern void register_all_protocol_handoffs(register_cb cb, void *client_data);

typedef struct { const char *name; int proto_id; int *hf; int *ft; size_t n; sqlite3_stmt *ins; } proto_t;

#define COMMIT_EVERY_N_ROWS 1000   /* successful INSERTs (sqlite3_step), not pcap packets */
#define COMMIT_EVERY_US     (60 * G_USEC_PER_SEC)

static sqlite3        *db;
static pcap_t         *pc;
static epan_t         *sess;
static epan_dissect_t *edt;
static proto_t        *protos;
static size_t          n_protos;
static guint32         fno;
static int             rows_since_commit;
static int64_t         last_commit_mono_us;

static void on_sig(int s) { (void)s; if (pc) pcap_breakloop(pc); }

static void db_fail(const char *what) {
    fprintf(stderr, "sqlite %s: %s\n", what, sqlite3_errmsg(db));
    if (pc) pcap_breakloop(pc);
}

static void maybe_commit(void) {
    int64_t now = g_get_monotonic_time();
    if (rows_since_commit < COMMIT_EVERY_N_ROWS &&
        now - last_commit_mono_us < COMMIT_EVERY_US)
        return;
    if (sqlite3_exec(db, "COMMIT; BEGIN", 0, 0, 0) != SQLITE_OK) {
        db_fail("commit");
        return;
    }
    rows_since_commit = 0;
    last_commit_mono_us = now;
}

static const char *ft2sql(int t) {
    switch (t) {
    case FT_NONE: case FT_PROTOCOL: return NULL;
    case FT_BOOLEAN: case FT_CHAR:
    case FT_UINT8: case FT_UINT16: case FT_UINT24: case FT_UINT32:
    case FT_UINT40: case FT_UINT48: case FT_UINT56: case FT_UINT64:
    case FT_INT8:  case FT_INT16:  case FT_INT24:  case FT_INT32:
    case FT_INT40: case FT_INT48:  case FT_INT56:  case FT_INT64:
    case FT_FRAMENUM:                                    return "INTEGER";
    case FT_FLOAT: case FT_DOUBLE:
    case FT_ABSOLUTE_TIME: case FT_RELATIVE_TIME:        return "REAL";
    case FT_BYTES: case FT_UINT_BYTES:                   return "BLOB";
    default:                                             return "TEXT";
    }
}

/* "dis.entity_id.x" -> "dis_entity_id_x" (caller frees) */
static char *san(const char *s) {
    size_t n = strlen(s); char *o = malloc(n + 2); size_t j = 0;
    if (!isalpha((unsigned char)s[0]) && s[0] != '_') o[j++] = '_';
    for (size_t i = 0; i < n; i++) {
        unsigned char c = s[i];
        o[j++] = (isalnum(c) || c == '_') ? tolower(c) : '_';
    }
    o[j] = 0; return o;
}

/* Minimal epan provider. HTTP (and other reassembly-heavy dissectors) call
 * epan_get_frame_ts() to look up past frames' timestamps (e.g. for http.time,
 * which is response_ts - request_ts). With no callback they'd spam warnings
 * and emit zeroed deltas. We keep a flat GArray of nstime_t indexed by
 * frame_num-1 -- frame numbers are monotonic from 1 and on_pkt pushes before
 * dissect_run, so the index always exists when the dissector asks. */
static GArray *g_ts_hist;
static const nstime_t *prov_ts(struct packet_provider_data *p, guint32 num) {
    (void)p;
    if (!g_ts_hist || num == 0 || num > g_ts_hist->len) return NULL;
    return &g_array_index(g_ts_hist, nstime_t, num - 1);
}
static wtap_block_t prov_mbk(struct packet_provider_data *p, const frame_data *f) {
    (void)p; (void)f; return NULL;
}
static const struct packet_provider_funcs g_prov = {
    .get_frame_ts       = prov_ts,
    .get_modified_block = prov_mbk,
};

/* Enumerate dissector fields -> CREATE TABLE -> prepare INSERT. Exit on error. */
static void build_proto(const char *name, proto_t *p) {
    p->name = name;
    p->proto_id = proto_get_id_by_filter_name(name);
    if (p->proto_id == -1) { fprintf(stderr, "unknown proto: %s\n", name); exit(1); }

    GHashTable *seen = g_hash_table_new(g_str_hash, g_str_equal);
    GArray *hf = g_array_new(0, 0, sizeof(int));
    GArray *ft = g_array_new(0, 0, sizeof(int));
    GPtrArray *cols = g_ptr_array_new();
    void *ck = NULL; header_field_info *h;
    for (h = proto_get_first_protocol_field(p->proto_id, &ck); h;
         h = proto_get_next_protocol_field (p->proto_id, &ck)) {
        if (!h->abbrev || !ft2sql(h->type) || g_hash_table_contains(seen, h->abbrev)) continue;
        g_hash_table_add(seen, (gpointer)h->abbrev);
        int id = h->id, t = h->type;
        g_array_append_val(hf, id);
        g_array_append_val(ft, t);
        g_ptr_array_add(cols, san(h->abbrev));
    }
    p->n = cols->len;

    GString *cre = g_string_new(NULL);
    GString *ins = g_string_new(NULL);
    g_string_printf(cre,
        "CREATE TABLE IF NOT EXISTS \"%s\" (ts_us INTEGER, src_ip TEXT, dst_ip TEXT, "
        "src_port INT, dst_port INT, frame_len INT", name);
    g_string_printf(ins, "INSERT INTO \"%s\" VALUES (?,?,?,?,?,?", name);
    for (size_t i = 0; i < p->n; i++) {
        char *c = g_ptr_array_index(cols, i);
        g_string_append_printf(cre, ", \"%s\" %s", c, ft2sql(g_array_index(ft, int, i)));
        g_string_append(ins, ",?");
        free(c);
    }
    g_string_append(cre, ")");
    g_string_append(ins, ")");

    char *err = NULL;
    if (sqlite3_exec(db, cre->str, 0, 0, &err) != SQLITE_OK) {
        fprintf(stderr, "create: %s\n", err); exit(1);
    }
    if (sqlite3_prepare_v2(db, ins->str, -1, &p->ins, NULL) != SQLITE_OK) {
        fprintf(stderr, "prepare: %s\n", sqlite3_errmsg(db)); exit(1);
    }

    p->hf = (int *)g_array_free(hf, FALSE);
    p->ft = (int *)g_array_free(ft, FALSE);
    g_ptr_array_free(cols, TRUE);
    g_hash_table_destroy(seen);
    g_string_free(cre, TRUE);
    g_string_free(ins, TRUE);
    fprintf(stderr, "[%s] %zu field columns\n", name, p->n);
}

/* Bind a single field instance natively (INTEGER / REAL / TEXT / BLOB).
 * Wireshark splits the integer accessors by width: fvalue_get_uinteger()
 * returns a uint32_t and asserts for FT_CHAR/FT_UINT8/16/24/32/FT_FRAMENUM/
 * FT_IPv4/FT_IEEE_11073_*; fvalue_get_uinteger64() is asserted-only for
 * FT_UINT40/48/56/64 and FT_BOOLEAN. Mixing them up triggers a ws_assert.
 * 4.x also removed the legacy void* fvalue_get() in favor of typed
 * accessors: fvalue_get_time / fvalue_get_string / fvalue_get_bytes_data. */
static void bind_fi(sqlite3_stmt *s, int idx, field_info *fi) {
    fvalue_t *fv = fi->value;       /* 4.x: field_info.value is a pointer */
    switch ((int)fi->hfinfo->type) {
    case FT_CHAR:
    case FT_UINT8: case FT_UINT16: case FT_UINT24: case FT_UINT32:
    case FT_FRAMENUM:
        sqlite3_bind_int64(s, idx, (sqlite3_int64)fvalue_get_uinteger(fv)); return;
    case FT_BOOLEAN:
    case FT_UINT40: case FT_UINT48: case FT_UINT56: case FT_UINT64:
        sqlite3_bind_int64(s, idx, (sqlite3_int64)fvalue_get_uinteger64(fv)); return;
    case FT_INT8: case FT_INT16: case FT_INT24: case FT_INT32:
        sqlite3_bind_int64(s, idx, (sqlite3_int64)fvalue_get_sinteger(fv)); return;
    case FT_INT40: case FT_INT48: case FT_INT56: case FT_INT64:
        sqlite3_bind_int64(s, idx, (sqlite3_int64)fvalue_get_sinteger64(fv)); return;
    case FT_FLOAT: case FT_DOUBLE:
        sqlite3_bind_double(s, idx, fvalue_get_floating(fv)); return;
    case FT_ABSOLUTE_TIME: case FT_RELATIVE_TIME: {
        const nstime_t *t = fvalue_get_time(fv);
        sqlite3_bind_double(s, idx, (double)t->secs + t->nsecs / 1e9); return;
    }
    case FT_BYTES: case FT_UINT_BYTES: {
        const void *data = fvalue_get_bytes_data(fv);
        size_t      sz   = fvalue_get_bytes_size(fv);
        sqlite3_bind_blob(s, idx, data, (int)sz, SQLITE_TRANSIENT); return;
    }
    case FT_STRING: case FT_STRINGZ: case FT_UINT_STRING:
    case FT_STRINGZPAD: case FT_STRINGZTRUNC:
        sqlite3_bind_text(s, idx, fvalue_get_string(fv), -1, SQLITE_TRANSIENT); return;
    default: {
        /* NULL allocator -> g_malloc; SQLITE_TRANSIENT copies before we free. */
        char *r = fvalue_to_string_repr(NULL, fv, FTREPR_DISPLAY, BASE_NONE);
        if (r) {
            sqlite3_bind_text(s, idx, r, -1, SQLITE_TRANSIENT);
            g_free(r);
        }
    }
    }
}

/* JSON-escape a string and append it (with surrounding quotes) to `out`. */
static void json_str(GString *out, const char *s) {
    g_string_append_c(out, '"');
    for (const char *p = s; *p; p++) {
        unsigned char c = (unsigned char)*p;
        switch (c) {
        case '"':  g_string_append(out, "\\\""); break;
        case '\\': g_string_append(out, "\\\\"); break;
        case '\b': g_string_append(out, "\\b");  break;
        case '\f': g_string_append(out, "\\f");  break;
        case '\n': g_string_append(out, "\\n");  break;
        case '\r': g_string_append(out, "\\r");  break;
        case '\t': g_string_append(out, "\\t");  break;
        default:
            if (c < 0x20) g_string_append_printf(out, "\\u%04x", c);
            else          g_string_append_c(out, *p);
        }
    }
    g_string_append_c(out, '"');
}

/* Append one field instance's value to a JSON-array-in-progress. */
static void json_append_fi(GString *out, field_info *fi) {
    if (!fi || !fi->hfinfo) { g_string_append(out, "null"); return; }
    fvalue_t *fv = fi->value;       /* 4.x: field_info.value is a pointer */
    switch ((int)fi->hfinfo->type) {
    case FT_BOOLEAN:
        g_string_append(out, fvalue_get_uinteger64(fv) ? "true" : "false"); return;
    case FT_CHAR:
    case FT_UINT8: case FT_UINT16: case FT_UINT24: case FT_UINT32:
    case FT_FRAMENUM:
        g_string_append_printf(out, "%u", fvalue_get_uinteger(fv)); return;
    case FT_UINT40: case FT_UINT48: case FT_UINT56: case FT_UINT64:
        g_string_append_printf(out, "%" G_GUINT64_FORMAT, fvalue_get_uinteger64(fv)); return;
    case FT_INT8: case FT_INT16: case FT_INT24: case FT_INT32:
        g_string_append_printf(out, "%d", fvalue_get_sinteger(fv)); return;
    case FT_INT40: case FT_INT48: case FT_INT56: case FT_INT64:
        g_string_append_printf(out, "%" G_GINT64_FORMAT, fvalue_get_sinteger64(fv)); return;
    case FT_FLOAT: case FT_DOUBLE:
        g_string_append_printf(out, "%.17g", fvalue_get_floating(fv)); return;
    case FT_ABSOLUTE_TIME: case FT_RELATIVE_TIME: {
        const nstime_t *t = fvalue_get_time(fv);
        if (!t) { g_string_append(out, "null"); return; }
        g_string_append_printf(out, "%.9f", (double)t->secs + t->nsecs / 1e9); return;
    }
    case FT_BYTES: case FT_UINT_BYTES: {
        const uint8_t *data = fvalue_get_bytes_data(fv);
        size_t         sz   = fvalue_get_bytes_size(fv);
        if (!data) { g_string_append(out, "null"); return; }
        g_string_append_c(out, '"');
        for (size_t i = 0; i < sz; i++) g_string_append_printf(out, "%02x", data[i]);
        g_string_append_c(out, '"'); return;
    }
    case FT_STRING: case FT_STRINGZ: case FT_UINT_STRING:
    case FT_STRINGZPAD: case FT_STRINGZTRUNC: {
        const char *s = fvalue_get_string(fv);
        if (!s) g_string_append(out, "null"); else json_str(out, s);
        return;
    }
    default: {
        char *r = fvalue_to_string_repr(NULL, fv, FTREPR_DISPLAY, BASE_NONE);
        if (!r) g_string_append(out, "null"); else { json_str(out, r); g_free(r); }
        return;
    }
    }
}

/* Bind whatever proto_find_finfo gave us:
 *   - 0 instances: leave NULL (already cleared by sqlite3_clear_bindings)
 *   - 1 instance:  bind native (INTEGER / REAL / TEXT / BLOB)
 *   - N instances: bind a JSON array as TEXT into the column (SQLite's
 *                  dynamic typing lets TEXT live in any column).
 */
static void bind_finfos(sqlite3_stmt *s, int idx, GPtrArray *fa) {
    if (!fa || fa->len == 0) return;
    if (fa->len == 1) { bind_fi(s, idx, g_ptr_array_index(fa, 0)); return; }
    GString *json = g_string_sized_new(64);
    g_string_append_c(json, '[');
    for (guint i = 0; i < fa->len; i++) {
        if (i) g_string_append_c(json, ',');
        json_append_fi(json, g_ptr_array_index(fa, i));
    }
    g_string_append_c(json, ']');
    sqlite3_bind_text(s, idx, json->str, -1, SQLITE_TRANSIENT);
    g_string_free(json, TRUE);
}

static void on_pkt(u_char *u, const struct pcap_pkthdr *h, const u_char *b) {
    (void)u;
    int64_t ts_us = (int64_t)h->ts.tv_sec * 1000000 + h->ts.tv_usec;

    /* In 4.x epan_dissect_run no longer takes a tvbuff_t; it builds one from
     * rec->data internally. So we copy the captured bytes into the wtap_rec's
     * Buffer rather than wrapping libpcap's buffer directly. One memcpy per
     * packet - costs ~ns at our packet sizes, not worth optimizing away.
     * wtap_setup_packet_rec sets rec_type, rec_type_name ("Packet") and the
     * encapsulation in one shot. rec_type_name being NULL would crash inside
     * the frame dissector's col_set_str(COL_PROTOCOL, rec_type_name). */
    wtap_rec r; wtap_rec_init(&r, h->caplen);
    wtap_setup_packet_rec(&r, WTAP_ENCAP_ETHERNET);
    ws_buffer_append(&r.data, b, h->caplen);
    r.presence_flags = WTAP_HAS_TS | WTAP_HAS_CAP_LEN;
    r.ts.secs  = (time_t)(ts_us / 1000000);
    r.ts.nsecs = (int)((ts_us % 1000000) * 1000);
    r.rec_header.packet_header.caplen = h->caplen;
    r.rec_header.packet_header.len    = h->len;
    frame_data fd; frame_data_init(&fd, ++fno, &r, 0, 0);

    g_array_append_val(g_ts_hist, fd.abs_ts);   /* makes prov_ts answerable */
    epan_dissect_run(edt, WTAP_FILE_TYPE_SUBTYPE_UNKNOWN, &r, &fd, NULL);

    packet_info *pi = &edt->pi;
    for (size_t k = 0; k < n_protos; k++) {
        proto_t *p = &protos[k];
        if (!pi->layers || !proto_is_frame_protocol(pi->layers, p->name)) continue;

        sqlite3_stmt *s = p->ins;
        sqlite3_reset(s); sqlite3_clear_bindings(s);
        sqlite3_bind_int64(s, 1, ts_us);
        /* IPv6 max is 45 chars + NUL; 64 is comfortable. address_to_str_buf
         * writes into a caller buffer with no wmem allocation - works in
         * both 3.6 and 4.x without worrying about wmem scope lifetime. */
        char src_buf[64], dst_buf[64];
        if (pi->net_src.type) {
            address_to_str_buf(&pi->net_src, src_buf, sizeof(src_buf));
            sqlite3_bind_text(s, 2, src_buf, -1, SQLITE_TRANSIENT);
        }
        if (pi->net_dst.type) {
            address_to_str_buf(&pi->net_dst, dst_buf, sizeof(dst_buf));
            sqlite3_bind_text(s, 3, dst_buf, -1, SQLITE_TRANSIENT);
        }
        if (pi->srcport)  sqlite3_bind_int(s, 4, pi->srcport);
        if (pi->destport) sqlite3_bind_int(s, 5, pi->destport);
        sqlite3_bind_int(s, 6, (int)h->len);

        for (size_t i = 0; i < p->n; i++) {
            GPtrArray *fa = proto_find_finfo(edt->tree, p->hf[i]);
            bind_finfos(s, 7 + (int)i, fa);
            if (fa) g_ptr_array_free(fa, TRUE);
        }
        if (sqlite3_step(s) != SQLITE_DONE) {
            db_fail("insert");
            break;
        }
        rows_since_commit++;
    }

    maybe_commit();

    /* epan_dissect_reset frees the per-packet wmem allocator and the tvb
     * epan built internally from rec->data. We own rec and fd, so we tear
     * them down explicitly. wtap_rec_cleanup also frees the Buffer in rec. */
    epan_dissect_reset(edt);
    frame_data_destroy(&fd);
    wtap_rec_cleanup(&r);
}

int main(int argc, char **argv) {
    const char *iface = NULL, *out = NULL, *bpf = NULL;
    const char *plist[32]; int np = 0;
    int c;
    while ((c = getopt(argc, argv, "i:o:p:f:")) != -1) {
        if      (c == 'i') iface  = optarg;
        else if (c == 'o') out    = optarg;
        else if (c == 'p') plist[np++] = optarg;
        else if (c == 'f') bpf    = optarg;
    }
    if (!iface || !out || np == 0) {
        fprintf(stderr,
            "usage: %s -i IFACE -o DB.sqlite -p PROTO [-p PROTO ...] [-f 'BPF']\n",
            argv[0]);
        return 2;
    }

    /* Initialize ws_log first so dot11decrypt etc. don't spam during
     * dissector registration. Env var alone isn't enough because some
     * dissectors log before ws_log lazy-init reads the env.
     * NOTE: ws_log_init signature in 4.x is (vcmdarg_err, console_title) -
     * the opposite order of 3.6's (app_name, vcmdarg_err). */
    g_setenv("WS_LOG_LEVEL", "warning", FALSE);
    ws_log_init(NULL, "dbshark");
    ws_log_set_level(LOG_LEVEL_WARNING);

    init_process_policies();
    /* 4.x init has two new prerequisites vs 3.6:
     *   1. configuration_init: records argv[0] (for progfile_dir) and the
     *      app "flavor" so filesystem helpers can build env-var names and
     *      find data dirs. Skipping it -> get_datafile_dir() segfaults.
     *   2. epan_init takes a non-optional epan_app_data_t whose
     *      env_var_prefix is dereferenced on entry (g_strdup). A NULL
     *      app_data crashes immediately.
     * We use "wireshark"/"WIRESHARK" so dissectors find their stock data
     * files; "dbshark" would just create empty private config dirs. */
    char *cfg_err = configuration_init(argv[0], "wireshark");
    if (cfg_err) { fprintf(stderr, "configuration_init: %s\n", cfg_err); return 1; }
    wtap_init(TRUE, "WIRESHARK", NULL, 0);
    /* register_func / handoff_func are the keys to dissector registration in
     * 4.x. libwireshark no longer auto-registers built-ins; epan_init invokes
     * these callbacks to drive every dissector's _register/_handoff function.
     * Forgetting them means proto_get_id_by_filter_name() returns -1 for
     * everything. */
    epan_app_data_t app_data = {
        .env_var_prefix = "WIRESHARK",
        .register_func  = register_all_protocols,
        .handoff_func   = register_all_protocol_handoffs,
    };
    if (!epan_init(NULL, NULL, TRUE, &app_data)) {
        fprintf(stderr, "epan_init failed\n"); return 1;
    }
    /* epan_load_settings triggers per-subsystem init (maxmind GeoIP, name
     * resolution, plugins, disabled-protocols list). Skipping it leaves
     * subsystems with uninitialized internal hash tables and the first IP
     * packet segfaults inside maxmind_db_lookup -> wmem_map_lookup. */
    epan_load_settings();

    if (sqlite3_open(out, &db) != SQLITE_OK) {
        fprintf(stderr, "open %s: %s\n", out, sqlite3_errmsg(db)); return 1;
    }
    sqlite3_exec(db, "PRAGMA journal_mode=WAL;PRAGMA synchronous=NORMAL;", 0, 0, 0);

    protos = calloc(np, sizeof(proto_t));
    n_protos = np;
    for (int i = 0; i < np; i++) build_proto(plist[i], &protos[i]);

    g_ts_hist = g_array_new(FALSE, FALSE, sizeof(nstime_t));
    sess = epan_new(NULL, &g_prov);
    /* proto_tree_visible=TRUE: with FALSE many dissectors (incl. http) still
     * skip adding sub-fields in 4.x as an optimization, so proto_find_finfo
     * returns empty even though pi->layers shows the protocol fired. We pay
     * a small CPU cost for the textual representation, but get every field. */
    edt  = epan_dissect_new(sess, TRUE, TRUE);

    char eb[PCAP_ERRBUF_SIZE];
    pc = pcap_open_live(iface, 65535, 1, 100, eb);
    if (!pc) { fprintf(stderr, "pcap_open_live(%s): %s\n", iface, eb); return 1; }
    if (bpf) {
        struct bpf_program prog;
        if (pcap_compile(pc, &prog, bpf, 1, PCAP_NETMASK_UNKNOWN) < 0 ||
            pcap_setfilter(pc, &prog) < 0) {
            fprintf(stderr, "bpf: %s\n", pcap_geterr(pc)); return 1;
        }
        pcap_freecode(&prog);
    }

    signal(SIGINT,  on_sig);
    signal(SIGTERM, on_sig);
    fprintf(stderr, "capturing on %s -> %s\n", iface, out);

    last_commit_mono_us = g_get_monotonic_time();
    if (sqlite3_exec(db, "BEGIN", 0, 0, 0) != SQLITE_OK) {
        fprintf(stderr, "sqlite begin: %s\n", sqlite3_errmsg(db));
        return 1;
    }
    pcap_loop(pc, -1, on_pkt, NULL);
    if (sqlite3_exec(db, "COMMIT", 0, 0, 0) != SQLITE_OK)
        fprintf(stderr, "sqlite commit: %s\n", sqlite3_errmsg(db));

    pcap_close(pc);
    epan_dissect_free(edt);
    epan_free(sess);
    g_array_free(g_ts_hist, TRUE);
    for (size_t i = 0; i < n_protos; i++) sqlite3_finalize(protos[i].ins);
    sqlite3_close(db);
    epan_cleanup();
    wtap_cleanup();
    return 0;
}