#include "reassembly_hold.h"

#include <epan/address.h>
#include <epan/conversation.h>
#include <epan/dissectors/packet-tcp.h>
#include <epan/packet.h>
#include <epan/packet_info.h>
#include <epan/prefs.h>
#include <epan/prefs-int.h>
#include <glib.h>
#include <stdlib.h>
#include <string.h>
#include <wiretap/wtap.h>

/* Flow keys are canonical (lower address first) so both directions share
 * one hold. IP fragment keys keep the original source: fragment ids are
 * per sender.
 */

typedef struct {
    uint32_t ip_id;
    uint16_t port_lo, port_hi;
    uint8_t ver, proto, addr_len, pad;
    uint8_t addr_lo[16];
    uint8_t addr_hi[16];
} flow_key_t;

typedef struct {
    uint32_t ip_id;
    uint8_t ver, proto, addr_len, pad;
    uint8_t src[16];
    uint8_t dst[16];
} ip_key_t;

typedef struct held_pkt {
    uint8_t *data;
    uint32_t caplen;
    uint32_t effective_frame;
    int pkt_len;
    int encap;
    int64_t ts_us;
    uint64_t capture_seq;
    struct held_pkt *next;
} held_pkt_t;

typedef struct {
    int have;
    int have_emitted;
    /* A SYN in this direction was seen, and a later segment is queued
     * ahead of maxnextseq. Replay must recreate that edge: Wireshark
     * only treats a segment as out-of-order when maxnextseq is non-zero,
     * which it sets from a SYN. The bytes cannot be copied out of the
     * file scope, so the new session gets a SYN at ooo_edge-1.
     */
    int need_ooo_syn;
    uint32_t ooo_edge;
    uint32_t base;
    uint32_t seen_next;
    uint32_t emitted_next;
} seq_cursor_t;

typedef struct flow {
    flow_key_t key;
    held_pkt_t *head, *tail;
    size_t n_pkts;
    int64_t last_ts_us;
    int64_t last_mono_us;
    int desynced;
    seq_cursor_t dir[2];
} flow_t;

typedef struct ip_group {
    ip_key_t key;
    held_pkt_t *head, *tail;
    size_t n_pkts;
    int64_t last_ts_us;
    int64_t last_mono_us;
    int dead;
    int saw_first;
    int saw_last;
    uint32_t total_end;
    uint32_t cov_s[64];
    uint32_t cov_e[64];
    size_t n_cov;
} ip_group_t;

typedef struct {
    int have_tcp;
    int dir;
    uint32_t l3_off;
    uint32_t l4_off;
    uint32_t tcp_seq;
    uint32_t tcp_payload;
    int is_frag;
    int frag_mf;
    uint32_t frag_off;
    uint32_t frag_end;
    flow_key_t flow;
    ip_key_t ip;
} parsed_pkt_t;

static int active;
static int shut_down;
static int relative_seq;
static uint64_t cap_bytes;
static int64_t idle_us;
static uint64_t hold_bytes;
static uint64_t hold_hwm;
static int64_t newest_ts;
static int cap_warned;
static GHashTable *flows;
static GHashTable *groups;

static reassembly_counters_t ctr;

enum {
    HOLD_TCP = 6,
    HOLD_UDP = 17,
    HOLD_IPV6_FRAG = 44,
    HOLD_HOPOPTS = 0,
    HOLD_ROUTING = 43,
    HOLD_DSTOPTS = 60,
    HOLD_AH = 51
};

static guint mem_hash(const void *p, size_t n) {
    const uint8_t *b = p;
    guint h = 2166136261u;
    for (size_t i = 0; i < n; i++) {
        h ^= b[i];
        h *= 16777619u;
    }
    return h;
}

static guint flow_hash(gconstpointer p) { return mem_hash(p, sizeof(flow_key_t)); }
static guint ip_hash(gconstpointer p) { return mem_hash(p, sizeof(ip_key_t)); }

static gboolean flow_equal(gconstpointer a, gconstpointer b) {
    return memcmp(a, b, sizeof(flow_key_t)) == 0;
}
static gboolean ip_equal(gconstpointer a, gconstpointer b) {
    return memcmp(a, b, sizeof(ip_key_t)) == 0;
}

static uint16_t rd16(const uint8_t *p) {
    return (uint16_t)((p[0] << 8) | p[1]);
}
static uint32_t rd32(const uint8_t *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | p[3];
}

/* seq <= end, with the usual TCP window. Lengths here are packet-sized. */
static int seq_leq(uint32_t a, uint32_t b) {
    return (int32_t)(a - b) <= 0;
}

static void note_bytes(size_t n, int add) {
    if (add) {
        hold_bytes += n;
        if (hold_bytes > hold_hwm)
            hold_hwm = hold_bytes;
    } else if (hold_bytes >= n) {
        hold_bytes -= n;
    } else {
        hold_bytes = 0;
    }
}

static void free_list(held_pkt_t *p) {
    while (p) {
        held_pkt_t *n = p->next;
        note_bytes(p->caplen, 0);
        g_free(p->data);
        g_free(p);
        p = n;
    }
}

static held_pkt_t *copy_pkt(int encap, const uint8_t *data, uint32_t caplen,
                            int pkt_len, int64_t ts_us, uint32_t frame,
                            uint64_t capture_seq) {
    held_pkt_t *h = g_new0(held_pkt_t, 1);
    h->data = g_memdup2(data, caplen);
    h->caplen = caplen;
    h->pkt_len = pkt_len;
    h->encap = encap;
    h->ts_us = ts_us;
    h->effective_frame = frame;
    h->capture_seq = capture_seq;
    note_bytes(caplen, 1);
    return h;
}

static void append_pkt(held_pkt_t **head, held_pkt_t **tail, size_t *n, held_pkt_t *h) {
    h->next = NULL;
    if (*tail)
        (*tail)->next = h;
    else
        *head = h;
    *tail = h;
    (*n)++;
}

static void fill_flow_key(flow_key_t *k, int ver, int proto, const uint8_t *src,
                          const uint8_t *dst, int addr_len, uint16_t sport,
                          uint16_t dport, int *dir) {
    memset(k, 0, sizeof(*k));
    k->ver = (uint8_t)ver;
    k->proto = (uint8_t)proto;
    k->addr_len = (uint8_t)addr_len;
    int cmp = memcmp(src, dst, (size_t)addr_len);
    int src_lo = cmp < 0 || (cmp == 0 && sport <= dport);
    memcpy(src_lo ? k->addr_lo : k->addr_hi, src, (size_t)addr_len);
    memcpy(src_lo ? k->addr_hi : k->addr_lo, dst, (size_t)addr_len);
    k->port_lo = src_lo ? sport : dport;
    k->port_hi = src_lo ? dport : sport;
    if (dir)
        *dir = src_lo ? 0 : 1;
}

static int l3_off(int encap, const uint8_t *data, uint32_t caplen, uint32_t *off,
                  uint16_t *ethertype) {
    uint32_t o = 0;
    uint16_t et = 0;
    if (encap == WTAP_ENCAP_ETHERNET) {
        if (caplen < 14)
            return 0;
        o = 14;
        et = rd16(data + 12);
        while ((et == 0x8100 || et == 0x88a8 || et == 0x9100) && caplen >= o + 4) {
            et = rd16(data + o + 2);
            o += 4;
        }
    } else if (encap == WTAP_ENCAP_SLL) {
        if (caplen < 16)
            return 0;
        o = 16;
        et = rd16(data + 14);
    } else if (encap == WTAP_ENCAP_SLL2) {
        if (caplen < 20)
            return 0;
        o = 20;
        et = rd16(data);
    } else if (encap == WTAP_ENCAP_NULL || encap == WTAP_ENCAP_LOOP) {
        if (caplen < 4)
            return 0;
        uint32_t fam = rd32(data);
        uint32_t fam_le = (uint32_t)data[0] | ((uint32_t)data[1] << 8) |
                          ((uint32_t)data[2] << 16) | ((uint32_t)data[3] << 24);
        o = 4;
        if (fam == 2 || fam_le == 2 || fam == 0x00000002)
            et = 0x0800;
        else if (fam == 10 || fam == 24 || fam == 28 || fam == 30 ||
                 fam_le == 10 || fam_le == 24 || fam_le == 28 || fam_le == 30)
            et = 0x86dd;
        else
            return 0;
    } else if (encap == WTAP_ENCAP_RAW_IP || encap == WTAP_ENCAP_RAW_IP4 ||
               encap == WTAP_ENCAP_RAW_IP6) {
        if (!caplen)
            return 0;
        o = 0;
        et = (data[0] >> 4) == 6 ? 0x86dd : 0x0800;
    } else {
        return 0;
    }
    *off = o;
    *ethertype = et;
    return 1;
}

static int parse_packet(int encap, const uint8_t *data, uint32_t caplen, parsed_pkt_t *out) {
    memset(out, 0, sizeof(*out));
    uint32_t off = 0;
    uint16_t et = 0;
    if (!data || !caplen || !l3_off(encap, data, caplen, &off, &et))
        return 0;
    const uint8_t *l4 = NULL;
    uint32_t l4_len = 0;
    int proto = 0;
    int ver = 0;
    const uint8_t *src = NULL, *dst = NULL;
    int addr_len = 0;

    if (et == 0x0800) {
        if (caplen < off + 20)
            return 0;
        const uint8_t *ip = data + off;
        int ihl = (ip[0] & 0x0f) * 4;
        if (ihl < 20 || caplen < off + (uint32_t)ihl)
            return 0;
        uint16_t tot = rd16(ip + 2);
        uint16_t frag = rd16(ip + 6);
        int mf = (frag & 0x2000) != 0;
        uint32_t foff = (uint32_t)(frag & 0x1fff) * 8u;
        uint32_t payload = 0;
        if (tot >= (uint16_t)ihl)
            payload = (uint32_t)tot - (uint32_t)ihl;
        if (off + (uint32_t)ihl + payload > caplen)
            payload = caplen - (off + (uint32_t)ihl);
        ver = 4;
        proto = ip[9];
        src = ip + 12;
        dst = ip + 16;
        addr_len = 4;
        if (mf || foff) {
            out->is_frag = 1;
            out->frag_mf = mf;
            out->frag_off = foff;
            out->frag_end = foff + payload;
            memset(&out->ip, 0, sizeof(out->ip));
            out->ip.ip_id = rd16(ip + 4);
            out->ip.ver = 4;
            out->ip.proto = (uint8_t)proto;
            out->ip.addr_len = 4;
            memcpy(out->ip.src, src, 4);
            memcpy(out->ip.dst, dst, 4);
        }
        if (foff == 0) {
            l4 = ip + ihl;
            l4_len = payload;
            out->l3_off = off;
            out->l4_off = off + (uint32_t)ihl;
        }
    } else if (et == 0x86dd) {
        if (caplen < off + 40)
            return 0;
        const uint8_t *ip = data + off;
        uint32_t plen = rd16(ip + 4);
        proto = ip[6];
        src = ip + 8;
        dst = ip + 24;
        addr_len = 16;
        ver = 6;
        uint32_t pos = off + 40;
        uint32_t limit = off + 40 + plen;
        if (limit > caplen)
            limit = caplen;
        int hops = 0;
        while (hops++ < 8 && (proto == HOLD_HOPOPTS || proto == HOLD_ROUTING ||
                              proto == HOLD_DSTOPTS || proto == HOLD_AH ||
                              proto == HOLD_IPV6_FRAG)) {
            if (pos + 8 > caplen)
                return 0;
            int nxt = data[pos];
            if (proto == HOLD_IPV6_FRAG) {
                uint16_t offlg = rd16(data + pos + 2);
                int mf = offlg & 0x1;
                uint32_t foff = (uint32_t)(offlg >> 3) * 8u;
                uint32_t payload = (pos + 8 < limit) ? limit - (pos + 8) : 0;
                out->is_frag = 1;
                out->frag_mf = mf;
                out->frag_off = foff;
                out->frag_end = foff + payload;
                memset(&out->ip, 0, sizeof(out->ip));
                out->ip.ip_id = rd32(data + pos + 4);
                out->ip.ver = 6;
                out->ip.proto = (uint8_t)nxt;
                out->ip.addr_len = 16;
                memcpy(out->ip.src, src, 16);
                memcpy(out->ip.dst, dst, 16);
                proto = nxt;
                if (foff == 0) {
                    l4 = data + pos + 8;
                    l4_len = payload;
                    out->l3_off = off;
                    out->l4_off = pos + 8;
                }
                break;
            }
            uint32_t hdr = (proto == HOLD_AH) ? (uint32_t)(data[pos + 1] + 2) * 4u
                                              : (uint32_t)(data[pos + 1] + 1) * 8u;
            if (hdr < 8 || pos + hdr > caplen)
                return 0;
            proto = nxt;
            pos += hdr;
        }
        if (!out->is_frag && pos < limit) {
            l4 = data + pos;
            l4_len = limit - pos;
            out->l3_off = off;
            out->l4_off = pos;
        }
    } else {
        return 0;
    }

    if (l4 && (proto == HOLD_TCP || proto == HOLD_UDP) && l4_len >= (proto == HOLD_TCP ? 20u : 8u)) {
        uint16_t sport = rd16(l4);
        uint16_t dport = rd16(l4 + 2);
        fill_flow_key(&out->flow, ver, proto, src, dst, addr_len, sport, dport, &out->dir);
        if (proto == HOLD_TCP && l4_len >= 20) {
            int doff = ((l4[12] >> 4) & 0x0f) * 4;
            if (doff >= 20 && (uint32_t)doff <= l4_len) {
                out->have_tcp = 1;
                out->tcp_seq = rd32(l4 + 4);
                out->tcp_payload = l4_len - (uint32_t)doff;
            }
        }
    }
    return 1;
}

static void touch_seq(seq_cursor_t *d, uint32_t seq, uint32_t len) {
    if (!len)
        return;
    uint32_t end = seq + len;
    if (!d->have) {
        d->have = 1;
        d->base = seq;
        d->seen_next = seq;
    }
    if (seq_leq(seq, d->seen_next) && !seq_leq(end, d->seen_next))
        d->seen_next = end;
}

static void destroy_flow(gpointer v) {
    flow_t *f = v;
    free_list(f->head);
    g_free(f);
}

static void destroy_group(gpointer v) {
    ip_group_t *g = v;
    free_list(g->head);
    g_free(g);
}

static flow_t *flow_get(const flow_key_t *key, int create) {
    if (!flows)
        flows = g_hash_table_new_full(flow_hash, flow_equal, NULL, destroy_flow);
    flow_t *f = g_hash_table_lookup(flows, key);
    if (f || !create)
        return f;
    f = g_new0(flow_t, 1);
    f->key = *key;
    g_hash_table_insert(flows, &f->key, f);
    return f;
}

static ip_group_t *group_get(const ip_key_t *key, int create) {
    if (!groups)
        groups = g_hash_table_new_full(ip_hash, ip_equal, NULL, destroy_group);
    ip_group_t *g = g_hash_table_lookup(groups, key);
    if (g || !create)
        return g;
    g = g_new0(ip_group_t, 1);
    g->key = *key;
    g_hash_table_insert(groups, &g->key, g);
    return g;
}

typedef struct {
    int any;
    int keep_all;
    uint32_t min_frame;
} open_state_t;

static bool msp_cb(const void *key, void *value, void *ud) {
    (void)key;
    const struct tcp_multisegment_pdu *msp = value;
    open_state_t *st = ud;
    if (msp->flags & MSP_FLAGS_GOT_ALL_SEGMENTS)
        return false;
    st->any = 1;
    uint32_t frame = msp->first_frame;
    if (msp->first_frame_with_seq && msp->first_frame_with_seq < frame)
        frame = msp->first_frame_with_seq;
    if (frame && frame < st->min_frame)
        st->min_frame = frame;
    return false;
}

static void scan_tcp_flow(const tcp_flow_t *flow, open_state_t *st) {
    if (flow->flags & TCP_FLOW_REASSEMBLE_UNTIL_FIN) {
        st->any = 1;
        st->keep_all = 1;
    }
    if (flow->ooo_segments && wmem_list_count(flow->ooo_segments) > 0) {
        st->any = 1;
        st->keep_all = 1;
    }
    if (flow->multisegment_pdus)
        wmem_tree_foreach(flow->multisegment_pdus, msp_cb, st);
}

/* 0 = not TCP, 1 = TCP with nothing unfinished, 2 = unfinished.
 * have_ooo / ooo_edge describe the current packet's direction: Wireshark
 * leaves maxnextseq at the contiguous edge when it queues a gap.
 */
static int tcp_open_state(packet_info *pi, uint32_t *min_frame, int *keep_all,
                          int *have_ooo, uint32_t *ooo_edge) {
    *min_frame = G_MAXUINT32;
    *keep_all = 0;
    *have_ooo = 0;
    *ooo_edge = 0;
    if (!pi || pi->ptype != PT_TCP)
        return 0;
    conversation_t *conv = find_conversation_pinfo(pi, 0);
    if (!conv)
        return 1;
    struct tcp_analysis *tcpd = get_tcp_conversation_data(conv, pi);
    if (!tcpd)
        return 1;
    open_state_t st = { .any = 0, .keep_all = 0, .min_frame = G_MAXUINT32 };
    scan_tcp_flow(&tcpd->flow1, &st);
    scan_tcp_flow(&tcpd->flow2, &st);
    if (tcpd->fwd && tcpd->fwd->ooo_segments &&
        wmem_list_count(tcpd->fwd->ooo_segments) > 0 && tcpd->fwd->maxnextseq) {
        *have_ooo = 1;
        /* packet-tcp.c rewrites th_seq to a relative number before it
         * records maxnextseq when both prefs are on; our parser sees the
         * wire value. base_seq is the public offset between them. */
        *ooo_edge = tcpd->fwd->maxnextseq + (relative_seq ? tcpd->fwd->base_seq : 0);
    }
    if (!st.any)
        return 1;
    *keep_all = st.keep_all;
    *min_frame = st.keep_all ? 0 : st.min_frame;
    return 2;
}

static void expire_flow_hold(flow_t *f) {
    f->dir[0].need_ooo_syn = 0;
    f->dir[1].need_ooo_syn = 0;
    if (!f->head)
        return;
    ctr.expired_flows++;
    ctr.expired_packets += f->n_pkts;
    free_list(f->head);
    f->head = f->tail = NULL;
    f->n_pkts = 0;
    f->desynced = 1;
}

static void expire_group(ip_group_t *g) {
    if (g->dead && !g->head)
        return;
    if (g->head) {
        ctr.expired_flows++;
        ctr.expired_packets += g->n_pkts;
        free_list(g->head);
        g->head = g->tail = NULL;
        g->n_pkts = 0;
    }
    g->dead = 1;
    g->n_cov = 0;
    g->saw_first = g->saw_last = 0;
}

static void enforce_cap(void) {
    if (!cap_bytes)
        return;
    while (hold_bytes > cap_bytes) {
        flow_t *oldest_f = NULL;
        ip_group_t *oldest_g = NULL;
        int64_t oldest = INT64_MAX;
        if (flows) {
            GHashTableIter it;
            gpointer v;
            g_hash_table_iter_init(&it, flows);
            while (g_hash_table_iter_next(&it, NULL, &v)) {
                flow_t *f = v;
                if (!f->head)
                    continue;
                if (f->last_mono_us < oldest) {
                    oldest = f->last_mono_us;
                    oldest_f = f;
                    oldest_g = NULL;
                }
            }
        }
        if (groups) {
            GHashTableIter it;
            gpointer v;
            g_hash_table_iter_init(&it, groups);
            while (g_hash_table_iter_next(&it, NULL, &v)) {
                ip_group_t *g = v;
                if (!g->head)
                    continue;
                if (g->last_mono_us < oldest) {
                    oldest = g->last_mono_us;
                    oldest_g = g;
                    oldest_f = NULL;
                }
            }
        }
        if (!oldest_f && !oldest_g)
            break;
        if (!cap_warned) {
            cap_warned = 1;
            g_warning("dbshark reassembly hold exceeded cap; expiring unfinished messages");
        }
        if (oldest_f)
            expire_flow_hold(oldest_f);
        else
            expire_group(oldest_g);
    }
}

static void trim_flow(flow_t *f, uint32_t min_frame, int keep_all) {
    if (keep_all || min_frame == 0)
        return;
    while (f->head && f->head->effective_frame < min_frame) {
        held_pkt_t *n = f->head->next;
        note_bytes(f->head->caplen, 0);
        g_free(f->head->data);
        g_free(f->head);
        f->head = n;
        f->n_pkts--;
        if (!f->head)
            f->tail = NULL;
    }
}

static void clear_flow_hold(flow_t *f, int completed) {
    if (!f->head)
        return;
    if (completed)
        ctr.completed++;
    free_list(f->head);
    f->head = f->tail = NULL;
    f->n_pkts = 0;
}

static void add_coverage(ip_group_t *g, uint32_t s, uint32_t e) {
    if (e < s || g->n_cov >= G_N_ELEMENTS(g->cov_s))
        return;
    g->cov_s[g->n_cov] = s;
    g->cov_e[g->n_cov] = e;
    g->n_cov++;
    for (size_t i = 1; i < g->n_cov; i++) {
        uint32_t cs = g->cov_s[i], ce = g->cov_e[i];
        size_t j = i;
        while (j > 0 && g->cov_s[j - 1] > cs) {
            g->cov_s[j] = g->cov_s[j - 1];
            g->cov_e[j] = g->cov_e[j - 1];
            j--;
        }
        g->cov_s[j] = cs;
        g->cov_e[j] = ce;
    }
    size_t w = 0;
    for (size_t i = 0; i < g->n_cov; i++) {
        if (w && g->cov_s[i] <= g->cov_e[w - 1]) {
            if (g->cov_e[i] > g->cov_e[w - 1])
                g->cov_e[w - 1] = g->cov_e[i];
        } else {
            g->cov_s[w] = g->cov_s[i];
            g->cov_e[w] = g->cov_e[i];
            w++;
        }
    }
    g->n_cov = w;
}

static int coverage_complete(const ip_group_t *g) {
    if (!g->saw_first || !g->saw_last)
        return 0;
    uint32_t at = 0;
    for (size_t i = 0; i < g->n_cov && at < g->total_end; i++) {
        if (g->cov_s[i] > at)
            return 0;
        if (g->cov_e[i] > at)
            at = g->cov_e[i];
    }
    return at >= g->total_end;
}

static int flow_key_from_pi(packet_info *pi, flow_key_t *key, int *dir) {
    if (!pi || pi->ptype != PT_TCP)
        return 0;
    const address *s = &pi->net_src;
    const address *d = &pi->net_dst;
    if (!s->data || !d->data || s->type != d->type)
        return 0;
    int ver = 0;
    if (s->type == AT_IPv4 && s->len == 4)
        ver = 4;
    else if (s->type == AT_IPv6 && s->len == 16)
        ver = 6;
    else
        return 0;
    if (pi->srcport > 65535 || pi->destport > 65535)
        return 0;
    fill_flow_key(key, ver, HOLD_TCP, s->data, d->data, s->len,
                  (uint16_t)pi->srcport, (uint16_t)pi->destport, dir);
    return 1;
}

static void move_group_to_flow(ip_group_t *g, flow_t *f, uint32_t frame) {
    for (held_pkt_t *p = g->head; p; p = p->next)
        p->effective_frame = frame;
    if (g->tail) {
        if (f->tail)
            f->tail->next = g->head;
        else
            f->head = g->head;
        f->tail = g->tail;
        f->n_pkts += g->n_pkts;
    }
    /* Packets now belong to the flow. destroy_group must not free them. */
    g->head = g->tail = NULL;
    g->n_pkts = 0;
    g_hash_table_remove(groups, &g->key);
}

static void drop_group(ip_group_t *g, int completed) {
    if (completed && g->n_pkts)
        ctr.completed++;
    g_hash_table_remove(groups, &g->key);
}

static int stale_time(int64_t last_ts, int64_t last_mono, int64_t now_mono, int64_t now_cap) {
    if (idle_us <= 0)
        return 0;
    if (last_mono && now_mono > last_mono && now_mono - last_mono > idle_us)
        return 1;
    if (last_ts && now_cap > last_ts && now_cap - last_ts > idle_us)
        return 1;
    return 0;
}

static int tcp_pref_bool(const char *name, int dflt) {
    module_t *m = prefs_find_module("tcp");
    pref_t *p = m ? prefs_find_preference(m, name) : NULL;
    return p ? (prefs_get_bool_value(p, pref_current) ? 1 : 0) : dflt;
}

/* Call after prefs_apply_all: relative_seq is read once from the TCP
 * preferences in force for this process. */
void reassembly_hold_configure(int on, uint64_t cap, int64_t idle) {
    active = on ? 1 : 0;
    cap_bytes = cap;
    idle_us = idle < 0 ? 0 : idle;
    shut_down = 0;
    relative_seq = tcp_pref_bool("analyze_sequence_numbers", 1) &&
                   tcp_pref_bool("relative_sequence_numbers", 1);
}

int reassembly_hold_active(void) { return active; }

int reassembly_hold_suppress(int encap, const uint8_t *data, uint32_t caplen) {
    if (!active)
        return 0;
    parsed_pkt_t p;
    if (!parse_packet(encap, data, caplen, &p) || !p.have_tcp || p.is_frag || !p.tcp_payload)
        return 0;
    flow_t *f = flow_get(&p.flow, 0);
    if (!f)
        return 0;
    seq_cursor_t *d = &f->dir[p.dir];
    if (!d->have_emitted)
        return 0;
    uint32_t end = p.tcp_seq + p.tcp_payload;
    if (seq_leq(d->base, p.tcp_seq) && seq_leq(end, d->emitted_next)) {
        ctr.suppressed_retransmissions++;
        return 1;
    }
    return 0;
}

void reassembly_hold_observe(int encap, const uint8_t *data, uint32_t caplen,
                             int pkt_len, int64_t ts_us, uint32_t session_frame,
                             uint64_t capture_seq, void *pinfo_v, int emitted_rows,
                             int is_replay) {
    if (!active || shut_down || !data || !caplen)
        return;
    packet_info *pi = pinfo_v;
    if (ts_us > newest_ts)
        newest_ts = ts_us;
    int64_t mono = g_get_monotonic_time();
    parsed_pkt_t p;
    if (!parse_packet(encap, data, caplen, &p))
        return;

    if (p.is_frag) {
        ip_group_t *g = group_get(&p.ip, 1);
        if (stale_time(g->last_ts_us, g->last_mono_us, mono, ts_us))
            expire_group(g);
        g->last_ts_us = ts_us;
        g->last_mono_us = mono;
        if (!g->dead) {
            append_pkt(&g->head, &g->tail, &g->n_pkts,
                       copy_pkt(encap, data, caplen, pkt_len, ts_us, session_frame, capture_seq));
            add_coverage(g, p.frag_off, p.frag_end);
            if (p.frag_off == 0)
                g->saw_first = 1;
            if (!p.frag_mf) {
                g->saw_last = 1;
                g->total_end = p.frag_end;
            }
        } else {
            ctr.lost_packets++;
        }
        if (!coverage_complete(g)) {
            enforce_cap();
            return;
        }
        uint32_t min_frame = 0;
        int keep_all = 0, have_ooo = 0;
        uint32_t ooo_edge = 0;
        int tcp = tcp_open_state(pi, &min_frame, &keep_all, &have_ooo, &ooo_edge);
        if (tcp == 2) {
            flow_key_t fk;
            int dir = 0;
            if (!flow_key_from_pi(pi, &fk, &dir) && p.have_tcp) {
                fk = p.flow;
                dir = p.dir;
            }
            if (fk.proto == HOLD_TCP || p.have_tcp) {
                if (!flow_key_from_pi(pi, &fk, &dir))
                    fk = p.flow;
                flow_t *f = flow_get(&fk, 1);
                f->last_ts_us = ts_us;
                f->last_mono_us = mono;
                f->dir[dir].need_ooo_syn = have_ooo;
                f->dir[dir].ooo_edge = ooo_edge;
                int starts_here = !keep_all && min_frame == session_frame;
                if (f->desynced && !starts_here) {
                    ctr.lost_packets++;
                    drop_group(g, 0);
                    return;
                }
                if (f->desynced && starts_here)
                    f->desynced = 0;
                move_group_to_flow(g, f, session_frame);
                trim_flow(f, min_frame, keep_all);
                enforce_cap();
                return;
            }
        }
        drop_group(g, 1);
        if (tcp == 1 && p.have_tcp) {
            flow_t *f = flow_get(&p.flow, 0);
            if (f)
                clear_flow_hold(f, 1);
        }
        return;
    }

    if (!p.have_tcp)
        return;

    flow_t *f = flow_get(&p.flow, 1);
    if (stale_time(f->last_ts_us, f->last_mono_us, mono, ts_us) && f->head)
        expire_flow_hold(f);
    f->last_ts_us = ts_us;
    f->last_mono_us = mono;

    if (!is_replay)
        touch_seq(&f->dir[p.dir], p.tcp_seq, p.tcp_payload);
    if (emitted_rows && !is_replay) {
        seq_cursor_t *d = &f->dir[p.dir];
        if (d->have) {
            d->emitted_next = d->seen_next;
            d->have_emitted = 1;
        }
    }

    uint32_t min_frame = 0;
    int keep_all = 0, have_ooo = 0;
    uint32_t ooo_edge = 0;
    int tcp = tcp_open_state(pi, &min_frame, &keep_all, &have_ooo, &ooo_edge);
    int starts_here = tcp == 2 && !keep_all && min_frame == session_frame;
    if (f->desynced && tcp == 2 && !starts_here) {
        if (p.tcp_payload)
            ctr.lost_packets++;
        return;
    }
    if (f->desynced && (emitted_rows || starts_here))
        f->desynced = 0;

    if (tcp != 2) {
        f->dir[0].need_ooo_syn = 0;
        f->dir[1].need_ooo_syn = 0;
        clear_flow_hold(f, 1);
        return;
    }
    f->dir[p.dir].need_ooo_syn = have_ooo;
    f->dir[p.dir].ooo_edge = ooo_edge;
    append_pkt(&f->head, &f->tail, &f->n_pkts,
               copy_pkt(encap, data, caplen, pkt_len, ts_us, session_frame, capture_seq));
    trim_flow(f, min_frame, keep_all);
    enforce_cap();
}

static gboolean tick_flow(gpointer key, gpointer value, gpointer user) {
    (void)key;
    flow_t *f = value;
    const int64_t *t = user;
    if (!stale_time(f->last_ts_us, f->last_mono_us, t[0], t[1]))
        return FALSE;
    if (f->head)
        expire_flow_hold(f);
    /* Value destructor frees the flow. A later packet starts a new one. */
    return TRUE;
}

static gboolean tick_group(gpointer key, gpointer value, gpointer user) {
    (void)key;
    ip_group_t *g = value;
    const int64_t *t = user;
    if (!stale_time(g->last_ts_us, g->last_mono_us, t[0], t[1]))
        return FALSE;
    if (g->head)
        expire_group(g);
    return TRUE;
}

void reassembly_hold_tick(int64_t mono_us, int64_t capture_ts_us) {
    if (!active || idle_us <= 0)
        return;
    if (capture_ts_us > newest_ts)
        newest_ts = capture_ts_us;
    int64_t t[2] = { mono_us, newest_ts };
    if (flows)
        g_hash_table_foreach_remove(flows, tick_flow, t);
    if (groups)
        g_hash_table_foreach_remove(groups, tick_group, t);
}

static size_t count_list(const held_pkt_t *p) {
    size_t n = 0;
    for (; p; p = p->next)
        n++;
    return n;
}

static size_t drain_list(held_pkt_t **head, held_pkt_t **tail, size_t *n_pkts,
                         replay_pkt_t *dst, size_t at) {
    held_pkt_t *p = *head;
    while (p) {
        held_pkt_t *n = p->next;
        dst[at].data = p->data;
        dst[at].caplen = p->caplen;
        dst[at].pkt_len = p->pkt_len;
        dst[at].encap = p->encap;
        dst[at].ts_us = p->ts_us;
        dst[at].capture_seq = p->capture_seq;
        note_bytes(p->caplen, 0);
        g_free(p);
        at++;
        p = n;
    }
    *head = *tail = NULL;
    *n_pkts = 0;
    return at;
}

/* Wireshark queues a TCP segment as out-of-order only when the flow has
 * a contiguous edge (maxnextseq), which a fresh session gets from a SYN.
 * Build a payload-free SYN from a held packet's own link, IP, and TCP
 * headers so the replayed gap is queued again instead of being handed
 * to the subdissector as the start of the stream. Its sequence number
 * sits one before the lowest byte the new session will see in this
 * direction, so nothing replayed looks like a retransmission.
 */
static int synth_syn(flow_t *f, int dir, replay_pkt_t *dst) {
    seq_cursor_t *d = &f->dir[dir];
    if (!d->need_ooo_syn)
        return 0;
    held_pkt_t *tmpl = NULL;
    parsed_pkt_t tp;
    uint32_t lowest = d->ooo_edge;
    for (held_pkt_t *h = f->head; h; h = h->next) {
        parsed_pkt_t q;
        if (!parse_packet(h->encap, h->data, h->caplen, &q) || !q.have_tcp ||
            q.is_frag || q.dir != dir)
            continue;
        if (seq_leq(q.tcp_seq, lowest) && q.tcp_seq != lowest)
            lowest = q.tcp_seq;
        if (!tmpl || h->capture_seq < tmpl->capture_seq) {
            tmpl = h;
            tp = q;
        }
    }
    if (!tmpl)
        return 0;
    uint32_t len = tp.l4_off + 20;
    if (len > tmpl->caplen)
        return 0;
    uint8_t *b = g_memdup2(tmpl->data, len);
    uint8_t *ip = b + tp.l3_off;
    if ((ip[0] >> 4) == 4) {
        uint16_t tot = (uint16_t)(len - tp.l3_off);
        ip[2] = (uint8_t)(tot >> 8);
        ip[3] = (uint8_t)tot;
        ip[6] = ip[7] = 0;
        ip[10] = ip[11] = 0;
    } else {
        uint16_t plen = (uint16_t)(len - tp.l3_off - 40);
        ip[4] = (uint8_t)(plen >> 8);
        ip[5] = (uint8_t)plen;
    }
    uint8_t *tcp = b + tp.l4_off;
    uint32_t seq = lowest - 1;
    tcp[4] = (uint8_t)(seq >> 24);
    tcp[5] = (uint8_t)(seq >> 16);
    tcp[6] = (uint8_t)(seq >> 8);
    tcp[7] = (uint8_t)seq;
    memset(tcp + 8, 0, 4);
    tcp[12] = 5 << 4;
    tcp[13] = 0x02;
    memset(tcp + 16, 0, 4);
    dst->data = b;
    dst->caplen = len;
    dst->pkt_len = (int)len;
    dst->encap = tmpl->encap;
    dst->ts_us = tmpl->ts_us;
    dst->capture_seq = tmpl->capture_seq;
    dst->synthetic = 1;
    ctr.synthetic_syns++;
    return 1;
}

static int cmp_replay(const void *a, const void *b) {
    const replay_pkt_t *pa = a;
    const replay_pkt_t *pb = b;
    if (pa->capture_seq < pb->capture_seq)
        return -1;
    if (pa->capture_seq > pb->capture_seq)
        return 1;
    return pb->synthetic - pa->synthetic;
}

size_t reassembly_hold_take_replay(replay_pkt_t **out) {
    *out = NULL;
    if (!active)
        return 0;
    size_t n = 0;
    if (flows) {
        GHashTableIter it;
        gpointer v;
        g_hash_table_iter_init(&it, flows);
        while (g_hash_table_iter_next(&it, NULL, &v)) {
            flow_t *f = v;
            if (f->head)
                n += count_list(f->head) + 2; /* room for one SYN per direction */
        }
    }
    if (groups) {
        GHashTableIter it;
        gpointer v;
        g_hash_table_iter_init(&it, groups);
        while (g_hash_table_iter_next(&it, NULL, &v))
            n += count_list(((ip_group_t *)v)->head);
    }
    if (!n)
        return 0;
    replay_pkt_t *pkts = g_new0(replay_pkt_t, n);
    size_t at = 0;
    if (flows) {
        GHashTableIter it;
        gpointer v;
        g_hash_table_iter_init(&it, flows);
        while (g_hash_table_iter_next(&it, NULL, &v)) {
            flow_t *f = v;
            if (!f->head)
                continue;
            for (int dir = 0; dir < 2; dir++)
                at += synth_syn(f, dir, &pkts[at]);
            at = drain_list(&f->head, &f->tail, &f->n_pkts, pkts, at);
        }
    }
    if (groups) {
        GHashTableIter it;
        gpointer v;
        g_hash_table_iter_init(&it, groups);
        while (g_hash_table_iter_next(&it, NULL, &v)) {
            ip_group_t *g = v;
            at = drain_list(&g->head, &g->tail, &g->n_pkts, pkts, at);
        }
    }
    if (at > 1)
        qsort(pkts, at, sizeof(*pkts), cmp_replay);
    *out = pkts;
    return at;
}

void reassembly_hold_release_replay(replay_pkt_t *pkts, size_t n) {
    if (!pkts)
        return;
    for (size_t i = 0; i < n; i++)
        g_free(pkts[i].data);
    g_free(pkts);
}

void reassembly_hold_counters(reassembly_counters_t *out) {
    ctr.hold_bytes = hold_bytes;
    ctr.hold_hwm = hold_hwm;
    *out = ctr;
}

static void count_flow_left(gpointer key, gpointer value, gpointer user) {
    (void)key;
    (void)user;
    flow_t *f = value;
    if (f->head && f->n_pkts) {
        ctr.incomplete_flows++;
        ctr.incomplete_packets += f->n_pkts;
    }
}

static void count_group_left(gpointer key, gpointer value, gpointer user) {
    (void)key;
    (void)user;
    ip_group_t *g = value;
    if (g->head && g->n_pkts) {
        ctr.incomplete_flows++;
        ctr.incomplete_packets += g->n_pkts;
    }
}

void reassembly_hold_shutdown(void) {
    if (shut_down)
        return;
    if (flows)
        g_hash_table_foreach(flows, count_flow_left, NULL);
    if (groups)
        g_hash_table_foreach(groups, count_group_left, NULL);
    if (flows) {
        GHashTable *old = flows;
        flows = NULL;
        g_hash_table_destroy(old);
    }
    if (groups) {
        GHashTable *old = groups;
        groups = NULL;
        g_hash_table_destroy(old);
    }
    shut_down = 1;
    active = 0;
}
