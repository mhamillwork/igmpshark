#!/usr/bin/env bash
# Apply a proto→port JSON map to a Wireshark config dir for dbshark.
#
# Wireshark (and dbshark, via epan_load_settings) binds dissectors to the ports
# in each protocol's Decode-As range preference, e.g. dis.udp.port. This writes
# those preferences and matching decode_as_entries.
#
# Needs jq or python3 to parse the JSON map.
#
# JSON — key is the Wireshark filter name (tshark -G protocols):
#
#   { "dis": [3000, 9999], "asterix": { "udp": [8600, 8601], "tcp": [8600] } }
#
# A bare list is applied to both udp.port and tcp.port. Unknown prefs (DIS has
# no tcp.port preference) are ignored at load time.
#
# Usage:
#   scripts/set_dissector_ports.sh ports.json --config-dir ./ws-config
#   export WIRESHARK_CONFIG_DIR=$PWD/ws-config
#   ./build/run/dbshark -i lo -p dis -f "$(scripts/set_dissector_ports.sh ports.json --print-bpf)" ...
set -euo pipefail

usage() {
    sed -n '2,20p' "$0" | sed 's/^# \?//'
    echo "Options: --config-dir DIR  --print-bpf  --dry-run"
    exit "${1:-2}"
}

JSON=""
CONFIG_DIR="${WIRESHARK_CONFIG_DIR:-$PWD/ws-config}"
PRINT_BPF=0
DRY_RUN=0

while [ $# -gt 0 ]; do
    case "$1" in
        -h|--help) usage 0 ;;
        --config-dir)
            [ $# -ge 2 ] || usage
            CONFIG_DIR=$2
            shift 2
            ;;
        --print-bpf) PRINT_BPF=1; shift ;;
        --dry-run)   DRY_RUN=1; shift ;;
        --) shift; break ;;
        -*) echo "unknown option: $1" >&2; usage ;;
        *)
            if [ -z "$JSON" ]; then JSON=$1; shift
            else echo "unexpected argument: $1" >&2; usage
            fi
            ;;
    esac
done

[ -n "$JSON" ] || usage
[ -f "$JSON" ] || { echo "not a file: $JSON" >&2; exit 1; }

# TSV rows: proto  table  value
# table is udp.port / tcp.port / sctp.port, or decode_as (value = short name)
json_rows() {
    local file=$1
    if command -v jq >/dev/null 2>&1; then
        jq -r '
            def as_ports:
              if type == "number" then [.]
              elif type == "array" then map(tonumber)
              else error("ports must be an int or list of ints") end;
            def emit($p; $table; $ports):
              ($ports | unique)[] | [$p, $table, tostring] | @tsv;
            [to_entries[] | .key as $p | .value as $v |
              if ($v | type) == "number" or ($v | type) == "array" then
                ($v | as_ports) as $ports |
                emit($p; "udp.port"; $ports),
                emit($p; "tcp.port"; $ports)
              elif ($v | type) == "object" then
                (if $v.decode_as then [$p, "decode_as", ($v.decode_as | tostring)] | @tsv else empty end),
                (if $v.udp  then emit($p; "udp.port";  ($v.udp  | as_ports)) else empty end),
                (if $v.tcp  then emit($p; "tcp.port";  ($v.tcp  | as_ports)) else empty end),
                (if $v.sctp then emit($p; "sctp.port"; ($v.sctp | as_ports)) else empty end),
                (if $v.ports then
                   emit($p; "udp.port"; ($v.ports | as_ports)),
                   emit($p; "tcp.port"; ($v.ports | as_ports))
                 else empty end)
              else
                error("unsupported mapping for \($p)")
              end
            ] | .[]
        ' "$file"
        return
    fi
    if command -v python3 >/dev/null 2>&1; then
        python3 - "$file" <<'PY'
import json, sys
path = sys.argv[1]
with open(path, encoding="utf-8") as f:
    data = json.load(f)
if not isinstance(data, dict):
    sys.exit("JSON root must be an object of proto → ports")

def ports(val):
    if isinstance(val, int):
        val = [val]
    if not isinstance(val, list):
        raise SystemExit(f"ports must be an int or list of ints, got {val!r}")
    out, seen = [], set()
    for p in val:
        n = int(p)
        if n < 1 or n > 65535:
            raise SystemExit(f"port out of range: {n}")
        if n not in seen:
            seen.add(n)
            out.append(n)
    return out

def emit(proto, table, plist):
    for p in plist:
        print(f"{proto}\t{table}\t{p}")

for proto, spec in data.items():
    if isinstance(spec, (int, list)):
        plist = ports(spec)
        emit(proto, "udp.port", plist)
        emit(proto, "tcp.port", plist)
    elif isinstance(spec, dict):
        if spec.get("decode_as"):
            print(f"{proto}\tdecode_as\t{spec['decode_as']}")
        if any(k in spec for k in ("udp", "tcp", "sctp")):
            for key, table in (("udp", "udp.port"), ("tcp", "tcp.port"), ("sctp", "sctp.port")):
                if key in spec:
                    emit(proto, table, ports(spec[key]))
        elif "ports" in spec:
            plist = ports(spec["ports"])
            emit(proto, "udp.port", plist)
            emit(proto, "tcp.port", plist)
        else:
            raise SystemExit(f"{proto}: expected list or {{udp, tcp, sctp, ports}}")
    else:
        raise SystemExit(f"{proto}: unsupported mapping {spec!r}")
PY
        return
    fi
    echo "error: need jq or python3 to read $file" >&2
    exit 1
}

ROWS=$(json_rows "$JSON")
[ -n "$ROWS" ] || { echo "error: no proto/port mappings in $JSON" >&2; exit 1; }

short_name() {
    local p=$1
    case "${p,,}" in
        dcerpc) echo DCERPC ;;
        nbns)   echo NBNS ;;
        tls)    echo TLS ;;
        *)      echo "${p^^}" ;;
    esac
}

# proto -> comma list per table; proto -> decode_as override
declare -A UDP_PORTS TCP_PORTS SCTP_PORTS DECODE_AS PROTOS
declare -A BPF_SEEN
BPF_CLAUSES=()

add_port() {
    local proto=$1 table=$2 port=$3 list
    if ! [[ $port =~ ^[0-9]+$ ]] || [ "$port" -lt 1 ] || [ "$port" -gt 65535 ]; then
        echo "error: bad port $port for $proto $table" >&2
        exit 1
    fi
    case "$table" in
        udp.port)  list=${UDP_PORTS[$proto]-} ;;
        tcp.port)  list=${TCP_PORTS[$proto]-} ;;
        sctp.port) list=${SCTP_PORTS[$proto]-} ;;
        *) echo "error: unknown table $table" >&2; exit 1 ;;
    esac
    case ",$list," in
        *",$port,"*) ;;
        *)
            if [ -n "$list" ]; then list=$list,$port; else list=$port; fi
            ;;
    esac
    case "$table" in
        udp.port)  UDP_PORTS[$proto]=$list ;;
        tcp.port)  TCP_PORTS[$proto]=$list ;;
        sctp.port) SCTP_PORTS[$proto]=$list ;;
    esac
    PROTOS[$proto]=1
    local transport=${table%%.*}
    local key=$transport:$port
    if [ -z "${BPF_SEEN[$key]-}" ]; then
        BPF_SEEN[$key]=1
        BPF_CLAUSES+=("$transport port $port")
    fi
}

while IFS=$'\t' read -r proto table value; do
    [ -n "$proto" ] || continue
    if [ "$table" = "decode_as" ]; then
        DECODE_AS[$proto]=$value
        PROTOS[$proto]=1
        continue
    fi
    add_port "$proto" "$table" "$value"
done <<< "$ROWS"

[ ${#PROTOS[@]} -gt 0 ] || { echo "error: no protocols" >&2; exit 1; }

bpf_filter() {
    local i s=""
    for i in "${BPF_CLAUSES[@]}"; do
        if [ -n "$s" ]; then s="$s or $i"; else s=$i; fi
    done
    printf '%s\n' "$s"
}

if [ "$PRINT_BPF" -eq 1 ]; then
    bpf_filter
    exit 0
fi

pref_body() {
    echo "# Generated by scripts/set_dissector_ports.sh"
    echo "# Range prefs: {filter}.{udp|tcp|sctp}.port  (Decode-As port lists)"
    local p
    for p in $(printf '%s\n' "${!PROTOS[@]}" | sort); do
        [ -n "${UDP_PORTS[$p]-}" ]  && echo "$p.udp.port: ${UDP_PORTS[$p]}"
        [ -n "${TCP_PORTS[$p]-}" ]  && echo "$p.tcp.port: ${TCP_PORTS[$p]}"
        [ -n "${SCTP_PORTS[$p]-}" ] && echo "$p.sctp.port: ${SCTP_PORTS[$p]}"
    done
    return 0
}

da_body() {
    echo '# "Decode As" entries file for Wireshark'
    echo "# Generated by scripts/set_dissector_ports.sh"
    local p name port table list
    for p in $(printf '%s\n' "${!PROTOS[@]}" | sort); do
        name=${DECODE_AS[$p]-$(short_name "$p")}
        for table in udp.port tcp.port sctp.port; do
            case "$table" in
                udp.port)  list=${UDP_PORTS[$p]-} ;;
                tcp.port)  list=${TCP_PORTS[$p]-} ;;
                sctp.port) list=${SCTP_PORTS[$p]-} ;;
            esac
            [ -n "$list" ] || continue
            IFS=, read -r -a ports <<< "$list"
            for port in "${ports[@]}"; do
                echo "decode_as_entry: $table,$port,(none),$name"
            done
        done
    done
    return 0
}

is_managed_proto() {
    local p=$1
    [ -n "${PROTOS[$p]-}" ]
}

merge_preferences() {
    local existing=$1 line copied=0
    if [ -f "$existing" ]; then
        while IFS= read -r line || [ -n "$line" ]; do
            case "$line" in
                "# Generated by scripts/set_dissector_ports.sh"|"# Generated by scripts/set_dissector_ports.py")
                    continue
                    ;;
                "# Range prefs: {filter}.{udp|tcp|sctp}.port  (Decode-As port lists)")
                    continue
                    ;;
            esac
            if [[ $line =~ ^([A-Za-z0-9_-]+)\.(udp|tcp|sctp)\.port[[:space:]]*: ]]; then
                is_managed_proto "${BASH_REMATCH[1]}" && continue
            fi
            [ -n "$line" ] || continue
            printf '%s\n' "$line"
            copied=1
        done < "$existing"
        if [ "$copied" -eq 1 ]; then echo; fi
    fi
    pref_body
    return 0
}

merge_decode_as() {
    local existing=$1 line p table list port copied=0
    declare -A claimed=()
    for p in "${!PROTOS[@]}"; do
        for table in udp.port tcp.port sctp.port; do
            case "$table" in
                udp.port)  list=${UDP_PORTS[$p]-} ;;
                tcp.port)  list=${TCP_PORTS[$p]-} ;;
                sctp.port) list=${SCTP_PORTS[$p]-} ;;
            esac
            [ -n "$list" ] || continue
            IFS=, read -r -a ports <<< "$list"
            for port in "${ports[@]}"; do
                claimed["$table,$port"]=1
            done
        done
    done
    if [ -f "$existing" ]; then
        while IFS= read -r line || [ -n "$line" ]; do
            case "$line" in
                "# Generated by scripts/set_dissector_ports.sh"|"# Generated by scripts/set_dissector_ports.py"|'# "Decode As" entries file for Wireshark')
                    continue
                    ;;
            esac
            if [[ $line =~ ^decode_as_entry:[[:space:]]*(udp|tcp|sctp)\.port,([0-9]+), ]]; then
                [ -n "${claimed[${BASH_REMATCH[1]}.port,${BASH_REMATCH[2]}]-}" ] && continue
            fi
            [ -n "$line" ] || continue
            printf '%s\n' "$line"
            copied=1
        done < "$existing"
        if [ "$copied" -eq 1 ]; then echo; fi
    fi
    da_body
    return 0
}

PREFS_PATH=$CONFIG_DIR/preferences
DA_PATH=$CONFIG_DIR/decode_as_entries
PREFS_OUT=$(merge_preferences "$PREFS_PATH")
DA_OUT=$(merge_decode_as "$DA_PATH")

if [ "$DRY_RUN" -eq 1 ]; then
    echo "--- $PREFS_PATH ---"
    printf '%s\n' "$PREFS_OUT"
    echo "--- $DA_PATH ---"
    printf '%s\n' "$DA_OUT"
    exit 0
fi

mkdir -p "$CONFIG_DIR"
printf '%s\n' "$PREFS_OUT" > "$PREFS_PATH"
printf '%s\n' "$DA_OUT" > "$DA_PATH"
echo "wrote $PREFS_PATH" >&2
echo "wrote $DA_PATH" >&2

ABS=$(cd "$CONFIG_DIR" && pwd)
BPF=$(bpf_filter)
PFLAGS=""
for p in $(printf '%s\n' "${!PROTOS[@]}" | sort); do
    PFLAGS="$PFLAGS -p $p"
done
echo "WIRESHARK_CONFIG_DIR=$ABS" >&2
echo "BPF: $BPF" >&2
echo "example: WIRESHARK_CONFIG_DIR=$ABS ./build/run/dbshark -i lo$PFLAGS -f '$BPF' -o CONNINFO" >&2
