/* pcapreplay — replay a pcap on a timeline via raw IPv4 sockets.
 *
 * libpcap reads offline captures sequentially: pcap_open_offline() then
 * pcap_next_ex() one packet at a time. The handle keeps an internal file
 * cursor — nothing is loaded into RAM except the current packet. There is
 * no portable "seek to packet N" API (pcapng block layout makes random
 * access hard), so we do NOT pre-scan the file. After the wall-clock
 * rendezvous (-T), one pass: read → alter → sleep until sched → send.
 *
 * IPv4 only. Needs CAP_NET_RAW (and CAP_NET_ADMIN for -l/-N).
 */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <getopt.h>
#include <inttypes.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include <sys/socket.h>

#include <pcap/pcap.h>
#include <pcap/dlt.h>

#define MAX_MAPS 64
#define PKT_MAX  65535

typedef struct {
    uint32_t old_be, new_be;
} ip_map_t;

typedef struct {
    const char *pcap_path;
    const char *bpf;
    const char *iface;
    const char *local_ip;
    ip_map_t    maps[MAX_MAPS];
    int         n_maps;
    double      speed;
    int64_t     t0_override;
    uint64_t    start_ns;
    int         have_start;
    int         start_now;
    int         notrack;
    int         print_t0;
    int         print_t_end;
    int         probe;
    int         dry_run;
    int         verbose;
    int         linktype;
    uint32_t    sink_be;     /* rewrite unmapped dst to this (-U) */
    int         sink_set;    /* 1 = sink unmapped dst; 0 = skip them */
    int         sink_explicit; /* user passed -U */
} opts_t;

static volatile sig_atomic_t stop;

static void die(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static void on_sig(int s) { (void)s; stop = 1; }

static int64_t tv_usec(const struct timeval *tv)
{
    return (int64_t)tv->tv_sec * 1000000LL + (int64_t)tv->tv_usec;
}

static uint64_t clk_ns(clockid_t clk)
{
    struct timespec ts;
    if (clock_gettime(clk, &ts) != 0)
        die("clock_gettime: %s", strerror(errno));
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

static uint64_t mono_ns(void) { return clk_ns(CLOCK_MONOTONIC); }
static uint64_t real_ns(void) { return clk_ns(CLOCK_REALTIME); }

static void sleep_until(clockid_t clk, uint64_t deadline_ns)
{
    struct timespec abs = {
        .tv_sec  = (time_t)(deadline_ns / 1000000000ULL),
        .tv_nsec = (long)(deadline_ns % 1000000000ULL),
    };
    while (!stop) {
        int r = clock_nanosleep(clk, TIMER_ABSTIME, &abs, NULL);
        if (r == 0 || r != EINTR)
            return;
    }
}

/* ---------------------------------------------------------------- link layer */

static const uint8_t *eth_ipv4(const uint8_t *f, size_t n, size_t *ip_len)
{
    size_t off = 14;
    uint16_t et;

    if (n < 14)
        return NULL;
    et = (uint16_t)((f[12] << 8) | f[13]);
    if (et == 0x8100) {
        if (n < 18)
            return NULL;
        et = (uint16_t)((f[16] << 8) | f[17]);
        off = 18;
    }
    if (et != 0x0800 || n < off + sizeof(struct iphdr))
        return NULL;
    *ip_len = n - off;
    return f + off;
}

static int looks_ipv4(const uint8_t *buf, size_t n, size_t off)
{
    if (n < off + sizeof(struct iphdr))
        return 0;
    const struct iphdr *ip = (const struct iphdr *)(buf + off);
    return ip->version == 4 && ip->ihl >= 5;
}

static const uint8_t *capture_ipv4(int dlt, const uint8_t *f, size_t n, size_t *ip_len)
{
    uint16_t et;

    switch (dlt) {
    case DLT_RAW:
        if (!looks_ipv4(f, n, 0))
            return NULL;
        *ip_len = n;
        return f;

    case DLT_NULL:
        if (n >= 4 + sizeof(struct iphdr) && looks_ipv4(f, n, 4)) {
            *ip_len = n - 4;
            return f + 4;
        }
        return NULL;

    case DLT_LINUX_SLL:
        if (n < 16)
            return NULL;
        et = (uint16_t)((f[14] << 8) | f[15]);
        if (et != 0x0800 || !looks_ipv4(f, n, 16))
            return NULL;
        *ip_len = n - 16;
        return f + 16;

    case DLT_LINUX_SLL2:
        if (n < 20)
            return NULL;
        et = (uint16_t)((f[0] << 8) | f[1]);
        if (et != 0x0800 || !looks_ipv4(f, n, 20))
            return NULL;
        *ip_len = n - 20;
        return f + 20;

    case DLT_EN10MB:
        return eth_ipv4(f, n, ip_len);

    default: {
        const uint8_t *p = eth_ipv4(f, n, ip_len);
        if (p)
            return p;
        if (looks_ipv4(f, n, 0)) {
            *ip_len = n;
            return f;
        }
        if (n >= 4 + sizeof(struct iphdr) && looks_ipv4(f, n, 4)) {
            *ip_len = n - 4;
            return f + 4;
        }
        return NULL;
    }
    }
}

static pcap_t *open_offline_pcap(const char *path, char errbuf[PCAP_ERRBUF_SIZE])
{
    pcap_t *pc = pcap_open_offline(path, errbuf);
    return pc;
}

static int capture_linktype(const char *path)
{
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_t *pc = open_offline_pcap(path, errbuf);
    if (!pc)
        die("pcap_open_offline(%s): %s", path, errbuf);
    int dlt = pcap_datalink(pc);
    pcap_close(pc);
    return dlt;
}

/* --------------------------------------------------------------------- pcap */

static pcap_t *open_pcap(const char *path, const char *bpf)
{
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_t *pc = open_offline_pcap(path, errbuf);
    if (!pc)
        die("pcap_open_offline(%s): %s", path, errbuf);

    if (bpf && bpf[0]) {
        struct bpf_program prog;
        if (pcap_compile(pc, &prog, bpf, 1, PCAP_NETMASK_UNKNOWN) < 0)
            die("bpf compile: %s", pcap_geterr(pc));
        if (pcap_setfilter(pc, &prog) < 0)
            die("bpf filter: %s", pcap_geterr(pc));
        pcap_freecode(&prog);
    }
    return pc;
}

static int next_pkt(pcap_t *pc, struct pcap_pkthdr **h, const u_char **d)
{
    for (;;) {
        int ret = pcap_next_ex(pc, h, d);
        if (ret == 1)
            return 1;
        if (ret == 0)
            continue;
        if (ret == PCAP_ERROR_BREAK)
            return 0;
        die("pcap_next_ex: %s", pcap_geterr(pc));
    }
}

static int64_t scan_t0(const char *path, const char *bpf)
{
    pcap_t *pc = open_pcap(path, bpf);
    struct pcap_pkthdr *h;
    const u_char *d;
    int64_t t0 = -1;

    while (next_pkt(pc, &h, &d)) {
        int64_t us = tv_usec(&h->ts);
        if (t0 < 0 || us < t0)
            t0 = us;
    }
    pcap_close(pc);
    if (t0 < 0)
        die("capture has no packets%s: %s",
            bpf && bpf[0] ? " matching BPF" : "", path);
    return t0;
}

static int64_t scan_t_end(const char *path)
{
    pcap_t *pc = open_pcap(path, NULL);
    struct pcap_pkthdr *h;
    const u_char *d;
    int64_t t_end = -1;

    while (next_pkt(pc, &h, &d)) {
        int64_t us = tv_usec(&h->ts);
        if (t_end < 0 || us > t_end)
            t_end = us;
    }
    pcap_close(pc);
    if (t_end < 0)
        die("capture has no packets: %s", path);
    return t_end;
}

/* ---------------------------------------------------------- packet rewrite */

static int parse_map(const char *s, ip_map_t *m)
{
    char buf[128], *eq;
    struct in_addr o, n;

    if (strlen(s) >= sizeof(buf))
        return -1;
    strcpy(buf, s);
    eq = strchr(buf, '=');
    if (!eq)
        return -1;
    *eq = '\0';
    if (inet_pton(AF_INET, buf, &o) != 1 || inet_pton(AF_INET, eq + 1, &n) != 1)
        return -1;
    m->old_be = o.s_addr;
    m->new_be = n.s_addr;
    return 0;
}

static int map_ip(uint32_t be, const opts_t *o, uint32_t *out)
{
    for (int i = 0; i < o->n_maps; i++)
        if (o->maps[i].old_be == be) {
            *out = o->maps[i].new_be;
            return 1;
        }
    return 0;
}

static uint16_t csum16(uint32_t sum)
{
    while (sum >> 16)
        sum = (sum & 0xffff) + (sum >> 16);
    return (uint16_t)~sum;
}

static uint16_t ip_csum(struct iphdr *ip)
{
    uint32_t sum = 0;
    uint16_t *w = (uint16_t *)ip;
    ip->check = 0;
    for (int i = 0; i < ip->ihl * 2; i++)
        sum += ntohs(w[i]);
    return htons(csum16(sum));
}

static uint16_t l4_csum(const struct iphdr *ip, const void *l4, size_t len, int proto)
{
    uint32_t sum = 0;
    const uint16_t *w = l4;

    sum += (ntohl(ip->saddr) >> 16) & 0xffff;
    sum += ntohl(ip->saddr) & 0xffff;
    sum += (ntohl(ip->daddr) >> 16) & 0xffff;
    sum += ntohl(ip->daddr) & 0xffff;
    sum += (uint32_t)proto + (uint32_t)len;
    while (len > 1) {
        sum += ntohs(*w++);
        len -= 2;
    }
    if (len)
        sum += *(const uint8_t *)w << 8;
    return csum16(sum);
}

typedef enum {
    PKT_OK,
    PKT_SUNK,       /* dst not in -M; rewritten to -U sink */
    PKT_SKIP,       /* not IPv4 or malformed */
    PKT_UNMAPPED,   /* src not in -M (when map is defined) */
} pkt_class_t;

/* Strip L2, remap -M hits on both endpoints, fix checksums. */
static pkt_class_t prepare_pkt(const uint8_t *frame, size_t caplen,
                               const opts_t *o, uint8_t *out,
                               size_t *out_len, struct sockaddr_in *dst)
{
    size_t ip_len;
    const uint8_t *raw = capture_ipv4(o->linktype, frame, caplen, &ip_len);

    if (!raw || ip_len < sizeof(struct iphdr))
        return PKT_SKIP;
    if (ip_len > PKT_MAX)
        return PKT_SKIP;

    const struct iphdr *src = (const struct iphdr *)raw;
    if (src->version != 4 || src->ihl < 5)
        return PKT_SKIP;

    /* With -M: src must be a known player. Unmapped dst goes to -U sink
     * (default 127.0.0.1) so egress to the internet is not sent for real. */
    uint32_t nsaddr = src->saddr, ndaddr = src->daddr;
    int sunk = 0;
    if (o->n_maps > 0) {
        if (!map_ip(src->saddr, o, &nsaddr))
            return PKT_UNMAPPED;
        if (!map_ip(src->daddr, o, &ndaddr)) {
            if (!o->sink_set)
                return PKT_UNMAPPED;
            ndaddr = o->sink_be;
            sunk = 1;
        }
    }

    size_t hlen = (size_t)src->ihl * 4;
    size_t tot  = ntohs(src->tot_len);
    if (tot >= hlen && tot <= ip_len)
        ip_len = tot;

    memcpy(out, raw, ip_len);
    struct iphdr *ip = (struct iphdr *)out;
    ip->saddr = nsaddr;
    ip->daddr = ndaddr;
    ip->check = ip_csum(ip);

    size_t plen = ip_len - hlen;
    if (plen > 0) {
        void *l4 = out + hlen;
        if (ip->protocol == IPPROTO_TCP && plen >= sizeof(struct tcphdr)) {
            struct tcphdr *t = l4;
            t->check = 0;
            t->check = htons(l4_csum(ip, l4, plen, IPPROTO_TCP));
        } else if (ip->protocol == IPPROTO_UDP && plen >= sizeof(struct udphdr)) {
            struct udphdr *u = l4;
            u->check = 0;
            u->check = htons(l4_csum(ip, l4, plen, IPPROTO_UDP));
        }
    }

    memset(dst, 0, sizeof(*dst));
    dst->sin_family      = AF_INET;
    dst->sin_addr.s_addr = ip->daddr;
    *out_len = ip_len;
    return sunk ? PKT_SUNK : PKT_OK;
}

/* ------------------------------------------------------------------- send */

static int open_raw(const char *iface)
{
    int fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if (fd < 0)
        die("SOCK_RAW: %s", strerror(errno));
    int one = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) < 0)
        die("IP_HDRINCL: %s", strerror(errno));
    if (iface && iface[0])
        setsockopt(fd, SOL_SOCKET, SO_BINDTODEVICE, iface, (socklen_t)strlen(iface) + 1);
    return fd;
}

static void emit_verbose(uint64_t n, int64_t t_us, int64_t t0_us,
                         const uint8_t *pkt, size_t len, int sunk)
{
    if (len < sizeof(struct iphdr))
        return;
    const struct iphdr *ip = (const struct iphdr *)pkt;
    char src[INET_ADDRSTRLEN], dst[INET_ADDRSTRLEN];
    if (!inet_ntop(AF_INET, &ip->saddr, src, sizeof(src)) ||
        !inet_ntop(AF_INET, &ip->daddr, dst, sizeof(dst)))
        return;

    const char *proto = "IP";
    unsigned sport = 0, dport = 0;
    size_t hlen = (size_t)ip->ihl * 4;
    size_t plen = len > hlen ? len - hlen : 0;
    if (ip->protocol == IPPROTO_TCP && plen >= sizeof(struct tcphdr)) {
        const struct tcphdr *t = (const void *)(pkt + hlen);
        proto = "TCP";
        sport = ntohs(t->source);
        dport = ntohs(t->dest);
    } else if (ip->protocol == IPPROTO_UDP && plen >= sizeof(struct udphdr)) {
        const struct udphdr *u = (const void *)(pkt + hlen);
        proto = "UDP";
        sport = ntohs(u->source);
        dport = ntohs(u->dest);
    } else if (ip->protocol == IPPROTO_ICMP) {
        proto = "ICMP";
    }

    double rel = (double)(t_us - t0_us) / 1e6;
    if (rel < 0.0)
        rel = 0.0;

    if (sport || dport)
        fprintf(stderr,
                "%6" PRIu64 " %10.6f  %15s:%-5u -> %15s:%-5u  %-4s  len=%-4zu%s\n",
                n, rel, src, sport, dst, dport, proto, len,
                sunk ? "  [sunk]" : "");
    else
        fprintf(stderr,
                "%6" PRIu64 " %10.6f  %15s -> %15s  %-4s  len=%-4zu%s\n",
                n, rel, src, dst, proto, len, sunk ? "  [sunk]" : "");
    fflush(stderr);
}

static void emit_status(uint64_t sent, uint64_t t_us, const uint8_t *pkt, size_t len)
{
    static uint64_t last_ns;
    uint64_t now = mono_ns();
    if (last_ns && now - last_ns < 50000000ULL)
        return;
    last_ns = now;

    if (len < sizeof(struct iphdr))
        return;
    const struct iphdr *ip = (const struct iphdr *)pkt;
    char src[INET_ADDRSTRLEN], dst[INET_ADDRSTRLEN];
    if (!inet_ntop(AF_INET, &ip->saddr, src, sizeof(src)) ||
        !inet_ntop(AF_INET, &ip->daddr, dst, sizeof(dst)))
        return;

    const char *proto = "ip";
    unsigned sport = 0, dport = 0;
    size_t hlen = (size_t)ip->ihl * 4;
    size_t plen = len > hlen ? len - hlen : 0;
    if (ip->protocol == IPPROTO_TCP && plen >= sizeof(struct tcphdr)) {
        const struct tcphdr *t = (const void *)(pkt + hlen);
        proto = "tcp";
        sport = ntohs(t->source);
        dport = ntohs(t->dest);
    } else if (ip->protocol == IPPROTO_UDP && plen >= sizeof(struct udphdr)) {
        const struct udphdr *u = (const void *)(pkt + hlen);
        proto = "udp";
        sport = ntohs(u->source);
        dport = ntohs(u->dest);
    } else if (ip->protocol == IPPROTO_ICMP) {
        proto = "icmp";
    }

    fprintf(stderr,
            "STATUS sent=%" PRIu64 " t_us=%" PRIu64
            " proto=%s src=%s dst=%s sport=%u dport=%u len=%zu\n",
            sent, t_us, proto, src, dst, sport, dport, len);
}

/* ----------------------------------------------------------- replay / probe */

static uint64_t sched_ns_for(const opts_t *o, int64_t t0_us, int64_t pkt_us)
{
    int64_t delta = pkt_us - t0_us;
    if (delta < 0)
        delta = 0;
    if (o->speed <= 0.0)
        return 0;
    return (uint64_t)((double)delta * 1000.0 / o->speed);
}

/* One sequential pass: BPF filter applied by libpcap, alter, pace, send. */
static int replay_stream(const opts_t *o, uint64_t anchor, int fd,
                         uint64_t *sent_out, int64_t *t0_out)
{
    pcap_t *pc = open_pcap(o->pcap_path, o->bpf);
    struct pcap_pkthdr *h;
    const u_char *d;
    int64_t t0 = o->t0_override;
    uint64_t sent = 0, failed = 0, pkts = 0, skipped = 0, unmapped = 0, sunk = 0;
    uint64_t last_sched = 0;

    while (!stop && next_pkt(pc, &h, &d)) {
        pkts++;
        uint8_t pkt[PKT_MAX];
        size_t len;
        struct sockaddr_in dst;
        pkt_class_t cls = prepare_pkt(d, h->caplen, o, pkt, &len, &dst);
        switch (cls) {
        case PKT_OK:
            break;
        case PKT_SUNK:
            sunk++;
            break;
        case PKT_UNMAPPED:
            unmapped++;
            continue;
        case PKT_SKIP:
            skipped++;
            continue;
        }

        int64_t t_us = tv_usec(&h->ts);
        if (t0 < 0)
            t0 = t_us;
        last_sched = sched_ns_for(o, t0, t_us);

        if (o->speed > 0.0)
            sleep_until(CLOCK_MONOTONIC, anchor + last_sched);

        if (o->dry_run || sendto(fd, pkt, len, 0,
                                 (struct sockaddr *)&dst, sizeof(dst)) >= 0) {
            sent++;
            if (o->verbose)
                emit_verbose(sent, t_us, t0, pkt, len, cls == PKT_SUNK);
            else
                emit_status(sent, (uint64_t)t_us, pkt, len);
        } else {
            failed++;
        }
    }
    pcap_close(pc);

    fprintf(stderr,
            "done: sent=%" PRIu64 " failed=%" PRIu64 " pkts=%" PRIu64
            " skip=%" PRIu64 " unmapped=%" PRIu64 " sunk=%" PRIu64
            " t0=%" PRId64 " us duration=%.3f s\n",
            sent, failed, pkts, skipped, unmapped, sunk, t0,
            (double)last_sched / 1e9);
    if (sent_out)
        *sent_out = sent;
    if (t0_out)
        *t0_out = t0;
    return failed ? 1 : (sent == 0 ? 1 : 0);
}

static void probe_capture(const opts_t *o)
{
    pcap_t *pc = open_pcap(o->pcap_path, o->bpf);
    struct pcap_pkthdr *h;
    const u_char *d;
    uint64_t pkts = 0, skipped = 0, unmapped = 0, sunk = 0, send = 0;

    while (next_pkt(pc, &h, &d)) {
        pkts++;
        uint8_t tmp[PKT_MAX];
        size_t len;
        struct sockaddr_in dst;
        switch (prepare_pkt(d, h->caplen, o, tmp, &len, &dst)) {
        case PKT_OK:       send++; break;
        case PKT_SUNK:     send++; sunk++; break;
        case PKT_UNMAPPED: unmapped++; break;
        case PKT_SKIP:     skipped++; break;
        }
    }
    pcap_close(pc);

    const char *dlt_name = pcap_datalink_val_to_name(o->linktype);
    fprintf(stderr,
            "probe: link=%s (%d) pkts=%" PRIu64 " send=%" PRIu64
            " sunk=%" PRIu64 " skip=%" PRIu64 " unmapped=%" PRIu64 "\n",
            dlt_name ? dlt_name : "?", o->linktype,
            pkts, send, sunk, skipped, unmapped);
    if (send == 0)
        fprintf(stderr,
                "probe: nothing to replay — check -M map, -U sink, and link type\n");
}

static uint64_t resolve_start(const opts_t *o)
{
    if (o->have_start)
        return o->start_ns;
    const char *env = getenv("PCAPREPLAY_START_NS");
    if (env && env[0])
        return strtoull(env, NULL, 10);
    if (o->start_now)
        return real_ns();

    fprintf(stderr, "CLOCK_REALTIME now: %" PRIu64 " ns (epoch)\n", real_ns());
    fprintf(stderr, "shared start (epoch ns): ");
    fflush(stderr);
    char line[64];
    if (!fgets(line, sizeof(line), stdin))
        die("read start time");
    return strtoull(line, NULL, 10);
}

static int iptables_ensure(const char *table, const char *rule)
{
    char t[16] = "", cmd[640];
    if (table)
        snprintf(t, sizeof(t), "-t %s ", table);
    snprintf(cmd, sizeof(cmd),
             "iptables %s-C %s 2>/dev/null || iptables %s-A %s", t, rule, t, rule);
    return system(cmd);
}

static void suppress_rst(const char *local_ip, int notrack)
{
    char rule[256];

    snprintf(rule, sizeof(rule),
             "OUTPUT -p tcp --tcp-flags RST RST -s %s -j DROP", local_ip);
    if (iptables_ensure(NULL, rule) == 0)
        fprintf(stderr, "iptables: suppressed TCP RST from %s\n", local_ip);
    else
        fprintf(stderr, "warning: iptables RST suppress failed (need CAP_NET_ADMIN)\n");

    if (notrack) {
        int ok = 0;
        snprintf(rule, sizeof(rule), "OUTPUT -s %s -j NOTRACK", local_ip);
        ok |= iptables_ensure("raw", rule) == 0;
        snprintf(rule, sizeof(rule), "PREROUTING -d %s -j NOTRACK", local_ip);
        ok |= iptables_ensure("raw", rule) == 0;
        if (ok)
            fprintf(stderr, "iptables: NOTRACK for %s\n", local_ip);
        else
            fprintf(stderr, "warning: NOTRACK install failed (need CAP_NET_ADMIN)\n");
    }
}

static void usage(void)
{
    fprintf(stderr,
            "usage: pcapreplay -r PCAP -i IFACE [options]\n"
            "\n"
            "  -r FILE       input pcap/pcapng (required)\n"
            "  -i IFACE      output interface (required unless -I)\n"
            "  -f 'BPF'      optional libpcap filter (egress pcaps need no -f)\n"
            "  -0 US         shared global t0 (epoch us); default: first send packet\n"
            "  -T NS         wall-clock start (epoch ns); env PCAPREPLAY_START_NS\n"
            "  -M old=new    IPv4 remap (optional, repeatable)\n"
            "  -U IP         unmapped dst rewritten here (-U none to skip)\n"
            "  -s SPEED      1.0=realtime, 0=flood (default 1.0)\n"
            "  -l IP         suppress kernel RST for TCP from this IP\n"
            "  -N            raw-table NOTRACK for -l IP\n"
            "  -P / -E       print first/last packet epoch (us) and exit\n"
            "  -I            count send/skip (one disk pass), then exit\n"
            "  -n            dry-run: pace and STATUS, no send\n"
            "  -v            per-packet line for each send (tshark-like)\n"
            "  -y            start immediately (skip -T prompt)\n");
}

int main(int argc, char **argv)
{
    opts_t o = { .speed = 1.0, .t0_override = -1 };
    int c;

    while ((c = getopt(argc, argv, "r:i:f:0:T:M:s:l:U:NPEInvyh")) != -1) {
        switch (c) {
        case 'r': o.pcap_path = optarg; break;
        case 'i': o.iface = optarg; break;
        case 'f': o.bpf = optarg; break;
        case '0': o.t0_override = strtoll(optarg, NULL, 10); break;
        case 'T': o.have_start = 1; o.start_ns = strtoull(optarg, NULL, 10); break;
        case 'M':
            if (o.n_maps >= MAX_MAPS) die("too many -M");
            if (parse_map(optarg, &o.maps[o.n_maps++]) != 0) die("bad -M: %s", optarg);
            break;
        case 'U':
            o.sink_explicit = 1;
            if (strcmp(optarg, "none") == 0) {
                o.sink_set = 0;
            } else {
                struct in_addr a;
                if (inet_pton(AF_INET, optarg, &a) != 1)
                    die("bad -U: %s", optarg);
                o.sink_be = a.s_addr;
                o.sink_set = 1;
            }
            break;
        case 's': o.speed = atof(optarg); break;
        case 'l': o.local_ip = optarg; break;
        case 'N': o.notrack = 1; break;
        case 'P': o.print_t0 = 1; break;
        case 'E': o.print_t_end = 1; break;
        case 'I': o.probe = 1; break;
        case 'n': o.dry_run = 1; break;
        case 'v': o.verbose = 1; break;
        case 'y': o.start_now = 1; break;
        case 'h': usage(); return 0;
        default: usage(); return 1;
        }
    }

    if (!o.pcap_path) { usage(); return 1; }

    if (o.print_t0) {
        printf("%" PRId64 "\n", scan_t0(o.pcap_path, o.bpf));
        return 0;
    }
    if (o.print_t_end) {
        printf("%" PRId64 "\n", scan_t_end(o.pcap_path));
        return 0;
    }

    if (o.n_maps > 0) {
        if (!o.sink_explicit || !o.sink_set)
            die("-U <sink IP> is required when using -M (unmapped dst rewrite)");
    }

    o.linktype = capture_linktype(o.pcap_path);

    if (o.probe) {
        probe_capture(&o);
        return 0;
    }

    if (!o.iface)
        die("-i <interface> is required (e.g. eth0, lo)");

    if (o.sink_set && o.n_maps > 0) {
        char sink[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &o.sink_be, sink, sizeof(sink));
        fprintf(stderr, "unmapped dst sink: %s (-U)\n", sink);
    }

    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);

    if (!o.dry_run && o.local_ip)
        suppress_rst(o.local_ip, o.notrack);

    int fd = -1;
    if (!o.dry_run) {
        fd = open_raw(o.iface);
    } else {
        fprintf(stderr, "dry-run: pacing and STATUS only (no raw socket)\n");
    }

    uint64_t start_real = resolve_start(&o);
    int64_t lead_ms = ((int64_t)start_real - (int64_t)real_ns()) / 1000000;
    fprintf(stderr, "start=%" PRIu64 " epoch-ns (in %+" PRId64 " ms)\n",
            start_real, lead_ms);
    if (lead_ms > 0)
        fprintf(stderr, "waiting on wall clock...\n");
    sleep_until(CLOCK_REALTIME, start_real);

    uint64_t anchor = mono_ns();
    const char *dlt_name = pcap_datalink_val_to_name(o.linktype);
    fprintf(stderr, "replay go (link=%s%s%s)\n",
            dlt_name ? dlt_name : "?",
            o.bpf ? ", bpf=" : "",
            o.bpf ? o.bpf : "");

    int rc = replay_stream(&o, anchor, fd, NULL, NULL);
    if (fd >= 0)
        close(fd);
    return rc;
}
