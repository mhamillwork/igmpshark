/* promshark — live/offline capture → Prometheus /metrics via libwireshark.
 *
 * Layout (mirrors opengl-globe/src/capture/):
 *
 *   libwireshark session .... epan init, sess/edt, ts_hist
 *   scrape window ........... shared prom_pkt_t list + window analyzer
 *   Prometheus exposition ... labels, gauge formatting, render_stats
 *   extractor registry ...... static table, -p enable, dispatch
 *   per-protocol extractors ... cache / extract (push raw rows only)
 *   /metrics HTTP server .... scrape thread, text/plain exposition
 *   packet loop ............. dissect + extractors_run per frame
 *   main
 *
 * Data path:
 *   wire → pcap → epan_dissect_run → extractors_run → prom_pkt_push
 *   Prometheus → GET /metrics → scrape_snapshot → pkt_stats_from → render
 *
 * Extractors push raw rows; all metric logic lives in the window analyzer.
 * Adding a protocol: implement cache/extract, add one s_extractors[] row.
 */
#define _GNU_SOURCE
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <inttypes.h>
#include <errno.h>
#include <poll.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include <glib.h>
#include <pcap/pcap.h>
#include <epan/epan.h>
#include <epan/epan_dissect.h>
#include <epan/proto.h>
#include <epan/packet.h>
#include <epan/tvbuff.h>
#include <epan/ftypes/ftypes.h>
#include <wiretap/wtap.h>
#include <wsutil/buffer.h>
#include <wsutil/filesystem.h>
#include <wsutil/privileges.h>
#include <wsutil/wslog.h>

/* libwireshark session
 *
 * One epan session for the process lifetime. Same init sequence as dbshark
 * and opengl-globe/capture.c: ws_log_init, configuration_init, wtap_init,
 * epan_init, epan_load_settings. Skipping any step causes obscure crashes
 * inside dissector registration or MaxMind lookups.
 *
 * sess/edt: dissect every packet through epan_dissect_run().
 * ts_hist:  flat GArray of frame timestamps indexed by frame_no-1. Some
 *           dissectors call back via prov_ts to read earlier frame times.
 *           Appended in process_packet() before each dissect_run.
 *
 * promshark_ws_init/shutdown bracket the whole run; extractors and the metrics
 * thread are torn down before epan_cleanup().
 */

static epan_t          *sess;
static epan_dissect_t  *edt;
static GArray          *ts_hist;
static guint32          frame_no;
static int              file_subtype = WTAP_FILE_TYPE_SUBTYPE_UNKNOWN;

static const nstime_t *prov_ts_cb(struct packet_provider_data *p, guint32 num)
{
    (void)p;
    if (!ts_hist || num == 0 || num > ts_hist->len) return NULL;
    return &g_array_index(ts_hist, nstime_t, num - 1);
}

static wtap_block_t prov_mbk_cb(struct packet_provider_data *p, const frame_data *f)
{
    (void)p; (void)f;
    return NULL;
}

static const struct packet_provider_funcs prov_funcs = {
    .get_frame_ts       = prov_ts_cb,
    .get_modified_block = prov_mbk_cb,
};

static void vcmdarg_err(const char *fmt, va_list ap)
{
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
}

static int promshark_ws_init(const char *argv0)
{
    g_setenv("WS_LOG_LEVEL", "warning", FALSE);
    ws_log_init("promshark", vcmdarg_err);
    ws_log_set_level(LOG_LEVEL_WARNING);
    init_process_policies();

    char *cfg_err = configuration_init(argv0, NULL);
    if (cfg_err) {
        fprintf(stderr, "configuration_init: %s\n", cfg_err);
        return -1;
    }

    wtap_init(TRUE);
    if (!epan_init(NULL, NULL, TRUE)) {
        fprintf(stderr, "epan_init failed\n");
        return -1;
    }
    epan_load_settings();
    return 0;
}

static void promshark_ws_shutdown(void)
{
    epan_dissect_free(edt);
    epan_free(sess);
    g_array_free(ts_hist, TRUE);
    epan_cleanup();
    wtap_cleanup();
}

/* scrape window
 *
 * Extractors append prom_pkt_t rows between HTTP scrapes. Each row is raw
 * capture data: proto name, packed entity_id, frame_us (wall), ts_us (proto).
 *
 * On /metrics: scrape_snapshot() copies the live list and clears it under a
 * brief lock. pkt_stats_from() walks the snapshot (no lock held) to compute
 * packet count, unique entity IDs, and latency min/max/avg. Per-proto latency
 * rules live in pkt_latency_sec() — extractors never touch metrics.
 */

typedef struct {
    const char *proto;
    uint64_t    entity_id;
    int64_t     frame_us;   /* capture timestamp */
    int64_t     ts_us;      /* protocol timestamp (e.g. DIS sim time) */
} prom_pkt_t;

typedef struct {
    uint64_t n;
    uint64_t unique_ids;
    double   latency_min, latency_max, latency_sum;
    gboolean have_latency;
} prom_stats_t;

static GArray         *scrape_pkts;
static pthread_mutex_t scrape_mu;

static void prom_scrape_init(void)
{
    scrape_pkts = g_array_new(FALSE, FALSE, sizeof(prom_pkt_t));
    pthread_mutex_init(&scrape_mu, NULL);
}

static void prom_scrape_shutdown(void)
{
    g_array_free(scrape_pkts, TRUE);
    pthread_mutex_destroy(&scrape_mu);
}

static void prom_pkt_push(const char *proto, uint64_t entity_id,
                          int64_t frame_us, int64_t ts_us)
{
    prom_pkt_t p = {
        .proto = proto,
        .entity_id = entity_id,
        .frame_us = frame_us,
        .ts_us = ts_us,
    };
    pthread_mutex_lock(&scrape_mu);
    g_array_append_val(scrape_pkts, p);
    pthread_mutex_unlock(&scrape_mu);
}

/* Lock briefly: copy window rows, clear live list, return snapshot for analysis. */
static GArray *scrape_snapshot(void)
{
    GArray *snap = g_array_new(FALSE, FALSE, sizeof(prom_pkt_t));
    pthread_mutex_lock(&scrape_mu);
    if (scrape_pkts->len)
        g_array_append_vals(snap, scrape_pkts->data, scrape_pkts->len);
    g_array_set_size(scrape_pkts, 0);
    pthread_mutex_unlock(&scrape_mu);
    return snap;
}

/* Per-proto latency from raw row fields. Add cases here as new extractors land. */
static double pkt_latency_sec(const prom_pkt_t *p,
                              int64_t *dis_wall0, int64_t *dis_sim0,
                              gboolean *dis_clocked)
{
    if (strcmp(p->proto, "dis") == 0) {
        if (!*dis_clocked) {
            *dis_wall0 = p->frame_us;
            *dis_sim0 = p->ts_us;
            *dis_clocked = TRUE;
            return 0.0;
        }
        return (double)(*dis_wall0 + (p->ts_us - *dis_sim0) - p->frame_us) / 1e6;
    }
    return (double)(p->frame_us - p->ts_us) / 1e6;
}

/* Analyze snapshot rows matching proto_filter (NULL = all). Caller owns snap. */
static prom_stats_t pkt_stats_from(GArray *snap, const char *proto_filter)
{
    prom_stats_t s = {0};
    int64_t dis_wall0 = 0, dis_sim0 = 0;
    gboolean dis_clocked = FALSE;
    GHashTable *seen = g_hash_table_new(g_direct_hash, g_direct_equal);

    for (guint i = 0; i < snap->len; i++) {
        const prom_pkt_t *p = &g_array_index(snap, prom_pkt_t, i);
        if (proto_filter && strcmp(p->proto, proto_filter) != 0)
            continue;

        s.n++;
        g_hash_table_add(seen, (gpointer)(uintptr_t)p->entity_id);

        double lat = pkt_latency_sec(p, &dis_wall0, &dis_sim0, &dis_clocked);
        if (!s.have_latency || lat < s.latency_min)
            s.latency_min = lat;
        if (!s.have_latency || lat > s.latency_max)
            s.latency_max = lat;
        s.have_latency = TRUE;
        s.latency_sum += lat;
    }

    s.unique_ids = g_hash_table_size(seen);
    g_hash_table_destroy(seen);
    return s;
}

/* extra Prometheus labels (-l KEY=VAL)
 *
 * Ops insisted every metric carry environment/team/cluster/pod labels so their
 * twelve Grafana dashboards can filter on something. We parse these once at
 * startup and staple them onto every exposition line. Max 16, because if you
 * need more labels you're doing it wrong and we don't want to hear about it.
 * Format is key=value; you'll get it wrong on the first try anyway.
 */

typedef struct { char *key; char *val; } prom_label_t;

static prom_label_t extra_labels[16];
static int          n_extra_labels;

static int add_extra_label(const char *arg)
{
    const char *eq = strchr(arg, '=');
    if (!eq || eq == arg || !eq[1]) {
        fprintf(stderr, "invalid label: %s (want key=value)\n", arg);
        return -1;
    }
    if (n_extra_labels >= (int)G_N_ELEMENTS(extra_labels)) return -1;
    extra_labels[n_extra_labels].key = g_strndup(arg, (gsize)(eq - arg));
    extra_labels[n_extra_labels++].val = g_strdup(eq + 1);
    return 0;
}

/* Prometheus exposition
 *
 * Build label sets and format text/plain 0.0.4 gauge lines. render_stats()
 * emits the window metrics (packets, unique entities, latency min/max/avg) for
 * one label set — called once for the aggregate and once per enabled proto.
 */

static void lbl_escape(GString *o, const char *s)
{
    for (; *s; s++) {
        if (*s == '\\' || *s == '"') {
            g_string_append_c(o, '\\');
            g_string_append_c(o, *s);
        } else if (*s == '\n')
            g_string_append(o, "\\n");
        else
            g_string_append_c(o, *s);
    }
}

static void lbl_pair(GString *o, const char *k, const char *v)
{
    lbl_escape(o, k);
    g_string_append(o, "=\"");
    lbl_escape(o, v);
    g_string_append(o, "\"");
}

static GString *labels_for(const char *protocol)
{
    GString *s = g_string_new("{");
    gboolean first = TRUE;
    if (protocol) {
        lbl_pair(s, "protocol", protocol);
        first = FALSE;
    }
    for (int i = 0; i < n_extra_labels; i++) {
        if (!first) g_string_append_c(s, ',');
        lbl_pair(s, extra_labels[i].key, extra_labels[i].val);
        first = FALSE;
    }
    g_string_append_c(s, '}');
    return s;
}

static void emit_gauge(GString *body, const char *name, const char *help,
                       const char *lbl, const char *val)
{
    g_string_append_printf(body,
        "# HELP %s %s\n# TYPE %s gauge\n%s%s %s\n\n",
        name, help, name, name, lbl, val);
}

static void render_stats(GString *body, prom_stats_t s, GString *lbl)
{
    char buf[32];

    snprintf(buf, sizeof buf, "%" PRIu64, s.n);
    emit_gauge(body, "promshark_window_packets",
               "Packets in last scrape window", lbl->str, buf);

    snprintf(buf, sizeof buf, "%" PRIu64, s.unique_ids);
    emit_gauge(body, "promshark_window_entities_unique",
               "Unique entity IDs in last scrape window", lbl->str, buf);

    if (!s.have_latency)
        return;

    snprintf(buf, sizeof buf, "%.6f", s.latency_min);
    emit_gauge(body, "promshark_window_latency_seconds_min",
               "Min latency in last scrape window", lbl->str, buf);
    snprintf(buf, sizeof buf, "%.6f", s.latency_max);
    emit_gauge(body, "promshark_window_latency_seconds_max",
               "Max latency in last scrape window", lbl->str, buf);
    snprintf(buf, sizeof buf, "%.6f", s.latency_sum / s.n);
    emit_gauge(body, "promshark_window_latency_seconds_avg",
               "Avg latency in last scrape window", lbl->str, buf);
}

/* extractor registry  (opengl-globe/src/capture/extract.c)
 *
 * Static table of protocol extractors. Each row is one Wireshark filter name
 * ("dis", future "asterix", …) with two callbacks:
 *
 *   cache_fn   — once after epan_init: resolve hf ids, allocate state
 *   extract_fn — per matching packet: read fields, prom_pkt_push a raw row
 *
 * Enabled at runtime by -p PROTO (repeatable). extractors_run() is called from
 * the packet loop. No render_fn — metrics come from the window analyzer only.
 *
 * To add a protocol: implement extract_FOO_cache/extract, add one row here.
 */

struct prom_extractor;

typedef void (*prom_extract_cache_fn)(struct prom_extractor *self);
typedef void (*prom_extract_fn)      (struct prom_extractor *self,
                                        epan_dissect_t *edt,
                                        packet_info *pi,
                                        int64_t recv_us);

typedef struct prom_extractor {
    const char          *proto_name;
    prom_extract_cache_fn cache_fn;
    prom_extract_fn       extract_fn;
    void                 *state;
    gboolean              enabled;
} prom_extractor_t;

static void extract_dis_cache(prom_extractor_t *self);
static void extract_dis      (prom_extractor_t *self,
                              epan_dissect_t *edt,
                              packet_info *pi,
                              int64_t recv_us);

static prom_extractor_t s_extractors[] = {
    {
        .proto_name = "dis",
        .cache_fn   = extract_dis_cache,
        .extract_fn = extract_dis,
    },
};

static prom_extractor_t *extractors_find(const char *name)
{
    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++)
        if (strcmp(s_extractors[i].proto_name, name) == 0)
            return &s_extractors[i];
    return NULL;
}

static gboolean extractors_enable(const char *name)
{
    prom_extractor_t *x = extractors_find(name);
    if (!x) return FALSE;
    x->enabled = TRUE;
    fprintf(stderr, "[%s] tracking\n", name);
    return TRUE;
}

static void extractors_cache_fields(void)
{
    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++)
        if (s_extractors[i].cache_fn)
            s_extractors[i].cache_fn(&s_extractors[i]);
}

static void extractors_run(epan_dissect_t *edt, packet_info *pi, int64_t recv_us)
{
    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++) {
        prom_extractor_t *x = &s_extractors[i];
        if (!x->enabled || !x->extract_fn) continue;
        if (!pi->layers) continue;
        if (!proto_is_frame_protocol(pi->layers, x->proto_name)) continue;
        x->extract_fn(x, edt, pi, recv_us);
    }
}

static void extractors_shutdown(void)
{
    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++) {
        g_free(s_extractors[i].state);
        s_extractors[i].state = NULL;
    }
}

static gboolean extractors_any_enabled(void)
{
    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++)
        if (s_extractors[i].enabled) return TRUE;
    return FALSE;
}

/* window analyzer render
 *
 * One scrape transaction: snapshot the list, analyze off-thread (no capture
 * lock), emit aggregate gauges, then per-enabled-proto gauges with a
 * protocol="dis" label. Snapshot is freed when done; live list is already empty.
 */

static void prom_window_render(GString *body)
{
    GArray *snap = scrape_snapshot();
    GString *lbl;

    lbl = labels_for(NULL);
    render_stats(body, pkt_stats_from(snap, NULL), lbl);
    g_string_free(lbl, TRUE);

    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++) {
        prom_extractor_t *x = &s_extractors[i];
        if (!x->enabled) continue;
        lbl = labels_for(x->proto_name);
        render_stats(body, pkt_stats_from(snap, x->proto_name), lbl);
        g_string_free(lbl, TRUE);
    }

    g_array_free(snap, TRUE);
}

/* wireshark field helpers
 *
 * Thin wrappers around proto_find_finfo for the common cases. Shared by all
 * extractors so each protocol file doesn't copy the same GPtrArray boilerplate.
 */

static gboolean ws_field_us(proto_tree *tree, int hf, guint idx, int64_t *us)
{
    GPtrArray *fa = proto_find_finfo(tree, hf);
    if (!fa || fa->len <= idx) {
        if (fa) g_ptr_array_free(fa, TRUE);
        return FALSE;
    }
    const nstime_t *t = fvalue_get_time(((field_info *)g_ptr_array_index(fa, idx))->value);
    *us = (int64_t)t->secs * 1000000LL + t->nsecs / 1000;
    g_ptr_array_free(fa, TRUE);
    return TRUE;
}

static gboolean ws_field_u16(proto_tree *tree, int hf, guint idx, guint16 *v)
{
    GPtrArray *fa = proto_find_finfo(tree, hf);
    if (!fa || fa->len <= idx) {
        if (fa) g_ptr_array_free(fa, TRUE);
        return FALSE;
    }
    *v = (guint16)fvalue_get_uinteger(((field_info *)g_ptr_array_index(fa, idx))->value);
    g_ptr_array_free(fa, TRUE);
    return TRUE;
}

/* DIS extractor  (opengl-globe/src/capture/extract_dis.c, stripped down)
 *
 * Read entity id + timestamp from the dissector tree, pack site/app/entity
 * into entity_id, push one prom_pkt_t row. No sim lifecycle, no metrics, no
 * PDU-type switchboard — the window analyzer figures out the rest.
 */

enum { HF_TS, HF_SITE, HF_APP, HF_ENT, HF_N };

typedef struct {
    int hf[HF_N];
} dis_state_t;

static dis_state_t *dis_of(prom_extractor_t *self)
{
    return (dis_state_t *)self->state;
}

static void extract_dis_cache(prom_extractor_t *self)
{
    dis_state_t *S = g_new0(dis_state_t, 1);
    self->state = S;

    static const char *names[HF_N] = {
        "dis.timestamp",
        "dis.entity_id_site", "dis.entity_id_application", "dis.entity_id_entity",
    };
    for (int i = 0; i < HF_N; i++) {
        S->hf[i] = proto_registrar_get_id_byname(names[i]);
        if (S->hf[i] < 0) {
            fprintf(stderr, "dis field missing: %s\n", names[i]);
            exit(1);
        }
    }
    if (proto_get_id_by_filter_name("dis") == -1) {
        fprintf(stderr, "dis protocol not available\n");
        exit(1);
    }
}

static void extract_dis(prom_extractor_t *self,
                        epan_dissect_t *edt,
                        packet_info *pi,
                        int64_t recv_us)
{
    (void)pi;
    dis_state_t *S = dis_of(self);
    proto_tree *tree = edt->tree;

    int64_t ts_us = recv_us;
    guint16 site, app, entity;
    uint64_t entity_id;

    ws_field_us(tree, S->hf[HF_TS], 0, &ts_us);
    if (!ws_field_u16(tree, S->hf[HF_SITE], 0, &site) ||
        !ws_field_u16(tree, S->hf[HF_APP], 0, &app) ||
        !ws_field_u16(tree, S->hf[HF_ENT], 0, &entity))
        return;

    entity_id = ((uint64_t)site << 32) | ((uint64_t)app << 16) | entity;
    if (!entity_id)
        return;

    prom_pkt_push(self->proto_name, entity_id, recv_us, ts_us);
}

/* /metrics HTTP server
 *
 * Minimal Prometheus exposition endpoint on a dedicated thread because
 * pcap_loop() blocks the main thread.
 *
 * Flow:  GET /metrics → prom_window_render (snapshot + analyze + emit)
 *        → text/plain body → connection closed.
 */

static pcap_t           *pc;
static volatile sig_atomic_t stop_loop;
static int               metrics_port = 9090;
static int               metrics_fd = -1;
static pthread_t         metrics_tid;

static void on_sig(int s)
{
    (void)s;
    stop_loop = 1;
    if (pc) pcap_breakloop(pc);
    if (metrics_fd >= 0) shutdown(metrics_fd, SHUT_RDWR);
}

static void serve_metrics(int cfd)
{
    char req[512];
    ssize_t n = recv(cfd, req, sizeof req - 1, 0);
    if (n <= 0) return;
    req[n] = '\0';
    const char *path = strncmp(req, "GET ", 4) == 0 ? req + 4 : req;

    if (strncmp(path, "/metrics", 8) != 0) {
        static const char nf[] =
            "HTTP/1.1 404 Not Found\r\nContent-Length: 13\r\n\r\n404 Not Found\n";
        send(cfd, nf, sizeof nf - 1, 0);
        return;
    }

    GString *body = g_string_new(NULL);
    prom_window_render(body);

    char hdr[128];
    snprintf(hdr, sizeof hdr,
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: text/plain; version=0.0.4\r\n"
        "Content-Length: %zu\r\nConnection: close\r\n\r\n", body->len);
    send(cfd, hdr, strlen(hdr), 0);
    send(cfd, body->str, body->len, 0);
    g_string_free(body, TRUE);
}

static void *metrics_thread(void *arg)
{
    (void)arg;
    while (!stop_loop) {
        struct pollfd pfd = { metrics_fd, POLLIN, 0 };
        if (poll(&pfd, 1, 500) <= 0) continue;
        struct sockaddr_in cli;
        socklen_t clen = sizeof cli;
        int cfd = accept(metrics_fd, (struct sockaddr *)&cli, &clen);
        if (cfd < 0) {
            if (errno == EINTR) continue;
            break;
        }
        serve_metrics(cfd);
        close(cfd);
    }
    return NULL;
}

static int metrics_listen(int port)
{
    metrics_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (metrics_fd < 0) return -1;

    int one = 1;
    setsockopt(metrics_fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = htonl(INADDR_ANY),
        .sin_port = htons((uint16_t)port),
    };
    if (bind(metrics_fd, (struct sockaddr *)&addr, sizeof addr) < 0 ||
        listen(metrics_fd, 16) < 0 ||
        pthread_create(&metrics_tid, NULL, metrics_thread, NULL) != 0) {
        close(metrics_fd);
        metrics_fd = -1;
        return -1;
    }
    fprintf(stderr, "metrics on http://0.0.0.0:%d/metrics\n", port);
    return 0;
}

static void metrics_shutdown(void)
{
    if (metrics_fd < 0) return;
    shutdown(metrics_fd, SHUT_RDWR);
    close(metrics_fd);
    metrics_fd = -1;
    pthread_join(metrics_tid, NULL);
}

/* packet loop  (opengl-globe/src/capture/pcap_loop.c)
 *
 * Shared hot path for live capture (on_pkt) and offline pcap (process_file).
 * Per packet:
 *   frame_data_init → append ts_hist → epan_dissect_run → extractors_run → reset
 *
 * recv_us passed to extractors is fd.abs_ts (capture time), not protocol sim time.
 * proto_tree_visible=TRUE on epan_dissect_new: required so proto_find_finfo
 * sees sub-fields; with FALSE many dissectors omit them from the tree.
 */

static void process_packet(wtap_rec *r, Buffer *buf, int64_t file_offset)
{
    frame_data fd;
    frame_data_init(&fd, ++frame_no, r, file_offset, 0);
    g_array_append_val(ts_hist, fd.abs_ts);

    epan_dissect_run(edt, file_subtype, r,
        tvb_new_real_data(ws_buffer_start_ptr(buf),
                          r->rec_header.packet_header.caplen,
                          r->rec_header.packet_header.len),
        &fd, NULL);

    int64_t recv_us = (int64_t)fd.abs_ts.secs * 1000000LL + fd.abs_ts.nsecs / 1000;
    extractors_run(edt, &edt->pi, recv_us);

    epan_dissect_reset(edt);
    frame_data_destroy(&fd);
}

static int process_file(const char *path)
{
    int err = 0;
    char *err_info = NULL;
    wtap *wth = wtap_open_offline(path, WTAP_TYPE_AUTO, &err, &err_info, FALSE);
    if (!wth) {
        fprintf(stderr, "wtap_open_offline(%s): %s\n", path,
                err_info ? err_info : wtap_strerror(err));
        g_free(err_info);
        return 1;
    }

    file_subtype = wtap_file_type_subtype(wth);
    fprintf(stderr, "reading %s -> metrics\n", path);

    wtap_rec rec;
    Buffer buf;
    int64_t off = 0;
    wtap_rec_init(&rec);
    ws_buffer_init(&buf, 1514);
    while (!stop_loop && wtap_read(wth, &rec, &buf, &err, &err_info, &off)) {
        if (rec.rec_type == REC_TYPE_PACKET)
            process_packet(&rec, &buf, off);
        wtap_rec_reset(&rec);
    }
    wtap_rec_cleanup(&rec);
    ws_buffer_free(&buf);

    int rc = (err != 0 && err != WTAP_ERR_SHORT_READ) ? 1 : 0;
    if (rc) fprintf(stderr, "wtap_read: %s\n", err_info ? err_info : wtap_strerror(err));
    g_free(err_info);
    wtap_close(wth);
    return rc;
}

static void on_pkt(u_char *user, const struct pcap_pkthdr *h, const u_char *bytes)
{
    (void)user;
    Buffer buf;
    ws_buffer_init(&buf, h->caplen);
    ws_buffer_append(&buf, (guint8 *)bytes, h->caplen);

    wtap_rec r;
    wtap_rec_init(&r);
    r.rec_type = REC_TYPE_PACKET;
    r.presence_flags = WTAP_HAS_TS | WTAP_HAS_CAP_LEN;
    r.ts.secs = h->ts.tv_sec;
    r.ts.nsecs = (int)(h->ts.tv_usec * 1000);
    r.rec_header.packet_header.caplen = h->caplen;
    r.rec_header.packet_header.len = h->len;
    r.rec_header.packet_header.pkt_encap = WTAP_ENCAP_ETHERNET;

    process_packet(&r, &buf, 0);
    wtap_rec_cleanup(&r);
    ws_buffer_free(&buf);
}

/* main
 *
 * Parse argv, init libwireshark + extractors, start metrics thread, then either:
 *   -r FILE  ingest offline, keep serving /metrics until Ctrl+C
 *   -i IFACE live pcap_loop until signal
 *
 * shutdown_all order: metrics thread → extractor state → scrape list → epan.
 */

static int shutdown_all(int rc)
{
    metrics_shutdown();
    extractors_shutdown();
    prom_scrape_shutdown();
    promshark_ws_shutdown();
    return rc;
}

int main(int argc, char **argv)
{
    const char *iface = NULL, *infile = NULL, *bpf = NULL;
    int c;

    while ((c = getopt(argc, argv, "i:r:p:f:m:l:")) != -1) {
        switch (c) {
        case 'i': iface = optarg; break;
        case 'r': infile = optarg; break;
        case 'p':
            if (!extractors_enable(optarg)) {
                fprintf(stderr, "unsupported protocol: %s\n", optarg);
                return 2;
            }
            break;
        case 'f': bpf = optarg; break;
        case 'm': metrics_port = atoi(optarg); break;
        case 'l': if (add_extra_label(optarg) != 0) return 2; break;
        default: c = '?'; break;
        }
    }
    if (c == '?' || (!iface && !infile) || (iface && infile) ||
        !extractors_any_enabled()) {
        fprintf(stderr,
            "usage: %s (-i IFACE | -r FILE) -p PROTO [-p PROTO ...] "
            "[-f BPF] [-m PORT] [-l KEY=VAL ...]\n"
            "\n"
            "  -i IFACE   live capture (optional -f BPF filter)\n"
            "  -r FILE    offline pcap/pcapng\n"
            "  -p PROTO   Wireshark protocol name (dis implemented)\n"
            "  -f BPF     live capture filter only\n"
            "  -m PORT    /metrics port (default 9090)\n"
            "  -l KEY=VAL extra Prometheus label (repeatable)\n",
            argv[0]);
        return 2;
    }
    if (metrics_port <= 0 || metrics_port > 65535) return 2;

    if (promshark_ws_init(argv[0]) != 0) return 1;
    prom_scrape_init();
    extractors_cache_fields();

    ts_hist = g_array_new(FALSE, FALSE, sizeof(nstime_t));
    sess = epan_new(NULL, &prov_funcs);
    edt = epan_dissect_new(sess, TRUE, TRUE);

    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);
    if (metrics_listen(metrics_port) != 0) {
        perror("metrics");
        return shutdown_all(1);
    }

    if (infile) {
        int rc = process_file(infile);
        fprintf(stderr, "ingest done; /metrics still served (Ctrl+C to exit)\n");
        while (!stop_loop) sleep(1);
        return shutdown_all(rc);
    }

    char errbuf[PCAP_ERRBUF_SIZE];
    pc = pcap_open_live(iface, 65535, 1, 100, errbuf);
    if (!pc) {
        fprintf(stderr, "pcap_open_live(%s): %s\n", iface, errbuf);
        return shutdown_all(1);
    }
    if (bpf) {
        struct bpf_program prog;
        if (pcap_compile(pc, &prog, bpf, 1, PCAP_NETMASK_UNKNOWN) < 0 ||
            pcap_setfilter(pc, &prog) < 0) {
            fprintf(stderr, "bpf: %s\n", pcap_geterr(pc));
            return shutdown_all(1);
        }
        pcap_freecode(&prog);
    }

    fprintf(stderr, "capturing on %s -> metrics\n", iface);
    pcap_loop(pc, -1, on_pkt, NULL);
    pcap_close(pc);
    return shutdown_all(0);
}
