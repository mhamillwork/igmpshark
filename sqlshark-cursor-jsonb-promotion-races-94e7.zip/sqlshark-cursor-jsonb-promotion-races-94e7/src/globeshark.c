/* globeshark — live capture → web-globe relay /ingest via libwireshark.
 *
 *
 * WHAT THIS PROGRAM IS
 *
 * A capture *adapter*, not a globe. It does NOT talk to the browser, draw
 * anything, or own scene state / DVR / viewport filtering. It only:
 *   1. captures live traffic (libpcap)
 *   2. dissects with libwireshark (same epan engine as Wireshark/tshark)
 *   3. runs protocol extractors → georeferenced entity poses
 *   4. sends JSON over WebSocket to the relay at /ingest
 *
 * The relay (~/web-globe) merges tracks, buffers history, filters by
 * viewport, and serves the globe. Adapters must NOT send "clock", upsert,
 * or display commands — only hello + batch of tracks.
 *
 * Lineage (read siblings if you want the bigger picture):
 *   - ~/opengl-globe  "Globe Wireshark": same extractors, but drew OpenGL
 *                     in-process. This file is that capture half, retargeted.
 *   - src/promshark.c metrics sibling; same field-helper / extractor pattern.
 *   - src/dbshark.c   dumps every field to Postgres; we only keep poses.
 *
 * 
 * FILE LAYOUT (read top → bottom; diamond — narrow edges, wide middle)
 *
 *   config .................. CLI / env knobs
 *   entity_update_t ......... pose struct extractors must fill
 *   ECEF helper ............. DIS locations → lat/lon/alt
 *   entity store ............ coalesce latest pose per (decoder, id)
 *   ingest JSON ............. hello once, then op:batch of taken updates
 *   WebSocket /ingest ....... lws client, reconnect, hello-first
 *   libwireshark session .... epan init, sess/edt, bounded ts_ring
 *   field helpers ........... primed proto_get_finfo_ptr_array + fvalue_get_*
 *   extractor registry ...... HOW TO ADD A PROTOCOL (start here for new work)
 *   DIS / ASTERIX / stub .... reference extractors
 *   event loop .............. pcap_dispatch ↔ flush_once ↔ lws_service
 *   main .................... argv, init order, shutdown order
 *                             (Windows: no getopt/unistd; WSAStartup +
 *                             console Ctrl handler; Npcap device names)
 *
 *
 * DATA PATH (single thread — no capture mutexes)
 *
 *   iface → pcap → epan_dissect_run → extractors_run → entity_push
 *   loop  → entity_take → {"op":"batch","tracks":[...]} → /ingest
 *
 * Coalesce: many PDUs for the same track overwrite one store row; flush
 * sends ~unique_tracks × flush_hz, not raw PDU rate — what a globe wants.
 *
 * Speed (why this is not "full Wireshark per packet"):
 *   hidden proto tree + hfid priming, unused dissectors off, O(1) field
 *   arrays instead of tree walks, reused pcap/wtap/JSON/lws buffers,
 *   dual hash maps so flush does not malloc a table.
 *
 * Ingest contract: ~/web-globe README + relay/relay.c, path /ingest,
 * subprotocol relay-ws. Required: display, id, lon, lat. DIS ids are
 * site:app:ent (colons). Heading lives in both orientation and
 * kinematics.heading_deg. entity.{force_id,kind,domain,marking} optional.
 *
 * New developer? Jump to "extractor registry" and copy the stub extractor.
 */
#ifndef _WIN32
#define _GNU_SOURCE
#endif
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0600
#endif
#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif
#endif
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <inttypes.h>
#include <stdint.h>
#include <errno.h>
#include <math.h>
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#else
#include <unistd.h>
#endif

#include <glib.h>
#include <pcap/pcap.h>
#include <epan/epan.h>
#include <epan/epan_dissect.h>
#include <epan/proto.h>
#include <epan/packet.h>
#include <epan/prefs.h>
#include <epan/tvbuff.h>
#include <epan/ftypes/ftypes.h>
#include <wiretap/wtap.h>
#include <wsutil/buffer.h>
#include <wsutil/filesystem.h>
#include <wsutil/privileges.h>
#include <wsutil/wslog.h>

#include <libwebsockets.h>

/* config
 *
 * Process-wide knobs. Set from CLI in main() (and a few env vars for k8s).
 *
 *   g_ingest_url     ...... relay WebSocket, default ws://127.0.0.1:8080/ingest
 *   g_node / g_pod ........ hello provenance (NODE_NAME / POD_NAME or hostname)
 *   g_captured_iface ...... hello.captured_iface (defaults to -i)
 *   g_display ............. optional override for track "display" label
 *   g_flush_hz ............ how often we entity_take → batch (default 10 Hz)
 *
 * sess / edt / frame_no / pc / stop_loop are the live-capture session globals
 * owned by the single event-loop thread.
 */

static const char *g_ingest_url = "ws://127.0.0.1:8080/ingest";
static const char *g_node;
static const char *g_pod;
static const char *g_captured_iface = "lo";
static const char *g_display;
static double      g_flush_hz = 10.0;

#ifdef __GNUC__
#define GLOBE_LIKELY(x)   __builtin_expect(!!(x), 1)
#define GLOBE_UNLIKELY(x) __builtin_expect(!!(x), 0)
#else
#define GLOBE_LIKELY(x)   (x)
#define GLOBE_UNLIKELY(x) (x)
#endif

static epan_t         *sess;
static epan_dissect_t *edt;
static guint32         frame_no;
static pcap_t         *pc;
static volatile sig_atomic_t stop_loop;

/* Reused live-capture record + payload. Allocating these per datagram was
 * the old path; epan_dissect_reset already recycles the tree. */
static Buffer   live_buf;
static wtap_rec live_rec;
static int      live_ready;

/* hfids extractors will read. Hidden trees only materialize primed leaves;
 * proto_tree_reset() clears ref_type, so we re-prime every packet. */
static int    *prime_ids;
static size_t  n_prime_ids;

static GString       *json_buf;
static unsigned char *lws_scratch;
static size_t         lws_scratch_cap;

/* entity_update_t — what every extractor must produce
 *
 * One georeferenced pose. Extractors fill this and call entity_push().
 * The store coalesces by (decoder, entity_id); JSON formatting later maps
 * fields onto the relay track object.
 *
 * Required for a visible track:
 *   decoder     string literal naming the protocol ("dis", "asterix", …).
 *               Also used as the -p name and as proto_is_frame_protocol key.
 *   entity_id   stable int64 key within that decoder. 0 is rejected.
 *               format_entity_id() may pretty-print it (DIS site:app:ent,
 *               ASTERIX ICAO hex); unknown decoders print decimal.
 *   t_ms        Unix time in milliseconds (usually the frame timestamp).
 *   lat_deg, lon_deg   WGS-84 degrees. Non-finite → entity_push drops.
 *
 * Optional (use NAN / -1 / empty when unknown):
 *   alt_m            meters MSL; omitted from JSON if NAN
 *   vel_n/e/u        m/s north/east/up (or ENU-ish); → kinematics.speed_mps
 *   heading_deg      degrees; → orientation + kinematics.heading_deg
 *   force_id         DIS force (1=Blue, 2=Red); -1 = unset
 *   kind, domain     IEEE-1278 entity type; -1 = unset. Globe glyphs use
 *                    domain (1 land, 2 air, 3 surface, 5 space).
 *   callsign         short label / marking → label + entity.marking
 *
 * Coordinate rules:
 *   - Prefer native lat/lon when the protocol has them (ASTERIX, AIS, …).
 *   - DIS Entity State is ECEF meters — convert with ecef_to_geodetic().
 *   - Do not push ECEF or radians into lat_deg/lon_deg.
 */

typedef struct {
    const char *decoder;
    int64_t     entity_id;
    int64_t     t_ms;

    double      lat_deg;
    double      lon_deg;
    float       alt_m;

    float       vel_n, vel_e, vel_u;
    float       heading_deg;
    int         force_id;
    int         kind;
    int         domain;
    char        callsign[16];
} entity_update_t;

/* WGS-84 ECEF → geodetic (opengl-globe/src/ecef.c)
 *
 * DIS Entity State locations are ECEF meters; the ingest contract wants
 * geodetic degrees + altitude meters.
 */

#define WGS84_A  6378137.0
#define WGS84_F  (1.0 / 298.257223563)
#define WGS84_E2 (WGS84_F * (2.0 - WGS84_F))
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

static double ecef_b, ecef_ep2, ecef_to_deg;

static void ecef_init(void)
{
    ecef_b = WGS84_A * sqrt(1.0 - WGS84_E2);
    ecef_ep2 = (WGS84_A * WGS84_A - ecef_b * ecef_b) / (ecef_b * ecef_b);
    ecef_to_deg = 180.0 / M_PI;
}

static void ecef_to_geodetic(double x, double y, double z,
                             double *lat_deg, double *lon_deg, double *alt_m)
{
    double a = WGS84_A, e2 = WGS84_E2, b = ecef_b, ep2 = ecef_ep2;
    double p = sqrt(x * x + y * y);
    double th = atan2(z * a, p * b);
    double sth = sin(th), cth = cos(th);
    double lat = atan2(z + ep2 * b * sth * sth * sth,
                       p - e2 * a * cth * cth * cth);
    double lon = atan2(y, x);
    double slat = sin(lat);
    double N = a / sqrt(1.0 - e2 * slat * slat);
    double alt = (p > 1e-9) ? p / cos(lat) - N : fabs(z) - b;
    if (lat_deg) *lat_deg = lat * ecef_to_deg;
    if (lon_deg) *lon_deg = lon * ecef_to_deg;
    if (alt_m) *alt_m = alt;
}

/* entity store — coalesce before send
 *
 * Capture path calls entity_push() for every complete pose. Many PDUs for
 * the same (decoder, entity_id) overwrite one row — the globe only needs
 * the latest pose per track at flush_hz, not every PDU.
 *
 * The event loop calls entity_take() when it is time to flush. take swaps
 * out the hash table so JSON/WS work does not block new PDUs: they land in
 * a fresh table and ride the next flush.
 *
 * No mutex: the single-threaded event loop owns both push and take.
 * entity_push rejects entity_id==0 and non-finite lat/lon.
 */

typedef struct {
    const char *decoder;
    int64_t     entity_id;
} entity_key_t;

static GHashTable *entity_maps[2];
static int         entity_live;

static guint entity_key_hash(gconstpointer p)
{
    const entity_key_t *k = p;
    /* decoder is a process-lifetime literal ("dis", "asterix", …). Pointer
     * mix beats g_str_hash on the hot lookup. */
    guint h = (guint)(uintptr_t)k->decoder;
    h ^= (guint)k->entity_id;
    h ^= (guint)(k->entity_id >> 32);
    return h;
}

static gboolean entity_key_equal(gconstpointer a, gconstpointer b)
{
    const entity_key_t *x = a, *y = b;
    return x->entity_id == y->entity_id && x->decoder == y->decoder;
}

static GHashTable *entity_map_new(void)
{
    return g_hash_table_new_full(entity_key_hash, entity_key_equal, g_free, g_free);
}

static void entity_store_init(void)
{
    entity_maps[0] = entity_map_new();
    entity_maps[1] = entity_map_new();
    entity_live = 0;
}

static void entity_store_shutdown(void)
{
    for (int i = 0; i < 2; i++) {
        if (entity_maps[i]) {
            g_hash_table_destroy(entity_maps[i]);
            entity_maps[i] = NULL;
        }
    }
}

static void entity_push(const entity_update_t *u)
{
    if (GLOBE_UNLIKELY(!u || !u->decoder)) return;
    if (GLOBE_UNLIKELY(!isfinite(u->lat_deg) || !isfinite(u->lon_deg))) return;
    if (GLOBE_UNLIKELY(u->entity_id == 0)) return;

    GHashTable *map = entity_maps[entity_live];
    entity_key_t lookup = { .decoder = u->decoder, .entity_id = u->entity_id };
    entity_update_t *cur = g_hash_table_lookup(map, &lookup);
    if (cur) {
        *cur = *u;
        return;
    }
    entity_key_t *k = g_new(entity_key_t, 1);
    *k = lookup;
    entity_update_t *v = g_new(entity_update_t, 1);
    *v = *u;
    g_hash_table_insert(map, k, v);
}

/* Swap the live table. Caller must g_hash_table_remove_all() the result
 * (do not destroy — the pair is reused). NULL if nothing pending. */
static GHashTable *entity_take(void)
{
    GHashTable *map = entity_maps[entity_live];
    if (!map || g_hash_table_size(map) == 0)
        return NULL;
    entity_live ^= 1;
    return map;
}

/* ingest JSON — adapter → relay contract
 *
 * Formats entity_update_t into the relay track object, plus hello / batch
 * wrappers. Spec: ~/web-globe README Ingest + relay/relay.c parse_fields.
 *
 * Session:
 *   {"op":"hello","schema":2,"node":…,"pod":…,"captured_iface":…}
 *   {"op":"batch","tracks":[ … ]}                        at flush_hz
 *
 * Each track (required): decoder, display, id, lon, lat, t
 * Optional: alt, label, schema, orientation.{heading,pitch,roll}_deg,
 *           kinematics.{speed_mps,heading_deg,climb_mps},
 *           entity.{force_id,kind,domain,marking}
 *
 * DIS public ids MUST be site:app:ent (colons). The relay also composes
 * site+app+ent that way; dotted ids would be a different track key.
 *
 * display_for_update(): -d override, else Blue/Red from force_id, else
 * "ADS-B" for asterix, else the decoder name.
 *
 * format_entity_id(): protocol-specific string form of entity_id. When you
 * add a decoder with a non-decimal public id (MMSI, ICAO, …), extend this
 * function the same way as "dis" / "asterix".
 *
 * Adapters never send clock / upsert / remove — the relay owns those.
 */

static void json_escape_append(GString *out, const char *s)
{
    for (; s && *s; s++) {
        unsigned char c = (unsigned char)*s;
        switch (c) {
        case '"':  g_string_append_len(out, "\\\"", 2); break;
        case '\\': g_string_append_len(out, "\\\\", 2); break;
        case '\n': g_string_append_len(out, "\\n", 2); break;
        case '\r': g_string_append_len(out, "\\r", 2); break;
        case '\t': g_string_append_len(out, "\\t", 2); break;
        default:
            if (c < 0x20) g_string_append_printf(out, "\\u%04x", c);
            else g_string_append_c(out, (char)c);
            break;
        }
    }
}

static const char *display_for_update(const entity_update_t *u)
{
    if (g_display && g_display[0])
        return g_display;
    if (!u || !u->decoder) return "unknown";
    if (u->force_id == 1) return "Blue force";
    if (u->force_id == 2) return "Red force";
    if (strcmp(u->decoder, "asterix") == 0) return "ADS-B";
    return u->decoder;
}

static void format_entity_id(const entity_update_t *u, char *buf, size_t n)
{
    if (strcmp(u->decoder, "dis") == 0) {
        uint64_t id = (uint64_t)u->entity_id;
        snprintf(buf, n, "%u:%u:%u",
                 (unsigned)((id >> 32) & 0xffff),
                 (unsigned)((id >> 16) & 0xffff),
                 (unsigned)(id & 0xffff));
    } else if (strcmp(u->decoder, "asterix") == 0) {
        snprintf(buf, n, "%06" PRIX64, (uint64_t)u->entity_id & 0xffffff);
    } else {
        snprintf(buf, n, "%" PRId64, u->entity_id);
    }
}

static void append_track_json(GString *s, const entity_update_t *u)
{
    char id[64];
    format_entity_id(u, id, sizeof id);

    /* schema:2 matches web-globe test_ingest / relay SCHEMA. Ignored by
     * parse_fields but kept so a publisher dump looks like the fixture. */
    g_string_append(s, "{\"schema\":2,\"decoder\":\"");
    json_escape_append(s, u->decoder);
    g_string_append(s, "\",\"display\":\"");
    json_escape_append(s, display_for_update(u));
    g_string_append(s, "\",\"id\":\"");
    json_escape_append(s, id);
    g_string_append_printf(s, "\",\"lon\":%.8f,\"lat\":%.8f,\"t\":%" PRId64,
                           u->lon_deg, u->lat_deg, u->t_ms);
    if (isfinite(u->alt_m))
        g_string_append_printf(s, ",\"alt\":%.3f", (double)u->alt_m);

    if (u->callsign[0]) {
        g_string_append(s, ",\"label\":\"");
        json_escape_append(s, u->callsign);
        g_string_append_c(s, '"');
    }

    int has_heading = isfinite(u->heading_deg);
    int has_speed = isfinite(u->vel_n) && isfinite(u->vel_e);
    int has_climb = has_speed && isfinite(u->vel_u);

    /* Globe HUD uses kinematics.heading_deg first, then orientation.
     * Relay stores them separately — send both, like test_ingest.py. */
    if (has_heading) {
        g_string_append_printf(s,
            ",\"orientation\":{\"heading_deg\":%.2f,\"pitch_deg\":0,\"roll_deg\":0}",
            u->heading_deg);
    }

    if (has_heading || has_speed) {
        g_string_append(s, ",\"kinematics\":{");
        int kf = 1;
        if (has_speed) {
            float speed = (float)hypot(u->vel_e, u->vel_n);
            if (has_climb)
                speed = (float)sqrt(speed * speed + u->vel_u * u->vel_u);
            g_string_append_printf(s, "\"speed_mps\":%.2f", speed);
            kf = 0;
        }
        if (has_heading) {
            g_string_append_printf(s, "%s\"heading_deg\":%.2f",
                                   kf ? "" : ",", u->heading_deg);
            kf = 0;
        }
        if (has_climb)
            g_string_append_printf(s, ",\"climb_mps\":%.2f", u->vel_u);
        g_string_append_c(s, '}');
    }

    int has_ent = (u->force_id >= 0) || (u->kind >= 0) ||
                  (u->domain >= 0) || u->callsign[0];
    if (has_ent) {
        g_string_append(s, ",\"entity\":{");
        int ef = 1;
        if (u->force_id >= 0) {
            g_string_append_printf(s, "\"force_id\":%d", u->force_id);
            ef = 0;
        }
        if (u->kind >= 0) {
            g_string_append_printf(s, "%s\"kind\":%d", ef ? "" : ",", u->kind);
            ef = 0;
        }
        if (u->domain >= 0) {
            g_string_append_printf(s, "%s\"domain\":%d",
                                   ef ? "" : ",", u->domain);
            ef = 0;
        }
        if (u->callsign[0]) {
            g_string_append(s, ef ? "" : ",");
            g_string_append(s, "\"marking\":\"");
            json_escape_append(s, u->callsign);
            g_string_append_c(s, '"');
        }
        g_string_append_c(s, '}');
    }
    g_string_append_c(s, '}');
}

static GString *json_acquire(gsize hint)
{
    GString *s = json_buf;
    json_buf = NULL;
    if (!s)
        return g_string_sized_new(hint);
    g_string_truncate(s, 0);
    if (s->allocated_len < hint)
        g_string_set_size(s, hint), g_string_truncate(s, 0);
    return s;
}

static void json_recycle(GString *s)
{
    if (!s) return;
    if (!json_buf) {
        g_string_truncate(s, 0);
        json_buf = s;
        return;
    }
    g_string_free(s, TRUE);
}

static GString *build_hello_json(void)
{
    GString *s = json_acquire(256);
    g_string_append(s, "{\"op\":\"hello\",\"schema\":2,\"node\":\"");
    json_escape_append(s, g_node);
    g_string_append(s, "\",\"pod\":\"");
    json_escape_append(s, g_pod);
    g_string_append(s, "\",\"captured_iface\":\"");
    json_escape_append(s, g_captured_iface);
    g_string_append(s, "\"}");
    return s;
}

static GString *build_batch_json_from_map(GHashTable *map)
{
    guint n = g_hash_table_size(map);
    GString *s = json_acquire(n * 256 + 64);
    g_string_append(s, "{\"op\":\"batch\",\"tracks\":[");
    GHashTableIter it;
    gpointer key, value;
    int first = 1;
    g_hash_table_iter_init(&it, map);
    while (g_hash_table_iter_next(&it, &key, &value)) {
        if (!first) g_string_append_c(s, ',');
        first = 0;
        append_track_json(s, (entity_update_t *)value);
    }
    g_string_append(s, "]}");
    return s;
}

/* WebSocket /ingest client (libwebsockets)
 *
 * Single-threaded: lws_service runs on the same loop as pcap_dispatch.
 * Subprotocol name is "relay-ws" (must match the relay).
 *
 * txq holds pending GString messages. On ESTABLISHED we push hello first;
 * on disconnect we clear the queue so a fresh hello is always first after
 * reconnect. WRITEABLE pops one message and may re-request writable if more
 * remain.
 *
 * Backpressure: txq_push returns FALSE when full (TXQ_MAX). flush_once then
 * skips entity_take that tick so poses keep coalescing until there is room —
 * better than dropping mid-batch or blocking capture.
 */

enum { TXQ_MAX = 64 };

static struct lws_context *ws_ctx;
static struct lws         *ws_wsi;
static int                 ws_established;
static int                 ws_hello_sent;
static GQueue             *txq;
static char                ws_host[256];
static char                ws_path[256];
static int                 ws_port = 8080;
static int                 ws_ssl;

static void txq_clear(void)
{
    if (!txq) return;
    while (!g_queue_is_empty(txq)) {
        GString *m = g_queue_pop_head(txq);
        json_recycle(m);
    }
}

static gboolean txq_has_room(void)
{
    return txq && g_queue_get_length(txq) < TXQ_MAX;
}

static gboolean txq_push(GString *msg)
{
    if (!msg) return FALSE;
    if (!txq || g_queue_get_length(txq) >= TXQ_MAX) {
        json_recycle(msg);
        return FALSE;
    }
    g_queue_push_tail(txq, msg);
    if (ws_wsi)
        lws_callback_on_writable(ws_wsi);
    return TRUE;
}

static void txq_push_hello(GString *msg)
{
    if (!msg) return;
    txq_clear();
    if (txq)
        g_queue_push_tail(txq, msg);
    else
        json_recycle(msg);
    if (ws_wsi)
        lws_callback_on_writable(ws_wsi);
}

static void ws_reset_session(void)
{
    txq_clear();
    ws_wsi = NULL;
    ws_established = 0;
    ws_hello_sent = 0;
}

static int parse_ws_url(const char *url)
{
    const char *p = url;
    ws_ssl = 0;
    if (g_str_has_prefix(p, "wss://")) { ws_ssl = 1; p += 6; }
    else if (g_str_has_prefix(p, "ws://")) { p += 5; }
    else {
        fprintf(stderr, "ingest URL must be ws:// or wss://\n");
        return -1;
    }
    const char *slash = strchr(p, '/');
    const char *colon = strchr(p, ':');
    size_t host_len;
    if (colon && (!slash || colon < slash)) {
        host_len = (size_t)(colon - p);
        ws_port = atoi(colon + 1);
    } else {
        host_len = slash ? (size_t)(slash - p) : strlen(p);
        ws_port = ws_ssl ? 443 : 80;
    }
    if (host_len == 0 || host_len >= sizeof ws_host) return -1;
    memcpy(ws_host, p, host_len);
    ws_host[host_len] = '\0';
    g_strlcpy(ws_path, slash ? slash : "/ingest", sizeof ws_path);
    return 0;
}

static int cb_ingest(struct lws *wsi, enum lws_callback_reasons reason,
                     void *user, void *in, size_t len)
{
    (void)user; (void)len;
    switch (reason) {
    case LWS_CALLBACK_CLIENT_CONNECTION_ERROR:
        fprintf(stderr, "[globeshark] connect error: %s\n",
                in ? (char *)in : "(unknown)");
        ws_reset_session();
        break;
    case LWS_CALLBACK_CLIENT_ESTABLISHED:
        fprintf(stderr, "[globeshark] ingest connected %s:%d%s\n",
                ws_host, ws_port, ws_path);
        ws_established = 1;
        ws_hello_sent = 0;
        txq_push_hello(build_hello_json());
        break;
    case LWS_CALLBACK_CLIENT_CLOSED:
        fprintf(stderr, "[globeshark] ingest closed — retrying\n");
        ws_reset_session();
        break;
    case LWS_CALLBACK_CLIENT_WRITEABLE: {
        GString *msg = txq ? g_queue_pop_head(txq) : NULL;
        int more = txq && g_queue_get_length(txq) > 0;
        if (!msg) break;
        size_t n = msg->len;
        if (lws_scratch_cap < LWS_PRE + n) {
            size_t cap = LWS_PRE + n;
            unsigned char *p = g_realloc(lws_scratch, cap);
            if (!p) {
                if (txq) g_queue_push_head(txq, msg);
                else json_recycle(msg);
                break;
            }
            lws_scratch = p;
            lws_scratch_cap = cap;
        }
        memcpy(lws_scratch + LWS_PRE, msg->str, n);
        int m = lws_write(wsi, lws_scratch + LWS_PRE, n, LWS_WRITE_TEXT);
        if (m < 0 || (size_t)m < n) {
            if (txq) g_queue_push_head(txq, msg);
            else json_recycle(msg);
            break;
        }
        if (!ws_hello_sent && msg->str &&
            g_str_has_prefix(msg->str, "{\"op\":\"hello\""))
            ws_hello_sent = 1;
        json_recycle(msg);
        if (more) lws_callback_on_writable(wsi);
        break;
    }
    default:
        break;
    }
    return 0;
}

static const struct lws_protocols protocols[] = {
    { "relay-ws", cb_ingest, 0, 16 * 1024, 0, NULL, 0 },
    { NULL, NULL, 0, 0, 0, NULL, 0 }
};

static int ws_connect(void)
{
    struct lws_client_connect_info i;
    memset(&i, 0, sizeof i);
    i.context = ws_ctx;
    i.address = ws_host;
    i.port = ws_port;
    i.path = ws_path;
    i.host = ws_host;
    i.origin = ws_host;
    i.protocol = protocols[0].name;
    i.ssl_connection = ws_ssl ? LCCSCF_USE_SSL : 0;
    i.pwsi = &ws_wsi;
    return lws_client_connect_via_info(&i) ? 0 : -1;
}

static int ws_init(void)
{
    if (parse_ws_url(g_ingest_url) != 0) return -1;
    txq = g_queue_new();
    struct lws_context_creation_info info;
    memset(&info, 0, sizeof info);
    info.port = CONTEXT_PORT_NO_LISTEN;
    info.protocols = protocols;
    info.options = LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT;
    ws_ctx = lws_create_context(&info);
    if (!ws_ctx) return -1;
    return ws_connect();
}

static void ws_shutdown(void)
{
    if (ws_ctx) { lws_context_destroy(ws_ctx); ws_ctx = NULL; }
    ws_wsi = NULL;
    txq_clear();
    if (txq) {
        g_queue_free(txq);
        txq = NULL;
    }
}

/* Take pending entities and queue one batch. No-op if not ready / empty /
 * backpressured. Called from the single event loop. */
static void flush_once(void)
{
    if (!ws_established || !ws_hello_sent || !txq_has_room())
        return;
    GHashTable *taken = entity_take();
    if (!taken) return;
    guint n = g_hash_table_size(taken);
    GString *msg = build_batch_json_from_map(taken);
    if (!txq_push(msg)) {
        /* Should not happen after txq_has_room; if it does, drop this take
         * (next PDUs will refill). Prefer not to re-merge into live map. */
        g_hash_table_remove_all(taken);
        return;
    }
    fprintf(stderr, "[globeshark] batch %u entities\n", n);
    g_hash_table_remove_all(taken);
}

/* libwireshark session
 *
 * Same init sequence as promshark / dbshark / opengl-globe capture.c:
 *   ws_log_init → configuration_init → wtap_init → epan_init → epan_load_settings
 * Skipping any step causes obscure crashes inside dissector registration or
 * MaxMind lookups — do not "simplify" this.
 *
 * sess / edt are reused every packet. edt is a *hidden* proto tree
 * (create=TRUE, vis=FALSE): TRY_TO_FAKE only allocates primed leaves, so
 * we skip the 240-byte GUI label on every other field. Extractors read
 * those leaves via proto_get_finfo_ptr_array (O(1) after prime), not a
 * full-tree proto_find_finfo walk.
 *
 * ts_ring: bounded frame-timestamp history for prov_ts callbacks (some
 * dissectors ask for earlier frame times). Live capture never needs an
 * unbounded GArray like offline tools sometimes keep.
 */

enum { TS_HIST_CAP = 8192 };
static nstime_t ts_ring[TS_HIST_CAP];

static const nstime_t *prov_ts_cb(struct packet_provider_data *p, guint32 num)
{
    (void)p;
    if (num == 0 || num > frame_no) return NULL;
    if (frame_no - num >= (guint32)TS_HIST_CAP) return NULL;
    return &ts_ring[(num - 1) % TS_HIST_CAP];
}

static wtap_block_t prov_mbk_cb(struct packet_provider_data *p, const frame_data *f)
{
    (void)p; (void)f;
    return NULL;
}

static const struct packet_provider_funcs prov_funcs = {
    .get_frame_ts = prov_ts_cb,
    .get_modified_block = prov_mbk_cb,
};

static void prime_add(int id)
{
    if (id < 0) return;
    for (size_t i = 0; i < n_prime_ids; i++)
        if (prime_ids[i] == id) return;
    int *p = realloc(prime_ids, (n_prime_ids + 1) * sizeof(*p));
    if (!p) return;
    prime_ids = p;
    prime_ids[n_prime_ids++] = id;
}

static void prime_all_hfids(void)
{
    for (size_t i = 0; i < n_prime_ids; i++)
        epan_dissect_prime_with_hfid(edt, prime_ids[i]);
}

static void set_pref_false(const char *name)
{
    char buf[128];
    char *err = NULL;
    snprintf(buf, sizeof buf, "%s:FALSE", name);
    prefs_set_pref_e rc = prefs_set_pref(buf, &err);
    if (rc == PREFS_SET_SYNTAX_ERR)
        g_free(err);
}

static void enable_proto_name(const char *name)
{
    int id = proto_get_id_by_filter_name(name);
    if (id < 0) return;
    if (proto_can_toggle_protocol(id))
        proto_set_decoding(id, TRUE);
}

/* Cut epan work we do not persist. Nameres/checksums/defrag/TCP reassembly
 * allocate and walk bytes we never send. proto_disable_all() then re-enable
 * the L2–L4 path plus each -p extractor: unused dissectors never create
 * tree nodes. frame cannot toggle — skip proto_set_decoding. */
static void vcmdarg_err(const char *fmt, va_list ap)
{
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
}

static int shark_init(const char *argv0)
{
    g_setenv("WS_LOG_LEVEL", "warning", FALSE);
    ws_log_init("globeshark", vcmdarg_err);
    ws_log_set_level(LOG_LEVEL_WARNING);
    init_process_policies();
    char *cfg_err = configuration_init(argv0, NULL);
    if (cfg_err) {
        fprintf(stderr, "configuration_init: %s\n", cfg_err);
        g_free(cfg_err);
        return -1;
    }
    wtap_init(TRUE);
    if (!epan_init(NULL, NULL, TRUE)) {
        fprintf(stderr, "epan_init failed\n");
        return -1;
    }
    epan_load_settings();
    ecef_init();
    return 0;
}

static void shark_shutdown(void)
{
    if (edt) { epan_dissect_free(edt); edt = NULL; }
    if (sess) { epan_free(sess); sess = NULL; }
    if (live_ready) {
        wtap_rec_cleanup(&live_rec);
        ws_buffer_free(&live_buf);
        live_ready = 0;
    }
    if (json_buf) { g_string_free(json_buf, TRUE); json_buf = NULL; }
    g_free(lws_scratch);
    lws_scratch = NULL;
    lws_scratch_cap = 0;
    free(prime_ids);
    prime_ids = NULL;
    n_prime_ids = 0;
    epan_cleanup();
    wtap_cleanup();
}

static int64_t frame_time_ms(const nstime_t *ts)
{
    if (!ts) return g_get_real_time() / 1000;
    return (int64_t)ts->secs * 1000LL + ts->nsecs / 1000000LL;
}

/* field helpers — reading Wireshark proto tree leaves
 *
 * Extractors never walk the tree by hand. They cache header-field (hf) ids
 * once in *_cache(), then per packet call:
 *
 *   ws_field_count(tree, hf)           how many occurrences
 *   ws_field_u16 / u32 / double / string(tree, hf, idx, …)
 *
 * Under the hood: proto_get_finfo_ptr_array after epan_dissect_prime_with_hfid.
 * That array is owned by the tree — do not free it. proto_find_finfo walked
 * the whole tree and allocated a GPtrArray per call (the old hot-path tax).
 *
 * CRITICAL — point hf ids at *leaf* fields, never FT_NONE parents.
 * ASTERIX is the classic trap: parents are containers; the numeric value
 * lives in a sibling/child like asterix.021_080_VALUE. Confirm with:
 *
 *   tshark -G fields | grep -i asterix.021_080
 *   tshark -r file.pcap -T fields -e asterix.021_130_LAT -e …
 *
 * hf_byname(name)         first registrar match
 * hf_byname_pref(name, T) prefer a specific ftenum when the same abbrev is
 *                         registered twice (DIS location is double+float)
 *
 * Type-check before fvalue_get_* — wrong FT_* → garbage or crash.
 */

static field_info *ws_fi(proto_tree *tree, int hf, guint idx)
{
    if (GLOBE_UNLIKELY(!tree || hf < 0)) return NULL;
    GPtrArray *fa = proto_get_finfo_ptr_array(tree, hf);
    if (!fa || idx >= fa->len) return NULL;
    field_info *fi = g_ptr_array_index(fa, idx);
    if (GLOBE_UNLIKELY(!fi || !fi->value || !fi->hfinfo)) return NULL;
    return fi;
}

static gboolean ws_ftype_uint(ftenum_t t)
{
    switch (t) {
    case FT_UINT8: case FT_UINT16: case FT_UINT24: case FT_UINT32:
    case FT_INT8:  case FT_INT16:  case FT_INT24:  case FT_INT32:
        return TRUE;
    default:
        return FALSE;
    }
}

static gboolean ws_field_u16(proto_tree *tree, int hf, guint idx, guint16 *v)
{
    field_info *fi = ws_fi(tree, hf, idx);
    if (!fi || !v || !ws_ftype_uint(fi->hfinfo->type)) return FALSE;
    *v = (guint16)fvalue_get_uinteger(fi->value);
    return TRUE;
}

static gboolean ws_field_u32(proto_tree *tree, int hf, guint idx, uint32_t *v)
{
    field_info *fi = ws_fi(tree, hf, idx);
    if (!fi || !v || !ws_ftype_uint(fi->hfinfo->type)) return FALSE;
    *v = fvalue_get_uinteger(fi->value);
    return TRUE;
}

static gboolean ws_field_double(proto_tree *tree, int hf, guint idx, double *v)
{
    field_info *fi = ws_fi(tree, hf, idx);
    if (!fi || !v) return FALSE;
    ftenum_t t = fi->hfinfo->type;
    if (t != FT_FLOAT && t != FT_DOUBLE) return FALSE;
    *v = fvalue_get_floating(fi->value);
    return TRUE;
}

static gboolean ws_field_string(proto_tree *tree, int hf, guint idx,
                                char *buf, size_t buflen)
{
    if (!buf || buflen == 0) return FALSE;
    field_info *fi = ws_fi(tree, hf, idx);
    if (!fi) return FALSE;
    ftenum_t t = fi->hfinfo->type;
    if (t != FT_STRING && t != FT_STRINGZ && t != FT_UINT_STRING) return FALSE;
    const char *s = fvalue_get_string(fi->value);
    if (!s) return FALSE;
    g_strlcpy(buf, s, buflen);
    return TRUE;
}

static guint ws_field_count(proto_tree *tree, int hf)
{
    if (GLOBE_UNLIKELY(!tree || hf < 0)) return 0;
    GPtrArray *fa = proto_get_finfo_ptr_array(tree, hf);
    return fa ? fa->len : 0;
}

static int hf_byname(const char *name)
{
    int id = proto_registrar_get_id_byname(name);
    prime_add(id);
    return id;
}

/* DIS registers some abbrevs twice (double + float). get_byname() returns
 * the last registration; same_name_next only walks newer names, so rewind
 * via same_name_prev_id to see both types. */
static header_field_info *hf_same_name_head(const char *name)
{
    header_field_info *hf = proto_registrar_get_byname(name);
    while (hf && hf->same_name_prev_id != -1) {
        header_field_info *prev = proto_registrar_get_nth((guint)hf->same_name_prev_id);
        if (!prev) break;
        hf = prev;
    }
    return hf;
}

static int hf_byname_pref(const char *name, ftenum_t prefer)
{
    int fallback = -1;
    for (header_field_info *hf = hf_same_name_head(name); hf; hf = hf->same_name_next) {
        if (fallback < 0) fallback = hf->id;
        if (hf->type == prefer) {
            prime_add(hf->id);
            return hf->id;
        }
    }
    if (fallback >= 0) {
        prime_add(fallback);
        return fallback;
    }
    return hf_byname(name);
}

/* extractor registry
 *
 * This is the only place that decides which protocols run. Everything else
 * (store, JSON, WebSocket) is protocol-agnostic.
 *
 * Mental model (same pattern as opengl-globe/src/capture/extract*.c and
 * promshark.c):
 *
 *   s_extractors[]          static table of globe_extractor_t rows
 *   -p PROTO                main() → extractors_enable(name) sets enabled
 *   extractors_cache_fields after epan_init: each enabled row's cache_fn
 *                           resolves hf ids into self->state (once)
 *   extractors_run          per dissected packet: if enabled AND
 *                           proto_is_frame_protocol(pi->layers, proto_name),
 *                           call extract_fn → entity_push(...)
 *   extractors_shutdown     g_free(self->state) for every row
 *
 * globe_extractor_t fields:
 *   proto_name   Wireshark filter name AND -p argument ("dis", "ais", …).
 *                Must match what appears in pi->layers / tshark -Y.
 *   cache_fn     Called once after dissectors are registered. Allocate a
 *                private state struct, resolve abbrevs with hf_byname*,
 *                store pointer in self->state. May exit(1) if a required
 *                protocol/field is missing.
 *   extract_fn   Called for matching packets. Read leaves with ws_field_*,
 *                fill entity_update_t, entity_push(). May emit 0..N poses
 *                (one PDU can carry several entities).
 *   state        Opaque; owned by the extractor; freed in shutdown.
 *   enabled      FALSE until -p; cache/extract skip disabled rows.
 *
 *
 * HOW TO ADD A NEW EXTRACTOR (checklist)
 *
 * 1. Pick a good protocol
 *    Needs a stable entity id + WGS-84 lat/lon (or convertible position) in
 *    Wireshark leaf fields. Prefer protocols already dissected by your
 *    Wireshark build (proto_get_id_by_filter_name("foo") >= 0).
 *
 * 2. Discover field abbrevs (do this before writing C)
 *      tshark -G protocols | grep -i foo
 *      tshark -G fields | grep -i '^foo\.'
 *      tshark -r sample.pcap -V -Y foo | less          # see tree shape
 *      tshark -r sample.pcap -T fields -e foo.id -e foo.lat -e foo.lon
 *    Prefer FT_DOUBLE / FT_UINT* leaves. Avoid FT_NONE parents (see ASTERIX).
 *    If one abbrev has two types, plan to use hf_byname_pref (see DIS XYZ).
 *
 * 3. Copy the stub extractor block below as a template
 *    Rename stub → your proto (functions, state type, HF_* enum, string
 *    literals). Keep decoder = the same string as proto_name.
 *
 * 4. Implement cache_fn
 *    - Check proto_get_id_by_filter_name(proto_name) >= 0
 *    - g_new0 your state struct; self->state = S
 *    - For each abbrev: S->hf[i] = hf_byname(...) or hf_byname_pref(...)
 *    - Required fields: exit(1) if missing. Optional: leave hf id < 0 and
 *      skip at extract time (DIS force/psi/marking pattern).
 *
 * 5. Implement extract_fn
 *    - Early-out if !self->state || !edt->tree
 *    - Count occurrences; take the min across id/lat/lon (or site/app/ent/xyz)
 *      so parallel arrays stay aligned when a PDU has N entities
 *    - For each index i: read required fields; on failure continue
 *    - memset entity_update_t; set decoder, entity_id, t_ms, lat, lon
 *    - Init optionals to NAN / -1 / ""; fill when hf >= 0
 *    - Convert units if needed (feet→m, knots→m/s, radians→degrees)
 *    - entity_push(&u)   // store rejects bad lat/lon/id
 *
 * 6. Register the row
 *    - Forward-declare cache/extract next to the other extract_* decls
 *    - Append one initializer to s_extractors[]
 *    - Add the name to usage()'s "-p PROTO" help line
 *
 * 7. Optional polish
 *    - format_entity_id(): pretty-print if users expect hex/MMSI/site:app:ent
 *    - display_for_update(): friendly display label if not using -d
 *
 * 8. Build & smoke-test
 *      ./build.sh
 *      ./globeshark -i lo -p yourproto -f 'udp port …' \
 *          -u ws://127.0.0.1:8080/ingest
 *    Watch stderr for "[yourproto] enabled", batch N entities, and the
 *    relay/globe for tracks. Use scripts/drivers/ as a pattern for a
 *    loopback generator if you lack real traffic.
 *
 * Do NOT: touch the WebSocket layer, invent a second store, or send
 * non-batch ops. Do NOT put FT_NONE parents in hf_byname lists.
 *
 * Reference implementations in this file:
 *   extract_dis*      ECEF → geodetic, packed site/app/entity id
 *   extract_asterix*  native lat/lon, multi-category helper
 *   extract_stub*     empty skeleton — start here
 */

struct globe_extractor;

typedef void (*globe_cache_fn)(struct globe_extractor *self);
typedef void (*globe_extract_fn)(struct globe_extractor *self,
                                 epan_dissect_t *edt,
                                 packet_info *pi,
                                 int64_t t_ms);

typedef struct globe_extractor {
    const char       *proto_name;
    globe_cache_fn    cache_fn;
    globe_extract_fn  extract_fn;
    void             *state;
    gboolean          enabled;
} globe_extractor_t;

static void extract_dis_cache(globe_extractor_t *self);
static void extract_dis(globe_extractor_t *self, epan_dissect_t *edt,
                        packet_info *pi, int64_t t_ms);
static void extract_asterix_cache(globe_extractor_t *self);
static void extract_asterix(globe_extractor_t *self, epan_dissect_t *edt,
                            packet_info *pi, int64_t t_ms);
static void extract_stub_cache(globe_extractor_t *self);
static void extract_stub(globe_extractor_t *self, epan_dissect_t *edt,
                         packet_info *pi, int64_t t_ms);

/* Registry table — one row per protocol. Enable with -p <proto_name>.
 * To add a protocol: implement cache/extract, then append a row here
 * (and update usage()). Full checklist is in the section banner above. */
static globe_extractor_t s_extractors[] = {
    { .proto_name = "dis",     .cache_fn = extract_dis_cache,
      .extract_fn = extract_dis },
    { .proto_name = "asterix", .cache_fn = extract_asterix_cache,
      .extract_fn = extract_asterix },
    { .proto_name = "stub",    .cache_fn = extract_stub_cache,
      .extract_fn = extract_stub },
};

static globe_extractor_t *enabled_run[8];
static size_t             n_enabled_run;

static void apply_epan_speed_prefs(void)
{
    set_pref_false("nameres.mac_name");
    set_pref_false("nameres.network_name");
    set_pref_false("nameres.transport_name");
    set_pref_false("nameres.dns_pkt_addr_resolution");
    set_pref_false("nameres.use_external_name_resolver");
    set_pref_false("ip.check_checksum");
    set_pref_false("udp.check_checksum");
    set_pref_false("tcp.check_checksum");
    set_pref_false("ip.defragment");
    set_pref_false("ipv6.defragment");
    set_pref_false("tcp.desegment_tcp_streams");
    set_pref_false("tcp.reassemble_out_of_order");
    prefs_apply_all();

    proto_disable_all();
    static const char *const walk[] = {
        "frame", "eth", "ethertype", "ip", "ipv6", "udp", "tcp", "sll", "vlan", "data"
    };
    for (size_t i = 0; i < G_N_ELEMENTS(walk); i++)
        enable_proto_name(walk[i]);
    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++)
        if (s_extractors[i].enabled)
            enable_proto_name(s_extractors[i].proto_name);
}

static globe_extractor_t *extractors_find(const char *name)
{
    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++)
        if (strcmp(s_extractors[i].proto_name, name) == 0)
            return &s_extractors[i];
    return NULL;
}

static gboolean extractors_enable(const char *name)
{
    globe_extractor_t *x = extractors_find(name);
    if (!x) return FALSE;
    x->enabled = TRUE;
    fprintf(stderr, "[%s] enabled\n", name);
    return TRUE;
}

static void extractors_cache_fields(void)
{
    n_enabled_run = 0;
    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++) {
        if (!s_extractors[i].enabled) continue;
        if (s_extractors[i].cache_fn)
            s_extractors[i].cache_fn(&s_extractors[i]);
        if (n_enabled_run < G_N_ELEMENTS(enabled_run))
            enabled_run[n_enabled_run++] = &s_extractors[i];
    }
}

static void extractors_run(epan_dissect_t *edt, packet_info *pi, int64_t t_ms)
{
    if (GLOBE_UNLIKELY(!edt || !edt->tree || !pi || !pi->layers)) return;
    for (size_t i = 0; i < n_enabled_run; i++) {
        globe_extractor_t *x = enabled_run[i];
        if (!proto_is_frame_protocol(pi->layers, x->proto_name)) continue;
        x->extract_fn(x, edt, pi, t_ms);
    }
}

static void extractors_shutdown(void)
{
    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++) {
        g_free(s_extractors[i].state);
        s_extractors[i].state = NULL;
    }
}

static gboolean extractors_any_enabled(void)
{
    for (size_t i = 0; i < G_N_ELEMENTS(s_extractors); i++)
        if (s_extractors[i].enabled) return TRUE;
    return FALSE;
}

/* DIS extractor — IEEE 1278 Entity State
 *
 * Why it exists: DIS is the simulation / training workhorse for this stack.
 * Entity State PDUs carry site/application/entity id + ECEF location.
 *
 * Required leaves → entity_id + lat/lon:
 *   dis.entity_id_site / _application / _entity   packed into int64
 *   dis.entity_location.{x,y,z}                   ECEF meters → geodetic
 * Optional:
 *   dis.force_id                    → force_id (Blue/Red display)
 *   dis.entityKind / dis.entityDomain → entity.kind / entity.domain
 *   dis.entity_orientation.psi      radians → heading_deg
 *   dis.entity_marking              → callsign
 *
 * Linear velocity in DIS is ECEF, not ENU — we omit it (would mislead the
 * globe's kinematics). Location abbrevs are registered as both double and
 * float; cache uses hf_byname_pref(..., FT_DOUBLE).
 *
 * Enable:  -p dis
 */

enum {
    HF_SITE, HF_APP, HF_ENT, HF_FORCE,
    HF_X, HF_Y, HF_Z,
    HF_PSI, HF_MARK,
    HF_KIND, HF_DOMAIN,
    HF_DIS_N
};

typedef struct {
    int hf[HF_DIS_N];
    int loc_alt[3]; /* other same-name id for x,y,z (float vs double) */
} dis_state_t;

static int hf_other_same_name(const char *name, int already)
{
    for (header_field_info *hf = hf_same_name_head(name); hf; hf = hf->same_name_next) {
        if (hf->id != already)
            return hf->id;
    }
    return -1;
}

static void extract_dis_cache(globe_extractor_t *self)
{
    static const char *names[HF_DIS_N] = {
        "dis.entity_id_site", "dis.entity_id_application", "dis.entity_id_entity",
        "dis.force_id",
        "dis.entity_location.x", "dis.entity_location.y", "dis.entity_location.z",
        "dis.entity_orientation.psi",
        "dis.entity_marking",
        "dis.entityKind", "dis.entityDomain",
    };
    if (proto_get_id_by_filter_name("dis") < 0) {
        fprintf(stderr, "dis protocol not available\n");
        exit(1);
    }
    dis_state_t *S = g_new0(dis_state_t, 1);
    self->state = S;
    for (int i = 0; i < HF_DIS_N; i++) {
        if (i >= HF_X && i <= HF_Z)
            S->hf[i] = hf_byname_pref(names[i], FT_DOUBLE);
        else
            S->hf[i] = hf_byname(names[i]);
        if (S->hf[i] < 0 && i <= HF_Z) {
            fprintf(stderr, "dis field missing: %s\n", names[i]);
            exit(1);
        }
        if (i >= HF_X && i <= HF_Z) {
            S->loc_alt[i - HF_X] = hf_other_same_name(names[i], S->hf[i]);
            prime_add(S->loc_alt[i - HF_X]);
        }
    }
}

static void extract_dis(globe_extractor_t *self, epan_dissect_t *edt,
                        packet_info *pi, int64_t t_ms)
{
    (void)pi;
    dis_state_t *S = self->state;
    if (!S || !edt || !edt->tree) return;
    proto_tree *tree = edt->tree;

    guint n = ws_field_count(tree, S->hf[HF_SITE]);
    guint napp = ws_field_count(tree, S->hf[HF_APP]);
    guint nent = ws_field_count(tree, S->hf[HF_ENT]);
    guint nx = ws_field_count(tree, S->hf[HF_X]);
    guint ny = ws_field_count(tree, S->hf[HF_Y]);
    guint nz = ws_field_count(tree, S->hf[HF_Z]);
    int hf_x = S->hf[HF_X], hf_y = S->hf[HF_Y], hf_z = S->hf[HF_Z];
    if (nx == 0 && S->loc_alt[0] >= 0) {
        nx = ws_field_count(tree, S->loc_alt[0]);
        hf_x = S->loc_alt[0];
    }
    if (ny == 0 && S->loc_alt[1] >= 0) {
        ny = ws_field_count(tree, S->loc_alt[1]);
        hf_y = S->loc_alt[1];
    }
    if (nz == 0 && S->loc_alt[2] >= 0) {
        nz = ws_field_count(tree, S->loc_alt[2]);
        hf_z = S->loc_alt[2];
    }
    if (napp < n) n = napp;
    if (nent < n) n = nent;
    if (nx < n) n = nx;
    if (ny < n) n = ny;
    if (nz < n) n = nz;

    for (guint i = 0; i < n; i++) {
        guint16 site, app, ent;
        double x, y, z;
        if (!ws_field_u16(tree, S->hf[HF_SITE], i, &site) ||
            !ws_field_u16(tree, S->hf[HF_APP], i, &app) ||
            !ws_field_u16(tree, S->hf[HF_ENT], i, &ent) ||
            !ws_field_double(tree, hf_x, i, &x) ||
            !ws_field_double(tree, hf_y, i, &y) ||
            !ws_field_double(tree, hf_z, i, &z))
            continue;

        int64_t eid = (int64_t)(((uint64_t)site << 32) | ((uint64_t)app << 16) | ent);
        if (eid == 0 || !isfinite(x) || !isfinite(y) || !isfinite(z))
            continue;

        entity_update_t u;
        memset(&u, 0, sizeof u);
        u.decoder = "dis";
        u.entity_id = eid;
        u.t_ms = t_ms;
        u.force_id = -1;
        u.kind = -1;
        u.domain = -1;
        u.alt_m = NAN;
        u.vel_n = u.vel_e = u.vel_u = NAN;
        u.heading_deg = NAN;
        {
            double alt;
            ecef_to_geodetic(x, y, z, &u.lat_deg, &u.lon_deg, &alt);
            if (isfinite(alt)) u.alt_m = (float)alt;
        }

        if (S->hf[HF_FORCE] >= 0) {
            uint32_t f;
            if (ws_field_u32(tree, S->hf[HF_FORCE], i, &f))
                u.force_id = (int)f;
        }
        if (S->hf[HF_PSI] >= 0) {
            double psi;
            if (ws_field_double(tree, S->hf[HF_PSI], i, &psi) && isfinite(psi))
                u.heading_deg = (float)(psi * (180.0 / M_PI));
        }
        if (S->hf[HF_MARK] >= 0)
            ws_field_string(tree, S->hf[HF_MARK], i, u.callsign, sizeof u.callsign);
        if (S->hf[HF_KIND] >= 0) {
            uint32_t k;
            if (ws_field_u32(tree, S->hf[HF_KIND], i, &k))
                u.kind = (int)k;
        }
        if (S->hf[HF_DOMAIN] >= 0) {
            uint32_t d;
            if (ws_field_u32(tree, S->hf[HF_DOMAIN], i, &d))
                u.domain = (int)d;
        }

        entity_push(&u);
    }
}

/* ASTERIX extractor — Eurocontrol surveillance (air tracks)
 *
 * CAT 021 (ADS-B) and CAT 062 (system tracks). Already geodetic — no ECEF.
 * Wireshark 4.2.6 leaf abbrevs use *_VALUE where the parent is FT_NONE;
 * if you bump Wireshark, re-check -G fields before assuming names.
 *
 * Shared helper asterix_emit_cat() walks parallel ICAO/lat/lon arrays and
 * optionally fills alt, velocity (VX/VY or GS+track angle), heading, callsign.
 * Altitude in these IEs is feet → convert with FT_PER_M. Ground speed in
 * CAT 021 is NM/s-ish in the dissector output we use — we scale ×1852 to m/s.
 *
 * entity_id = 24-bit ICAO address; format_entity_id prints 6 hex digits.
 * display_for_update maps decoder "asterix" → "ADS-B" unless -d is set.
 *
 * Enable:  -p asterix
 *
 * Adding another category (048, 010, …): resolve new hf abbrevs in cache,
 * then one more asterix_emit_cat(...) call — usually no new -p name needed.
 */

#define FT_PER_M 3.280839895013123

enum {
    HF_A21_ICAO, HF_A21_LAT, HF_A21_LON, HF_A21_ALT, HF_A21_GS, HF_A21_TRK, HF_A21_CALL,
    HF_A62_ICAO, HF_A62_LAT, HF_A62_LON, HF_A62_VX, HF_A62_VY, HF_A62_ALT, HF_A62_HDG, HF_A62_CALL,
    HF_AST_N
};

typedef struct { int hf[HF_AST_N]; } asterix_state_t;

static void extract_asterix_cache(globe_extractor_t *self)
{
    static const char *names[HF_AST_N] = {
        "asterix.021_080_VALUE", "asterix.021_130_LAT", "asterix.021_130_LON",
        "asterix.021_140_VALUE", "asterix.021_160_GS", "asterix.021_160_TA",
        "asterix.021_170_VALUE",
        "asterix.062_380_ADR_VALUE", "asterix.062_105_LAT", "asterix.062_105_LON",
        "asterix.062_185_VX", "asterix.062_185_VY", "asterix.062_380_GAL_VALUE",
        "asterix.062_380_MHG_VALUE", "asterix.062_245_CHR",
    };

    if (proto_get_id_by_filter_name("asterix") < 0) {
        fprintf(stderr, "asterix protocol not available\n");
        exit(1);
    }
    asterix_state_t *S = g_new0(asterix_state_t, 1);
    self->state = S;
    for (int i = 0; i < HF_AST_N; i++)
        S->hf[i] = hf_byname(names[i]);
    if (S->hf[HF_A21_ICAO] < 0 && S->hf[HF_A62_ICAO] < 0)
        fprintf(stderr, "warning: asterix lat/icao fields not resolved\n");
}

static void asterix_emit_cat(proto_tree *tree, int hf_icao, int hf_lat, int hf_lon,
                             int hf_alt, int hf_vx, int hf_vy,
                             int hf_gs, int hf_trk, int hf_hdg, int hf_call,
                             int64_t t_ms)
{
    if (hf_icao < 0 || hf_lat < 0 || hf_lon < 0) return;
    guint n = ws_field_count(tree, hf_icao);
    guint nlat = ws_field_count(tree, hf_lat);
    guint nlon = ws_field_count(tree, hf_lon);
    if (nlat < n) n = nlat;
    if (nlon < n) n = nlon;

    for (guint i = 0; i < n; i++) {
        uint32_t icao;
        double lat, lon;
        if (!ws_field_u32(tree, hf_icao, i, &icao) || icao == 0) continue;
        if (!ws_field_double(tree, hf_lat, i, &lat) ||
            !ws_field_double(tree, hf_lon, i, &lon))
            continue;
        if (!isfinite(lat) || !isfinite(lon)) continue;

        entity_update_t u;
        memset(&u, 0, sizeof u);
        u.decoder = "asterix";
        u.entity_id = (int64_t)icao;
        u.t_ms = t_ms;
        u.lat_deg = lat;
        u.lon_deg = lon;
        u.force_id = -1;
        u.kind = 1;    /* Platform — web-globe kindLabel */
        u.domain = 2;  /* Air — shapeFromDomain → triangle */
        u.alt_m = NAN;
        u.vel_n = u.vel_e = u.vel_u = NAN;
        u.heading_deg = NAN;

        if (hf_alt >= 0) {
            double ft;
            if (ws_field_double(tree, hf_alt, i, &ft) && isfinite(ft))
                u.alt_m = (float)(ft / FT_PER_M);
        }
        if (hf_vx >= 0 && hf_vy >= 0) {
            double vx, vy;
            if (ws_field_double(tree, hf_vx, i, &vx) &&
                ws_field_double(tree, hf_vy, i, &vy)) {
                u.vel_e = (float)vx;
                u.vel_n = (float)vy;
                u.vel_u = 0;
                u.heading_deg = (float)(atan2(vx, vy) * (180.0 / M_PI));
                if (u.heading_deg < 0) u.heading_deg += 360.0f;
            }
        } else if (hf_gs >= 0 && hf_trk >= 0) {
            double gs, trk;
            if (ws_field_double(tree, hf_gs, i, &gs) &&
                ws_field_double(tree, hf_trk, i, &trk) && isfinite(trk)) {
                gs *= 1852.0;
                double r = trk * (M_PI / 180.0);
                u.heading_deg = (float)trk;
                u.vel_e = (float)(gs * sin(r));
                u.vel_n = (float)(gs * cos(r));
                u.vel_u = 0;
            }
        }
        if (hf_hdg >= 0) {
            double h;
            if (ws_field_double(tree, hf_hdg, i, &h) && isfinite(h))
                u.heading_deg = (float)h;
        }
        if (hf_call >= 0)
            ws_field_string(tree, hf_call, i, u.callsign, sizeof u.callsign);

        entity_push(&u);
    }
}

static void extract_asterix(globe_extractor_t *self, epan_dissect_t *edt,
                            packet_info *pi, int64_t t_ms)
{
    (void)pi;
    asterix_state_t *S = self->state;
    if (!S || !edt || !edt->tree) return;
    proto_tree *tree = edt->tree;

    asterix_emit_cat(tree,
        S->hf[HF_A21_ICAO], S->hf[HF_A21_LAT], S->hf[HF_A21_LON],
        S->hf[HF_A21_ALT], -1, -1,
        S->hf[HF_A21_GS], S->hf[HF_A21_TRK], -1, S->hf[HF_A21_CALL], t_ms);

    asterix_emit_cat(tree,
        S->hf[HF_A62_ICAO], S->hf[HF_A62_LAT], S->hf[HF_A62_LON],
        S->hf[HF_A62_ALT], S->hf[HF_A62_VX], S->hf[HF_A62_VY],
        -1, -1, S->hf[HF_A62_HDG], S->hf[HF_A62_CALL], t_ms);
}

/* stub extractor — copy/paste template for a new protocol
 *
 * Intentionally empty so a new developer can:
 *   1. Duplicate this whole block (cache + extract + state types)
 *   2. Rename stub → ais / mavlink / …
 *   3. Fill field abbrevs and entity_push logic (see registry HOW TO)
 *   4. Add a s_extractors[] row + usage() help text
 *
 * Enable today with -p stub to prove the registry path (you will only see
 * "[stub] enabled" / "extractor stubbed" — no entities until filled in).
 *
 * Steps inside the functions once you have real abbrevs:
 *   extract_*_cache:  hf_byname / hf_byname_pref into self->state
 *   extract_*:        ws_field_* → entity_update_t → entity_push
 *                     (proto_is_frame_protocol already matched proto_name)
 */

static void extract_stub_cache(globe_extractor_t *self)
{
    /* No Wireshark fields yet — state stays NULL. */
    self->state = NULL;
    fprintf(stderr, "[stub] extractor stubbed (no fields yet)\n");
}

static void extract_stub(globe_extractor_t *self, epan_dissect_t *edt,
                         packet_info *pi, int64_t t_ms)
{
    (void)self; (void)edt; (void)pi; (void)t_ms;
    /* TODO: proto_is_frame_protocol already matched "stub"; emit entities. */
}

/* event loop — single thread owns pcap + flush + lws
 *
 * run_live():
 *   pcap_open_live(..., 250ms timeout) so dispatch returns even when idle
 *   each iteration:
 *     pcap_dispatch → on_pkt → process_packet → extractors_run → entity_push
 *     lws_service     drive WebSocket (connect / writable / close)
 *     reconnect       if ws_wsi is NULL, retry ~1 Hz
 *     flush_once      when flush_hz interval elapsed (entity_take → batch)
 *
 * process_packet builds a wtap_rec + tvbuff, primes mapped hfids, runs
 * epan_dissect_run on a hidden proto tree, then extractors_run.
 * No flush thread, no mutexes — keep it that way.
 */

static void on_sig(int s)
{
    (void)s;
    stop_loop = 1;
    if (pc) pcap_breakloop(pc);
}

#ifdef _WIN32
static int wsa_started;

static BOOL WINAPI on_console(DWORD ev)
{
    if (ev == CTRL_C_EVENT || ev == CTRL_BREAK_EVENT || ev == CTRL_CLOSE_EVENT) {
        on_sig(SIGINT);
        return TRUE;
    }
    return FALSE;
}

static void win_wsa_cleanup(void)
{
    if (wsa_started) {
        WSACleanup();
        wsa_started = 0;
    }
}
#endif

static int dlt_to_wtap_encap(int dlt)
{
    switch (dlt) {
    case DLT_EN10MB: return WTAP_ENCAP_ETHERNET;
#ifdef DLT_RAW
    case DLT_RAW:    return WTAP_ENCAP_RAW_IP;
#endif
#ifdef DLT_NULL
    case DLT_NULL:   return WTAP_ENCAP_NULL;
#endif
#ifdef DLT_LINUX_SLL
    case DLT_LINUX_SLL: return WTAP_ENCAP_SLL;
#endif
#ifdef DLT_IEEE802_11
    case DLT_IEEE802_11: return WTAP_ENCAP_IEEE_802_11;
#endif
    default:         return WTAP_ENCAP_ETHERNET;
    }
}

static void process_packet(wtap_rec *r, Buffer *buf)
{
    if (GLOBE_UNLIKELY(!r || !buf || !edt)) return;
    guint32 caplen = r->rec_header.packet_header.caplen;
    guint32 pktlen = r->rec_header.packet_header.len;
    if (GLOBE_UNLIKELY(caplen == 0 || ws_buffer_length(buf) < caplen)) return;

    frame_data fd;
    frame_data_init(&fd, ++frame_no, r, 0, 0);
    ts_ring[(frame_no - 1) % TS_HIST_CAP] = fd.abs_ts;

    /* Hidden tree: proto_tree_reset() cleared last packet's ref_types.
     * Re-prime or DIS Entity State fields get faked and extractors see 0. */
    prime_all_hfids();
    epan_dissect_run(edt, WTAP_FILE_TYPE_SUBTYPE_UNKNOWN, r,
        tvb_new_real_data(ws_buffer_start_ptr(buf), caplen, pktlen),
        &fd, NULL);

    extractors_run(edt, &edt->pi, frame_time_ms(&fd.abs_ts));

    epan_dissect_reset(edt);
    frame_data_destroy(&fd);
}

static void on_pkt(u_char *user, const struct pcap_pkthdr *h, const u_char *bytes)
{
    if (GLOBE_UNLIKELY(!user || !h || !bytes)) return;
    if (GLOBE_UNLIKELY(h->caplen == 0 || h->caplen > 65535)) return;

    int encap = *(int *)user;
    if (!live_ready) {
        ws_buffer_init(&live_buf, 65535);
        wtap_rec_init(&live_rec);
        live_ready = 1;
    }
    ws_buffer_clean(&live_buf);
    ws_buffer_append(&live_buf, (guint8 *)bytes, h->caplen);
    wtap_rec_reset(&live_rec);

    live_rec.rec_type = REC_TYPE_PACKET;
    live_rec.presence_flags = WTAP_HAS_TS | WTAP_HAS_CAP_LEN;
    live_rec.ts.secs = h->ts.tv_sec;
    live_rec.ts.nsecs = (int)(h->ts.tv_usec * 1000);
    if (live_rec.ts.nsecs < 0) live_rec.ts.nsecs = 0;
    if (live_rec.ts.nsecs >= 1000000000) live_rec.ts.nsecs = 999999999;
    live_rec.rec_header.packet_header.caplen = h->caplen;
    live_rec.rec_header.packet_header.len = h->len >= h->caplen ? h->len : h->caplen;
    live_rec.rec_header.packet_header.pkt_encap = encap;

    process_packet(&live_rec, &live_buf);
}

static void print_pcap_devices(void)
{
    pcap_if_t *all = NULL;
    char err[PCAP_ERRBUF_SIZE];
    if (pcap_findalldevs(&all, err) != 0) {
        fprintf(stderr, "pcap_findalldevs: %s\n", err);
        return;
    }
    fprintf(stderr, "available capture devices:\n");
    for (pcap_if_t *d = all; d; d = d->next) {
        fprintf(stderr, "  %s", d->name ? d->name : "(unnamed)");
        if (d->description && d->description[0])
            fprintf(stderr, "  (%s)", d->description);
        fputc('\n', stderr);
    }
    pcap_freealldevs(all);
}

static int run_live(const char *iface, const char *bpf)
{
    char err[PCAP_ERRBUF_SIZE];
    /* pcap_open_live() on Linux uses TPACKET_V3; the timeout is ignored until
     * a block fills, so a 5 Hz DIS stream can sit invisible for minutes.
     * immediate mode delivers each packet (what tcpdump does). Npcap on
     * Windows honors the same pcap_create / set_immediate_mode / activate
     * sequence; iface is an Npcap name such as \Device\NPF_{GUID}. */
    pc = pcap_create(iface, err);
    if (!pc) {
        fprintf(stderr, "pcap_create(%s): %s\n", iface, err);
        print_pcap_devices();
        return 1;
    }
    (void)pcap_set_snaplen(pc, 65535);
    (void)pcap_set_promisc(pc, 1);
    (void)pcap_set_timeout(pc, 250);
    (void)pcap_set_buffer_size(pc, 8 * 1024 * 1024);
    if (pcap_set_immediate_mode(pc, 1) != 0)
        fprintf(stderr, "pcap_set_immediate_mode: %s\n", pcap_geterr(pc));
    int rc_act = pcap_activate(pc);
    if (rc_act < 0) {
        fprintf(stderr, "pcap_activate(%s): %s\n", iface, pcap_geterr(pc));
        pcap_close(pc);
        pc = NULL;
        print_pcap_devices();
        return 1;
    }
    if (bpf && bpf[0]) {
        struct bpf_program fp;
        if (pcap_compile(pc, &fp, bpf, 1, PCAP_NETMASK_UNKNOWN) != 0 ||
            pcap_setfilter(pc, &fp) != 0) {
            fprintf(stderr, "bpf: %s\n", pcap_geterr(pc));
            pcap_close(pc);
            pc = NULL;
            return 1;
        }
        pcap_freecode(&fp);
    }

    int dlt = pcap_datalink(pc);
    int encap = dlt_to_wtap_encap(dlt);
    int interval_ms = (int)(1000.0 / (g_flush_hz > 0.1 ? g_flush_hz : 10.0));
    int64_t last_flush_ms = 0;
    int since_retry = 0;
    unsigned long pkt_n = 0;

    fprintf(stderr, "[globeshark] capturing %s dlt=%d encap=%d → %s\n",
            iface, dlt, encap, g_ingest_url);

    while (!stop_loop) {
        int n = pcap_dispatch(pc, 256, on_pkt, (u_char *)&encap);
        if (n < 0)
            break;
        if (n > 0) {
            pkt_n += (unsigned)n;
            if (pkt_n <= 8 || (pkt_n % 5000) == 0)
                fprintf(stderr, "[globeshark] captured %lu packets\n", pkt_n);
        }

        if (ws_ctx)
            lws_service(ws_ctx, n > 0 ? 0 : 20);

        if (!ws_wsi) {
            since_retry += 250; /* roughly one pcap timeout */
            if (since_retry >= 1000) {
                since_retry = 0;
                ws_connect();
            }
            continue;
        }
        since_retry = 0;

        int64_t now_ms = g_get_monotonic_time() / 1000;
        if (now_ms - last_flush_ms >= interval_ms) {
            last_flush_ms = now_ms;
            flush_once();
        }
    }

    pcap_close(pc);
    pc = NULL;
    return 0;
}

/* main
 *
 * Startup order matters:
 *   1. parse argv (-p enables extractors; need ≥1 and -i)
 *   2. shark_init / apply_epan_speed_prefs / epan_new / hidden tree
 *      epan_dissect_new(TRUE, FALSE) + fake_protocols(FALSE)
 *   3. extractors_cache_fields()   // needs dissectors registered; primes hfids
 *   4. entity_store_init()
 *   5. ws_init()                   // connect; hello on ESTABLISHED
 *   6. run_live() until SIGINT/SIGTERM (Windows: Ctrl-C / console close)
 *
 * Shutdown order (shutdown_all): WS → store → extractors → epan.
 *
 * Typical local demo (relay already listening on :8080):
 *   ./globeshark -i lo -p dis -f 'udp port 3000' \
 *       -u ws://127.0.0.1:8080/ingest
 *   python3 scripts/drivers/dis_driver.py --objects 50 --rate 5
 */

static int shutdown_all(int rc)
{
    stop_loop = 1;
    ws_shutdown();
    entity_store_shutdown();
    extractors_shutdown();
    shark_shutdown();
    return rc;
}

static void usage(const char *argv0)
{
    fprintf(stderr,
        "usage: %s -i IFACE -p PROTO [-p PROTO ...] [options]\n"
        "\n"
        "  Live capture adapter: dissect traffic, extract entities, send ingest\n"
        "  JSON to the web-globe relay. The relay owns upsert / DVR / display.\n"
        "\n"
        "  -i IFACE   live capture interface (required)\n"
        "             Linux: eth0, lo, …\n"
        "             Windows/Npcap: \"\\Device\\NPF_{GUID}\". On open failure\n"
        "             the adapter list is printed.\n"
        "  -p PROTO   dis | asterix | stub (repeatable)\n"
        "  -f BPF     libpcap filter\n"
        "  -u URL     ingest WebSocket (default %s)\n"
        "  -d NAME    ingest display label (default: Blue/Red force from DIS)\n"
        "  -n NODE    hello.node (default hostname / $NODE_NAME)\n"
        "  -o POD     hello.pod  (default hostname / $POD_NAME)\n"
        "  -I IFACE   hello.captured_iface (default: -i value)\n"
        "  -H HZ      batch send rate (default 10)\n",
        argv0, g_ingest_url);
}

int main(int argc, char **argv)
{
    const char *iface = NULL, *bpf = NULL;

    g_node = getenv("NODE_NAME");
    if (!g_node) g_node = getenv("NODE");
    g_pod = getenv("POD_NAME");
    if (!g_pod) g_pod = getenv("POD");

    /*
     * Portable argv walk (MSVC has no POSIX getopt). Same flags as before.
     * Combined short options (-ifoo) are not accepted; use -i foo.
     */
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
            usage(argv[0]);
            return 0;
        }
        if (argv[i][0] == '-' && argv[i][1] && !argv[i][2] && i + 1 < argc) {
            char o = argv[i][1];
            const char *a = argv[++i];
            if (o == 'i') iface = a;
            else if (o == 'p') {
                if (!extractors_enable(a)) {
                    fprintf(stderr, "unsupported protocol: %s\n", a);
                    return 2;
                }
            }
            else if (o == 'f') bpf = a;
            else if (o == 'u') g_ingest_url = a;
            else if (o == 'd') g_display = a;
            else if (o == 'n') g_node = a;
            else if (o == 'o') g_pod = a;
            else if (o == 'I') g_captured_iface = a;
            else if (o == 'H') g_flush_hz = atof(a);
            else {
                usage(argv[0]);
                return 2;
            }
            continue;
        }
        usage(argv[0]);
        return 2;
    }

    if (!iface || !extractors_any_enabled()) {
        usage(argv[0]);
        return 2;
    }

#ifdef _WIN32
    {
        WSADATA wsa;
        if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
            fprintf(stderr, "WSAStartup failed\n");
            return 1;
        }
        wsa_started = 1;
        atexit(win_wsa_cleanup);
    }
    SetConsoleCtrlHandler(on_console, TRUE);
#else
    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);
#endif

    char hostbuf[256];
    if (!g_node || !g_node[0]) {
        if (gethostname(hostbuf, sizeof hostbuf) != 0)
            g_strlcpy(hostbuf, "globeshark", sizeof hostbuf);
        hostbuf[sizeof hostbuf - 1] = '\0';
        g_node = g_strdup(hostbuf);
    }
    if (!g_pod || !g_pod[0]) g_pod = g_node;
    if (iface) g_captured_iface = iface;

    if (shark_init(argv[0]) != 0) return 1;
    apply_epan_speed_prefs();
    sess = epan_new(NULL, &prov_funcs);
    /* Hidden tree: vis=FALSE. fake_protocols=FALSE so FT_PROTOCOL nodes for
     * DIS/ASTERIX still exist as parents of primed leaves. */
    edt = epan_dissect_new(sess, TRUE, FALSE);
    if (!sess || !edt) {
        fprintf(stderr, "epan session init failed\n");
        return shutdown_all(1);
    }
    epan_dissect_fake_protocols(edt, FALSE);
    extractors_cache_fields();
    prime_all_hfids();
    entity_store_init();

    lws_set_log_level(LLL_ERR | LLL_WARN, NULL);
    if (ws_init() != 0) return shutdown_all(1);

    int rc = run_live(iface, bpf);
    return shutdown_all(rc);
}
