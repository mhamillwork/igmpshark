# logshark

**dbshark** captures or reads a pcap and `COPY`s dissected fields into
Postgres. It links **libwireshark** (epan) directly.

Design: [tests/dbshark/reports/DBSHARK_DESIGN.rst](tests/dbshark/reports/DBSHARK_DESIGN.rst).
Performance: [tests/dbshark/reports/PERFORMANCE.rst](tests/dbshark/reports/PERFORMANCE.rst).
Multi-node races: [tests/dbshark/reports/CURRENT_BUGS.rst](tests/dbshark/reports/CURRENT_BUGS.rst).
Test suite: [tests/dbshark/README.md](tests/dbshark/README.md).

Layout:

| Path | Contents |
|---|---|
| `src/` | dbshark (`dbshark.c`, `reassembly_hold.c`) and other source-only programs |
| `tests/dbshark/build/` | build scripts, dependency installers, `CMakeLists.txt`, RHEL 8/9 Dockerfile |
| `tests/dbshark/reports/` | design, performance and bug reports |
| `tests/dbshark/` | reassembly unit test, durability catalog (`break/`), two-node race (`compose/`), `run-rhel.sh` |
| `tools/` | offline converters (`pcap2sqlite`, `pcap2hdf5`) and `reset_pg.pl` |
| `ws-config/` | Wireshark `decode_as_entries` for non-standard ports |

Other programs under `src/` (`globeshark`, `promshark`, `dbshark-lite`,
`pcapreplay`) and `tools/` are source only; `build.sh` does not build them.

## Build

```bash
sudo ./tests/dbshark/build/deps-debian.sh      # or: sudo ./tests/dbshark/build/deps-rhel.sh
./tests/dbshark/build/build-wireshark-4.2.6.sh # libs → ~/wireshark-4.2.6
./tests/dbshark/build/build.sh                 # → build/run/dbshark
```

Needs: glib2, libpcap, libpq, pkg-config, and the Wireshark 4.2.6 build
deps (flex, c-ares, libgcrypt, pcre2). Set `WS=` if the Wireshark tree is
elsewhere. CMake alternative:

```bash
cmake -S tests/dbshark/build -B build -DCMAKE_BUILD_TYPE=Release \
  -DWIRESHARK_ROOT=$HOME/wireshark-4.2.6 -DWIRESHARK_LIBRARY_DIR=$HOME/wireshark-4.2.6/build/run
cmake --build build
```

```bash
sudo setcap cap_net_raw,cap_net_admin=eip ./build/run/dbshark
```

## Run

```bash
./build/run/dbshark -r capture.pcap -o CONNINFO -p dis
./build/run/dbshark -i eth0 -p dis -f 'udp port 3000' -o CONNINFO
# Bound Wireshark session memory. Split TCP/IP messages are replayed
# across the rotation and inserted once. Defaults: 64 MiB hold, 30 s idle.
./build/run/dbshark -r capture.pcap -o CONNINFO -p http -M 100000
```

## Decode As / non-standard ports

Dissectors bind to a default port (DIS = UDP 3000, …). Traffic on another
port is not tagged as that protocol unless you override the port list.

Edit [`ws-config/decode_as_entries`](ws-config/decode_as_entries) and:

```bash
export WIRESHARK_CONFIG_DIR=$PWD/ws-config
./build/run/dbshark -r capture.pcap -o CONNINFO -p dis
```

Live capture still needs a BPF that includes those ports. `-p` is the
Wireshark filter name (`dis`); the fourth field in the file is the short
name (`DIS`).

| Platform | Default config dir |
|---|---|
| Linux | `~/.config/wireshark/` |
| Windows | `%APPDATA%\Wireshark\` |

`WIRESHARK_CONFIG_DIR` overrides that.

## Test

```bash
python3 tests/dbshark/test_reassembly_rotate.py   # -M rotation vs no-reset baseline
./tests/dbshark/break/run.sh                      # durability catalog
./tests/dbshark/compose/run.sh                    # two-node race
./tests/dbshark/run-rhel.sh                       # all of the above inside RHEL 8 and RHEL 9 containers
```
